"""Compiled ARM64 fixed Request/IRQ/Accept/PS_RDY/ADC, then PPS on same session.

No fabricated ConfirmFixed baseline is used. Bus/IRQ/ADC/CC and kernel device
ownership are emulated, so this is NOT a physical charging acceptance test.
"""
from pathlib import Path
import hashlib,json,struct
ROOT=Path(__file__).resolve().parent
source=(ROOT/'TestPpsTransport.py').read_text().split('\nfor base in (')[0]
source=source.replace("build-frs-transport/sk_pd_frs_transport.component.dll",
    "build-frs-transport/sk_pd_frs_transport.component.dll")
# Delay callback has a different ABI from SPMI, asserted independently below.
source=source.replace('super().__init__(base,name)',
    'super().__init__(base,name,data=self.fixed_data)')
source=source.replace('        self.baseline(rev=revision)',
    "        assert self.caps(rev=revision,pdos=(scope['FIXED5'],(180<<10)|200,scope['FIXED12'],scope['APDO']))[0]==5")
scope={'__file__':str(ROOT/'TestPpsTransport.py')}
exec(compile(source,str(ROOT/'TestPpsTransport.py'),'exec'),scope)
Transport=scope['Transport'];packet=scope['packet'];ROWS=[]

class FixedTransport(Transport):
    def __init__(self,base,name,revision=2,now=0,data=0):
        self.fixed_data=data
        super().__init__(base,name,revision)
        self.f=0x20006000;self.fo=0x20006200;self.fl=0x20006400;self.ft=0x20006600
        self.fs=self.call('SkPdFixedSize')
        self.u.mem_write(self.f-8,b'FXSTART!');self.u.mem_write(self.f+self.fs,b'FXEND!!!')
        self.u.mem_write(self.ft,struct.pack('<4I',15,26,450,100))
        if now:
            # Attach clock was already initialized by Transport at zero.
            self.u.mem_write(self.s+136,struct.pack('<I',now)) # PPS Guard.LastNow
        assert self.call('SkPdFixedInitialize',self.f,self.s,now,self.ft)==0
        self.setfixedlimits()
    def call(self,name,*args):
        r=super().call(name,*args)
        if hasattr(self,'fs'):
            assert bytes(self.u.mem_read(self.f-8,8))==b'FXSTART!'
            assert bytes(self.u.mem_read(self.f+self.fs,8))==b'FXEND!!!'
        return r
    def setfixedlimits(self,prereq=3,mv=9000,ma=3000,cable=3000,mw=18000,tol=300):
        self.u.mem_write(self.fl,struct.pack('<6I',prereq,mv,ma,cable,mw,tol))
    def foutput(self):
        flags=struct.unpack('<4I',bytes(self.u.mem_read(self.fo,16)))
        gen,token,n=struct.unpack('<3I',bytes(self.u.mem_read(self.fo+16,12)))
        c=struct.unpack('<5I',bytes(self.u.mem_read(self.fo+60,20)))
        assert n<=32
        return flags,(gen,token,bytes(self.u.mem_read(self.fo+28,n))),c
    def fstate(self):return struct.unpack('<I',bytes(self.u.mem_read(self.f+36,4)))[0]
    def begin(self,now=1,pos=4,mv=9000,ma=3000,grant=1):
        return super().begin(now,pos,mv,ma,grant)
    def fbegin(self,now=1,pos=2,ma=2000,flags=0x03000000,grant=1,generation=77):
        return self.call('SkPdFixedBegin',self.f,generation,now,pos,ma,flags,grant,self.fl,self.fo)
    def fsend(self):return self.call('SkPmicTxSubmit',self.tx_ctx,self.fo+16)
    def fack(self,now=2,token=None,result=1,generation=77):
        if token is None:token=struct.unpack('<I',bytes(self.u.mem_read(self.f+44,4)))[0]
        if generation==77 and token and result in (1,2,3):
            self.registers[0x1744]=b'\0'
            p=self.call('SkPmicTxComplete',self.tx_ctx,generation,token,result)
            assert p==0 if result==1 else p&0xffffffff==0xc0000185
        return self.call('SkPdFixedTxComplete',self.f,generation,now,token,result,self.fo)
    def fphy(self,p,now):
        self.registers.update({0x174b:b'\x01',0x174a:b'\0',0x1748:bytes([len(p)-3]),
            0x1780:p[2:4],0x1782:p[4:]})
        self.u.mem_write(self.rx_length,struct.pack('<I',32))
        r=self.call('SkPmicRxRead',self.rx_ctx,self.rx_frame,self.rx_length,self.rx_token)
        token=struct.unpack('<I',bytes(self.u.mem_read(self.rx_token,4)))[0]
        if token:
            ack=self.call('SkPmicRxRelease',self.rx_ctx,token)
            if ack:return ack
        if r:return r
        n=struct.unpack('<I',bytes(self.u.mem_read(self.rx_length,4)))[0]
        assert bytes(self.u.mem_read(self.rx_frame,n))==p
        return self.call('SkPdFixedReceive',self.f,77,now,self.rx_frame,n,self.fo)
    def fobserve(self,now=5,request=None,vbus=9000,safe=1,generation=77):
        if request is None:request=struct.unpack('<I',bytes(self.u.mem_read(self.f+40,4)))[0]
        return self.call('SkPdFixedObserve',self.f,generation,now,request,vbus,safe,self.fl,self.fo)
    def fpoll(self,now):return self.call('SkPdFixedPoll',self.f,77,now,self.fo)
    def handshake(self,now=1,pos=2,ma=2000):
        assert self.fbegin(now,pos,ma)==0
        flags,tx,c=self.foutput();assert flags[0]==3 and not any(c)
        expected=(pos<<28)|0x03000000|((ma//10)<<10)|(ma//10)
        # No session reinitialization: the RDO and PD2/3 revision reach PHY.
        rev=struct.unpack('<I',bytes(self.u.mem_read(self.s+12,4)))[0]
        mid=struct.unpack('<I',bytes(self.u.mem_read(self.s+32,4)))[0]
        assert tx[2]==packet(2,mid,rev,0,self.data,struct.pack('<I',expected))
        assert self.fsend()==0 and self.fstate()==1
        assert self.begin(now=now)[0] in (-8,-20)
        assert self.fack(now+1)==0 and self.fstate()==2
        rxid=struct.unpack('<I',bytes(self.u.mem_read(self.s+48,4)))[0]
        assert self.fphy(packet(3,(rxid+1)&7,rev,data=1-self.data),now+2)==0 and self.fstate()==3
        assert self.fphy(packet(6,(rxid+2)&7,rev,data=1-self.data),now+3)==0 and self.fstate()==4
        # PS_RDY alone cannot allow PPS, report fixed or release the lease.
        assert self.begin(now=now+3)[0] in (-8,-20)
        assert not any(self.foutput()[2])
    def confirmed(self,now=1,pos=2,ma=2000):
        self.handshake(now,pos,ma)
        voltage=5000 if pos==1 else 9000
        assert self.fobserve(now+4,vbus=voltage)==0 and self.fstate()==5
        flags,tx,c=self.foutput()
        assert flags[0]==4 and c==(pos,0,voltage,ma,voltage*ma//1000) and not tx[2]
        assert struct.unpack('<I',bytes(self.u.mem_read(self.s+224,4)))[0]==1
    def finish(self):
        ROWS.append(dict(Name=self.name,Base=hex(self.base),ARM64Calls=self.calls,
            SPMIOperations=len(self.io),FixedState=self.fstate()))

for base in (0x140000000,0x180000000):
    for revision in (1,2):
        for pos,ma in ((1,1000),(2,2000)):
            e=FixedTransport(base,f'fixed-PD{revision+1}-position{pos}',revision)
            e.confirmed(pos=pos,ma=ma)
            if revision==1:assert e.begin(now=6)[0]==-8
            e.finish()

    e=FixedTransport(base,'fixed9-to-PPS9-no-fabricated-baseline-and-shared-wire-ID')
    e.confirmed();assert e.begin(now=6)[0]==0
    assert e.output()[1][2]==packet(2,1,2,0,0,struct.pack('<I',0x4303843c))
    assert e.send()==0 and e.goodcrc(7)==0
    assert e.phy_receive(packet(3,3),8)==0 and e.phy_receive(packet(6,4),9)==0
    assert e.observe(10)[0]==0 and e.state()==(5,1)
    before=bytes(e.u.mem_read(e.s,e.size))
    assert e.fpoll(1)==-30 # stale fixed poll cannot cancel active PPS
    assert bytes(e.u.mem_read(e.s,e.size))==before;e.finish()

    for pos,ma,flags,grant,expected in ((3,1000,0x03000000,1,-2),(4,1000,0,1,-2),(0,1000,0,1,-1),
        (5,1000,0,1,-1),(2,1501,0,1,-3),(2,2100,0,1,-3),
        (1,3100,0,1,-3),(1,0,0,1,-3),(1,1000,0x08000000,1,-1),
        (1,1000,0,2,-1),(1,1000,0,0,6)):
        e=FixedTransport(base,f'reject-invalid-fixed-input-{pos}-{ma}-{flags}-{grant}')
        assert e.fbegin(pos=pos,ma=ma,flags=flags,grant=grant)==expected
        assert e.fstate()==0 and not e.io and e.foutput()[1][2]==b'';e.finish()

    for field,value,expected in (('prereq',1,-22),('mv',10000,-1),('mv',8000,-3),('ma',1000,-3),
        ('cable',1000,-3),('mw',10000,-3),('tol',0,-1),('tol',1001,-1),('ma',5000,-1)):
        e=FixedTransport(base,'board-limit-before-transmit-'+field)
        e.setfixedlimits(**{field:value});assert e.fbegin()==expected and not e.io;e.finish()

    for message in (3,6):
        e=FixedTransport(base,'response-before-physical-TX-completion-'+str(message))
        assert e.fbegin()==0 and e.fsend()==0
        assert e.fphy(packet(message,1),2)==-30 and e.fstate()==6
        assert e.foutput()[0][0]==48 and not any(e.foutput()[2]);e.finish()

    e=FixedTransport(base,'PS_RDY-before-Accept-cannot-confirm')
    assert e.fbegin()==0 and e.fsend()==0 and e.fack()==0
    assert e.fphy(packet(6,1),3)==-30 and e.fstate()==6;e.finish()

    for result in (2,3):
        e=FixedTransport(base,'TX-failed-discarded-'+str(result))
        assert e.fbegin()==0 and e.fsend()==0
        assert e.fack(result=result)==-23 and e.foutput()[0][0]==48;e.finish()

    for message in (4,12):
        e=FixedTransport(base,'initial-Reject-Wait-preserves-default-sink-'+str(message))
        assert e.fbegin()==0 and e.fsend()==0 and e.fack()==0
        assert e.fphy(packet(message,1),3)==0 and e.fstate()==7
        assert e.foutput()[0][0]==64 and e.begin(now=4)[0]==-8;e.finish()

        e=FixedTransport(base,'renegotiation-Reject-Wait-keeps-confirmed-fixed-'+str(message))
        e.confirmed();assert e.fbegin(6,pos=1,ma=1000)==0 and e.fsend()==0 and e.fack(7)==0
        assert e.fphy(packet(message,3),8)==0 and e.fstate()==5
        assert e.foutput()[0][0]==8 and e.foutput()[2]==(2,0,9000,2000,18000)
        assert e.begin(now=9)[0]==0;e.finish()

    e=FixedTransport(base,'new-capabilities-refused-request-preserves-physical-fixed-but-defers-PPS')
    e.confirmed();assert e.caps(now=6,mid=3,pdos=(scope['scope']['FIXED5'],(180<<10)|200,
        scope['scope']['FIXED12'],scope['scope']['APDO']))[0]==5
    assert e.fbegin(7,pos=1,ma=1000)==0 and e.fsend()==0 and e.fack(8)==0
    assert e.fphy(packet(4,4),9)==0 and e.foutput()[0][0]==8
    assert e.foutput()[2]==(2,0,9000,2000,18000)
    assert e.begin(now=10)[0]==-8;e.finish()

    e=FixedTransport(base,'duplicate-Accept-does-not-restart-transition-deadline')
    assert e.fbegin()==0 and e.fsend()==0 and e.fack()==0
    assert e.fphy(packet(3,1),3)==0 and e.fphy(packet(3,1),100)==2
    assert e.fpoll(453)==-31 and e.foutput()[0][0]==48;e.finish()

    for phase,deadline in ((1,16),(2,28),(3,453),(4,104)):
        e=FixedTransport(base,'deadline-exact-boundary-'+str(phase))
        assert e.fbegin()==0 and e.fsend()==0
        if phase>=2:assert e.fack()==0
        if phase>=3:assert e.fphy(packet(3,1),3)==0
        if phase>=4:assert e.fphy(packet(6,2),4)==0
        assert e.fpoll(deadline)==-31 and e.fstate()==6 and e.foutput()[0][0]==48;e.finish()

    for request,gen in ((0,77),(999,77),(1,78)):
        e=FixedTransport(base,'stale-sensor-or-generation-'+str(request)+'-'+str(gen))
        e.handshake();assert e.fobserve(request=request,generation=gen)==-21
        assert e.fstate()==4 and e.fobserve()==0;e.finish()

    for vbus,safe in ((0,1),(8699,1),(9001,1),(9000,0)):
        e=FixedTransport(base,'ADC-and-safe-input-fault-'+str(vbus)+'-'+str(safe))
        e.handshake();assert e.fobserve(vbus=vbus,safe=safe)==-3
        assert e.fstate()==6 and e.foutput()[0][0]==48;e.finish()

    e=FixedTransport(base,'late-ADC-cannot-confirm-even-without-timer-callback')
    e.handshake();assert e.fobserve(now=104)==-31 and e.fstate()==6;e.finish()

    e=FixedTransport(base,'limits-tighten-during-voltage-transition')
    e.handshake();e.setfixedlimits(cable=1000)
    assert e.fobserve()==-3 and e.fstate()==6;e.finish()

    e=FixedTransport(base,'SoftReset-invalidates-pending-fixed-token')
    assert e.fbegin()==0 and e.fsend()==0
    assert e.fphy(packet(13,0),2)==3 and e.fstate()==6
    assert e.call('SkPdFixedTxComplete',e.f,77,3,1,1,e.fo)==-21;e.finish()

    e=FixedTransport(base,'clock-backwards-demands-owner-recovery')
    assert e.fbegin(10)==0 and e.fpoll(9)==-32 and e.fstate()==6;e.finish()

    e=FixedTransport(base,'sink-DFP-fixed-handshake-preserves-host-data-role',data=1)
    e.confirmed();assert e.begin(now=6)[0]==0
    assert e.output()[1][2]==packet(2,1,2,0,1,struct.pack('<I',0x4303843c));e.finish()

    e=FixedTransport(base,'fixed-retry-after-Wait-keeps-incremented-wire-MessageID')
    assert e.fbegin()==0 and e.fsend()==0 and e.fack()==0
    assert e.fphy(packet(12,1),3)==0
    e.confirmed(now=4);e.finish()

    e=FixedTransport(base,'millisecond-wrap-keeps-fixed-deadlines')
    # Start near wrap without changing native transport generation or IDs.
    e.u.mem_write(e.f+28,struct.pack('<I',0xfffffff0))
    e.u.mem_write(e.s+136,struct.pack('<I',0xfffffff0))
    assert e.fbegin(now=0xfffffff1)==0 and e.fsend()==0 and e.fack(0xfffffff2)==0
    assert e.fphy(packet(3,1),0xfffffff3)==0
    assert e.fphy(packet(6,2),0xfffffff4)==0
    assert e.fobserve(now=2)==0;e.finish()

    e=FixedTransport(base,'stale-TX-completion-does-not-consume-current-token')
    assert e.fbegin()==0 and e.fsend()==0
    assert e.call('SkPdFixedTxComplete',e.f,77,2,99,1,e.fo)==-21
    assert e.fstate()==1 and e.fack()==0;e.finish()

    for error in (0xc0000185,0x103):
        e=FixedTransport(base,'ambiguous-SPMI-send-requires-explicit-owner-fault-'+hex(error))
        assert e.fbegin()==0;e.fail_send=error
        assert e.fsend()&0xffffffff==0xc0000185
        assert e.call('SkPdFixedFault',e.f,77,2,e.fo)==-23
        assert e.foutput()[0][0]==48 and e.fstate()==6;e.finish()

    e=FixedTransport(base,'RX-ACK-failure-is-not-published-as-Accept')
    assert e.fbegin()==0 and e.fsend()==0 and e.fack()==0
    e.fail_ack=0xc0000185
    assert e.fphy(packet(3,1),3)&0xffffffff==0xc0000185 and e.fstate()==2
    assert e.call('SkPdFixedFault',e.f,77,3,e.fo)==-23
    assert e.foutput()[0][0]==48;e.finish()

    e=FixedTransport(base,'unexpected-session-reset-invalidates-fixed-AMS-lease')
    assert e.fbegin()==0 and e.fsend()==0
    # Model a competing reset writer that wrongly bypassed the port consumer.
    e.u.mem_write(e.s+24,b'\0'*4);e.u.mem_write(e.s+36,b'\0'*4)
    assert e.fpoll(2)==-23 and e.foutput()[0][0]==48;e.finish()

for base in (0x140000000,0x180000000):
    for data in (0,1):
        for response in (4,12):
            e=FixedTransport(base,f'initial-PPS-refusal-restores-fixed-without-USB-reset-{data}-{response}',data=data)
            e.confirmed();assert e.begin(now=6)[0]==0
            request=struct.unpack('<I',bytes(e.u.mem_read(e.s+124,4)))[0]
            assert e.send()==0 and e.goodcrc(7)==0
            assert e.phy_receive(packet(response,3,data=1-data),8)==0
            fast,tx=e.output()
            assert fast==(18,77,request,0x230320c8) and not tx[2] and e.state()==(0,0)
            # No reset or role change: both wire MessageIDs and generation survive.
            assert struct.unpack('<I',bytes(e.u.mem_read(e.s+32,4)))[0]==2
            assert e.begin(now=9)[0]==-8
            assert e.observe(now=9,request=request)[0]==-6 and e.state()==(0,0)
            assert e.fbegin(now=10,pos=1,ma=1000)==0
            assert e.foutput()[1][2]==packet(2,2,2,0,data,struct.pack('<I',0x13019064))
            assert e.fsend()==0 and e.fack(11)==0
            assert e.fphy(packet(3,4,data=1-data),12)==0
            assert e.fphy(packet(6,5,data=1-data),13)==0
            assert e.fobserve(14,vbus=5000)==0 and e.foutput()[2]==(1,0,5000,1000,5000)
            assert e.begin(now=15)[0]==-8;e.finish()

    e=FixedTransport(base,'new-capabilities-allow-PPS-reconsideration-with-monotonic-request-ID')
    e.confirmed();assert e.begin(now=6)[0]==0
    old_request=struct.unpack('<I',bytes(e.u.mem_read(e.s+124,4)))[0]
    assert e.send()==0 and e.goodcrc(7)==0 and e.phy_receive(packet(4,3),8)==0
    assert e.caps(now=9,mid=4,pdos=(scope['scope']['FIXED5'],(180<<10)|200,
        scope['scope']['FIXED12'],scope['scope']['APDO']))[0]==5
    e.confirmed(now=10);assert e.begin(now=15)[0]==0
    assert struct.unpack('<I',bytes(e.u.mem_read(e.s+124,4)))[0]==old_request+1
    assert e.send()==0 and e.goodcrc(16)==0
    assert e.phy_receive(packet(3,7),17)==0 and e.phy_receive(packet(6,0),18)==0
    assert e.observe(now=19,request=old_request)[0]==-5 and e.state()==(4,0)
    assert e.observe(now=19)[0]==0 and e.state()==(5,1);e.finish()

    for response in (4,12):
        e=FixedTransport(base,f'PPS-refusal-after-Accept-cannot-restore-stale-fixed-{response}')
        e.confirmed();assert e.begin(now=6)[0]==0 and e.send()==0 and e.goodcrc(7)==0
        assert e.phy_receive(packet(3,3),8)==0
        assert e.phy_receive(packet(response,4),9)==0 and e.state()==(6,0)
        assert e.output()[0][0]==10 and not(e.output()[0][0]&16);e.finish()

        e=FixedTransport(base,f'PPS-refusal-before-TX-completion-is-ambiguous-{response}')
        e.confirmed();assert e.begin(now=6)[0]==0 and e.send()==0
        assert e.phy_receive(packet(response,3),7)==-6 and e.state()==(6,0)
        assert e.output()[0][0]==10;e.finish()

        e=FixedTransport(base,f'late-initial-PPS-refusal-cannot-bypass-timeout-{response}')
        e.confirmed();assert e.begin(now=6)[0]==0 and e.send()==0 and e.goodcrc(7)==0
        assert e.phy_receive(packet(response,3),37)==-6 and e.state()==(6,0)
        assert e.output()[0][0]==10;e.finish()

        e=FixedTransport(base,f'rejected-PPS-refresh-has-no-fixed-fallback-proof-{response}')
        e.confirmed();assert e.begin(now=6)[0]==0 and e.send()==0 and e.goodcrc(7)==0
        assert e.phy_receive(packet(3,3),8)==0 and e.phy_receive(packet(6,4),9)==0
        assert e.observe(now=10)[0]==0
        e.refresh_samples(start=1000,end=7000)
        assert e.poll(7007)[0]==0 and e.send()==0 and e.goodcrc(7008)==0
        assert e.phy_receive(packet(response,5),7009)==0 and e.state()==(6,0)
        assert e.output()[0][0]==10;e.finish()

    for response in (4,12):
        e=FixedTransport(base,f'reordered-PDOs-cannot-reinterpret-existing-fixed-RDO-{response}')
        e.confirmed()
        fixed_snapshot=bytes(e.u.mem_read(e.s+268,28))
        assert e.caps(now=6,mid=3,pdos=(scope['scope']['FIXED5'],scope['scope']['FIXED12'],
            (180<<10)|200,scope['scope']['APDO']))[0]==5
        assert bytes(e.u.mem_read(e.s+268,28))==fixed_snapshot
        assert struct.unpack('<I',bytes(e.u.mem_read(e.s+196,4)))[0]==scope['scope']['FIXED12']
        assert e.fbegin(7,pos=1,ma=1000)==0 and e.fsend()==0 and e.fack(8)==0
        assert e.fphy(packet(response,4),9)==0 and e.foutput()[0][0]==8
        assert e.foutput()[0][3]==0x230320c8 and e.foutput()[2]==(2,0,9000,2000,18000)
        assert e.begin(now=10)[0]==-8
        # A NEW successful Request, transition and ADC are required for PPS.
        e.confirmed(now=11,pos=1,ma=1000)
        assert e.begin(now=16)[0]==0
        assert struct.unpack('<2I',bytes(e.u.mem_read(e.s+256,8)))==(2,2);e.finish()

    e=FixedTransport(base,'duplicate-capabilities-do-not-advance-capability-epoch')
    e.confirmed()
    pdos=(scope['scope']['FIXED5'],scope['scope']['FIXED12'],(180<<10)|200,scope['scope']['APDO'])
    assert e.caps(now=6,mid=3,pdos=pdos)[0]==5
    assert e.caps(now=7,mid=3,pdos=pdos)[0]==2
    assert struct.unpack('<I',bytes(e.u.mem_read(e.s+256,4)))[0]==2;e.finish()

    e=FixedTransport(base,'capability-epoch-wrap-requires-owner-recovery')
    e.confirmed();e.u.mem_write(e.s+256,struct.pack('<I',0xffffffff))
    assert e.caps(now=6,mid=3)[0]==-6 and e.state()==(6,0)
    assert e.output()[0][0]==10;e.finish()

result=dict(Passed=True,Scenarios=len(ROWS),ARM64Calls=sum(x['ARM64Calls'] for x in ROWS),
    ImageSHA256=hashlib.sha256(scope['scope']['RAW']).hexdigest(),Cases=ROWS,
    CompiledFixedAndPpsSessionAndPmicBodiesExecuted=True,FabricatedConfirmFixedBaseline=False,
    BusIRQADCAndCCModelled=True,NativeDPCMappingIntegrated=False,PhysicalPpsProven=False,
    PhysicalFixedChargeProven=False,HubContinuityProven=False,Installable=False,Installed=False)
(ROOT/'fixed-pps-transport-qa.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='Cases'},indent=2))
