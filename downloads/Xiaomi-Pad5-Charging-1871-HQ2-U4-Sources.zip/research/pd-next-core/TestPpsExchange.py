"""Execute the built ARM64 PPS coordinator with independent wire/timing cases.
No PMIC, kernel API, cable action or installed driver is invoked.
"""
from pathlib import Path
import hashlib,json,struct,sys,os
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,r'H:\Vlad\Charging\Build1867\offline-deps')
import pefile
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_ARM
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE
from unicorn.arm64_const import *
RAW=Path(os.environ.get('SK_PPS_REPLAY_IMAGE',str(ROOT/'build/sk_pps_charge_binding.component.dll'))).read_bytes()
PE=pefile.PE(data=RAW);assert not getattr(PE,'DIRECTORY_ENTRY_IMPORT',None)
EXPORTS={x.name.decode():x.address for x in PE.DIRECTORY_ENTRY_EXPORT.symbols}
PAC=set()
for sec in PE.sections:
    if sec.Characteristics&0x20000000:
        for i in Cs(CS_ARCH_ARM64,CS_MODE_ARM).disasm(PE.get_data(sec.VirtualAddress,sec.Misc_VirtualSize),sec.VirtualAddress):
            if i.mnemonic in ('pacibsp','autibsp','paciasp','autiasp'):PAC.add(i.address)
ARGS=[UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3,
      UC_ARM64_REG_X4,UC_ARM64_REG_X5,UC_ARM64_REG_X6,UC_ARM64_REG_X7]
SAVED=[UC_ARM64_REG_X19,UC_ARM64_REG_X20,UC_ARM64_REG_X21,UC_ARM64_REG_X22,
       UC_ARM64_REG_X23,UC_ARM64_REG_X24,UC_ARM64_REG_X25,UC_ARM64_REG_X26,
       UC_ARM64_REG_X27,UC_ARM64_REG_X28,UC_ARM64_REG_X29]
ROWS=[]
FIXED5=(100<<10)|300
FIXED12=(240<<10)|150
APDO=0xc0000000|(110<<17)|(50<<8)|60
FIXED_RDO=(2<<28)|0x03000000|(150<<10)|150

def packet(kind=3,mid=0,rev=2,power=1,data=1,payload=b'',sop=0):
    h=kind|(data<<5)|(rev<<6)|(power<<8)|(mid<<9)|((len(payload)//4)<<12)
    return bytes([3+len(payload),sop])+struct.pack('<H',h)+payload

class Exchange:
    def __init__(self,base,name,native=1,data=0,now=0):
        self.base=base;self.name=name;self.calls=0;self.data=data
        self.u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);p=pefile.PE(data=RAW);p.relocate_image(base)
        im=p.get_memory_mapped_image();self.u.mem_map(base,(len(im)+4095)&~4095);self.u.mem_write(base,im)
        self.u.mem_map(0x20000000,0x10000);self.u.mem_map(0x70000000,0x10000)
        self.s=0x20001000;self.out=0x20003000;self.rx=0x20004000;self.limits=0x20005000;self.end=0x2000f000
        self.u.hook_add(UC_HOOK_CODE,self.hook)
        self.size=self.call('Size');assert self.size==296
        self.u.mem_write(self.s-8,b'BEFORE!!');self.u.mem_write(self.s+self.size,b'AFTER!!!')
        self.init=self.call('Initialize',self.s,77,now,data,native)
        self.setlimits()
    def hook(self,u,a,n,_):
        if a==self.end:u.emu_stop()
        elif a-self.base in PAC:u.reg_write(UC_ARM64_REG_PC,a+4)
    def call(self,name,*args):
        self.calls+=1
        for i,r in enumerate(SAVED):self.u.reg_write(r,0xabab000000000000+i)
        for i,r in enumerate(ARGS):self.u.reg_write(r,args[i] if i<len(args) else 0)
        self.u.reg_write(UC_ARM64_REG_SP,0x70008000)
        for i,arg in enumerate(args[8:]):self.u.mem_write(0x70008000+i*8,struct.pack('<Q',arg))
        self.u.reg_write(UC_ARM64_REG_LR,self.end)
        self.u.emu_start(self.base+EXPORTS['SkPdPpsExchange'+name],0,count=200000)
        assert self.u.reg_read(UC_ARM64_REG_PC)==self.end and self.u.reg_read(UC_ARM64_REG_SP)==0x70008000
        assert all(self.u.reg_read(r)==0xabab000000000000+i for i,r in enumerate(SAVED))
        if hasattr(self,'size'):
            assert bytes(self.u.mem_read(self.s-8,8))==b'BEFORE!!' and bytes(self.u.mem_read(self.s+self.size,8))==b'AFTER!!!'
        return struct.unpack('<i',struct.pack('<I',self.u.reg_read(UC_ARM64_REG_W0)))[0]
    def setlimits(self,prereq=15,mv=11000,ma=3000,cable=3000,mw=30000,pdp=0,tol=300):
        self.u.mem_write(self.limits,struct.pack('<7I',prereq,mv,ma,cable,mw,pdp,tol))
    def output(self):
        fast=struct.unpack('<4I',bytes(self.u.mem_read(self.out,16)))
        gen,token,n=struct.unpack('<3I',bytes(self.u.mem_read(self.out+16,12)));assert n<=32
        return fast,(gen,token,bytes(self.u.mem_read(self.out+28,n)))
    def receive(self,p,now=0,generation=77):
        self.u.mem_write(self.rx,p)
        result=self.call('Receive',self.s,generation,now,self.rx,len(p),self.out)
        return result,self.output()
    def caps(self,rev=2,pdos=(FIXED5,FIXED12,APDO),now=0,mid=0):
        return self.receive(packet(1,mid,rev,data=1-self.data,payload=struct.pack('<'+'I'*len(pdos),*pdos)),now)
    def fixed(self,rdo=FIXED_RDO):return self.call('ConfirmFixed',self.s,77,rdo)
    def baseline(self,rev=2,pdos=(FIXED5,FIXED12,APDO),now=0):
        assert self.init==0 and self.caps(rev,pdos,now)[0]==5 and self.fixed()==0
    def begin(self,now=1,pos=3,mv=9000,ma=3000,grant=1):
        result=self.call('Begin',self.s,77,now,pos,mv,ma,grant,self.limits,self.out)
        return result,self.output()
    def ack(self,now=2,token=None,result=1,generation=77):
        if token is None:token=struct.unpack('<I',bytes(self.u.mem_read(self.s+236,4)))[0]
        r=self.call('TxComplete',self.s,generation,now,token,result,self.out)
        return r,self.output()
    def observe(self,now=5,vbus=9000,safe=1,request=None,generation=77):
        if request is None:request=struct.unpack('<I',bytes(self.u.mem_read(self.s+124,4)))[0]
        r=self.call('Observe',self.s,generation,now,request,vbus,safe,self.out)
        return r,self.output()
    def poll(self,now,grant=1):
        r=self.call('Poll',self.s,77,now,grant,self.limits,self.out)
        return r,self.output()
    def state(self):return struct.unpack('<2I',bytes(self.u.mem_read(self.s+128,8)))
    def active(self):
        self.baseline();r,(f,tx)=self.begin();assert r==0 and f[0]==3
        assert tx[2]==packet(2,0,2,0,self.data,struct.pack('<I',0x3303843c))
        assert self.ack()[0]==0
        assert self.receive(packet(3,5,data=1-self.data),3)[0]==0
        assert self.receive(packet(6,6,data=1-self.data),4)[0]==0
        assert self.state()==(4,0)
        r,(f,tx)=self.observe();assert r==0 and f[0]==4 and not tx[2]
        assert self.state()==(5,1)
    def refresh_samples(self,start=1000,end=7000):
        for t in range(start,end+1,1000):assert self.observe(t)[0]==0
    def finish(self):ROWS.append(dict(Name=self.name,Base=hex(self.base),ARM64Calls=self.calls))

for base in (0x140000000,0x180000000):
    e=Exchange(base,'native-running-does-not-create-PPS-owner',native=0);assert e.init==-8;e.finish()
    for data in (0,1):
        e=Exchange(base,'complete-handshake-wire-ID-independent-and-ADC-confirmation-'+str(data),data=data)
        e.active();e.finish()
    e=Exchange(base,'no-APDO-or-unconfirmed-fixed-baseline-no-transmitter')
    assert e.begin()[0]==-8;assert e.caps(now=1)[0]==5;assert e.begin(now=2)[0]==-8
    assert e.fixed(0x3303843c)==-2 and e.fixed()==0
    assert e.begin(now=3,pos=4)[0]==-1;e.finish()
    e=Exchange(base,'PD2-source-no-PPS-request');e.baseline(rev=1)
    assert e.begin()[0]==-8 and e.output()[1][2]==b'';e.finish()
    e=Exchange(base,'SinkTxNG-defers-without-changing-request-or-wire-ID');e.baseline()
    assert e.begin(grant=0)[0]==4 and e.state()==(0,0)
    assert e.begin(now=2)[0]==0 and e.output()[1][1]==1;e.finish()
    e=Exchange(base,'retry-and-peer-MessageID-do-not-confuse-response-ID');e.baseline()
    r,(f,tx)=e.begin();token=tx[1]
    assert e.ack(token=token+1)[0]==-5 and e.state()==(1,0)
    assert e.ack(token=token)[0]==0
    assert e.receive(packet(3,1),3)[0]==0
    assert e.receive(packet(3,1),4)[0]==2
    assert e.receive(packet(6,2),5)[0]==0 and e.observe(6)[0]==0;e.finish()
    for response in (4,12):
        e=Exchange(base,'initial-Reject-or-Wait-keeps-fixed-contract-'+str(response));e.baseline();e.begin();e.ack()
        r,(f,tx)=e.receive(packet(response,1),3)
        assert r==0 and f[0]==18 and f[3]==FIXED_RDO and e.state()==(0,0) and not tx[2]
        assert e.begin(now=4)[0]==-8;e.finish()
    for response in (3,6):
        e=Exchange(base,'response-before-matching-GoodCRC-requires-recovery-'+str(response));e.baseline();e.begin()
        r,(f,tx)=e.receive(packet(response,1),2)
        assert r==-6 and f[0]==10 and e.state()==(6,0);e.finish()
    e=Exchange(base,'PS_RDY-before-Accept-does-not-enable-pump');e.baseline();e.begin();e.ack()
    assert e.receive(packet(6,1),3)[0]==-6 and e.state()==(6,0);e.finish()
    e=Exchange(base,'PD2-Accept-cannot-confirm-PD3-PPS');e.baseline();e.begin();e.ack()
    r,(f,tx)=e.receive(packet(3,1,rev=1),3)
    assert r==-2 and f[0]==10 and e.state()==(6,0);e.finish()
    e=Exchange(base,'PD2-PS_RDY-cannot-confirm-PD3-PPS');e.baseline();e.begin();e.ack()
    assert e.receive(packet(3,1),3)[0]==0
    r,(f,tx)=e.receive(packet(6,2,rev=1),4)
    assert r==-2 and f[0]==10 and e.state()==(6,0);e.finish()
    e=Exchange(base,'unsolicited-Accept-not-associated-with-old-Request');e.baseline()
    assert e.receive(packet(3,1),1)[0]==-6;e.finish()
    for result in (2,3):
        e=Exchange(base,'PHY-failed-or-discarded-transmit-'+str(result));e.baseline();e.begin()
        r,(f,tx)=e.ack(result=result)
        assert r==-23 and f[0]==10 and e.state()==(6,0);e.finish()
    e=Exchange(base,'response-at-expired-deadline-cannot-enable-contract');e.baseline();e.begin();e.ack()
    r,(f,tx)=e.receive(packet(3,1),32)
    assert r==-6 and f[0]==10 and e.state()==(6,0);e.finish()
    e=Exchange(base,'late-ACK-invalidates-pending-wire-token');e.baseline();r,(f,tx)=e.begin()
    r,(f,_)=e.ack(now=101,token=tx[1]);assert r==-6 and f[0]==10
    assert e.ack(now=102,token=tx[1])[0]==-5;e.finish()
    e=Exchange(base,'SoftReset-cancels-outstanding-PPS-and-old-completion');e.baseline();r,(f,tx)=e.begin()
    assert e.receive(packet(13,0),2)[0]==3
    assert e.state()==(6,0) and e.ack(token=tx[1])[0]==-5;e.finish()
    e=Exchange(base,'new-SourceCaps-during-active-PPS-requires-policy-recovery');e.active()
    r,(f,tx)=e.caps(mid=7,now=6);assert r==-6 and f[0]==10;e.finish()
    for pdos in ((FIXED12,APDO),(100<<10,APDO),(FIXED5,APDO|0x02000000)):
        e=Exchange(base,'malformed-first-PDO-or-APDO-never-transmitted-'+hex(pdos[0]))
        r,_=e.caps(pdos=pdos)
        if pdos[0]==FIXED5:
            assert r==5;assert e.fixed((1<<28)|(100<<10)|100)==0
            assert e.begin(pos=2)[0]==-4
        else:assert r==-4 and e.state()==(6,0)
        e.finish()
    e=Exchange(base,'unchanged-refresh-needs-new-ACK-Accept-PS_RDY-ADC');e.active();e.refresh_samples()
    assert e.poll(7001)[1][1][2]==b''
    r,(f,tx)=e.poll(7002);assert r==0 and f[0]==1
    assert tx[2]==packet(2,1,2,0,0,struct.pack('<I',0x3303843c))
    assert e.state()==(1,1) and e.ack(now=7003,token=tx[1])[0]==0
    assert e.receive(packet(3,7),7004)[0]==0
    assert e.receive(packet(6,0),7005)[0]==0
    assert e.observe(7006)[0]==0 and e.state()==(5,1);e.finish()
    e=Exchange(base,'SinkTxNG-blocks-refresh-but-does-not-bypass-liveness');e.active();e.refresh_samples()
    assert e.poll(7002,0)[0]==4 and e.state()==(5,1)
    assert e.observe(8000)[0]==0 and e.poll(8001,0)[0]==4
    assert e.observe(9000)[0]==0
    r,(f,tx)=e.poll(9002,0);assert r==-6 and f[0]==10 and not tx[2];e.finish()
    e=Exchange(base,'sensor-timeout-still-enforced-during-SinkTxNG');e.active()
    r,(f,tx)=e.poll(1006,0);assert r==-6 and f[0]==10;e.finish()
    for field,value in (('prereq',7),('mv',8000),('ma',2000),('cable',1500),('mw',18000),('pdp',18000),('tol',0)):
        e=Exchange(base,'active-limits-tighten-'+field);e.active();e.setlimits(**{field:value})
        r,(f,tx)=e.poll(6);assert r==-8 and f[0]==10 and not tx[2];e.finish()
    for safe,vbus in ((0,9000),(1,11001),(1,9400),(1,0)):
        e=Exchange(base,'ADC-or-thermal-fault-disables-PPS-'+str(safe)+'-'+str(vbus));e.active()
        r,(f,tx)=e.observe(6,vbus,safe);assert r==0 and f[0]==10 and e.state()==(6,0);e.finish()
    e=Exchange(base,'stale-generation-or-ADC-request-does-not-confirm');e.baseline();e.begin();e.ack()
    assert e.receive(packet(3,1),3)[0]==0 and e.receive(packet(6,2),4)[0]==0
    assert e.observe(5,request=0)[0]==-5 and e.observe(5,generation=78)[0]==-5
    assert e.state()==(4,0) and e.observe(6)[0]==0;e.finish()
    e=Exchange(base,'role-DFP-kept-through-PPS-exchange',data=1);e.active();assert e.data==1;e.finish()
    e=Exchange(base,'guard-millisecond-wrap-preserves-deadline',now=0xfffffff0);e.baseline(now=0xfffffff0)
    assert e.begin(now=0xfffffff1)[0]==0 and e.ack(now=0xfffffff2)[0]==0
    assert e.receive(packet(3,1),0xfffffff3)[0]==0 and e.receive(packet(6,2),0xfffffff4)[0]==0
    assert e.observe(0xfffffff5)[0]==0 and e.poll(10)[0]==0;e.finish()

result=dict(Passed=True,Scenarios=len(ROWS),ARM64Calls=sum(x['ARM64Calls'] for x in ROWS),
    ImageSHA256=hashlib.sha256(RAW).hexdigest(),Cases=ROWS,
    NativePolicyAdapterIntegrated=False,PhyAdapterIntegrated=False,KernelLoaded=False,
    FullPD3PolicyImplemented=False,HardwareIO=False,Installable=False,
    PpsHardwareProven=False,HubContinuityProven=False,
    Scope='PPS coordinator/session/guard compiled ARM64 control flow; input PHY events and fixed baseline are modeled.')
(ROOT/'pps-exchange-qa.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='Cases'},indent=2))
