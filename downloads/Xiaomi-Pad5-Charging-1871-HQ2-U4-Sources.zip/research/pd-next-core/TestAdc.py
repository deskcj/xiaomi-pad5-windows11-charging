"""ARM64 ADC completion owner with explicit electrical events and bus failures.

The original hardware bit is byte-pinned/Ghidra-reviewed separately. This
executes new compiled control flow, not a live LN8000 test or IRQ calibration.
"""
from pathlib import Path
import hashlib
import json
import struct
from unicorn.arm64_const import UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_X2

root = Path(__file__).resolve().parent
scope = {'__file__': str(root / 'TestBinding.py')}
exec(compile((root / 'TestBinding.py').read_text().split('\nfor base in (')[0],
             scope['__file__'], 'exec'), scope)
Binding = scope['Binding']
rows = []


class Adc(Binding):
    def __init__(self, base, name, active=False):
        self.adc_clock_ready = False
        super().__init__(base, name)
        if active:
            self.active_pump()
        else:
            self.pps()
            assert self.configure() == 0
        self.now = 30
        self.clock = 0x2100d020
        self.adc = 0x21008000
        self.adc_out = 0x21009000
        self.delay_index = 0
        self.delay_ms = 120
        self.stuck_int = False
        self.adc_clock_ready = True
        assert self.call('SkLnAdcSize') == 136
        assert self.call('SkLn8000Size') == 80
        assert self.call('SkLnAdcInitialize', self.adc, self.lctx, self.clock,
                         0x6789, 77) == 0
        self.u.mem_write(self.adc - 8, b'ADCBEFOR')
        self.u.mem_write(self.adc + 136, b'ADCAFTER')

    def hook(self, u, a, n, data):
        if self.adc_clock_ready and a == self.clock:
            assert u.reg_read(UC_ARM64_REG_X0) == 0x6789
            self.ret(self.now)
            return
        if self.adc_clock_ready and a in (self.lread, self.lwrite):
            if len(self.ln_io) + 1 == self.delay_index:
                self.now = (self.now + self.delay_ms) & 0xffffffff
            stuck = (self.stuck_int and a == self.lwrite and
                     u.reg_read(UC_ARM64_REG_X1) == 0x26 and not
                     (u.mem_read(u.reg_read(UC_ARM64_REG_X2), 1)[0] & 1))
        else:
            stuck = False
        super().hook(u, a, n, data)
        if stuck:
            self.lregs[0x26] |= 1

    def arm(self, gen=77):
        return self.call('SkLnAdcArm', self.adc, gen)

    def apoll(self, bits, step=2, gen=77):
        self.now = (self.now + step) & 0xffffffff
        self.lregs[1] = bits
        self.u.mem_write(self.adc_out, b'\xa5' * 76)
        s = self.call('SkLnAdcPoll', self.adc, gen, self.adc_out)
        if s != 0:
            assert bytes(self.u.mem_read(self.adc_out, 76)) == bytes(76)
        assert bytes(self.u.mem_read(self.adc - 8, 8)) == b'ADCBEFOR'
        assert bytes(self.u.mem_read(self.adc + 136, 8)) == b'ADCAFTER'
        return s

    def result(self):
        return struct.unpack('<3I', bytes(self.u.mem_read(self.adc_out, 12)))

    def fresh(self):
        assert self.arm() == 0x103 and self.apoll(0) == 0x103
        assert self.apoll(2) == 0

    def sampled_start(self):
        self.set_proof(now=self.now, flags=37, mode=2, mv=123, serial=0xdead)
        return self.call('SkPpsPathBeginSampled', self.path, self.adc, 77,
                         self.permit, self.proof)

    def sampled_poll(self):
        self.set_proof(now=self.now, flags=37, mode=4, mv=123, serial=0xdead)
        return self.call('SkPpsPathPollSampled', self.path, self.adc, 77,
                         self.permit, self.proof)

    def adc_state(self):
        return struct.unpack('<8I', bytes(self.u.mem_read(self.adc + 24, 32)))

    def events(self):
        return self.adc_state()[-1]

    def record(self, name, **extra):
        assert not self.u.mem_read(self.lctx + 28, 4).strip(b'\0') # Busy
        rows.append(dict(Case=name, Base=hex(self.base), ARM64Calls=self.calls,
                         ADCState=self.adc_state(), LNTransfers=len(self.ln_io),
                         Fast=self.fast(), OwnInterruptPause=int.from_bytes(
                             self.u.mem_read(self.lctx + 76, 4), 'little'), **extra))


for base in (0x140000000, 0x180000000):
    r = Adc(base, 'old DONE must not grant permission')
    assert r.arm() == 0x103
    assert r.apoll(2) == 0x103
    assert r.apoll(2) == 0x103
    assert r.apoll(0) == 0x103
    earliest = r.now
    assert r.apoll(2) == 0
    assert r.result() == (77, 1, earliest)
    assert r.lregs[0x26] & 3 == 0
    assert not any(r.fast())
    assert r.apoll(2) == 0xc00000a3 # No double publication of the same result
    r.record('OldDoneDrained_LowThenHigh_CoherentReleasedSample')
    assert r.arm() == 0x103
    assert r.apoll(0) == 0x103
    assert r.apoll(2) == 0 and r.result()[1] == 2
    r.record('ConversionSerialAdvancesOnlyAfterAnotherHardwareTransition')

    for stuck in (0, 2):
        r = Adc(base, 'stuck ADC bit')
        assert r.arm() == 0x103
        for i in range(49):
            assert r.apoll(stuck) == 0x103
        assert r.apoll(stuck) == 0xc00000b5
        assert r.lregs[0x26] & 1 == 0
        r.record('StuckLowOrHighNeverPublishesFreshness', Level=stuck)

    r = Adc(base, 'interrupt settle time')
    assert r.arm() == 0x103
    n = len(r.ln_io)
    assert r.apoll(0, step=0) == 0x103 and len(r.ln_io) == n
    assert r.apoll(0, step=1) == 0x103
    assert r.apoll(2, step=1) == 0
    r.record('AtLeastOneMillisecondSettlingWithoutBlockingSleep')

    r = Adc(base, 'foreign generation')
    assert r.arm() == 0x103
    n = len(r.ln_io)
    assert r.apoll(2, gen=76) == 0xc0000120 and len(r.ln_io) == n
    assert r.apoll(0) == 0x103 and r.apoll(2) == 0
    r.record('StaleEventCannotReleaseCurrentAttachmentHold')

    for mode in (0, 1, 2, 3, 4, 5, 7):
        r = Adc(base, 'ADC mode without continuous completion')
        r.lregs[0x23] = (r.lregs[0x23] & 31) | (mode << 5)
        n = len(r.ln_io)
        assert r.arm() == 0xc00000a3
        assert all(x['Kind'] != 'Write' for x in r.ln_io[n:])
        r.record('UnsupportedOrStoppedAdcCannotProduceFreshProof', Mode=mode)

    for foreign in (1, 2, 3):
        r = Adc(base, 'foreign hold')
        r.lregs[0x26] |= foreign
        n = len(r.ln_io)
        assert r.arm() == 0x80000011
        assert r.lregs[0x26] & foreign == foreign
        assert all(x['Kind'] != 'Write' for x in r.ln_io[n:])
        r.record('ForeignInterruptAndAdcHoldsArePreserved', Holds=foreign)

    for bits in (1, 4, 8, 64, 128):
        r = Adc(base, 'safety interrupt', active=True)
        assert r.arm() == 0x103
        assert r.apoll(bits | 2) == 0xc00000a3
        assert r.events() & bits and r.fast() == (0, 0, 0)
        r.record('SafetyInterruptRetainedAndRunningPumpStopped', Bits=bits)

    r = Adc(base, 'coalesced benign interrupts retained')
    assert r.arm() == 0x103 and r.apoll(0x30) == 0x103
    assert r.apoll(2) == 0 and r.events() == 0x30
    r.record('ModeAndChargePhaseEventsRetainedForCompleteOwner')

    r = Adc(base, 'clock reversal')
    assert r.arm() == 0x103
    r.now = 20
    assert r.apoll(2, step=0) == 0xc000000d
    assert r.lregs[0x26] & 1 == 0
    r.record('ClockReversalFailsAndReleasesOwnedHold')

    r = Adc(base, 'clock wrap')
    r.now = 0xfffffff8
    # Initialize separately in this clock epoch, not a backwards jump.
    assert r.call('SkLnAdcInitialize', r.adc, r.lctx, r.clock, 0x6789, 77) == 0
    assert r.arm() == 0x103 and r.apoll(0, step=4) == 0x103
    assert r.apoll(2, step=8) == 0 and r.result() == (77, 1, 0xfffffffc)
    r.record('MonotonicMillisecondWrapPreservesConservativeAge')

    r = Adc(base, 'serial overflow')
    r.u.mem_write(r.adc + 48, struct.pack('<I', 0xffffffff))
    assert r.arm() == 0x103 and r.apoll(0) == 0x103
    assert r.apoll(2) == 0xc0000095
    r.record('ConversionSerialOverflowRequiresNewOwnerGeneration')

    r = Adc(base, 'cancel while held', active=True)
    assert r.arm() == 0x103
    assert r.call('SkLnAdcCancel', r.adc, 77) == 0
    assert r.fast() == (0, 0, 0) and r.lregs[0x26] & 3 == 0
    r.record('CancelConfirmsPumpStandbyAndOwnedHoldRelease')

    r = Adc(base, 'unrecoverable interrupt resume', active=True)
    assert r.arm() == 0x103
    r.stuck_int = True
    assert r.apoll(0) == 0xc000009c
    assert int.from_bytes(r.u.mem_read(r.lctx + 76, 4), 'little') == 1
    assert int.from_bytes(r.u.mem_read(r.lctx + 36, 4), 'little') == 1
    assert r.fast()[2] == 1
    r.record('FailedInterruptResumeRetainsShutdownAndHoldObligations')
    r.stuck_int = False
    assert r.call('SkLn8000Standby', r.lctx, 77) == 0
    assert r.fast() == (0, 0, 0) and r.lregs[0x26] & 1 == 0
    r.record('BaseConverterRecoveryReleasesAdcOwnerHold')

    r = Adc(base, 'measured path')
    r.fresh()
    start = len(r.ln_io)
    assert r.sampled_start() == 0x103
    start_transfers = len(r.ln_io) - start
    r.now += 10
    r.fresh()
    r.set_permit(now=r.now)
    assert r.sampled_poll() == 0 and r.fast() == (0, 1, 1)
    r.record('FixedAndPpsWireHandshake_RealDoneModel_TimedConverterStartPoll',
             StartTransfers=start_transfers)
    r.now += 101
    assert r.call('SkLnAdcCopyReady', r.adc, 77, r.adc_out) == 0xc00000a3
    assert r.fast() == (0, 0, 0)
    r.record('ExpiredOwnerSampleStopsRunningPump')

    for boundary in range(1, start_transfers + 1):
        r = Adc(base, 'slow start bus operation')
        r.fresh()
        r.delay_index = len(r.ln_io) + boundary
        assert r.sampled_start() not in (0, 0x103)
        assert r.fast() == (0, 0, 0) and r.lregs[3] == 2
        r.record('LateStatusReadOrConverterWriteCannotGrantRunningSuccess',
                 Boundary=boundary)

    r = Adc(base, 'budget expires while ADC is still fresh')
    r.now = 106
    r.fresh() # now110, original permit at10 is exactly100ms old
    r.delay_index = len(r.ln_io) + 1
    r.delay_ms = 5
    assert r.sampled_start() == 0xc00000a3
    assert not any(r.fast()) and r.lregs[3] == 2
    r.record('FreshAdcCannotRenewExpiredMainInputBudget')

    r = Adc(base, 'caller fabricated ADC permission')
    r.set_proof(now=30, flags=53, mode=2)
    assert r.call('SkPpsPathBeginSampled', r.path, r.adc, 77,
                  r.permit, r.proof) == 0xc00000a3
    assert not any(r.fast())
    r.record('CallerFreshAdcFlagCannotSubstituteForOwnerAcquisition')

    r = Adc(base, 'confirmed voltage belongs to lost owner')
    r.fresh()
    r.u.mem_write(r.s + 16, struct.pack('<I', 0))
    assert r.sampled_start() == 0xc00000a3 and not any(r.fast())
    r.record('CompletedAdcCannotSubstituteForSinglePdOwner')

    baseline = Adc(base, 'transfer boundaries')
    start = len(baseline.ln_io)
    assert baseline.arm() == 0x103
    assert baseline.apoll(0) == 0x103 and baseline.apoll(2) == 0
    count = len(baseline.ln_io) - start
    for kind in ('fail_index', 'short_index', 'information_index', 'delay_index'):
        for boundary in range(1, count + 1):
            r = Adc(base, 'boundary failure')
            setattr(r, kind, len(r.ln_io) + boundary)
            s = r.arm()
            if s == 0x103:
                s = r.apoll(0)
            if s == 0x103:
                s = r.apoll(2)
            assert s not in (0, 0x103), (kind, boundary, hex(s))
            assert bytes(r.u.mem_read(r.adc_out, 76)) == bytes(76)
            assert r.lregs[0x26] & 3 == 0
            r.record('EveryBusFailureOrLongTransactionRejectsSample',
                     Kind=kind, Boundary=boundary)

report = dict(Passed=True, Scenarios=len(rows),
              ARM64Calls=sum(r['ARM64Calls'] for r in rows),
              ImageSHA256=hashlib.sha256((root / 'build/sk_pps_charge_binding.component.dll').read_bytes()).hexdigest(),
              PhysicalAdcDoneSemanticsValidated=False, HardwareIO=False,
              FastChargingFixProven=False, HubContinuityFixProven=False, Cases=rows)
(root / 'adc-completion-qa.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k != 'Cases'}, indent=2))
