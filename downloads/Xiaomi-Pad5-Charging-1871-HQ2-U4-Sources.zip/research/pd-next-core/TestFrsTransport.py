"""Execute compiled ARM64 FRS logic; PHY/CC/power proofs are modeled.

Independent wire packets verify discovery, roles and MessageIDs. No bus I/O,
installed driver, cable change or claim of sub-150us hardware completion.
"""
from pathlib import Path
import hashlib,json,struct,sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,r'H:\Vlad\Charging\Build1867\offline-deps')
import pefile
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_ARM
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE
from unicorn.arm64_const import *
RAW=(ROOT/'build/sk_pps_charge_binding.component.dll').read_bytes()
PE=pefile.PE(data=RAW)
assert PE.FILE_HEADER.Machine==0xaa64 and not getattr(PE,'DIRECTORY_ENTRY_IMPORT',None)
EXPORTS={x.name.decode():x.address for x in PE.DIRECTORY_ENTRY_EXPORT.symbols}
PAC=set()
for sec in PE.sections:
    if sec.Characteristics&0x20000000:
        for i in Cs(CS_ARCH_ARM64,CS_MODE_ARM).disasm(PE.get_data(sec.VirtualAddress,sec.Misc_VirtualSize),sec.VirtualAddress):
            if i.mnemonic in ('pacibsp','autibsp','paciasp','autiasp'):PAC.add(i.address)
ARGS=[UC_ARM64_REG_X0+i for i in range(8)]
SAVED=[UC_ARM64_REG_X19+i for i in range(11)]
ROWS=[]
def packet(kind,mid=1,rev=2,power=1,data=0,payload=b'',sop=0):
    head=kind|(data<<5)|(rev<<6)|(power<<8)|(mid<<9)|((len(payload)//4)<<12)
    return bytes([3+len(payload),sop])+struct.pack('<H',head)+payload
def sinkpdo(current=2,drp=1,voltage=5000,operating=500):
    return (drp<<29)|(current<<23)|((voltage//50)<<10)|(operating//10)
class Replay:
    def __init__(self,base,name,data=1,now=0,default=900):
        self.name=name;self.base=base;self.data=data;self.calls=0
        self.u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
        p=pefile.PE(data=RAW);p.relocate_image(base);im=p.get_memory_mapped_image()
        self.u.mem_map(base,(len(im)+4095)&~4095);self.u.mem_write(base,im)
        self.u.mem_map(0x20000000,0x10000);self.u.mem_map(0x70000000,0x10000)
        self.f=0x20001000;self.s=0x20002000;self.out=0x20003000
        self.rx=0x20004000;self.env=0x20005000;self.timers=0x20006000;self.h=0x20007000
        self.source_proof=0x20008000;self.end=0x2000f000
        self.u.hook_add(UC_HOOK_CODE,self.hook)
        self.size=self.call('SkPdFrsSize');assert self.size==80
        self.u.mem_write(self.f-8,b'FRSBEGIN');self.u.mem_write(self.f+self.size,b'FRSEND!!')
        self.u.mem_write(self.out-8,b'OUTSTART');self.u.mem_write(self.out+60,b'OUTEND!!')
        assert self.call('SkPdSessionInitialize',self.s,77,0,data,1)==0
        self.put(self.s+32,6) # fixed contract already exchanged messages
        self.u.mem_write(self.timers,struct.pack('<5I',100,30,500,15,100))
        assert self.call('SkPdFrsInitialize',self.f,self.s,now,self.timers,default)==0
    def hook(self,u,a,n,_):
        if a==self.end:u.emu_stop()
        elif a-self.base in PAC:u.reg_write(UC_ARM64_REG_PC,a+4)
    def put(self,a,v):self.u.mem_write(a,struct.pack('<I',v))
    def get(self,a):return struct.unpack('<I',bytes(self.u.mem_read(a,4)))[0]
    def call(self,name,*args):
        self.calls+=1
        for i,r in enumerate(SAVED):self.u.reg_write(r,0xabcd000000000000+i)
        for i,r in enumerate(ARGS):self.u.reg_write(r,args[i] if i<len(args) else 0)
        self.u.reg_write(UC_ARM64_REG_SP,0x70008000)
        for i,a in enumerate(args[8:]):self.u.mem_write(0x70008000+8*i,struct.pack('<Q',a))
        self.u.reg_write(UC_ARM64_REG_LR,self.end)
        self.u.emu_start(self.base+EXPORTS[name],0,count=200000)
        assert self.u.reg_read(UC_ARM64_REG_PC)==self.end
        assert self.u.reg_read(UC_ARM64_REG_SP)==0x70008000
        assert all(self.u.reg_read(r)==0xabcd000000000000+i for i,r in enumerate(SAVED))
        if hasattr(self,'size'):
            assert bytes(self.u.mem_read(self.f-8,8))==b'FRSBEGIN'
            assert bytes(self.u.mem_read(self.f+self.size,8))==b'FRSEND!!'
            assert bytes(self.u.mem_read(self.out-8,8))==b'OUTSTART'
            assert bytes(self.u.mem_read(self.out+60,8))==b'OUTEND!!'
        return struct.unpack('<i',struct.pack('<I',self.u.reg_read(UC_ARM64_REG_W0)))[0]
    def op(self,name,now,*args,gen=77):
        return self.call('SkPdFrs'+name,self.f,gen,now,*args,self.out)
    def evidence(self,now,flags=15,budget=1500,generation=77,sample=None):
        self.u.mem_write(self.env,struct.pack('<4I',generation,flags,now if sample is None else sample,budget))
    def output(self):
        flags,gen,token,current,tgen,ttoken,n=struct.unpack('<7I',bytes(self.u.mem_read(self.out,28)))
        assert n<=32
        return dict(Flags=flags,Generation=gen,HardwareToken=token,Current=current,
                    TxGeneration=tgen,TxToken=ttoken,Frame=bytes(self.u.mem_read(self.out+28,n)))
    def state(self):return self.get(self.f+32)
    def hwtoken(self):return self.get(self.f+52)
    def query(self,now=1,grant=1,**proof):
        self.evidence(now,**proof);return self.op('Query',now,grant,self.env)
    def ack(self,now=2,result=1,token=None):
        if token is None:token=self.output()['TxToken']
        return self.op('TxComplete',now,token,result)
    def receive(self,p,now=3,gen=77):
        self.u.mem_write(self.rx,p);return self.op('Receive',now,self.rx,len(p),gen=gen)
    def capable(self,current=2,default=None,budget=1500):
        assert self.query(budget=budget)==0
        assert self.output()['Frame']==packet(8,6,power=0,data=self.data)
        assert self.ack()==0
        assert self.receive(packet(4,data=1-self.data,payload=struct.pack('<I',sinkpdo(current))))==0
        assert self.state()==3
    def arm(self,now=4,**proof):
        self.evidence(now,**proof);return self.op('Arm',now,self.env)
    def armed(self):
        self.capable();assert self.arm()==0
        assert self.output()['Flags']==1 and self.output()['Current']==1500
        assert self.op('ArmComplete',5,self.hwtoken(),1)==0 and self.state()==5
    def signal(self,now=6,**proof):
        self.evidence(now,flags=14,**proof);return self.op('Signal',now,self.hwtoken(),self.env)
    def accept(self,now=8):
        return self.receive(packet(3,2,data=1-self.data),now)
    def off(self,now=9,power=0):
        return self.receive(packet(6,3,power=power,data=1-self.data),now)
    def source_ready(self,now=10,voltage=5000,charge_off=1,sourcing=1,
                     conversion=None,serial=1,generation=77,token=None,null=False):
        self.u.mem_write(self.source_proof,struct.pack('<7I',generation,
            self.hwtoken() if token is None else token,now if conversion is None else conversion,
            serial,voltage,sourcing,charge_off))
        return self.op('SourceReady',now,0 if null else self.source_proof)
    def poll(self,now,**proof):
        self.evidence(now,**proof);return self.op('Poll',now,self.env)
    def finish(self,**extra):
        ROWS.append(dict(Case=self.name,Base=hex(self.base),ARM64Calls=self.calls,
                         State=self.state(),SessionPowerRole=self.get(self.s+4),
                         SessionDataRole=self.get(self.s+8),**extra))

for base in (0x140000000,0x180000000):
    for data in (0,1):
        r=Replay(base,'complete-FRS-keeps-data-role',data=data);r.armed()
        assert r.signal()==0 and r.output()['Flags']==4
        assert r.output()['Frame']==packet(19,7,power=0,data=data)
        assert r.ack(7)==0 and r.accept()==0
        assert r.accept(9)==2 # duplicate Accept after advancing state
        assert r.off(10)==0 and r.get(r.s+4)==0
        assert r.off(11)==2
        assert r.source_ready(12)==0
        assert r.output()['Flags']==8 and r.get(r.s+4)==0
        assert r.off(13)==2
        assert r.op('HeaderComplete',14,r.hwtoken(),1)==0
        assert r.output()['Frame']==packet(6,0,power=1,data=data)
        assert r.ack(15)==0 and r.state()==12 and r.output()['Flags']==16
        assert r.get(r.s+8)==data and r.get(r.s+32)==1 and r.get(r.s+24)==0
        r.finish(DataRoleNeverChanged=True)
    for current,budget,default,accepted in ((0,1500,900,False),(1,500,500,True),
            (1,500,900,False),(1,900,900,True),(2,1000,900,False),
            (2,1500,900,True),(3,1500,900,False),(3,3000,900,True)):
        r=Replay(base,f'current-{current}-budget-{budget}-usbdefault-{default}',default=default)
        assert r.query(budget=budget)==0 and r.ack()==0
        status=r.receive(packet(4,payload=struct.pack('<I',sinkpdo(current))))
        assert status==(0 if current else 6)
        if current:assert r.arm(budget=budget)==(0 if accepted else -40)
        assert not r.get(r.s+20) and not r.get(r.s+24)
        r.finish()
    for kind in (4,12,16):
        r=Replay(base,f'query-refusal-{kind}')
        assert r.query()==0 and r.ack()==0
        assert r.receive(packet(kind))==6 and r.state()==14
        assert r.output()['Flags']==0 and r.get(r.s+20)==0 and r.get(r.s+24)==0
        r.finish()
    for pdo in (sinkpdo(drp=0),sinkpdo(voltage=9000),sinkpdo(operating=0),0xc0000000):
        r=Replay(base,f'invalid-or-non-DRP-sinkpdo-{pdo:x}')
        assert r.query()==0 and r.ack()==0
        status=r.receive(packet(4,payload=struct.pack('<I',pdo)))
        assert status==(6 if pdo==sinkpdo(drp=0) else -4)
        assert r.state() in (13,14) and r.get(r.f+68)==0;r.finish()
    r=Replay(base,'PD2-never-arms-FRS');r.put(r.s+12,1)
    assert r.query()==-40 and r.output()['Frame']==b'' and r.arm()==-41;r.finish()
    r=Replay(base,'SinkTxNG-defers-query')
    assert r.query(grant=0)==7 and r.get(r.s+24)==0 and r.output()['Frame']==b'';r.finish()
    r=Replay(base,'shared-AMS-prevents-query')
    assert r.call('SkPdSessionAcquire',r.s,77,1)==0 and r.query()==-20;r.finish()
    r=Replay(base,'native-owner-revoked-while-armed');r.armed();r.put(r.s+16,0)
    assert r.poll(6)==-23 and r.output()['Flags']==38 and r.get(r.f+68)==1;r.finish()
    for missing in (1,2,4,8):
        r=Replay(base,f'arm-needs-proof-{missing}')
        r.capable();assert r.arm(flags=15&~missing)==-40
        assert r.output()['Flags']==0 and r.get(r.f+68)==0;r.finish()
        r=Replay(base,f'armed-revocation-{missing}');r.armed()
        assert r.poll(6,flags=15&~missing)==-40
        assert r.output()['Flags']==38 and r.get(r.f+68)==1;r.finish()
    for sample,generation,budget in ((100,77,1500),(0,78,1500),(0,77,1000)):
        r=Replay(base,'arm-stale-or-reduced-proof');r.capable()
        assert r.arm(sample=sample,generation=generation,budget=budget)==-40;r.finish()
    for changed_offset,value in ((4,1),(8,0),(12,1),(24,1)):
        r=Replay(base,f'armed-session-change-{changed_offset}');r.armed();r.put(r.s+changed_offset,value)
        assert r.poll(6) in (-40,-20) and r.output()['Flags']==38;r.finish()
    for verified in (0,2):
        r=Replay(base,f'failed-arm-{verified}');r.capable();assert r.arm()==0
        assert r.op('ArmComplete',5,r.hwtoken(),verified)==-40
        assert r.get(r.f+68)==1 and r.output()['Flags']==38
        assert r.call('SkPdFrsDisarmComplete',r.f,78,r.hwtoken(),1)==-21
        assert r.call('SkPdFrsDisarmComplete',r.f,77,r.hwtoken(),0)==-40
        assert r.get(r.f+68)==1
        assert r.call('SkPdFrsDisarmComplete',r.f,77,r.hwtoken(),1)==0
        assert r.get(r.f+68)==0 and r.state()==13;r.finish()
    r=Replay(base,'ordinary-disarm-does-not-reset-wire');r.armed()
    before=bytes(r.u.mem_read(r.s,120));oldtoken=r.hwtoken()
    assert r.op('Disarm',6)==0 and r.output()['Flags']==2
    assert r.poll(7)==0
    assert r.call('SkPdFrsDisarmComplete',r.f,77,oldtoken,1)==0
    assert r.state()==0 and bytes(r.u.mem_read(r.s,120))==before
    assert r.query(8)==0 and r.ack(9)==0
    assert r.receive(packet(4,2,payload=struct.pack('<I',sinkpdo())),10)==0
    assert r.arm(11)==0 and r.hwtoken()==oldtoken+1
    assert r.op('ArmComplete',12,oldtoken,1)==-21 and r.state()==4;r.finish()
    r=Replay(base,'requery-can-discover-lower-current')
    r.capable(current=3,budget=3000)
    assert r.query(4,budget=1500)==0 and r.ack(5)==0
    assert r.receive(packet(4,2,payload=struct.pack('<I',sinkpdo(2))),6)==0
    assert r.arm(7,budget=1500)==0;r.finish()
    r=Replay(base,'query-no-answer-preserves-fixed-contract')
    assert r.query()==0 and r.ack()==0 and r.poll(32)==6
    assert r.state()==14 and not r.get(r.s+20) and r.get(r.s+32)==7;r.finish()
    for phase,deadline in (('query',101),('arm',104),('accept',37),('sourceoff',508),('sourceready',24)):
        r=Replay(base,'timeout-'+phase)
        if phase=='query':assert r.query()==0
        elif phase=='arm':r.capable();assert r.arm()==0
        else:
            r.armed();assert r.signal()==0 and r.ack(7)==0
            if phase!='accept':assert r.accept()==0
            if phase=='sourceready':assert r.off()==0
        assert r.poll(deadline,flags=14 if phase in ('accept','sourceoff','sourceready') else 15)==-43
        assert r.state()==13 and r.output()['Flags']&32;r.finish()
    for result in (2,3):
        r=Replay(base,f'FR_SWAP-TX-failure-{result}');r.armed()
        assert r.signal()==0 and r.ack(7,result)==-23
        assert r.output()['Flags']==38 and r.get(r.f+68)==1;r.finish()
    r=Replay(base,'old-power-role-PS_RDY-rejected');r.armed()
    assert r.signal()==0 and r.ack(7)==0 and r.accept()==0
    assert r.off(power=1)==-4 and r.get(r.s+4)==0 and r.output()['Flags']==38;r.finish()
    for voltage,charge_off in ((12000,1),(0,1),(4749,1),(5501,1),(5000,0)):
        r=Replay(base,f'no-source-ready-with-{voltage}-chargeoff-{charge_off}');r.armed()
        assert r.signal()==0 and r.ack(7)==0 and r.accept()==0 and r.off()==0
        assert r.source_ready(10,voltage=voltage,charge_off=charge_off)==-40
        assert r.get(r.s+4)==0 and r.output()['Flags']==38;r.finish()
    r=Replay(base,'source-header-write-failure');r.armed()
    assert r.signal()==0 and r.ack(7)==0 and r.accept()==0 and r.off()==0
    assert r.source_ready()==0
    assert r.op('HeaderComplete',11,r.hwtoken(),0)==-40 and r.get(r.s+4)==0;r.finish()
    r=Replay(base,'clock-regression-while-armed');r.armed()
    assert r.poll(4)==-42 and r.output()['Flags']==38;r.finish()
    r=Replay(base,'wrapped-monotonic-clock',now=0xfffffff0)
    assert r.query(1)==0 and r.ack(2)==0;r.finish()
    r=Replay(base,'stale-generation-no-actions');r.armed()
    assert r.op('Signal',6,r.hwtoken(),r.env,gen=78)==-21
    assert r.output()['Flags']==0 and r.state()==5;r.finish()
    r=Replay(base,'swap-ready-entry-needs-authorized-lease')
    p=packet(6,power=0);r.u.mem_write(r.rx,p)
    assert r.call('SkPdSessionReceiveSwapReady',r.s,77,r.rx,len(p),r.h)==-22
    assert r.get(r.s+4)==0;r.finish()
    for proof in ({'sourcing':0},{'conversion':8},{'conversion':11},{'serial':0},
                  {'generation':78},{'token':2},{'null':True}):
        r=Replay(base,'source-ready-missing-fresh-physical-proof-'+str(proof));r.armed()
        assert r.signal()==0 and r.ack(7)==0 and r.accept()==0 and r.off()==0
        assert r.source_ready(**proof)==-40 and r.output()['Flags']==38
        assert r.get(r.s+4)==0;r.finish()

result=dict(Passed=True,Scenarios=len(ROWS),ARM64Calls=sum(x['ARM64Calls'] for x in ROWS),
    ImageSHA256=hashlib.sha256(RAW).hexdigest(),Cases=ROWS,
    SourcePins=[dict(File=p.name,SHA256=hashlib.sha256(p.read_bytes()).hexdigest())
                for p in (ROOT/'src').glob('*.c')],
    HardwareIO=False,HardwareFRSBound=False,Installable=False,
    Sub150usPhysicalTransitionProven=False,HubContinuityProven=False,
    NativeTcpciOwnerReplaced=False,PowerRoleSwapKeepsDataRole=True,
    Scope='Actual ARM64 component; physical arm, TX completion, VBUS and charge-off confirmations modeled.')
(ROOT/'frs-transport-qa.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('Cases','SourcePins')},indent=2))
