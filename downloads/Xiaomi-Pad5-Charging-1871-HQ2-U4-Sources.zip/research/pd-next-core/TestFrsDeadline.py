"""Late callbacks from this attachment must service the active FRS deadline.

Run the old/fixed ARM64 image. Physical power, kernel and sensors are modeled.
Stale generations still cannot mutate a new attachment.
"""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
unfixed='--expect-unfixed' in sys.argv
helper=root/'TestFrsTransport.py'
scope={'__file__':str(helper)}
exec(compile(helper.read_text().split('\nfor base in (')[0],str(helper),'exec'),scope)
Replay=scope['Replay'];rows=[]

def phase(r,name):
    if name=='QueryTX':
        assert r.query()==0
        return 'TxComplete',101,(r.output()['TxToken'],1),False
    r.capable();assert r.arm()==0
    if name=='ArmPending':return 'ArmComplete',104,(r.hwtoken(),1),True
    assert r.op('ArmComplete',5,r.hwtoken(),1)==0
    if name=='Armed':return 'Signal',6,(r.hwtoken(),r.env),True
    assert r.signal()==0
    if name=='SwapTX':return 'TxComplete',106,(r.output()['TxToken'],1),True
    assert r.ack(7)==0 and r.accept()==0 and r.off()==0
    assert r.source_ready()==0
    if name=='HeaderPending':return 'HeaderComplete',24,(r.hwtoken(),1),True
    assert r.op('HeaderComplete',11,r.hwtoken(),1)==0
    return 'TxComplete',111,(r.output()['TxToken'],1),True

for base in (0x140000000,0x180000000):
    for name in ('QueryTX','ArmPending','Armed','SwapTX','HeaderPending','PSReadyTX'):
        for mode in ('zero-token','wrong-token','stale-generation','clock-regression'):
            r=Replay(base,name+'-'+mode)
            fn,now,args,armed=phase(r,name)
            args=list(args)
            r.evidence(now,flags=14 if name!='ArmPending' else 15)
            before=bytes(r.u.mem_read(r.f,r.size)),bytes(r.u.mem_read(r.s,120))
            if mode=='zero-token':args[0]=0
            if mode in ('wrong-token','clock-regression'):args[0]+=100
            if mode=='clock-regression':now=r.get(r.f+36)-1
            result=r.op(fn,now,*args,gen=78 if mode=='stale-generation' else 77)
            if mode=='stale-generation' or unfixed:
                assert result==-21 and r.output()['Flags']==0
                assert before==(bytes(r.u.mem_read(r.f,r.size)),bytes(r.u.mem_read(r.s,120)))
            elif name=='Armed' and mode!='clock-regression':
                # No finite phase deadline while safely armed; an unrelated
                # token is rejected without canceling the active latch.
                assert result==-21 and r.output()['Flags']==0 and r.state()==5
            else:
                assert result==(-42 if mode=='clock-regression' else -43)
                assert r.state()==13 and r.get(r.s+20)==1
                assert r.output()['Flags']==(38 if armed else 36)
                assert r.get(r.f+68)==int(armed)
            rows.append(dict(Case=r.name,Base=hex(base),Result=result,Flags=r.output()['Flags'],
                State=r.state(),ArmObligation=r.get(r.f+68),ARM64Calls=r.calls))
report=dict(Passed=True,DefectReproduced=unfixed,Scenarios=len(rows),
    ARM64Calls=sum(x['ARM64Calls'] for x in rows),ImageSHA256=hashlib.sha256(scope['RAW']).hexdigest(),
    Cases=rows,HardwareIO=False,DriverChanged=False,Installable=False)
target=root/('deadline-before.json' if unfixed else 'deadline-fixed-qa.json')
target.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='Cases'},indent=2))
