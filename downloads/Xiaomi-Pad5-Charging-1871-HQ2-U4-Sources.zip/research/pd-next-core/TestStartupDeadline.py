"""A slow RCP transaction must not overrun the 100ms converter startup bound.

Explicit ADC/IRQ/bus/clock model; the compiled ARM64 functions execute.
"""
from pathlib import Path
import hashlib
import json
import sys

root = Path(__file__).resolve().parent
scope = {'__file__': str(root / 'TestAdc.py')}
exec(compile((root / 'TestAdc.py').read_text().split('\nfor base in (')[0],
             scope['__file__'], 'exec'), scope)
Adc = scope['Adc']
before = '--expect-before' in sys.argv
rows = []

for base in (0x140000000, 0x180000000):
    pilot = Adc(base, 'RCP boundary measurement')
    pilot.fresh()
    assert pilot.sampled_start() == 0x103
    pilot.now = 124
    pilot.fresh()  # converter start34, current128, newest ADC earliest126
    pilot.set_permit(now=pilot.now)
    first = len(pilot.ln_io)
    assert pilot.sampled_poll() == 0
    boundary = next(i + 1 for i, e in enumerate(pilot.ln_io[first:])
                    if e['Kind'] == 'Write' and e['Register'] == 0x1e)

    r = Adc(base, 'late RCP confirmation')
    r.fresh()
    assert r.sampled_start() == 0x103
    r.now = 124
    r.fresh()
    r.set_permit(now=r.now)
    r.delay_ms = 12
    r.delay_index = len(r.ln_io) + boundary
    s = r.sampled_poll()
    if before:
        assert s == 0 and r.fast() == (0, 1, 1)
    else:
        assert s == 0xc00000b5 and r.fast() == (0, 0, 0)
        assert r.lregs[3] == 2
    rows.append(dict(Base=hex(base), Result=hex(s), ClockMs=r.now,
                     StartupElapsedMs=r.now - 34, LatestSampleEarliestMs=126,
                     SafetyObservedAtMs=128, RcpTransferBoundary=boundary,
                     Fast=r.fast(), ARM64Calls=r.calls))

report = dict(Passed=True, Counterexample=before, Scenarios=len(rows),
              ARM64Calls=sum(x['ARM64Calls'] for x in rows),
              ImageSHA256=hashlib.sha256((root / 'build/sk_pps_charge_binding.component.dll').read_bytes()).hexdigest(),
              HardwareIO=False, FastChargingFixProven=False,
              HubContinuityFixProven=False, Cases=rows)
name = 'startup-deadline-before.json' if before else 'startup-deadline-qa.json'
(root / name).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
