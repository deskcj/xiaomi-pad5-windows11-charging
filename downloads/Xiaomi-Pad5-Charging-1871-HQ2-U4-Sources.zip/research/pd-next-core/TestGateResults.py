"""Informational/PENDING results cannot authorize a physical pump command."""
from pathlib import Path
import hashlib
import json
import struct
from unicorn.arm64_const import UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_X2

root = Path(__file__).resolve().parent
scope = {'__file__': str(root / 'TestAdc.py')}
exec(compile((root / 'TestAdc.py').read_text().split('\nfor base in (')[0],
             scope['__file__'], 'exec'), scope)
Adc = scope['Adc']
rows = []


class GateAdc(Adc):
    def __init__(self, base, status, fail_at):
        self.gate_ready = False
        super().__init__(base, 'permission status boundary')
        self.check_fn = 0x2100d040
        self.gate = 0x2100b000
        self.status, self.fail_at, self.validations = status, fail_at, 0
        self.gate_ready = True

    def hook(self, u, address, size, data):
        if self.gate_ready and address == self.check_fn:
            assert u.reg_read(UC_ARM64_REG_X0) == 0x8899
            assert u.reg_read(UC_ARM64_REG_X1) == 77
            assert u.reg_read(UC_ARM64_REG_X2) == self.now
            self.validations += 1
            self.ret(self.status if self.validations >= self.fail_at else 0)
            return
        super().hook(u, address, size, data)

    def start_gated(self):
        self.fresh()
        self.set_proof(now=self.now, sample=self.now - 2, flags=63)
        self.u.mem_write(self.gate, struct.pack('<4QI4x', self.clock, 0x6789,
                                               self.check_fn, 0x8899, self.now))
        return self.call('SkLn8000Begin2To1Gated', self.lctx, 77, self.now,
                         self.proof, self.gate)


for base in (0x140000000, 0x180000000):
    for status in (0x103, 1, 0xc0000185):
        for fail_at in (1, 3, 6):
            r = GateAdc(base, status, fail_at)
            expected = 0xc00000a3 if status < 0x80000000 else status
            assert r.start_gated() == expected
            assert r.fast() == (0, 0, 0) and r.lregs[3] == 2
            rows.append(dict(Base=hex(base), Permission=hex(status),
                             ValidationBoundary=fail_at, ARM64Calls=r.calls))
    r = GateAdc(base, 0, 1)
    assert r.start_gated() == 0x103 and r.fast() == (1, 0, 1)
    assert r.validations == 6
    rows.append(dict(Base=hex(base), Case='AllSixPhysicalCommandChecksGranted', ARM64Calls=r.calls))

report = dict(Passed=True, Scenarios=len(rows),
              ARM64Calls=sum(r['ARM64Calls'] for r in rows),
              ImageSHA256=hashlib.sha256((root / 'build/sk_pps_charge_binding.component.dll').read_bytes()).hexdigest(),
              HardwareIO=False, FastChargingFixProven=False,
              HubContinuityFixProven=False, Cases=rows)
(root / 'gate-results-qa.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k != 'Cases'}, indent=2))
