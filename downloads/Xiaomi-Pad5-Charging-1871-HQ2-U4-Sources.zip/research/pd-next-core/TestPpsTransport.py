"""Execute PPS session/guard -> PMIC TX and PMIC RX -> session/guard.

The compiled bodies run; bus, IRQ completion, sensors and confirmed fixed
baseline are modeled. This is not physical PPS/charge-pump acceptance.
"""
from pathlib import Path
import hashlib,json,struct
ROOT=Path(__file__).resolve().parent
source=(ROOT/'TestPpsExchange.py').read_text().split('\nfor base in (')[0]
source=source.replace("RAW=(ROOT/'build-frs-transport/sk_pd_frs_transport.component.dll').read_bytes()",
    "RAW=(ROOT/'build-frs-transport/sk_pd_frs_transport.component.dll').read_bytes()")
source=source.replace("EXPORTS['SkPdPpsExchange'+name]", "EXPORTS[name if name.startswith('Sk') else 'SkPdPpsExchange'+name]")
scope={'__file__':str(ROOT/'TestPpsExchange.py')}
exec(compile(source,str(ROOT/'TestPpsExchange.py'),'exec'),scope)
Exchange=scope['Exchange'];ARGS=scope['ARGS'];packet=scope['packet']
ROWS=[]
class Transport(Exchange):
    def __init__(self,base,name,revision=2):
        self.bus_ready=False
        super().__init__(base,name)
        self.tx_ctx=0x20008000;self.tx_ops=0x20008400
        self.rx_ctx=0x20009000;self.rx_ops=0x20009400
        self.rx_frame=0x2000a000;self.rx_length=0x2000a040;self.rx_token=0x2000a048
        self.read_fn=0x2000d000;self.write_fn=0x2000d010;self.update_fn=0x2000d020;self.delay_fn=0x2000d030
        self.u.mem_write(self.tx_ops,struct.pack('<4Q',self.read_fn,self.write_fn,self.update_fn,self.delay_fn))
        self.u.mem_write(self.rx_ops,struct.pack('<2Q',self.read_fn,self.update_fn))
        self.bus_ready=True;self.registers={0x1744:b'\0',0x174b:b'\0',0x1740:b'\xf0',0x1742:b'\xe0'}
        self.io=[];self.fail_send=0;self.fail_ack=0
        assert self.call('SkPmicTxInitialize',self.tx_ctx,self.tx_ops,0x1234,2,0x1700,77,1)==0
        assert self.call('SkPmicRxInitialize',self.rx_ctx,self.rx_ops,0x1234,2,0x1700)==0
        self.baseline(rev=revision)
    def ret(self,status):
        self.u.reg_write(scope['UC_ARM64_REG_X0'],status)
        self.u.reg_write(scope['UC_ARM64_REG_PC'],self.u.reg_read(scope['UC_ARM64_REG_LR']))
    def hook(self,u,a,n,unused):
        if not self.bus_ready or a not in (self.read_fn,self.write_fn,self.update_fn,self.delay_fn):
            return super().hook(u,a,n,unused)
        x=[u.reg_read(r) for r in ARGS];assert x[:2]==[0x1234,2]
        if a==self.delay_fn:
            self.io.append(('Delay',0,2,None));self.ret(0);return
        reg,p,v=x[2:5];status=0
        if a==self.read_fn:
            content=self.registers[reg];assert len(content)==v
            u.mem_write(p,content);self.io.append(('Read',reg,v,None))
        elif a==self.write_fn:
            content=bytes(u.mem_read(p,v));self.registers[reg]=content
            self.io.append(('Write',reg,v,content.hex()))
        else:
            self.io.append(('Update',reg,p,v))
            self.registers[reg]=bytes([(self.registers[reg][0]&~p)|(v&p)])
            if reg==0x1744 and v&1:status=self.fail_send
            if reg==0x174b:status=self.fail_ack
        self.ret(status)
    def send(self):return self.call('SkPmicTxSubmit',self.tx_ctx,self.out+16)
    def goodcrc(self,now=2):
        token=self.output()[1][1]
        self.registers[0x1744]=b'\0'
        result=self.call('SkPmicTxComplete',self.tx_ctx,77,token,1)
        if result:return result
        return self.ack(now,token=token)[0]
    def phy_receive(self,p,now):
        self.registers.update({0x174b:b'\x01',0x174a:b'\0',0x1748:bytes([len(p)-3]),
            0x1780:p[2:4],0x1782:p[4:]})
        self.u.mem_write(self.rx_length,struct.pack('<I',32))
        r=self.call('SkPmicRxRead',self.rx_ctx,self.rx_frame,self.rx_length,self.rx_token)
        token=struct.unpack('<I',bytes(self.u.mem_read(self.rx_token,4)))[0]
        if token:
            ack=self.call('SkPmicRxRelease',self.rx_ctx,token)
            if ack:return ack
        if r:return r
        n=struct.unpack('<I',bytes(self.u.mem_read(self.rx_length,4)))[0]
        copy=bytes(self.u.mem_read(self.rx_frame,n));assert copy==p
        return self.receive(copy,now)[0]
    def active_phy(self):
        assert self.begin()[0]==0
        assert self.send()==0 and self.state()==(1,0)
        # Register submission has not activated fast charging or advanced the
        # wire session. Only the modeled physical completion does so here.
        assert self.registers[0x1762]==struct.pack('<I',0x3303843c)
        assert self.goodcrc()==0
        assert self.phy_receive(packet(3,5),3)==0
        assert self.phy_receive(packet(6,6),4)==0 and self.state()==(4,0)
        assert self.observe(5)[0]==0 and self.state()==(5,1)
    def finish(self):
        ROWS.append(dict(Name=self.name,Base=hex(self.base),ARM64Calls=self.calls,
            SPMIOperations=len(self.io),GuardState=self.state()))

for base in (0x140000000,0x180000000):
    e=Transport(base,'PPS-Request-to-registers-ACK-Accept-PS_RDY-ADC')
    e.active_phy();e.finish()

    e=Transport(base,'PD2-baseline-preserves-ordinary-charge-without-PPS-transmit',revision=1)
    assert e.begin()[0]==-8 and not e.io;e.finish()

    e=Transport(base,'register-success-alone-cannot-enable-PPS')
    assert e.begin()[0]==0 and e.send()==0 and e.state()==(1,0)
    assert e.observe(2)[0]!=0 and e.state()[1]==0;e.finish()

    e=Transport(base,'early-Accept-before-TX-completion-demands-recovery')
    assert e.begin()[0]==0 and e.send()==0
    assert e.phy_receive(packet(3,5),2)==-6
    assert e.state()==(6,0);e.finish()

    for error in (0xc0000185,0x103):
        e=Transport(base,'ambiguous-Send-error-or-pending-cannot-confirm-PPS-'+hex(error))
        assert e.begin()[0]==0;e.fail_send=error
        assert e.send()&0xffffffff==0xc0000185
        assert e.call('Fault',e.s,77,2,e.out)==0
        assert e.output()[0][0]==10 and e.state()==(6,0)
        e.finish()

    e=Transport(base,'failed-RX-ACK-does-not-publish-Accept')
    assert e.begin()[0]==0 and e.send()==0 and e.goodcrc()==0
    e.fail_ack=0xc0000185
    assert e.phy_receive(packet(3,5),3)&0xffffffff==0xc0000185
    assert e.state()==(2,0)
    assert e.call('Fault',e.s,77,3,e.out)==0 and e.state()==(6,0);e.finish()

    e=Transport(base,'refresh-keeps-session-MessageID-and-needs-complete-handshake')
    e.active_phy();e.refresh_samples()
    assert e.poll(7002)[0]==0
    assert e.output()[1][2]==packet(2,1,2,0,0,struct.pack('<I',0x3303843c))
    assert e.send()==0 and e.state()==(1,1) and e.goodcrc(7003)==0
    assert e.phy_receive(packet(3,7),7004)==0
    assert e.phy_receive(packet(6,0),7005)==0
    assert e.observe(7006)[0]==0 and e.state()==(5,1);e.finish()

result=dict(Passed=True,Scenarios=len(ROWS),ARM64Calls=sum(x['ARM64Calls'] for x in ROWS),
    ImageSHA256=hashlib.sha256(scope['RAW']).hexdigest(),Cases=ROWS,
    SessionGuardPMICCompiledBodiesExecuted=True,BusIRQADCAndFixedBaselineModelled=True,
    RealPDOrChargePumpIO=False,RealPpsPowerMeasured=False,
    NativeDPCMappingIntegrated=False,FullFixedOrSourcePolicyImplemented=False,
    WindowsPpsReportingIntegrated=False,Installable=False,Installed=False,
    HubContinuityProven=False,PpsHardwareProven=False)
(ROOT/'pps-transport-qa.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='Cases'},indent=2))
