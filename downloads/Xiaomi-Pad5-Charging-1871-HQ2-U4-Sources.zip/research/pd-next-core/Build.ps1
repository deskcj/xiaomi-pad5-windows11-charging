$ErrorActionPreference='Stop'
$skCompiler='H:\Vlad\EWDK\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207\bin\Hostarm64\arm64'
$skKit='H:\Vlad\EWDK\Program Files\Windows Kits\10'
$skInclude=@('/external:W0','/analyze:external-',
 '/external:IH:\Vlad\EWDK\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207\include',
 "/external:I$skKit\Include\10.0.26100.0\km","/external:I$skKit\Include\10.0.26100.0\shared","/external:I$skKit\Include\10.0.26100.0\ucrt")
$skOut=Join-Path $PSScriptRoot 'build'
New-Item -ItemType Directory -Path $skOut -Force | Out-Null
$skObjects=@()
foreach($skUnit in 'sk_pd_protocol','sk_pd_session','sk_pps_guard','sk_pd_pps_exchange',
 'sk_pd_fixed_exchange','sk_pmic_pd_tx','sk_pmic_pd_rx','sk_ln8000','sk_ln8000_profile',
 'sk_ln8000_config','sk_pps_charge_path','sk_ln8000_adc','sk_pd_frs') {
 $skFile=Join-Path $PSScriptRoot ('src\'+$skUnit+'.c')
 & "$skCompiler\cl.exe" /nologo /c /TC /kernel /GS /guard:cf /O2 /W4 /WX /analyze /Zl /D_ARM64_ /DARM64 @skInclude $skFile "/Fo$skOut\$skUnit-analyzed.obj" *> "$skOut\$skUnit-analysis.log"
 if($LASTEXITCODE -ne 0) {Get-Content -LiteralPath "$skOut\$skUnit-analysis.log";throw 'Analysis failed'}
 & "$skCompiler\cl.exe" /nologo /c /TC /kernel /GS- /O2 /W4 /WX /Zl /D_ARM64_ /DARM64 @skInclude $skFile "/Fo$skOut\$skUnit.obj" *> "$skOut\$skUnit-compile.log"
 if($LASTEXITCODE -ne 0) {Get-Content -LiteralPath "$skOut\$skUnit-compile.log";throw 'Compile failed'}
 $skObjects+="$skOut\$skUnit.obj"
}
$skExports=@('Size','Initialize','Probe','Snapshot','Decode','Standby','BatteryTemperature','Begin2To1','Poll2To1','ReadProfile') | ForEach-Object {'/EXPORT:SkLn8000'+$_}
$skExports+=@('Size','Initialize','Apply','Check','Stop','Begin2To1','Poll2To1') | ForEach-Object {'/EXPORT:SkLnConfig'+$_}
$skExports+=@('Size','Initialize','ConsumeAction','Configure','Begin','Poll','Stop') | ForEach-Object {'/EXPORT:SkPpsPath'+$_}
$skExports+=@('Size','Initialize','Arm','Poll','Cancel') | ForEach-Object {'/EXPORT:SkLnAdc'+$_}
$skExports+=@('/EXPORT:SkLnAdcCopyReady','/EXPORT:SkLn8000Begin2To1Timed',
 '/EXPORT:SkLn8000Poll2To1Timed','/EXPORT:SkLnConfigBegin2To1Timed',
 '/EXPORT:SkLnConfigPoll2To1Timed','/EXPORT:SkPpsPathBeginSampled',
 '/EXPORT:SkPpsPathPollSampled')
$skExports+=@('/EXPORT:SkLn8000Begin2To1Gated','/EXPORT:SkLn8000Poll2To1Gated',
 '/EXPORT:SkLnConfigBegin2To1Gated','/EXPORT:SkLnConfigPoll2To1Gated',
 '/EXPORT:SkPpsPathTakeAction')
$skExports+=@('Initialize','Receive','ConfirmFixed','Begin','TxComplete','Observe','Poll','Fault','Size') | ForEach-Object {'/EXPORT:SkPdPpsExchange'+$_}
$skExports+=@('Initialize','Begin','TxComplete','Receive','Observe','Poll','Fault','Size') | ForEach-Object {'/EXPORT:SkPdFixed'+$_}
$skExports+=@('Initialize','Submit','Complete','Size') | ForEach-Object {'/EXPORT:SkPmicTx'+$_}
$skExports+=@('Initialize','Read','Release','Size') | ForEach-Object {'/EXPORT:SkPmicRx'+$_}
$skExports+=@('Size','Initialize','Query','Receive','TxComplete','Arm','ArmComplete','Signal','SourceReady','HeaderComplete','Poll','Disarm','DisarmComplete') | ForEach-Object {'/EXPORT:SkPdFrs'+$_}
$skExports+=@('Initialize','Acquire','Release','Transmit','TxComplete','PpsRequest','Reset','Receive','ReceiveSwapReady','SetRoles') | ForEach-Object {'/EXPORT:SkPdSession'+$_}
& "$skCompiler\link.exe" /nologo /DLL /NOENTRY /NODEFAULTLIB /MACHINE:ARM64 /INCREMENTAL:NO "/OUT:$skOut\sk_pps_charge_binding.component.dll" @skExports @skObjects *> "$skOut\link.log"
if($LASTEXITCODE -ne 0) {Get-Content -LiteralPath "$skOut\link.log";throw 'Link failed'}
Get-FileHash -LiteralPath "$skOut\sk_pps_charge_binding.component.dll" -Algorithm SHA256
