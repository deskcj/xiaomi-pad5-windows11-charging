#ifndef SK_PD_SESSION_H
#define SK_PD_SESSION_H
#include "sk_pd_protocol.h"

/* SOP-only wire session, driven ONLY by the single runtime consumer.
 * Local AMS lease != normative PD3 SinkTxNG/AMS arbitration. The device
 * adapter must stop native TCPM first, implement PD policy/timers, and map
 * successful PHY TX completion to verified GoodCRC before use on hardware.
 * This module performs no I/O, role swap, voltage selection or reporting.
 */
enum {
    SK_PD_SESSION_BUSY=-20, SK_PD_SESSION_STALE=-21,
    SK_PD_SESSION_NOT_READY=-22, SK_PD_SESSION_DUPLICATE=2,
    SK_PD_SESSION_SOFT_RESET=3, SK_PD_SESSION_RECOVERY=-23,
    SK_PD_SESSION_TX_SUCCESS=1, SK_PD_SESSION_TX_FAILED=2,
    SK_PD_SESSION_TX_DISCARDED=3
};
typedef struct SK_PD_SESSION {
    SK_PD_U32 Generation, PowerRole, DataRole, Revision;
    SK_PD_U32 NativeStopped, Faulted, Lease, NextToken;
    SK_PD_U32 TxMessageId, PendingToken, PendingBytes;
    SK_PD_U32 RxValid, RxMessageId, RxBytes;
    unsigned char Pending[32], LastRx[32];
} SK_PD_SESSION;
typedef struct SK_PD_SESSION_TX {
    SK_PD_U32 Generation, Token, FrameBytes;
    unsigned char Frame[32];
} SK_PD_SESSION_TX;
typedef struct SK_PD_SESSION_PPS_REQUEST {
    SK_PD_U32 Pdo, Position, Millivolts, Milliamps, Flags;
} SK_PD_SESSION_PPS_REQUEST;

int SkPdSessionInitialize(SK_PD_SESSION *, SK_PD_U32 Generation,
                         SK_PD_U32 PowerRole, SK_PD_U32 DataRole,
                         SK_PD_U32 NativeStopped);
int SkPdSessionAcquire(SK_PD_SESSION *, SK_PD_U32 Generation, SK_PD_U32 Lease);
int SkPdSessionRelease(SK_PD_SESSION *, SK_PD_U32 Generation, SK_PD_U32 Lease);
int SkPdSessionTransmit(SK_PD_SESSION *, SK_PD_U32 Generation, SK_PD_U32 Lease,
                       SK_PD_U32 MessageType, const unsigned char *Payload,
                       SK_PD_U32 PayloadBytes, SK_PD_SESSION_TX *);
int SkPdSessionTxComplete(SK_PD_SESSION *, SK_PD_U32 Generation,
                         SK_PD_U32 Token, SK_PD_U32 Result);
/* PPS must use the session's negotiated revision, never a hardcoded PD3
 * header beside a downgraded/native PD2 owner. Board/thermal/PDP/ADC limits
 * and handshake still come from sk_pps_guard and the complete device policy.
 */
int SkPdSessionPpsRequest(SK_PD_SESSION *, SK_PD_U32 Generation, SK_PD_U32 Lease,
                         const SK_PD_SESSION_PPS_REQUEST *, SK_PD_SESSION_TX *);
int SkPdSessionReceive(SK_PD_SESSION *, SK_PD_U32 Generation,
                      const unsigned char *Frame, SK_PD_U32 FrameBytes,
                      SK_PD_HEADER *);
/* Only the FRS owner, lease 3, after matching FR_SWAP/Accept may route the
 * initial Source's PS_RDY through this entry. That peer header says Sink.
 * This narrowly permits PD3 SOP PS_RDY with unchanged opposite data role;
 * it never changes local roles or relaxes the ordinary receive validator. */
int SkPdSessionReceiveSwapReady(SK_PD_SESSION *, SK_PD_U32 Generation,
                               const unsigned char *Frame,
                               SK_PD_U32 FrameBytes, SK_PD_HEADER *);
/* After the policy has actually completed reset/role changes, not on a
 * status hint. Reset cancels pending transport tokens without reusing them.
 */
int SkPdSessionReset(SK_PD_SESSION *, SK_PD_U32 Generation);
int SkPdSessionSetRoles(SK_PD_SESSION *, SK_PD_U32 Generation,
                       SK_PD_U32 Lease, SK_PD_U32 PowerRole, SK_PD_U32 DataRole);
#endif
