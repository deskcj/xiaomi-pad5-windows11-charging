/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "sk_ln8000_profile.h"

static void zero_output(SK_LN_PROFILE_STATUS *p)
{ULONG i;for(i=0;i<sizeof(*p);++i)((volatile UCHAR *)p)[i]=0;}
static NTSTATUS exact(SK_LN8000 *c,UCHAR reg,PUCHAR buffer,ULONG bytes)
{
    ULONG actual=0;NTSTATUS s=c->Ops.Read(c->Device,reg,buffer,bytes,&actual);
    /* Informational STATUS_PENDING does not complete a synchronous SPB read.
     * Do not publish stale/uninitialized bytes as a configuration snapshot. */
    if(s!=STATUS_SUCCESS)return NT_SUCCESS(s)?STATUS_IO_DEVICE_ERROR:s;
    return actual==bytes?STATUS_SUCCESS:STATUS_DEVICE_DATA_ERROR;
}
NTSTATUS SkLn8000ReadProfile(SK_LN8000 *c,ULONG generation,ULONG now,
                           SK_LN_PROFILE_STATUS *out)
{
    NTSTATUS s;UCHAR id=0,bank[15];ULONG i,flags=0;
    if(!out)return STATUS_INVALID_PARAMETER;
    zero_output(out);
    if(!c || !generation || !c->Ops.Read)return STATUS_INVALID_PARAMETER;
    if(generation!=c->Generation)return STATUS_CANCELLED;
    if(c->Busy)return STATUS_DEVICE_BUSY;
    if(c->NeedsRecovery)return STATUS_DEVICE_NOT_READY;
    c->Busy=1;
    s=exact(c,0,&id,1);
    if(NT_SUCCESS(s) && id!=0x42)s=STATUS_NO_SUCH_DEVICE;
    c->Probed=NT_SUCCESS(s);
    if(NT_SUCCESS(s))s=exact(c,0x1b,bank,sizeof(bank));
    if(NT_SUCCESS(s)){
        for(i=0;i<sizeof(bank);++i)out->Registers[i]=bank[i];
        /* Masks match byte-pinned original init and Xiaomi's LN definitions.
         * Clear DISABLE bits mean enabled; no assumption that zeroed silicon
         * is initialized or that thermistors are physically connected. */
        if(!(bank[6]&0x20))flags|=SK_LN_CFG_BAT_OVP;
        if(!(bank[6]&0x10))flags|=SK_LN_CFG_VAC_OVP;
        if(!(bank[6]&4))flags|=SK_LN_CFG_VIN_OVP;
        if(!(bank[6]&0x40))flags|=SK_LN_CFG_IIN_OCP;
        if(!(bank[1]&0x20))flags|=SK_LN_CFG_FLOAT_LOOP;
        if(!(bank[1]&0x10))flags|=SK_LN_CFG_IIN_LOOP;
        if(bank[1]&4)flags|=SK_LN_CFG_DIE_LIMIT;
        if(bank[1]&2)flags|=SK_LN_CFG_DIE_REGULATION;
        if(bank[10]&2)flags|=SK_LN_CFG_BUS_NTC;
        if(bank[10]&1)flags|=SK_LN_CFG_BAT_NTC;
        if(bank[3]&4)flags|=SK_LN_CFG_REVERSE_DETECTION;
        if(bank[3]&8)flags|=SK_LN_CFG_STANDBY_COMMAND;
        out->FloatMicrovolts=3725000u+5000u*bank[13];
        out->InputLimitMicroamps=50000u*(bank[0]&0x7f);
        out->NtcAlarmRaw=bank[7]|((ULONG)(bank[8]&3)<<8);
        out->ConfiguredFlags=flags;
        out->AdcEnabledChannels=bank[9];
        out->AdcMode=(bank[8]>>5)&7;
        out->NtcShutdownRaw=(bank[1]>>2)&3;
        out->WatchdogEnabled=(bank[11]>>7)&1;
        out->AutoRecoveryMask=(bank[10]>>4)&15;
        out->Generation=generation;out->ReadAtMs=now;out->Complete=1;
    }
    c->Busy=0;return s;
}
