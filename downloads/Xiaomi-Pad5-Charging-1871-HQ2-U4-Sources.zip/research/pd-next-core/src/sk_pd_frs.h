#ifndef SK_PD_FRS_H
#define SK_PD_FRS_H
#include "sk_pd_session.h"

/* Fixed-contract Sink-side FRS policy for the single runtime consumer.
 * No register writes, native-owner replacement, interrupt or timer binding.
 * The physical adapter must implement autonomous VBUS handover BEFORE it
 * confirms Arm. Software cannot supply the sub-150us power transition.
 * Use the same Session as fixed/PPS. Disarm and confirm it before starting
 * another AMS/voltage change. Never route a real cable detach as FRS.
 * All output actions, including those returned with errors, are mandatory.
 * Same-attachment callbacks service clock/phase expiry before rejecting an
 * unrelated token. A stale attachment generation still cannot touch this one.
 */
enum {
    SK_FRS_NOT_READY=-40, SK_FRS_BAD_STATE=-41, SK_FRS_CLOCK=-42,
    SK_FRS_TIMEOUT=-43, SK_FRS_UNAVAILABLE=6, SK_FRS_DEFERRED=7,
    SK_FRS_IDLE=0, SK_FRS_QUERY_TX, SK_FRS_QUERY_REPLY, SK_FRS_CAPABLE,
    SK_FRS_ARM_PENDING, SK_FRS_ARMED, SK_FRS_SWAP_TX, SK_FRS_ACCEPT,
    SK_FRS_SOURCE_OFF, SK_FRS_SOURCE_READY, SK_FRS_HEADER_PENDING,
    SK_FRS_PS_READY_TX, SK_FRS_SOURCE_STARTUP, SK_FRS_RECOVERY,
    SK_FRS_UNSUPPORTED, SK_FRS_DISARM_PENDING,
    SK_FRS_ARM_HARDWARE=1, SK_FRS_DISARM_HARDWARE=2,
    SK_FRS_QUIESCE_CHARGE=4, SK_FRS_SET_SOURCE_HEADER=8,
    SK_FRS_START_SOURCE=16, SK_FRS_OWNER_RECOVERY=32,
    SK_FRS_FIXED_CONFIRMED=1, SK_FRS_EXCLUSIVE_OWNER=2,
    SK_FRS_AUTONOMOUS_PATH_VERIFIED=4, SK_FRS_REVERSE_PROTECTION=8,
    SK_FRS_ALL_PROOFS=15,
    SK_FRS_ENV_MAX_AGE_MS=100
};
typedef struct SK_FRS_ENV {
    SK_PD_U32 Generation, Flags, SampleAtMs, SourceBudgetMilliamps;
} SK_FRS_ENV;
typedef struct SK_FRS_TIMERS {
    SK_PD_U32 TxMs, ResponseMs, SourceOffMs, SourceReadyMs, ArmMs;
} SK_FRS_TIMERS;
typedef struct SK_FRS_SOURCE_PROOF {
    SK_PD_U32 Generation, HardwareToken, ConversionAtMs, AdcConversionSerial;
    SK_PD_U32 Millivolts, SourcingConfirmed, ChargeOffConfirmed;
} SK_FRS_SOURCE_PROOF;
typedef struct SK_FRS_OUTPUT {
    SK_PD_U32 Flags, Generation, HardwareToken, RequiredMilliamps;
    SK_PD_SESSION_TX Tx;
} SK_FRS_OUTPUT;
typedef struct SK_PD_FRS {
    SK_PD_SESSION *Session;
    SK_FRS_TIMERS Timers;
    SK_PD_U32 Generation, State, LastNowMs, PhaseAtMs, DataRole;
    SK_PD_U32 WireToken, HardwareToken, NextHardwareToken;
    SK_PD_U32 RequiredMilliamps, SinkPdo, ArmObligation, SourceSeen;
    SK_PD_U32 DefaultUsbMilliamps;
} SK_PD_FRS;

/* Initialize only unexposed storage, after confirmed physical disarm. */
int SkPdFrsInitialize(SK_PD_FRS *,SK_PD_SESSION *,SK_PD_U32 NowMs,
                     const SK_FRS_TIMERS *,SK_PD_U32 DefaultUsbMilliamps);
int SkPdFrsQuery(SK_PD_FRS *,SK_PD_U32 Generation,SK_PD_U32 NowMs,
                SK_PD_U32 SinkTxAllowed,const SK_FRS_ENV *,SK_FRS_OUTPUT *);
int SkPdFrsReceive(SK_PD_FRS *,SK_PD_U32 Generation,SK_PD_U32 NowMs,
                  const unsigned char *,SK_PD_U32 Bytes,SK_FRS_OUTPUT *);
int SkPdFrsTxComplete(SK_PD_FRS *,SK_PD_U32 Generation,SK_PD_U32 NowMs,
                     SK_PD_U32 Token,SK_PD_U32 Result,SK_FRS_OUTPUT *);
int SkPdFrsArm(SK_PD_FRS *,SK_PD_U32 Generation,SK_PD_U32 NowMs,
              const SK_FRS_ENV *,SK_FRS_OUTPUT *);
/* Tokens tag real adapter completions, not a write to the virtual cache. */
int SkPdFrsArmComplete(SK_PD_FRS *,SK_PD_U32 Generation,SK_PD_U32 NowMs,
                      SK_PD_U32 HardwareToken,SK_PD_U32 Verified,SK_FRS_OUTPUT *);
/* Only the matching armed hardware FRS latch can invoke Signal. Charge
 * quiescence is an action; the autonomous hardware path already holds VBUS.
 * We preserve the data role and send FR_SWAP as the initial Sink. */
int SkPdFrsSignal(SK_PD_FRS *,SK_PD_U32 Generation,SK_PD_U32 NowMs,
                 SK_PD_U32 HardwareToken,const SK_FRS_ENV *,SK_FRS_OUTPUT *);
/* A completed ADC conversion after the peer's Source-off PS_RDY is required.
 * ConversionAtMs is the conversion completion time, not a new read date of
 * cached ADC data. SourcingConfirmed comes from the physical output path;
 * external/cached 5V and an OTG command/cache bit cannot supply that proof. */
int SkPdFrsSourceReady(SK_PD_FRS *,SK_PD_U32 Generation,SK_PD_U32 NowMs,
                      const SK_FRS_SOURCE_PROOF *,SK_FRS_OUTPUT *);
int SkPdFrsHeaderComplete(SK_PD_FRS *,SK_PD_U32 Generation,SK_PD_U32 NowMs,
                         SK_PD_U32 HardwareToken,SK_PD_U32 Verified,SK_FRS_OUTPUT *);
int SkPdFrsPoll(SK_PD_FRS *,SK_PD_U32 Generation,SK_PD_U32 NowMs,
               const SK_FRS_ENV *,SK_FRS_OUTPUT *);
int SkPdFrsDisarm(SK_PD_FRS *,SK_PD_U32 Generation,SK_PD_U32 NowMs,SK_FRS_OUTPUT *);
/* Even a failed Arm can have affected hardware. Keep the disable obligation
 * until the same attachment's adapter proves physical disarm. Recovery of
 * an in-flight swap still belongs to the complete port/source policy. */
int SkPdFrsDisarmComplete(SK_PD_FRS *,SK_PD_U32 Generation,
                         SK_PD_U32 HardwareToken,SK_PD_U32 Verified);
SK_PD_U32 SkPdFrsSize(void);
#endif
