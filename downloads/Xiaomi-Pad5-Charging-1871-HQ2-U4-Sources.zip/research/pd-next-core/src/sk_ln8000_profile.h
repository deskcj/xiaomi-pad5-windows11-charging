/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef SK_LN8000_PROFILE_H
#define SK_LN8000_PROFILE_H
#include "sk_ln8000.h"

enum {
    SK_LN_CFG_BAT_OVP=1, SK_LN_CFG_VAC_OVP=2, SK_LN_CFG_VIN_OVP=4,
    SK_LN_CFG_IIN_OCP=8, SK_LN_CFG_FLOAT_LOOP=16, SK_LN_CFG_IIN_LOOP=32,
    SK_LN_CFG_DIE_LIMIT=64, SK_LN_CFG_DIE_REGULATION=128,
    SK_LN_CFG_BUS_NTC=256, SK_LN_CFG_BAT_NTC=512,
    SK_LN_CFG_REVERSE_DETECTION=1024, SK_LN_CFG_STANDBY_COMMAND=2048
};
typedef struct SK_LN_PROFILE_STATUS {
    ULONG Generation,ReadAtMs,Complete;
    ULONG FloatMicrovolts,InputLimitMicroamps,NtcAlarmRaw;
    ULONG ConfiguredFlags,AdcEnabledChannels,AdcMode,NtcShutdownRaw;
    ULONG WatchdogEnabled,AutoRecoveryMask;
    UCHAR Registers[15]; /*0x1b..0x29, configuration only; no interrupt ACK*/
} SK_LN_PROFILE_STATUS;

/* Informational read only: exact bus completion and current configuration.
 * This is NOT a calibrated/validated profile, ADC freshness, actual current,
 * functional thermal protection or permission to start fast charging.
 * The parent physical adapter serializes all LN calls at PASSIVE_LEVEL.
 * Configuration can change after this read; use the same exclusive owner.
 * No register writes, status clearing, ADC pause or fault recovery here.
 */
NTSTATUS SkLn8000ReadProfile(SK_LN8000 *,ULONG Generation,ULONG ReadAtMs,
                           SK_LN_PROFILE_STATUS *);
#endif
