/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "sk_ln8000_adc.h"

static void zero(void *p,ULONG bytes)
{ULONG i;for(i=0;i<bytes;++i)((volatile UCHAR *)p)[i]=0;}
static NTSTATUS valid(SK_LN_ADC *a,ULONG gen)
{
    if(!a || !a->Converter || !a->Clock || !gen ||
       !a->Converter->Ops.Read || !a->Converter->Ops.Write)
        return STATUS_INVALID_PARAMETER;
    return gen==a->Generation && gen==a->Converter->Generation?
        STATUS_SUCCESS:STATUS_CANCELLED;
}
static NTSTATUS time_now(SK_LN_ADC *a,ULONG *now)
{
    *now=a->Clock(a->ClockContext);
    if(*now-a->LastNowMs>0x7fffffffu)return STATUS_INVALID_PARAMETER;
    a->LastNowMs=*now;return STATUS_SUCCESS;
}
static NTSTATUS read_exact(SK_LN_ADC *a,UCHAR reg,PUCHAR b,ULONG n)
{
    ULONG actual=0;NTSTATUS s=a->Converter->Ops.Read(
        a->Converter->Device,reg,b,n,&actual);
    if(s!=STATUS_SUCCESS)return NT_SUCCESS(s)?STATUS_IO_DEVICE_ERROR:s;
    return actual==n?STATUS_SUCCESS:STATUS_DEVICE_DATA_ERROR;
}
static NTSTATUS hold(SK_LN_ADC *a,ULONG acquire)
{
    SK_LN8000 *d=a->Converter;UCHAR b=0;ULONG actual=0;NTSTATUS s;
    s=read_exact(a,0x26,&b,1);if(s!=STATUS_SUCCESS)return s;
    if(acquire && (b&3))return STATUS_DEVICE_BUSY;
    if(acquire)d->OwnIntPause=1; /* BEFORE ambiguous write */
    b=(UCHAR)((b&~1u)|(acquire?1u:0u));
    s=d->Ops.Write(d->Device,0x26,&b,1,&actual);
    if(s!=STATUS_SUCCESS)return NT_SUCCESS(s)?STATUS_IO_DEVICE_ERROR:s;
    if(actual!=1)return STATUS_DEVICE_DATA_ERROR;
    s=read_exact(a,0x26,&b,1);if(s!=STATUS_SUCCESS)return s;
    if((b&1u)!=(acquire?1u:0u))return STATUS_DEVICE_DATA_ERROR;
    if(!acquire)d->OwnIntPause=0;
    return STATUS_SUCCESS;
}
static NTSTATUS fail(SK_LN_ADC *a,ULONG gen,NTSTATUS why)
{
    SK_LN8000 *d=a->Converter;NTSTATUS s=STATUS_SUCCESS;
    a->State=SK_LN_ADC_FAILED;d->Busy=0;
    zero(&a->LastResult,sizeof(a->LastResult));
    if(d->OwnIntPause || d->OwnAdcPause || d->FastObligation || d->NeedsRecovery){
        /* Standby independently releases both owned holds, with readback.
         * It must not clear the recovery latch if either release fails. */
        s=SkLn8000Standby(d,gen);
    }
    return s==STATUS_SUCCESS?why:s;
}
static NTSTATUS config(SK_LN_ADC *a)
{
    UCHAR b[2]={0};NTSTATUS s=read_exact(a,0x23,b,2);
    if(s!=STATUS_SUCCESS)return s;
    return (b[0]&0xe0)==0xc0 && (b[1]&0x3e)==0x3e?
        STATUS_SUCCESS:STATUS_DEVICE_NOT_READY;
}
static NTSTATUS freeze(SK_LN_ADC *a)
{
    ULONG now;NTSTATUS s=time_now(a,&now);
    if(s!=STATUS_SUCCESS)return s;
    if(now-a->StartedAtMs>=100u)return STATUS_IO_TIMEOUT;
    s=hold(a,1);if(s!=STATUS_SUCCESS)return s;
    /* Clock AFTER verified acquisition supplies a conservative full 1ms
     * settling interval, including potentially slow SPB transactions. */
    s=time_now(a,&now);if(s!=STATUS_SUCCESS)return s;
    if(now-a->StartedAtMs>=100u)return STATUS_IO_TIMEOUT;
    a->FreezeAtMs=now;return STATUS_PENDING;
}
ULONG SkLnAdcSize(VOID){return sizeof(SK_LN_ADC);}
NTSTATUS SkLnAdcInitialize(SK_LN_ADC *a,SK_LN8000 *d,SK_LN_ADC_CLOCK clock,
    PVOID context,ULONG gen)
{
    if(!a || !d || !clock || !gen || gen!=d->Generation ||
       !d->Ops.Read || !d->Ops.Write || d->Busy || d->OwnIntPause ||
       d->OwnAdcPause || d->NeedsRecovery)return STATUS_INVALID_PARAMETER;
    zero(a,sizeof(*a));a->Converter=d;a->Clock=clock;a->ClockContext=context;
    a->Generation=gen;a->LastNowMs=clock(context);return STATUS_SUCCESS;
}
NTSTATUS SkLnAdcArm(SK_LN_ADC *a,ULONG gen)
{
    ULONG now;NTSTATUS s=valid(a,gen);if(s!=STATUS_SUCCESS)return s;
    if(a->Converter->Busy || a->Converter->OwnIntPause ||
       a->Converter->OwnAdcPause)return STATUS_DEVICE_BUSY;
    if(a->State==SK_LN_ADC_DRAIN || a->State==SK_LN_ADC_WAIT_HIGH)
        return STATUS_DEVICE_BUSY;
    if(a->Converter->NeedsRecovery)return STATUS_DEVICE_NOT_READY;
    s=time_now(a,&now);if(s!=STATUS_SUCCESS)return fail(a,gen,s);
    a->StartedAtMs=now;a->EarliestAtMs=0;a->State=SK_LN_ADC_DRAIN;
    zero(&a->LastResult,sizeof(a->LastResult));
    s=SkLn8000Probe(a->Converter,gen);if(s!=STATUS_SUCCESS)return fail(a,gen,s);
    a->Converter->Busy=1;
    s=config(a);if(s==STATUS_SUCCESS)s=freeze(a);
    a->Converter->Busy=0;
    return s==STATUS_PENDING?s:fail(a,gen,s);
}
NTSTATUS SkLnAdcCancel(SK_LN_ADC *a,ULONG gen)
{
    NTSTATUS s=valid(a,gen);if(s!=STATUS_SUCCESS)return s;
    if(a->Converter->Busy)return STATUS_DEVICE_BUSY;
    s=fail(a,gen,STATUS_SUCCESS);
    if(s==STATUS_SUCCESS)a->State=SK_LN_ADC_IDLE;
    return s;
}
NTSTATUS SkLnAdcPoll(SK_LN_ADC *a,ULONG gen,SK_LN_ADC_RESULT *out)
{
    SK_LN8000 *d;SK_LN_SNAPSHOT snapshot;ULONG now,earliest;UCHAR bits=0;
    NTSTATUS s;if(!out)return STATUS_INVALID_PARAMETER;zero(out,sizeof(*out));
    s=valid(a,gen);if(s!=STATUS_SUCCESS)return s;d=a->Converter;
    if(d->Busy)return STATUS_DEVICE_BUSY;
    if(a->State!=SK_LN_ADC_DRAIN && a->State!=SK_LN_ADC_WAIT_HIGH)
        return STATUS_DEVICE_NOT_READY;
    s=time_now(a,&now);if(s!=STATUS_SUCCESS)return fail(a,gen,s);
    if(now-a->StartedAtMs>=100u)return fail(a,gen,STATUS_IO_TIMEOUT);
    if(now-a->FreezeAtMs<1u)return STATUS_PENDING;
    if(!d->OwnIntPause || d->NeedsRecovery)return fail(a,gen,STATUS_DEVICE_NOT_READY);
    d->Busy=1;s=read_exact(a,1,&bits,1);
    if(s==STATUS_SUCCESS)a->PendingInterrupts|=bits&0xfdu;
    if(s==STATUS_SUCCESS)s=time_now(a,&now);
    earliest=now; /* BEFORE interrupt resume: lower completion bound */
    if(s==STATUS_SUCCESS)s=hold(a,0);
    if(s==STATUS_SUCCESS)s=time_now(a,&now);
    if(s==STATUS_SUCCESS && now-a->StartedAtMs>=100u)s=STATUS_IO_TIMEOUT;
    if(s==STATUS_SUCCESS && (bits&0xcdu))s=STATUS_DEVICE_NOT_READY;
    if(s==STATUS_SUCCESS)s=config(a);
    d->Busy=0;if(s!=STATUS_SUCCESS)return fail(a,gen,s);
    if(a->State==SK_LN_ADC_DRAIN || !(bits&2)){
        if(!(bits&2)){a->EarliestAtMs=earliest;a->State=SK_LN_ADC_WAIT_HIGH;}
        d->Busy=1;s=freeze(a);d->Busy=0;
        return s==STATUS_PENDING?s:fail(a,gen,s);
    }
    /* DONE is now high after a witnessed low. Snapshot pauses the ADC bank
     * and checks its own exact release; a read's date never renews evidence. */
    s=SkLn8000Snapshot(d,gen,now,&snapshot);
    if(s==STATUS_SUCCESS)s=time_now(a,&now);
    if(s==STATUS_SUCCESS && (now-a->StartedAtMs>=100u ||
       now-a->EarliestAtMs>100u || snapshot.FaultBits))s=STATUS_DEVICE_NOT_READY;
    if(s!=STATUS_SUCCESS)return fail(a,gen,s);
    if(a->Serial==0xffffffffu)return fail(a,gen,STATUS_INTEGER_OVERFLOW);
    ++a->Serial;a->State=SK_LN_ADC_READY;
    out->Generation=gen;out->ConversionSerial=a->Serial;
    out->EarliestAtMs=a->EarliestAtMs;out->Snapshot=snapshot;
    a->LastResult=*out;
    return STATUS_SUCCESS;
}
NTSTATUS SkLnAdcCopyReady(SK_LN_ADC *a,ULONG gen,SK_LN_ADC_RESULT *out)
{
    ULONG now;NTSTATUS s;if(!out)return STATUS_INVALID_PARAMETER;
    zero(out,sizeof(*out));s=valid(a,gen);if(s!=STATUS_SUCCESS)return s;
    if(a->Converter->Busy)return STATUS_DEVICE_BUSY;
    s=time_now(a,&now);
    if(s==STATUS_SUCCESS && (a->State!=SK_LN_ADC_READY ||
       a->Converter->OwnAdcPause || a->Converter->OwnIntPause ||
       a->Converter->NeedsRecovery || !a->LastResult.ConversionSerial ||
       a->LastResult.Generation!=gen || a->LastResult.ConversionSerial!=a->Serial ||
       now-a->LastResult.EarliestAtMs>100u))s=STATUS_DEVICE_NOT_READY;
    if(s!=STATUS_SUCCESS)return fail(a,gen,s);
    *out=a->LastResult;return STATUS_SUCCESS;
}
