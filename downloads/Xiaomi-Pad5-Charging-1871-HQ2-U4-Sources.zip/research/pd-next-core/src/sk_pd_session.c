#include "sk_pd_session.h"

static void clear(unsigned char *p, SK_PD_U32 n)
{SK_PD_U32 i;for(i=0;i<n;++i)((volatile unsigned char *)p)[i]=0;}
static int ready(SK_PD_SESSION *s, SK_PD_U32 generation)
{
    if(!s || !generation)return SK_PD_INVALID_ARGUMENT;
    if(generation!=s->Generation)return SK_PD_SESSION_STALE;
    if(!s->NativeStopped)return SK_PD_SESSION_NOT_READY;
    if(s->Faulted)return SK_PD_SESSION_RECOVERY;
    return SK_PD_OK;
}
static int fault(SK_PD_SESSION *s)
{
    s->Faulted=1;s->Lease=0;s->PendingToken=0;
    s->PendingBytes=0;clear(s->Pending,32);
    return SK_PD_SESSION_RECOVERY;
}
int SkPdSessionInitialize(SK_PD_SESSION *s, SK_PD_U32 generation,
                         SK_PD_U32 power, SK_PD_U32 data, SK_PD_U32 native)
{
    if(!s || !generation || power>1 || data>1 || native>1)
        return SK_PD_INVALID_ARGUMENT;
    s->Generation=generation;s->PowerRole=power;s->DataRole=data;s->Revision=2;
    s->NativeStopped=native;s->Faulted=0;s->Lease=0;s->NextToken=0;
    s->TxMessageId=0;s->PendingToken=0;s->PendingBytes=0;
    s->RxValid=0;s->RxMessageId=0;s->RxBytes=0;
    clear(s->Pending,32);clear(s->LastRx,32);return SK_PD_OK;
}
int SkPdSessionAcquire(SK_PD_SESSION *s, SK_PD_U32 generation, SK_PD_U32 lease)
{
    int result=ready(s,generation);if(result)return result;
    if(!lease)return SK_PD_INVALID_ARGUMENT;
    if(s->Lease)return SK_PD_SESSION_BUSY;
    s->Lease=lease;return SK_PD_OK;
}
int SkPdSessionRelease(SK_PD_SESSION *s, SK_PD_U32 generation, SK_PD_U32 lease)
{
    int result=ready(s,generation);if(result)return result;
    if(!lease || lease!=s->Lease)return SK_PD_SESSION_STALE;
    if(s->PendingToken)return SK_PD_SESSION_BUSY;
    s->Lease=0;return SK_PD_OK;
}
int SkPdSessionTransmit(SK_PD_SESSION *s, SK_PD_U32 generation, SK_PD_U32 lease,
                       SK_PD_U32 type, const unsigned char *payload,
                       SK_PD_U32 bytes, SK_PD_SESSION_TX *tx)
{
    SK_PD_U32 i,header;
    int result;
    if(!tx)return SK_PD_INVALID_ARGUMENT;
    tx->Generation=0;tx->Token=0;tx->FrameBytes=0;clear(tx->Frame,32);
    result=ready(s,generation);if(result)return result;
    if(!lease || lease!=s->Lease)return SK_PD_SESSION_STALE;
    if(s->PendingToken)return SK_PD_SESSION_BUSY;
    if(!type || type>31 || bytes>28 || (bytes&3) || (bytes && !payload))
        return SK_PD_INVALID_ARGUMENT;
    if(!bytes && (type==1 || (s->Revision==1 && type>13)))return SK_PD_UNSUPPORTED;
    if(!bytes && type==13 && s->TxMessageId!=0)return SK_PD_SESSION_NOT_READY;
    if(s->NextToken==0xffffffffU)return fault(s);
    header=type|(s->DataRole<<5)|(s->Revision<<6)|(s->PowerRole<<8)|
           (s->TxMessageId<<9)|((bytes/4)<<12);
    tx->Generation=generation;tx->Token=++s->NextToken;tx->FrameBytes=4+bytes;
    tx->Frame[0]=(unsigned char)(3+bytes);tx->Frame[1]=0;
    tx->Frame[2]=(unsigned char)header;tx->Frame[3]=(unsigned char)(header>>8);
    for(i=0;i<bytes;++i)tx->Frame[4+i]=payload[i];
    for(i=0;i<32;++i)s->Pending[i]=tx->Frame[i];
    s->PendingToken=tx->Token;s->PendingBytes=tx->FrameBytes;return SK_PD_OK;
}
int SkPdSessionTxComplete(SK_PD_SESSION *s, SK_PD_U32 generation,
                         SK_PD_U32 token, SK_PD_U32 result)
{
    int status=ready(s,generation);if(status)return status;
    if(!token || token!=s->PendingToken)return SK_PD_SESSION_STALE;
    if(result<1 || result>3)return SK_PD_INVALID_ARGUMENT;
    if(result!=SK_PD_SESSION_TX_SUCCESS)return fault(s);
    s->TxMessageId=(s->TxMessageId+1)&7;s->PendingToken=0;s->PendingBytes=0;
    clear(s->Pending,32);return SK_PD_OK;
}
int SkPdSessionPpsRequest(SK_PD_SESSION *s, SK_PD_U32 generation, SK_PD_U32 lease,
                         const SK_PD_SESSION_PPS_REQUEST *request, SK_PD_SESSION_TX *tx)
{
    SK_PD_U32 rdo,i;
    unsigned char payload[4];
    int result;
    if(!tx)return SK_PD_INVALID_ARGUMENT;
    tx->Generation=0;tx->Token=0;tx->FrameBytes=0;clear(tx->Frame,32);
    result=ready(s,generation);if(result)return result;
    if(!request)return SK_PD_INVALID_ARGUMENT;
    result=SkPdBuildPpsRdo(request->Pdo,request->Position,s->Revision,
                          request->Millivolts,request->Milliamps,request->Flags,&rdo);
    if(result)return result;
    for(i=0;i<4;++i)payload[i]=(unsigned char)(rdo>>(8*i));
    return SkPdSessionTransmit(s,generation,lease,2,payload,4,tx);
}
int SkPdSessionReset(SK_PD_SESSION *s, SK_PD_U32 generation)
{
    if(!s || !generation)return SK_PD_INVALID_ARGUMENT;
    if(generation!=s->Generation)return SK_PD_SESSION_STALE;
    if(!s->NativeStopped)return SK_PD_SESSION_NOT_READY;
    s->Faulted=0;s->Lease=0;s->TxMessageId=0;s->PendingToken=0;s->PendingBytes=0;
    s->RxValid=0;s->RxMessageId=0;s->RxBytes=0;
    clear(s->Pending,32);clear(s->LastRx,32);return SK_PD_OK;
}
static int receive(SK_PD_SESSION *s, SK_PD_U32 generation,
                   const unsigned char *frame, SK_PD_U32 bytes,
                   SK_PD_HEADER *h, SK_PD_U32 swap_ready)
{
    SK_PD_U32 i;
    int result=ready(s,generation);if(result)return result;
    if(!frame || !h)return SK_PD_INVALID_ARGUMENT;
    if(bytes<4 || bytes>32 || frame[0]+1U!=bytes)return SK_PD_INVALID_ENCODING;
    if(frame[1]!=0)return SK_PD_UNSUPPORTED; /* Cable SOPs need separate state. */
    result=SkPdDecodeHeader((SK_PD_U16)(frame[2]|(frame[3]<<8)),h);
    if(result)return result;
    if(bytes!=4+4*h->DataObjects)return SK_PD_INVALID_ENCODING;
    if(h->Revision==0)return SK_PD_UNSUPPORTED;
    if(h->Extended)return SK_PD_UNSUPPORTED; /* No chunk/extended policy here. */
    if(h->MessageType==0)return SK_PD_INVALID_ENCODING;
    if(h->DataObjects==0 && h->MessageType==1)return SK_PD_UNSUPPORTED; /* PHY GoodCRC */
    if(h->DataObjects==0 && h->Revision==1 && h->MessageType>13)
        return SK_PD_UNSUPPORTED;
    /* The initial Source is already a Sink in its swap PS_RDY. Keep our
     * local Sink header until physical source readiness is confirmed; do
     * not temporarily change roles to get this frame past validation. */
    if(swap_ready && (s->Lease!=3 || s->PowerRole!=0 || s->Revision!=2 ||
                     h->Revision!=2 || h->DataObjects || h->MessageType!=6))
        return SK_PD_SESSION_NOT_READY;
    if(h->PowerRole!=(swap_ready?0U:1U-s->PowerRole) || h->DataRole==s->DataRole)
        return SK_PD_INVALID_ENCODING;
    if(!h->DataObjects && h->MessageType==13) {
        /* SoftReset must reach policy even with a repeated/old RX MessageID.
         * Reset IDs and invalidate old TX completion before policy's Accept.
         */
        if(h->Revision<s->Revision)s->Revision=h->Revision;
        SkPdSessionReset(s,generation);return SK_PD_SESSION_SOFT_RESET;
    }
    if(s->RxValid && h->MessageId==s->RxMessageId) {
        if(bytes!=s->RxBytes)return fault(s);
        for(i=0;i<bytes;++i)if(frame[i]!=s->LastRx[i])return fault(s);
        return SK_PD_SESSION_DUPLICATE;
    }
    if(h->Revision<s->Revision)s->Revision=h->Revision;
    s->RxValid=1;s->RxMessageId=h->MessageId;s->RxBytes=bytes;
    for(i=0;i<bytes;++i)s->LastRx[i]=frame[i];
    for(i=bytes;i<32;++i)((volatile unsigned char *)s->LastRx)[i]=0;
    return SK_PD_OK;
}
int SkPdSessionReceive(SK_PD_SESSION *s, SK_PD_U32 generation,
                      const unsigned char *frame, SK_PD_U32 bytes,
                      SK_PD_HEADER *h)
{ return receive(s,generation,frame,bytes,h,0); }
int SkPdSessionReceiveSwapReady(SK_PD_SESSION *s, SK_PD_U32 generation,
                               const unsigned char *frame, SK_PD_U32 bytes,
                               SK_PD_HEADER *h)
{ return receive(s,generation,frame,bytes,h,1); }
int SkPdSessionSetRoles(SK_PD_SESSION *s, SK_PD_U32 generation,
                       SK_PD_U32 lease, SK_PD_U32 power, SK_PD_U32 data)
{
    int result=ready(s,generation);if(result)return result;
    if(!lease || lease!=s->Lease)return SK_PD_SESSION_STALE;
    if(s->PendingToken)return SK_PD_SESSION_BUSY;
    if(power>1 || data>1)return SK_PD_INVALID_ARGUMENT;
    s->PowerRole=power;s->DataRole=data;return SK_PD_OK;
}
