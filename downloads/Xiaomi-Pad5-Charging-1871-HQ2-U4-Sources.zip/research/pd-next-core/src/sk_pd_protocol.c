#include "sk_pd_protocol.h"

static int PpsBounds(SK_PD_U32 Pdo, SK_PD_U32 *Minimum,
                     SK_PD_U32 *Maximum, SK_PD_U32 *Current)
{
    if ((Pdo >> 30) != 3 || ((Pdo >> 28) & 3) != 0)
        return SK_PD_UNSUPPORTED;
    *Minimum = ((Pdo >> 8) & 255) * 100;
    *Maximum = ((Pdo >> 17) & 255) * 100;
    *Current = (Pdo & 127) * 50;
    if ((Pdo & 0x06010080U) != 0 ||
        *Minimum < 3300 || *Maximum > 21000 || *Minimum > *Maximum ||
        *Current == 0)
        return SK_PD_INVALID_ENCODING;
    return SK_PD_OK;
}

int SkPdDecodeHeader(SK_PD_U16 Raw, SK_PD_HEADER *Header)
{
    if (!Header)
        return SK_PD_INVALID_ARGUMENT;
    Header->MessageType = Raw & 31;
    Header->Revision = (Raw >> 6) & 3;
    Header->DataObjects = (Raw >> 12) & 7;
    Header->Extended = (Raw >> 15) & 1;
    Header->DataRole = (Raw >> 5) & 1;
    Header->PowerRole = (Raw >> 8) & 1;
    Header->MessageId = (Raw >> 9) & 7;
    if (Header->Revision == 3 ||
        (Header->Extended && (Header->DataObjects == 0 || Header->Revision != 2)))
        return SK_PD_INVALID_ENCODING;
    return SK_PD_OK;
}

int SkPdBuildPpsRdo(SK_PD_U32 Pdo, SK_PD_U32 Position, SK_PD_U32 Revision,
                    SK_PD_U32 Millivolts, SK_PD_U32 Milliamps,
                    SK_PD_U32 Flags, SK_PD_U32 *Rdo)
{
    SK_PD_U32 minimum, maximum, current;
    int result;
    if (!Rdo)
        return SK_PD_INVALID_ARGUMENT;
    *Rdo = 0;
    if (Position == 0 || Position > 7 || (Flags & ~0x07000000U) != 0)
        return SK_PD_INVALID_ARGUMENT;
    if (Revision != 2)
        return SK_PD_UNSUPPORTED;
    result = PpsBounds(Pdo, &minimum, &maximum, &current);
    if (result != SK_PD_OK)
        return result;
    if (Millivolts < minimum || Millivolts > maximum ||
        Milliamps == 0 || Milliamps > current)
        return SK_PD_OUT_OF_RANGE;
    if (Millivolts % 20 != 0 || Milliamps % 50 != 0)
        return SK_PD_INVALID_ENCODING;
    *Rdo = (Position << 28) | Flags | ((Millivolts / 20) << 9) | (Milliamps / 50);
    return SK_PD_OK;
}

int SkPdDecodeContract(const SK_PD_U32 *Pdos, SK_PD_U32 Count, SK_PD_U32 Rdo,
                       SK_PD_U32 Revision, SK_PD_CONTRACT *Contract)
{
    SK_PD_U32 position, pdo, type, voltage, current, maximum, requestedMaximum;
    SK_PD_U32 minimumVoltage, maximumVoltage, maximumCurrent;
    int result;
    if (!Contract)
        return SK_PD_INVALID_ARGUMENT;
    Contract->ObjectPosition = 0;
    Contract->IsPps = 0;
    Contract->Millivolts = 0;
    Contract->Milliamps = 0;
    Contract->PowerLimitMilliwatts = 0;
    if (!Pdos || Count == 0 || Count > 7 || Revision > 2)
        return SK_PD_INVALID_ARGUMENT;
    position = (Rdo >> 28) & 7;
    if (position == 0 || position > Count || (Rdo & 0x80000000U) != 0)
        return SK_PD_INVALID_ENCODING;
    pdo = Pdos[position - 1];
    type = pdo >> 30;
    if (type == 0) {
        if ((Rdo & 0x00f00000U) != 0 || (Rdo & 0x08000000U) != 0)
            return SK_PD_UNSUPPORTED;
        voltage = ((pdo >> 10) & 1023) * 50;
        maximum = (pdo & 1023) * 10;
        current = ((Rdo >> 10) & 1023) * 10;
        requestedMaximum = (Rdo & 1023) * 10;
        if (voltage == 0 || current == 0 || current > maximum)
            return SK_PD_OUT_OF_RANGE;
        if (requestedMaximum < current)
            return SK_PD_INVALID_ENCODING;
        if ((Rdo & 0x04000000U) == 0 && requestedMaximum > maximum)
            return SK_PD_OUT_OF_RANGE;
    } else if (type == 3) {
        if (Revision != 2)
            return SK_PD_UNSUPPORTED;
        result = PpsBounds(pdo, &minimumVoltage, &maximumVoltage, &maximumCurrent);
        if (result != SK_PD_OK)
            return result;
        /* Bits 7..8, 21..23 and 27 are reserved in a PPS RDO. */
        if ((Rdo & 0x08e00180U) != 0)
            return SK_PD_INVALID_ENCODING;
        voltage = ((Rdo >> 9) & 2047) * 20;
        current = (Rdo & 127) * 50;
        if (voltage < minimumVoltage || voltage > maximumVoltage ||
            current == 0 || current > maximumCurrent)
            return SK_PD_OUT_OF_RANGE;
    } else {
        return SK_PD_UNSUPPORTED;
    }
    Contract->ObjectPosition = position;
    Contract->IsPps = (type == 3);
    Contract->Millivolts = voltage;
    Contract->Milliamps = current;
    Contract->PowerLimitMilliwatts = voltage * current / 1000;
    return SK_PD_OK;
}
