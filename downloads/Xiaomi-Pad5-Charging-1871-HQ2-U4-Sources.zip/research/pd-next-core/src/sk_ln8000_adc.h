/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef SK_LN8000_ADC_H
#define SK_LN8000_ADC_H
#include "sk_ln8000.h"

/* SAME serialized converter owner; never a second INT1 reader. Original
 * nabu INT1.bit1 is ADC_DONE, TIMER_CTRL.bit0 pauses interrupt updates and
 * bit1 pauses the ADC result bank. Reading INT1 consumes other events too:
 * PendingInterrupts must be routed to the complete charger policy even on
 * a failure. No GPIO IRQ, physical endpoint, or Windows PD binding here.
 *
 * A read timestamp/changed ADC value is not a new conversion. Require a
 * hardware DONE-low baseline followed by DONE-high. Results are dated at
 * the EARLIEST possible completion time, making freshness conservative.
 * Clock must read the real monotonic millisecond clock on EVERY callback.
 * Fixed callback time, fabricated IRQ or frozen clock cannot be used on a
 * tablet. The physical adapter must validate this bit on the actual LN8000.
 * Existing ADC NORMAL mode and all used channels are required. The module
 * never changes mode, interrupt mask, voltage or current to get a sample.
 */
typedef SK_LN_CLOCK SK_LN_ADC_CLOCK;
enum { SK_LN_ADC_IDLE=0, SK_LN_ADC_DRAIN=1, SK_LN_ADC_WAIT_HIGH=2,
       SK_LN_ADC_READY=3, SK_LN_ADC_FAILED=4 };
typedef struct SK_LN_ADC_RESULT {
    ULONG Generation,ConversionSerial,EarliestAtMs;
    SK_LN_SNAPSHOT Snapshot;
} SK_LN_ADC_RESULT;
typedef struct SK_LN_ADC {
    SK_LN8000 *Converter;
    SK_LN_ADC_CLOCK Clock;
    PVOID ClockContext;
    ULONG Generation,State,LastNowMs,StartedAtMs,FreezeAtMs,EarliestAtMs;
    ULONG Serial,PendingInterrupts;
    SK_LN_ADC_RESULT LastResult; /* only completed owner acquisition writes it */
} SK_LN_ADC;

NTSTATUS SkLnAdcInitialize(SK_LN_ADC *,SK_LN8000 *,SK_LN_ADC_CLOCK,PVOID,ULONG);
NTSTATUS SkLnAdcArm(SK_LN_ADC *,ULONG Generation);
/* Pending until >=1ms interrupt settling and a fresh DONE transition; fails
 * closed after 100ms. Exact transfers, current clock, released holds and a
 * coherent bank are mandatory before SUCCESS. Failure invalidates output,
 * stops an obligated running pump, and retains failed hold/shutdown duties.
 */
NTSTATUS SkLnAdcPoll(SK_LN_ADC *,ULONG Generation,SK_LN_ADC_RESULT *);
NTSTATUS SkLnAdcCancel(SK_LN_ADC *,ULONG Generation);
NTSTATUS SkLnAdcCopyReady(SK_LN_ADC *,ULONG Generation,SK_LN_ADC_RESULT *);
ULONG SkLnAdcSize(VOID);
#endif
