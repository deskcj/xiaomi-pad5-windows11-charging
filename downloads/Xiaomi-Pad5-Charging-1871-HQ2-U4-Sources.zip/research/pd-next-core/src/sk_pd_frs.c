#include "sk_pd_frs.h"

static void clear(unsigned char *p,SK_PD_U32 n)
{ SK_PD_U32 i;for(i=0;i<n;++i)((volatile unsigned char *)p)[i]=0; }
static void actions(SK_PD_FRS *f,SK_FRS_OUTPUT *o,SK_PD_U32 flags)
{
    o->Flags=flags;o->Generation=f->Generation;
    o->HardwareToken=f->HardwareToken;o->RequiredMilliamps=f->RequiredMilliamps;
}
static int enter(SK_PD_FRS *f,SK_PD_U32 gen,SK_FRS_OUTPUT *o)
{
    if(!o)return SK_PD_INVALID_ARGUMENT;
    clear((unsigned char *)o,sizeof(*o));
    if(!f || !f->Session || !gen)return SK_PD_INVALID_ARGUMENT;
    if(gen!=f->Generation || gen!=f->Session->Generation)return SK_PD_SESSION_STALE;
    return SK_PD_OK;
}
static int recover(SK_PD_FRS *f,SK_FRS_OUTPUT *o,int status)
{
    f->State=SK_FRS_RECOVERY;f->Session->Faulted=1;
    /* The port owner must cancel/drain physical TX. Invalidate local tokens
     * without recycling MessageIDs, and retain the physical arm obligation. */
    f->Session->PendingToken=0;f->Session->PendingBytes=0;
    clear(f->Session->Pending,32);f->WireToken=0;f->Session->Lease=0;
    actions(f,o,SK_FRS_QUIESCE_CHARGE|SK_FRS_OWNER_RECOVERY|
                  (f->ArmObligation?SK_FRS_DISARM_HARDWARE:0));
    return status;
}
static int timer(SK_PD_FRS *f,SK_PD_U32 now,SK_FRS_OUTPUT *o)
{
    SK_PD_U32 limit=0;
    if(now-f->LastNowMs>0x7fffffffU)return recover(f,o,SK_FRS_CLOCK);
    f->LastNowMs=now;
    if(!f->Session->NativeStopped || f->Session->Faulted || f->State==SK_FRS_RECOVERY)
        return recover(f,o,SK_PD_SESSION_RECOVERY);
    switch(f->State){
    case SK_FRS_QUERY_TX:case SK_FRS_SWAP_TX:case SK_FRS_PS_READY_TX:
        limit=f->Timers.TxMs;break;
    case SK_FRS_QUERY_REPLY:case SK_FRS_ACCEPT:limit=f->Timers.ResponseMs;break;
    case SK_FRS_ARM_PENDING:case SK_FRS_DISARM_PENDING:limit=f->Timers.ArmMs;break;
    case SK_FRS_SOURCE_OFF:limit=f->Timers.SourceOffMs;break;
    case SK_FRS_SOURCE_READY:case SK_FRS_HEADER_PENDING:limit=f->Timers.SourceReadyMs;break;
    default:break;
    }
    if(limit && now-f->PhaseAtMs>=limit){
        if(f->State==SK_FRS_QUERY_REPLY){
            int r=SkPdSessionRelease(f->Session,f->Generation,3);
            if(r)return recover(f,o,r);
            f->State=SK_FRS_UNSUPPORTED;return SK_FRS_UNAVAILABLE;
        }
        return recover(f,o,SK_FRS_TIMEOUT);
    }
    return SK_PD_OK;
}
static int env_ok(SK_PD_FRS *f,SK_PD_U32 now,const SK_FRS_ENV *e,SK_PD_U32 flags)
{
    if(!e || e->Generation!=f->Generation || (e->Flags&flags)!=flags ||
       now-e->SampleAtMs>SK_FRS_ENV_MAX_AGE_MS ||
       ((flags&SK_FRS_AUTONOMOUS_PATH_VERIFIED) &&
        e->SourceBudgetMilliamps<f->RequiredMilliamps) ||
       e->SourceBudgetMilliamps>3000)return SK_FRS_NOT_READY;
    return SK_PD_OK;
}
static int emit(SK_PD_FRS *f,SK_PD_U32 kind,SK_PD_U32 state,
                SK_PD_U32 now,SK_FRS_OUTPUT *o)
{
    int r=SkPdSessionTransmit(f->Session,f->Generation,3,kind,0,0,&o->Tx);
    if(r)return recover(f,o,r);
    f->WireToken=o->Tx.Token;f->State=state;f->PhaseAtMs=now;
    return SK_PD_OK;
}
SK_PD_U32 SkPdFrsSize(void){return sizeof(SK_PD_FRS);}
int SkPdFrsInitialize(SK_PD_FRS *f,SK_PD_SESSION *s,SK_PD_U32 now,
                     const SK_FRS_TIMERS *t,SK_PD_U32 default_current)
{
    if(!f || !s || !t || !s->Generation || !s->NativeStopped || s->Faulted ||
       !t->TxMs || t->TxMs>5000 || !t->ResponseMs || t->ResponseMs>5000 ||
       !t->SourceOffMs || t->SourceOffMs>5000 || !t->SourceReadyMs ||
       t->SourceReadyMs>5000 || !t->ArmMs || t->ArmMs>5000 ||
       (default_current!=500 && default_current!=900))
        return SK_PD_INVALID_ARGUMENT;
    clear((unsigned char *)f,sizeof(*f));f->Session=s;f->Timers=*t;
    f->Generation=s->Generation;f->LastNowMs=now;f->DataRole=s->DataRole;
    f->DefaultUsbMilliamps=default_current;
    return SK_PD_OK;
}
int SkPdFrsQuery(SK_PD_FRS *f,SK_PD_U32 gen,SK_PD_U32 now,
                SK_PD_U32 grant,const SK_FRS_ENV *e,SK_FRS_OUTPUT *o)
{
    int r=enter(f,gen,o);if(r)return r;
    r=timer(f,now,o);if(r)return r;
    if(grant>1)return SK_PD_INVALID_ARGUMENT;
    if(f->ArmObligation || (f->State!=SK_FRS_IDLE && f->State!=SK_FRS_CAPABLE &&
                            f->State!=SK_FRS_UNSUPPORTED))return SK_FRS_BAD_STATE;
    if(f->Session->Revision!=2 || f->Session->PowerRole!=0 ||
       f->Session->DataRole!=f->DataRole)return SK_FRS_NOT_READY;
    r=env_ok(f,now,e,SK_FRS_FIXED_CONFIRMED|SK_FRS_EXCLUSIVE_OWNER);if(r)return r;
    if(f->Session->Lease || f->Session->PendingToken)return SK_PD_SESSION_BUSY;
    if(!grant)return SK_FRS_DEFERRED;
    r=SkPdSessionAcquire(f->Session,gen,3);if(r)return r;
    f->RequiredMilliamps=0;f->SinkPdo=0;
    return emit(f,8,SK_FRS_QUERY_TX,now,o); /* Get_Sink_Cap */
}
int SkPdFrsReceive(SK_PD_FRS *f,SK_PD_U32 gen,SK_PD_U32 now,
                  const unsigned char *p,SK_PD_U32 n,SK_FRS_OUTPUT *o)
{
    SK_PD_HEADER h;SK_PD_U32 pdo,current;int r=enter(f,gen,o);if(r)return r;
    r=timer(f,now,o);if(r)return r;
    /* Filter duplicate Accept normally; a duplicate swapped-role PS_RDY
     * still uses its narrow validator while our local header remains Sink. */
    if((f->State==SK_FRS_SOURCE_OFF || f->State==SK_FRS_SOURCE_READY ||
        f->State==SK_FRS_HEADER_PENDING) && p && n>=4 &&
       ((p[2]|((SK_PD_U32)p[3]<<8))&0x701fU)==6)
        r=SkPdSessionReceiveSwapReady(f->Session,gen,p,n,&h);
    else r=SkPdSessionReceive(f->Session,gen,p,n,&h);
    if(r==SK_PD_SESSION_DUPLICATE)return r;
    if(r)return recover(f,o,r);
    if(f->State==SK_FRS_QUERY_REPLY){
        r=SkPdSessionRelease(f->Session,gen,3);if(r)return recover(f,o,r);
        if(!h.DataObjects && (h.MessageType==4 || h.MessageType==12 || h.MessageType==16)){
            f->State=SK_FRS_UNSUPPORTED;return SK_FRS_UNAVAILABLE;
        }
        if(f->Session->Revision!=2){f->State=SK_FRS_UNSUPPORTED;return SK_FRS_UNAVAILABLE;}
        if(h.MessageType!=4 || !h.DataObjects)return recover(f,o,SK_PD_INVALID_ENCODING);
        pdo=(SK_PD_U32)p[4]|((SK_PD_U32)p[5]<<8)|((SK_PD_U32)p[6]<<16)|((SK_PD_U32)p[7]<<24);
        /* The first Sink PDO must be fixed 5V. Dual-role power and FRS current
         * are independent of USB hub VID/PID or advertised Source wattage. */
        if(pdo>>30 || ((pdo>>10)&1023)!=100 || !(pdo&1023))
            return recover(f,o,SK_PD_INVALID_ENCODING);
        current=(pdo>>23)&3;
        f->SinkPdo=pdo;f->RequiredMilliamps=current==1?f->DefaultUsbMilliamps:
            (current==2?1500:(current==3?3000:0));
        if(!(pdo&0x20000000U) || !current){f->State=SK_FRS_UNSUPPORTED;return SK_FRS_UNAVAILABLE;}
        f->State=SK_FRS_CAPABLE;actions(f,o,0);return SK_PD_OK;
    }
    if(f->Session->Revision!=2)return recover(f,o,SK_FRS_NOT_READY);
    if(f->State==SK_FRS_ACCEPT && !h.DataObjects && h.MessageType==3){
        f->State=SK_FRS_SOURCE_OFF;f->PhaseAtMs=now;return SK_PD_OK;
    }
    if(f->State==SK_FRS_SOURCE_OFF && !h.DataObjects && h.MessageType==6){
        f->State=SK_FRS_SOURCE_READY;f->PhaseAtMs=now;return SK_PD_OK;
    }
    return recover(f,o,SK_FRS_BAD_STATE);
}
int SkPdFrsTxComplete(SK_PD_FRS *f,SK_PD_U32 gen,SK_PD_U32 now,
                     SK_PD_U32 token,SK_PD_U32 result,SK_FRS_OUTPUT *o)
{
    int r=enter(f,gen,o);if(r)return r;
    r=timer(f,now,o);if(r)return r;
    if(!token || token!=f->WireToken)return SK_PD_SESSION_STALE;
    if(f->State!=SK_FRS_QUERY_TX && f->State!=SK_FRS_SWAP_TX &&
       f->State!=SK_FRS_PS_READY_TX)return SK_FRS_BAD_STATE;
    r=SkPdSessionTxComplete(f->Session,gen,token,result);
    if(r)return recover(f,o,r);
    f->WireToken=0;f->PhaseAtMs=now;
    if(f->State==SK_FRS_QUERY_TX)f->State=SK_FRS_QUERY_REPLY;
    else if(f->State==SK_FRS_SWAP_TX)f->State=SK_FRS_ACCEPT;
    else{
        r=SkPdSessionRelease(f->Session,gen,3);if(r)return recover(f,o,r);
        f->State=SK_FRS_SOURCE_STARTUP;actions(f,o,SK_FRS_START_SOURCE);
    }
    return SK_PD_OK;
}
int SkPdFrsArm(SK_PD_FRS *f,SK_PD_U32 gen,SK_PD_U32 now,
              const SK_FRS_ENV *e,SK_FRS_OUTPUT *o)
{
    int r=enter(f,gen,o);if(r)return r;
    r=timer(f,now,o);if(r)return r;
    if(f->State!=SK_FRS_CAPABLE || f->ArmObligation)return SK_FRS_BAD_STATE;
    if(f->Session->Revision!=2 || f->Session->PowerRole!=0 ||
       f->Session->DataRole!=f->DataRole)return SK_FRS_NOT_READY;
    r=env_ok(f,now,e,SK_FRS_ALL_PROOFS);if(r)return r;
    if(f->Session->Lease || f->Session->PendingToken)return SK_PD_SESSION_BUSY;
    if(f->NextHardwareToken==0xffffffffU)return recover(f,o,SK_FRS_BAD_STATE);
    f->HardwareToken=++f->NextHardwareToken;f->ArmObligation=1;
    f->State=SK_FRS_ARM_PENDING;f->PhaseAtMs=now;actions(f,o,SK_FRS_ARM_HARDWARE);
    return SK_PD_OK;
}
int SkPdFrsArmComplete(SK_PD_FRS *f,SK_PD_U32 gen,SK_PD_U32 now,
                      SK_PD_U32 token,SK_PD_U32 verified,SK_FRS_OUTPUT *o)
{
    int r=enter(f,gen,o);if(r)return r;
    r=timer(f,now,o);if(r)return r;
    if(!token || token!=f->HardwareToken)return SK_PD_SESSION_STALE;
    if(f->State!=SK_FRS_ARM_PENDING)return SK_FRS_BAD_STATE;
    if(verified!=1)return recover(f,o,SK_FRS_NOT_READY);
    f->State=SK_FRS_ARMED;return SK_PD_OK;
}
int SkPdFrsSignal(SK_PD_FRS *f,SK_PD_U32 gen,SK_PD_U32 now,
                 SK_PD_U32 token,const SK_FRS_ENV *e,SK_FRS_OUTPUT *o)
{
    int r=enter(f,gen,o);if(r)return r;
    r=timer(f,now,o);if(r)return r;
    if(!token || token!=f->HardwareToken)return SK_PD_SESSION_STALE;
    if(f->State!=SK_FRS_ARMED)return SK_FRS_BAD_STATE;
    r=env_ok(f,now,e,SK_FRS_ALL_PROOFS & ~SK_FRS_FIXED_CONFIRMED);
    if(r)return recover(f,o,r);
    if(f->Session->PowerRole!=0 || f->Session->Revision!=2 ||
       f->Session->DataRole!=f->DataRole)return recover(f,o,SK_FRS_NOT_READY);
    r=SkPdSessionAcquire(f->Session,gen,3);if(r)return recover(f,o,r);
    actions(f,o,SK_FRS_QUIESCE_CHARGE);
    return emit(f,19,SK_FRS_SWAP_TX,now,o);
}
int SkPdFrsSourceReady(SK_PD_FRS *f,SK_PD_U32 gen,SK_PD_U32 now,
                      const SK_FRS_SOURCE_PROOF *p,SK_FRS_OUTPUT *o)
{
    int r=enter(f,gen,o);if(r)return r;
    r=timer(f,now,o);if(r)return r;
    if(f->State!=SK_FRS_SOURCE_READY)return SK_FRS_BAD_STATE;
    if(!p || p->Generation!=gen || !p->HardwareToken ||
       p->HardwareToken!=f->HardwareToken || !p->AdcConversionSerial ||
       now-p->ConversionAtMs>SK_FRS_ENV_MAX_AGE_MS ||
       p->ConversionAtMs-f->PhaseAtMs>0x7fffffffU ||
       p->SourcingConfirmed!=1 || p->ChargeOffConfirmed!=1 ||
       p->Millivolts<4750 || p->Millivolts>5500)
        return recover(f,o,SK_FRS_NOT_READY);
    f->SourceSeen=1;f->State=SK_FRS_HEADER_PENDING;
    /* Keep the source-ready deadline; do not extend it by resetting PhaseAt. */
    actions(f,o,SK_FRS_SET_SOURCE_HEADER);return SK_PD_OK;
}
int SkPdFrsHeaderComplete(SK_PD_FRS *f,SK_PD_U32 gen,SK_PD_U32 now,
                         SK_PD_U32 token,SK_PD_U32 verified,SK_FRS_OUTPUT *o)
{
    int r=enter(f,gen,o);if(r)return r;
    r=timer(f,now,o);if(r)return r;
    if(!token || token!=f->HardwareToken)return SK_PD_SESSION_STALE;
    if(f->State!=SK_FRS_HEADER_PENDING)return SK_FRS_BAD_STATE;
    if(verified!=1 || !f->SourceSeen)return recover(f,o,SK_FRS_NOT_READY);
    r=SkPdSessionSetRoles(f->Session,gen,3,1,f->DataRole);if(r)return recover(f,o,r);
    return emit(f,6,SK_FRS_PS_READY_TX,now,o);
}
int SkPdFrsPoll(SK_PD_FRS *f,SK_PD_U32 gen,SK_PD_U32 now,
               const SK_FRS_ENV *e,SK_FRS_OUTPUT *o)
{
    SK_PD_U32 flags;int r=enter(f,gen,o);if(r)return r;
    r=timer(f,now,o);if(r)return r;
    if(f->ArmObligation && f->State!=SK_FRS_SOURCE_STARTUP && f->State!=SK_FRS_DISARM_PENDING){
        flags=f->State==SK_FRS_ARM_PENDING || f->State==SK_FRS_ARMED?
            SK_FRS_ALL_PROOFS:SK_FRS_ALL_PROOFS & ~SK_FRS_FIXED_CONFIRMED;
        r=env_ok(f,now,e,flags);if(r)return recover(f,o,r);
        if(f->Session->DataRole!=f->DataRole)return recover(f,o,SK_FRS_NOT_READY);
        if(f->State==SK_FRS_ARM_PENDING || f->State==SK_FRS_ARMED){
            if(f->Session->PowerRole!=0 || f->Session->Revision!=2)
                return recover(f,o,SK_FRS_NOT_READY);
            if(f->Session->Lease || f->Session->PendingToken)
                return recover(f,o,SK_PD_SESSION_BUSY);
        }
    }
    return SK_PD_OK;
}
int SkPdFrsDisarm(SK_PD_FRS *f,SK_PD_U32 gen,SK_PD_U32 now,SK_FRS_OUTPUT *o)
{
    int r=enter(f,gen,o);if(r)return r;
    r=timer(f,now,o);if(r)return r;
    if(f->State>=SK_FRS_SWAP_TX && f->State<=SK_FRS_PS_READY_TX)
        return recover(f,o,SK_FRS_BAD_STATE);
    if(f->ArmObligation){
        actions(f,o,SK_FRS_DISARM_HARDWARE);
        if(f->State!=SK_FRS_DISARM_PENDING)f->PhaseAtMs=now;
        f->State=SK_FRS_DISARM_PENDING;
    }
    else if(f->State==SK_FRS_IDLE || f->State==SK_FRS_CAPABLE || f->State==SK_FRS_UNSUPPORTED)
        f->State=SK_FRS_IDLE;
    else return recover(f,o,SK_FRS_BAD_STATE);
    return SK_PD_OK;
}
int SkPdFrsDisarmComplete(SK_PD_FRS *f,SK_PD_U32 gen,SK_PD_U32 token,SK_PD_U32 verified)
{
    if(!f || !f->Session || !gen)return SK_PD_INVALID_ARGUMENT;
    if(gen!=f->Generation || gen!=f->Session->Generation)return SK_PD_SESSION_STALE;
    if(!token || token!=f->HardwareToken)return SK_PD_SESSION_STALE;
    if(!f->ArmObligation || (f->State!=SK_FRS_RECOVERY && f->State!=SK_FRS_DISARM_PENDING))
        return SK_FRS_BAD_STATE;
    if(verified!=1)return SK_FRS_NOT_READY;
    f->ArmObligation=0;f->SourceSeen=0;
    if(!f->Session->Faulted)f->State=SK_FRS_IDLE;
    return SK_PD_OK;
}
