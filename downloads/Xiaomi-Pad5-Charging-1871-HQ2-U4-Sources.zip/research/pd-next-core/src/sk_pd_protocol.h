#ifndef SK_PD_PROTOCOL_H
#define SK_PD_PROTOCOL_H

/* Transport-free PD wire codec. No register access, transmission or timers.
 * This component is not a PD policy engine or an installable Windows driver. */
typedef unsigned int SK_PD_U32;
typedef unsigned short SK_PD_U16;
typedef char SK_PD_REQUIRE_U32[(sizeof(SK_PD_U32) == 4) ? 1 : -1];
typedef char SK_PD_REQUIRE_U16[(sizeof(SK_PD_U16) == 2) ? 1 : -1];

enum {
    SK_PD_OK = 0,
    SK_PD_INVALID_ARGUMENT = -1,
    SK_PD_UNSUPPORTED = -2,
    SK_PD_OUT_OF_RANGE = -3,
    SK_PD_INVALID_ENCODING = -4
};

typedef struct SK_PD_HEADER {
    SK_PD_U32 MessageType;
    SK_PD_U32 Revision;
    SK_PD_U32 DataObjects;
    SK_PD_U32 Extended;
    SK_PD_U32 DataRole;
    SK_PD_U32 PowerRole;
    SK_PD_U32 MessageId;
} SK_PD_HEADER;

typedef struct SK_PD_CONTRACT {
    SK_PD_U32 ObjectPosition;
    SK_PD_U32 IsPps;
    SK_PD_U32 Millivolts;
    SK_PD_U32 Milliamps;
    SK_PD_U32 PowerLimitMilliwatts; /* RDO limit, not measured charging power. */
} SK_PD_CONTRACT;

/* Header parse preserves the extended bit and all five message-type bits.
 * It does not dispatch messages or imply support for an extended message. */
int SkPdDecodeHeader(SK_PD_U16 Raw, SK_PD_HEADER *Header);

/* PPS only: PD revision bits=2, SPR APDO subtype=0, exact 20mV/50mA units.
 * Flags allow only NoUsbSuspend/UsbCommunication/CapabilityMismatch.
 * Actual thermal, battery, cable and source-PDP limits belong to the policy. */
int SkPdBuildPpsRdo(SK_PD_U32 Pdo, SK_PD_U32 Position, SK_PD_U32 Revision,
                    SK_PD_U32 Millivolts, SK_PD_U32 Milliamps,
                    SK_PD_U32 Flags, SK_PD_U32 *Rdo);

/* Decode a selected fixed or PPS contract without interpreting PPS as fixed.
 * Caller guarantees a readable PDO array of Count entries. Outputs are zero
 * on failure. This does not confirm Accept/PS_RDY or enable any power path. */
int SkPdDecodeContract(const SK_PD_U32 *Pdos, SK_PD_U32 Count, SK_PD_U32 Rdo,
                       SK_PD_U32 Revision, SK_PD_CONTRACT *Contract);

#endif
