#include "sk_pmic_pd_rx.h"
#include "sk_pd_protocol.h"

#define RX_SIZE 0x48
#define RX_STATUS 0x4a
#define RX_ACK 0x4b
#define RX_HEADER 0x80
#define RX_PAYLOAD 0x82

static NTSTATUS sync_result(NTSTATUS status)
{
    return status==STATUS_SUCCESS ? STATUS_SUCCESS :
           ((NT_SUCCESS(status) || status==STATUS_NO_MORE_ENTRIES) ? STATUS_IO_DEVICE_ERROR : status);
}
static NTSTATUS read_bytes(SK_PMIC_PD_RX *r, USHORT offset, PUCHAR p, ULONG n)
{
    return sync_result(r->Ops.Read(r->BusContext,r->SID,(USHORT)(r->Base+offset),p,n));
}
ULONG SkPmicRxSize(VOID) { return sizeof(SK_PMIC_PD_RX); }
NTSTATUS SkPmicRxInitialize(SK_PMIC_PD_RX *r, const SK_PMIC_RX_OPS *ops,
                          PVOID bus, UCHAR sid, USHORT base)
{
    /* Pin this implementation to the observed PM8150B PD peripheral. A
     * device adapter must prove the SID/base binding before use.
     */
    if(!r || !ops || !ops->Read || !ops->Update || sid!=2 || base!=0x1700)
        return STATUS_INVALID_PARAMETER;
    if(r->Initialized)return STATUS_INVALID_DEVICE_STATE;
    r->Ops=*ops;r->BusContext=bus;r->SID=sid;r->Base=base;r->Reserved=0;
    r->NextToken=0;r->ActiveToken=0;r->Faulted=0;r->Initialized=1;
    return STATUS_SUCCESS;
}
NTSTATUS SkPmicRxRead(PVOID context, PUCHAR frame, PULONG length, PULONG token)
{
    SK_PMIC_PD_RX *r=(SK_PMIC_PD_RX *)context;
    SK_PD_HEADER header;
    ULONG capacity,wire_length,i;
    UCHAR state=0,channel=0,count=0;
    NTSTATUS status;
    if(!length || !token)return STATUS_INVALID_PARAMETER;
    capacity=*length;*length=0;*token=0;
    if(!r || !frame || capacity<32 || !r->Initialized)return STATUS_INVALID_PARAMETER;
    if(r->Faulted)return STATUS_INVALID_DEVICE_STATE;
    if(r->ActiveToken)return STATUS_DEVICE_BUSY;
    if(r->NextToken==MAXULONG)return STATUS_INTEGER_OVERFLOW;
    for(i=0;i<32;++i)((volatile UCHAR *)frame)[i]=0;
    status=read_bytes(r,RX_ACK,&state,1);
    if(status!=STATUS_SUCCESS){r->Faulted=1;return status;}
    if(!(state&1))return STATUS_NO_MORE_ENTRIES;
    /* Ownership is recorded before ANY further I/O, including malformed
     * size/status/header and partial bus read. The runtime always releases
     * this token exactly once before exposing the immutable copied packet.
     */
    r->ActiveToken=++r->NextToken;*token=r->ActiveToken;
    status=read_bytes(r,RX_STATUS,&channel,1);
    if(status!=STATUS_SUCCESS)goto fail;
    status=read_bytes(r,RX_SIZE,&count,1);
    if(status!=STATUS_SUCCESS)goto fail;
    count&=31;channel&=7;
    if(count<1 || count>29 || channel>2){status=STATUS_DATA_ERROR;goto fail;}
    wire_length=(ULONG)count+1; /* hardware count excludes one header byte */
    status=read_bytes(r,RX_HEADER,frame+2,2);
    if(status!=STATUS_SUCCESS)goto fail;
    if(SkPdDecodeHeader((SK_PD_U16)(frame[2]|((USHORT)frame[3]<<8)),&header)!=SK_PD_OK ||
       wire_length!=2+4*header.DataObjects){status=STATUS_DATA_ERROR;goto fail;}
    if(wire_length>2) {
        status=read_bytes(r,RX_PAYLOAD,frame+4,wire_length-2);
        if(status!=STATUS_SUCCESS)goto fail;
    }
    frame[0]=(UCHAR)(wire_length+1);frame[1]=channel;
    *length=wire_length+2;
    return STATUS_SUCCESS;
fail:
    r->Faulted=1;
    for(i=0;i<32;++i)((volatile UCHAR *)frame)[i]=0;
    return status;
}
NTSTATUS SkPmicRxRelease(PVOID context, ULONG token)
{
    SK_PMIC_PD_RX *r=(SK_PMIC_PD_RX *)context;
    NTSTATUS status;
    if(!r || !r->Initialized || !token)return STATUS_INVALID_PARAMETER;
    if(token!=r->ActiveToken)return STATUS_CANCELLED;
    /* Consume the logical token BEFORE I/O: a failed or pending ACK must
     * never be retried against a subsequently-arrived packet. Faulted
     * transport requires physical shutdown/reset by its owning adapter.
     */
    r->ActiveToken=0;
    status=sync_result(r->Ops.Update(r->BusContext,r->SID,(USHORT)(r->Base+RX_ACK),1,0));
    if(status!=STATUS_SUCCESS)r->Faulted=1;
    return status;
}
