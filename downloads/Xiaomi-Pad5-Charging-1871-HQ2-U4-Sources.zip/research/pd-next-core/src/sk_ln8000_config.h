/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef SK_LN8000_CONFIG_H
#define SK_LN8000_CONFIG_H
#include "sk_ln8000_profile.h"

/* Serialized PASSIVE_LEVEL component, using the SAME SK_LN8000 bus owner.
 * Not installed, not a new bus owner, and never negotiates a PD contract.
 * Configuring limits cannot establish ADC freshness or actual charge power.
 * Permission must come from current physical board/NTC/main charger evidence;
 * a saved fixture or a completed register read is not that permission.
 */
#define SK_LN_CONFIG_EXCLUSIVE 1u
#define SK_LN_CONFIG_BOARD_AND_NTC_VALIDATED 2u
#define SK_LN_CONFIG_MAIN_QUIESCED 4u
#define SK_LN_CONFIG_MAIN_INPUT_BUDGET_VERIFIED 8u
#define SK_LN_CONFIG_ALL_PROOFS 15u
typedef struct SK_LN_CONFIG_PERMIT {
    ULONG Generation,ObservedAtMs,Flags,ContractMaxMicrovolts,ContractMaxMicroamps;
    /* A fresh, calibrated conservative upper bound for main buck/system
     * input, in USB input amps. Disabling the main battery charger does not
     * stop the buck from powering the running tablet. Reserve that draw
     * before assigning current to the pump; battery amps are not USB amps.
     * Physical adapter must include measurement uncertainty/headroom here.
     */
    ULONG MainInputBudgetMicroamps;
} SK_LN_CONFIG_PERMIT;
typedef struct SK_LN_CONFIG_REQUEST {
    ULONG FloatMicrovolts,InputLimitMicroamps,NtcAlarmRaw;
} SK_LN_CONFIG_REQUEST;
typedef struct SK_LN_CONFIG {
    SK_LN8000 *Converter;
    ULONG Generation,Committed,ShutdownObligation,LastNowMs;
    UCHAR Masks[15],Values[15]; /* known fields 0x1b..0x29 only */
} SK_LN_CONFIG;

NTSTATUS SkLnConfigInitialize(SK_LN_CONFIG *,SK_LN8000 *,ULONG Generation,ULONG NowMs);
/* Bounded, verified standby-first transaction. Success leaves the converter
 * in physical STANDBY, with RCP disabled for the existing two-phase start.
 * Known voltage/current/thermal protections and both NTC ADC channels are
 * enabled. ADC uses known NORMAL mode for completion monitoring, including
 * standby. Reserved bits, frequency, threshold and watchdog are preserved.
 * The low-current limit rounds DOWN in 50mA increments; no wrap/saturation.
 * A partial/failed write invalidates the configuration and requests standby.
 * Failure to confirm standby retains ShutdownObligation/NeedsRecovery.
 * No restoration of an earlier potentially unsafe enable/config image.
 */
NTSTATUS SkLnConfigApply(SK_LN_CONFIG *,ULONG Generation,ULONG NowMs,
                       const SK_LN_CONFIG_PERMIT *,const SK_LN_CONFIG_REQUEST *);
/* Current register readback against the committed masks, with fresh permit.
 * A control bit being enabled does NOT prove a protection's electrical
 * function or thermistor calibration. Checks precede Begin2To1/Poll2To1 in
 * the future physical adapter; this component is not wired to it yet.
 * A mismatch during an active pump requests verified shutdown.
 */
NTSTATUS SkLnConfigCheck(SK_LN_CONFIG *,ULONG Generation,ULONG NowMs,
                       const SK_LN_CONFIG_PERMIT *,SK_LN_PROFILE_STATUS *);
NTSTATUS SkLnConfigStop(SK_LN_CONFIG *,ULONG Generation);
/* Entry points for the future physical owner: configuration/readback checks
 * are mandatory before every real converter command. The PROFILE_VERIFIED
 * bit is derived here from committed readback and the calibrated-board
 * permit; the caller must supply all OTHER physical PPS/battery proofs.
 * Contract, converter and requested current must share the same limits.
 * These entry points still do not provide the physical bus/PD adapter.
 */
NTSTATUS SkLnConfigBegin2To1(SK_LN_CONFIG *,ULONG Generation,ULONG NowMs,
    const SK_LN_CONFIG_PERMIT *,const SK_LN_PPS_PROOF *);
NTSTATUS SkLnConfigPoll2To1(SK_LN_CONFIG *,ULONG Generation,ULONG NowMs,
    const SK_LN_CONFIG_PERMIT *,const SK_LN_PPS_PROOF *);
NTSTATUS SkLnConfigBegin2To1Timed(SK_LN_CONFIG *,ULONG Generation,ULONG NowMs,
    const SK_LN_CONFIG_PERMIT *,const SK_LN_PPS_PROOF *,SK_LN_CLOCK,PVOID);
NTSTATUS SkLnConfigPoll2To1Timed(SK_LN_CONFIG *,ULONG Generation,ULONG NowMs,
    const SK_LN_CONFIG_PERMIT *,const SK_LN_PPS_PROOF *,SK_LN_CLOCK,PVOID);
NTSTATUS SkLnConfigBegin2To1Gated(SK_LN_CONFIG *,ULONG,ULONG,
    const SK_LN_CONFIG_PERMIT *,const SK_LN_PPS_PROOF *,const SK_LN_GATE *);
NTSTATUS SkLnConfigPoll2To1Gated(SK_LN_CONFIG *,ULONG,ULONG,
    const SK_LN_CONFIG_PERMIT *,const SK_LN_PPS_PROOF *,const SK_LN_GATE *);
ULONG SkLnConfigSize(VOID);
#endif
