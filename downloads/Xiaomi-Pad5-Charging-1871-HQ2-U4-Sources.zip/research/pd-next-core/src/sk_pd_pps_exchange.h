#ifndef SK_PD_PPS_EXCHANGE_H
#define SK_PD_PPS_EXCHANGE_H
#include "sk_pd_session.h"
#include "sk_pps_guard.h"

/* PPS AMS coordinator for the SINGLE consumer, between immutable RX and the
 * verified PHY TX adapter. Not a second transmitter beside UcmTcpciCx.
 *
 * Before Initialize: stop native policy, cancel/drain its HW work, own RX/TX
 * and confirm fast-path disabled. NativeStopped is the adapter's evidence,
 * not evidence supplied by this module. ConfirmFixed is invoked ONLY by a
 * complete fixed-PD owner after matching Request/Accept/PS_RDY, with limits
 * and electrical state validated. The fixed owner and this component must
 * use the SAME Session and must not reinitialize wire IDs between AMSs.
 *
 * SinkTxAllowed=1 means a current, attachment-matched Rp3.0/SinkTxOK hardware
 * sample and no other active AMS, serialized with TX submission. No saved
 * boolean or unsolicited timer substitutes for that sample. 0 defers the
 * request but continues sensor/deadline monitoring. Full CC/PD/source/role
 * policy, extended responses and timers/scheduling are not provided here.
 * Every returned Fast Flags must be acted on by the hardware/report adapter.
 */
enum { SK_PPS_EXCHANGE_DEFERRED=4, SK_PPS_EXCHANGE_CAPABILITIES=5,
       SK_PPS_FIXED_CONTRACT_RESTORED=16 };
typedef struct SK_PD_PPS_OUTPUT {
    /* With FIXED_CONTRACT_RESTORED, Rdo is the existing FIXED contract,
     * never an APDO or a fabricated replacement PDO. Apply DISABLE_FAST
     * before restoring ordinary draw/reporting; Type-C stays attached. */
    SK_PPS_ACTION Fast;
    SK_PD_SESSION_TX Tx;
} SK_PD_PPS_OUTPUT;

typedef struct SK_PD_PPS_EXCHANGE {
    SK_PD_SESSION Session;
    SK_PPS_GUARD Guard;
    SK_PD_U32 SourcePdos[7], SourceCount, FixedReady;
    SK_PD_U32 Pdo, Position, WireToken, Lease;
    SK_PD_U32 FixedRdo, AttemptFromFixed, InitialRefused;
    /* Immutable capability snapshot for the existing physical fixed
     * contract. A new advertisement does not change VBUS by itself, and
     * its reordered PDOs must not reinterpret the old RDO. FixedReady
     * still requires confirmation against the CURRENT advertisement. */
    SK_PD_U32 SourceEpoch, FixedEpoch, FixedSourceCount, FixedSourcePdos[7];
} SK_PD_PPS_EXCHANGE;

int SkPdPpsExchangeInitialize(SK_PD_PPS_EXCHANGE *, SK_PD_U32 Generation,
    SK_PD_U32 Now, SK_PD_U32 DataRole, SK_PD_U32 NativeStopped);
int SkPdPpsExchangeReceive(SK_PD_PPS_EXCHANGE *, SK_PD_U32 Generation,
    SK_PD_U32 Now, const unsigned char *Frame, SK_PD_U32 Bytes, SK_PD_PPS_OUTPUT *);
int SkPdPpsExchangeConfirmFixed(SK_PD_PPS_EXCHANGE *, SK_PD_U32 Generation,
    SK_PD_U32 Rdo);
int SkPdPpsExchangeBegin(SK_PD_PPS_EXCHANGE *, SK_PD_U32 Generation,
    SK_PD_U32 Now, SK_PD_U32 Position, SK_PD_U32 Millivolts,
    SK_PD_U32 Milliamps, SK_PD_U32 SinkTxAllowed,
    const SK_PPS_LIMITS *, SK_PD_PPS_OUTPUT *);
int SkPdPpsExchangeTxComplete(SK_PD_PPS_EXCHANGE *, SK_PD_U32 Generation,
    SK_PD_U32 Now, SK_PD_U32 Token, SK_PD_U32 Result, SK_PD_PPS_OUTPUT *);
int SkPdPpsExchangeObserve(SK_PD_PPS_EXCHANGE *, SK_PD_U32 Generation,
    SK_PD_U32 Now, SK_PD_U32 RequestId, SK_PD_U32 VbusMillivolts,
    SK_PD_U32 SafeInputs, SK_PD_PPS_OUTPUT *);
int SkPdPpsExchangePoll(SK_PD_PPS_EXCHANGE *, SK_PD_U32 Generation,
    SK_PD_U32 Now, SK_PD_U32 SinkTxAllowed, const SK_PPS_LIMITS *, SK_PD_PPS_OUTPUT *);
int SkPdPpsExchangeFault(SK_PD_PPS_EXCHANGE *, SK_PD_U32 Generation,
    SK_PD_U32 Now, SK_PD_PPS_OUTPUT *);
SK_PD_U32 SkPdPpsExchangeSize(void);
#endif
