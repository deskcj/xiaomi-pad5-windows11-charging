#include "sk_pd_fixed_exchange.h"

static void zero(void *p,SK_PD_U32 n)
{SK_PD_U32 i;for(i=0;i<n;++i)((volatile unsigned char *)p)[i]=0;}
static int enter(SK_PD_FIXED_EXCHANGE *f,SK_PD_U32 generation,SK_PD_FIXED_OUTPUT *o)
{
    if(!o)return SK_PD_INVALID_ARGUMENT;
    zero(o,sizeof(*o));
    if(!f || !f->Pps || !generation)return SK_PD_INVALID_ARGUMENT;
    if(generation!=f->Generation || generation!=f->Pps->Session.Generation)
        return SK_PD_SESSION_STALE;
    if(!f->Pps->Session.NativeStopped)return SK_PD_SESSION_NOT_READY;
    return SK_PD_OK;
}
static int recover(SK_PD_FIXED_EXCHANGE *f,SK_PD_U32 now,SK_PD_FIXED_OUTPUT *o,int why)
{
    SK_PD_PPS_OUTPUT p;
    (void)SkPdPpsExchangeFault(f->Pps,f->Generation,now,&p);
    f->State=SK_FIXED_RECOVERY;f->WireToken=0;f->HaveContract=0;
    zero(&f->Confirmed,sizeof(f->Confirmed));
    zero(&o->Tx,sizeof(o->Tx));zero(&o->Contract,sizeof(o->Contract));
    o->Flags=SK_FIXED_DISABLE_FAST|SK_FIXED_OWNER_RECOVERY;
    o->Generation=f->Generation;o->RequestId=f->RequestId;o->Rdo=f->Rdo;
    return why;
}
static int check(SK_PD_FIXED_EXCHANGE *f,SK_PD_U32 now,SK_PD_FIXED_OUTPUT *o)
{
    SK_PD_U32 timeout=0;
    SK_PPS_ACTION a;
    if(f->State==SK_FIXED_RECOVERY)return SK_FIXED_BAD_STATE;
    if(f->Pps->Guard.State!=SK_PPS_IDLE)
        return SK_FIXED_BAD_STATE; /* PPS owns active state; do not cancel it. */
    if(f->Pps->Session.Faulted)return recover(f,now,o,SK_PD_SESSION_RECOVERY);
    if(f->State>=SK_FIXED_WAIT_TX && f->State<=SK_FIXED_WAIT_MEASUREMENT){
        if(f->Pps->Session.Lease!=2 ||
           f->Pps->Session.PendingToken!=f->WireToken)
            return recover(f,now,o,SK_PD_SESSION_RECOVERY);
    }
    if(now-f->LastNow>0x7fffffffU)return recover(f,now,o,SK_FIXED_CLOCK_ERROR);
    f->LastNow=now;
    if(SkPpsCheckTimers(&f->Pps->Guard,now,&a))
        return recover(f,now,o,SK_FIXED_CLOCK_ERROR);
    switch(f->State){
    case SK_FIXED_WAIT_TX:timeout=f->Timers.TxMs;break;
    case SK_FIXED_WAIT_ACCEPT:timeout=f->Timers.ResponseMs;break;
    case SK_FIXED_WAIT_PS_RDY:timeout=f->Timers.TransitionMs;break;
    case SK_FIXED_WAIT_MEASUREMENT:timeout=f->Timers.MeasurementMs;break;
    default:break;
    }
    if(timeout && now-f->PhaseStart>=timeout)return recover(f,now,o,SK_FIXED_TIMED_OUT);
    return SK_PD_OK;
}
static int limits_ok(const SK_PD_CONTRACT *c,const SK_PD_FIXED_LIMITS *l)
{
    if(!l)return SK_PD_INVALID_ARGUMENT;
    if(l->Prerequisites!=SK_FIXED_ALL_PREREQUISITES)return SK_PD_SESSION_NOT_READY;
    if(!l->MaxMillivolts || l->MaxMillivolts>9000 || !l->MaxMilliamps ||
       l->MaxMilliamps>3000 || !l->CableMilliamps || l->CableMilliamps>3000 ||
       !l->MaxMilliwatts || !l->VbusToleranceMillivolts || l->VbusToleranceMillivolts>1000)
        return SK_PD_INVALID_ARGUMENT;
    if(c->Millivolts>l->MaxMillivolts || c->Milliamps>l->MaxMilliamps ||
       c->Milliamps>l->CableMilliamps || c->PowerLimitMilliwatts>l->MaxMilliwatts)
        return SK_PD_OUT_OF_RANGE;
    return SK_PD_OK;
}
SK_PD_U32 SkPdFixedSize(void){return sizeof(SK_PD_FIXED_EXCHANGE);}
int SkPdFixedInitialize(SK_PD_FIXED_EXCHANGE *f,SK_PD_PPS_EXCHANGE *e,
    SK_PD_U32 now,const SK_PD_FIXED_TIMERS *t)
{
    SK_PPS_ACTION a;
    if(!f || !e || !t || !e->Session.Generation || !e->Session.NativeStopped ||
       e->Session.PowerRole || e->Session.Lease || e->Session.PendingToken ||
       e->Session.Faulted || e->Guard.State!=SK_PPS_IDLE || e->FixedReady ||
       !t->TxMs || t->TxMs>100 || !t->ResponseMs || t->ResponseMs>100 ||
       !t->TransitionMs || t->TransitionMs>1000 || !t->MeasurementMs || t->MeasurementMs>1000)
        return SK_PD_INVALID_ARGUMENT;
    if(SkPpsCheckTimers(&e->Guard,now,&a))return SK_FIXED_CLOCK_ERROR;
    zero(f,sizeof(*f));f->Pps=e;f->Timers=*t;
    f->Generation=e->Session.Generation;f->LastNow=now;
    return SK_PD_OK;
}
int SkPdFixedBegin(SK_PD_FIXED_EXCHANGE *f,SK_PD_U32 generation,
    SK_PD_U32 now,SK_PD_U32 position,SK_PD_U32 ma,SK_PD_U32 flags,
    SK_PD_U32 grant,const SK_PD_FIXED_LIMITS *limits,SK_PD_FIXED_OUTPUT *o)
{
    SK_PD_U32 pdo,rdo,i;unsigned char payload[4];SK_PD_CONTRACT c;
    int r=enter(f,generation,o);if(r)return r;
    r=check(f,now,o);if(r)return r;
    if(f->State!=SK_FIXED_IDLE && f->State!=SK_FIXED_READY && f->State!=SK_FIXED_REJECTED)
        return SK_FIXED_BAD_STATE;
    if(f->Pps->Session.PowerRole || f->Pps->Session.Lease || f->Pps->Session.PendingToken)
        return SK_PD_SESSION_BUSY;
    if(!position || position>f->Pps->SourceCount || grant>1 || (flags&~0x07000000U))
        return SK_PD_INVALID_ARGUMENT;
    pdo=f->Pps->SourcePdos[position-1];
    if(pdo>>30)return SK_PD_UNSUPPORTED;
    if(!ma || ma>3000 || ma%10 || ma>(pdo&1023)*10)return SK_PD_OUT_OF_RANGE;
    /* Original nabu pd_select_pdo rejects fixed voltage >9000000uV. Preserve
     * its 5..9V fixed bound, independently of supplied software limit values. */
    if(((pdo>>10)&1023)<100 || ((pdo>>10)&1023)>180)return SK_PD_UNSUPPORTED;
    rdo=(position<<28)|flags|((ma/10)<<10)|(ma/10);
    r=SkPdDecodeContract(f->Pps->SourcePdos,f->Pps->SourceCount,rdo,
        f->Pps->Session.Revision,&c);if(r)return r;
    r=limits_ok(&c,limits);if(r)return r;
    if(!grant)return SK_FIXED_DEFERRED;
    /* New Source_Capabilities require renegotiation before PPS, but do not
     * change the existing physical fixed contract without Accept/PS_RDY.
     * Keep that immutable contract for a refused replacement Request. */
    r=SkPdSessionAcquire(&f->Pps->Session,generation,2);if(r)return r;
    for(i=0;i<4;++i)payload[i]=(unsigned char)(rdo>>(8*i));
    r=SkPdSessionTransmit(&f->Pps->Session,generation,2,2,payload,4,&o->Tx);
    if(r)return recover(f,now,o,r);
    f->Rdo=rdo;f->Pending=c;f->WireToken=o->Tx.Token;f->RequestId=o->Tx.Token;
    f->State=SK_FIXED_WAIT_TX;f->PhaseStart=now;f->Pps->FixedReady=0;
    o->Flags=SK_FIXED_LIMIT_DRAW|SK_FIXED_TRANSMIT;
    o->Generation=generation;o->RequestId=f->RequestId;o->Rdo=rdo;
    return SK_PD_OK;
}
int SkPdFixedTxComplete(SK_PD_FIXED_EXCHANGE *f,SK_PD_U32 generation,
    SK_PD_U32 now,SK_PD_U32 token,SK_PD_U32 result,SK_PD_FIXED_OUTPUT *o)
{
    int r=enter(f,generation,o);if(r)return r;
    if(!token || token!=f->WireToken)return SK_PD_SESSION_STALE;
    r=check(f,now,o);if(r)return r;
    if(f->State!=SK_FIXED_WAIT_TX)return SK_FIXED_BAD_STATE;
    if(result<1 || result>3)return SK_PD_INVALID_ARGUMENT;
    r=SkPdSessionTxComplete(&f->Pps->Session,generation,token,result);
    if(r)return recover(f,now,o,r);
    f->WireToken=0;f->State=SK_FIXED_WAIT_ACCEPT;f->PhaseStart=now;
    return SK_PD_OK;
}
int SkPdFixedReceive(SK_PD_FIXED_EXCHANGE *f,SK_PD_U32 generation,
    SK_PD_U32 now,const unsigned char *frame,SK_PD_U32 bytes,SK_PD_FIXED_OUTPUT *o)
{
    SK_PD_HEADER h;int r=enter(f,generation,o);if(r)return r;
    r=check(f,now,o);if(r)return r;
    if(f->State<SK_FIXED_WAIT_TX || f->State>SK_FIXED_WAIT_MEASUREMENT)
        return SK_FIXED_BAD_STATE;
    r=SkPdSessionReceive(&f->Pps->Session,generation,frame,bytes,&h);
    if(r==SK_PD_SESSION_DUPLICATE)return r;
    if(r)return recover(f,now,o,r);
    if(h.DataObjects)return recover(f,now,o,SK_PD_UNSUPPORTED);
    if(f->State==SK_FIXED_WAIT_ACCEPT && h.MessageType==3){
        f->State=SK_FIXED_WAIT_PS_RDY;f->PhaseStart=now;return SK_PD_OK;
    }
    if(f->State==SK_FIXED_WAIT_PS_RDY && h.MessageType==6){
        f->State=SK_FIXED_WAIT_MEASUREMENT;f->PhaseStart=now;return SK_PD_OK;
    }
    if(f->State==SK_FIXED_WAIT_ACCEPT && (h.MessageType==4 || h.MessageType==12)){
        r=SkPdSessionRelease(&f->Pps->Session,generation,2);
        if(r)return recover(f,now,o,r);
        f->State=f->HaveContract?SK_FIXED_READY:SK_FIXED_REJECTED;
        f->Pps->FixedReady=f->HaveContract &&
                          f->Pps->FixedEpoch==f->Pps->SourceEpoch;
        o->Flags=f->HaveContract?SK_FIXED_RESTORE_CONTRACT:SK_FIXED_KEEP_DEFAULT_SINK;
        o->Generation=generation;o->RequestId=f->RequestId;
        if(f->HaveContract){o->Contract=f->Confirmed;o->Rdo=f->ConfirmedRdo;}
        return SK_PD_OK;
    }
    return recover(f,now,o,SK_FIXED_BAD_STATE);
}
int SkPdFixedObserve(SK_PD_FIXED_EXCHANGE *f,SK_PD_U32 generation,
    SK_PD_U32 now,SK_PD_U32 request,SK_PD_U32 vbus,SK_PD_U32 safe,
    const SK_PD_FIXED_LIMITS *limits,SK_PD_FIXED_OUTPUT *o)
{
    SK_PD_U32 delta;int r=enter(f,generation,o);if(r)return r;
    if(!request || request!=f->RequestId)return SK_PD_SESSION_STALE;
    r=check(f,now,o);if(r)return r;
    if(f->State!=SK_FIXED_WAIT_MEASUREMENT)return SK_FIXED_BAD_STATE;
    r=limits_ok(&f->Pending,limits);
    if(r)return recover(f,now,o,r);
    delta=vbus>f->Pending.Millivolts?vbus-f->Pending.Millivolts:f->Pending.Millivolts-vbus;
    if(safe!=1 || !vbus || vbus>limits->MaxMillivolts || delta>limits->VbusToleranceMillivolts)
        return recover(f,now,o,SK_PD_OUT_OF_RANGE);
    /* Own the AMS until the voltage is measured, then allow PPS on the SAME
     * wire session. Never reinitialize IDs between fixed and PPS requests. */
    r=SkPdSessionRelease(&f->Pps->Session,generation,2);
    if(r)return recover(f,now,o,r);
    r=SkPdPpsExchangeConfirmFixed(f->Pps,generation,f->Rdo);
    if(r)return recover(f,now,o,r);
    f->Confirmed=f->Pending;f->ConfirmedRdo=f->Rdo;f->HaveContract=1;f->State=SK_FIXED_READY;
    o->Flags=SK_FIXED_REPORT_CONTRACT;o->Generation=generation;
    o->RequestId=f->RequestId;o->Rdo=f->Rdo;o->Contract=f->Confirmed;
    return SK_PD_OK;
}
int SkPdFixedPoll(SK_PD_FIXED_EXCHANGE *f,SK_PD_U32 generation,
    SK_PD_U32 now,SK_PD_FIXED_OUTPUT *o)
{int r=enter(f,generation,o);return r?r:check(f,now,o);}
int SkPdFixedFault(SK_PD_FIXED_EXCHANGE *f,SK_PD_U32 generation,
    SK_PD_U32 now,SK_PD_FIXED_OUTPUT *o)
{int r=enter(f,generation,o);return r?r:recover(f,now,o,SK_PD_SESSION_RECOVERY);}
