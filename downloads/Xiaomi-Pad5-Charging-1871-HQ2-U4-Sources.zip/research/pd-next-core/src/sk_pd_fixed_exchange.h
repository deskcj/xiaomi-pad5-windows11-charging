#ifndef SK_PD_FIXED_EXCHANGE_H
#define SK_PD_FIXED_EXCHANGE_H
#include "sk_pd_pps_exchange.h"

/* Initial/repeated nabu fixed-sink AMS, sharing the PPS owner's wire session.
 * SINGLE PASSIVE_LEVEL consumer only; route incoming frames to this component
 * while its lease is active, otherwise to the appropriate complete policy.
 * Not a source/role policy, Windows device binding or installed driver.
 *
 * Owner must apply LIMIT_DRAW before submitting Tx, bind physical TX IRQs to
 * its token, and supply attachment-matched CC permission, ADC/fault/thermal
 * inputs and timers. No register submission confirms a contract. Keep the
 * lease through PS_RDY AND ADC: PPS cannot start during voltage validation.
 * Original nabu pd_select_pdo rejects FIXED >9V. This target policy retains
 * that bound; PPS >9V still requires its separately verified charger path.
 */
enum {
    SK_FIXED_IDLE=0, SK_FIXED_WAIT_TX=1, SK_FIXED_WAIT_ACCEPT=2,
    SK_FIXED_WAIT_PS_RDY=3, SK_FIXED_WAIT_MEASUREMENT=4,
    SK_FIXED_READY=5, SK_FIXED_RECOVERY=6, SK_FIXED_REJECTED=7,
    SK_FIXED_BAD_STATE=-30, SK_FIXED_TIMED_OUT=-31, SK_FIXED_CLOCK_ERROR=-32,
    SK_FIXED_DEFERRED=6,
    SK_FIXED_LIMIT_DRAW=1, SK_FIXED_TRANSMIT=2,
    SK_FIXED_REPORT_CONTRACT=4, SK_FIXED_RESTORE_CONTRACT=8,
    SK_FIXED_DISABLE_FAST=16, SK_FIXED_OWNER_RECOVERY=32,
    SK_FIXED_KEEP_DEFAULT_SINK=64,
    SK_FIXED_SINK_PATH_OWNED=1, SK_FIXED_FAST_DISABLED=2,
    SK_FIXED_ALL_PREREQUISITES=3
};
typedef struct SK_PD_FIXED_TIMERS {
    SK_PD_U32 TxMs, ResponseMs, TransitionMs, MeasurementMs;
} SK_PD_FIXED_TIMERS;
typedef struct SK_PD_FIXED_LIMITS {
    SK_PD_U32 Prerequisites, MaxMillivolts, MaxMilliamps, CableMilliamps;
    SK_PD_U32 MaxMilliwatts, VbusToleranceMillivolts;
} SK_PD_FIXED_LIMITS;
typedef struct SK_PD_FIXED_OUTPUT {
    SK_PD_U32 Flags, Generation, RequestId, Rdo;
    SK_PD_SESSION_TX Tx;
    /* Valid ONLY with REPORT/RESTORE flags. On RESTORE, Rdo uses the
     * Pps.FixedSourcePdos snapshot, even if a new advertisement reordered
     * the live SourcePdos. Never decode it against those new PDOs. */
    SK_PD_CONTRACT Contract;
} SK_PD_FIXED_OUTPUT;
typedef struct SK_PD_FIXED_EXCHANGE {
    SK_PD_PPS_EXCHANGE *Pps;
    SK_PD_FIXED_TIMERS Timers;
    SK_PD_U32 Generation, LastNow, PhaseStart, State, RequestId, WireToken;
    SK_PD_U32 Rdo, ConfirmedRdo, HaveContract;
    SK_PD_CONTRACT Pending, Confirmed;
} SK_PD_FIXED_EXCHANGE;

int SkPdFixedInitialize(SK_PD_FIXED_EXCHANGE *, SK_PD_PPS_EXCHANGE *,
    SK_PD_U32 Now, const SK_PD_FIXED_TIMERS *);
int SkPdFixedBegin(SK_PD_FIXED_EXCHANGE *, SK_PD_U32 Generation,
    SK_PD_U32 Now, SK_PD_U32 Position, SK_PD_U32 Milliamps, SK_PD_U32 Flags,
    SK_PD_U32 SinkTxAllowed, const SK_PD_FIXED_LIMITS *, SK_PD_FIXED_OUTPUT *);
int SkPdFixedTxComplete(SK_PD_FIXED_EXCHANGE *, SK_PD_U32 Generation,
    SK_PD_U32 Now, SK_PD_U32 Token, SK_PD_U32 Result, SK_PD_FIXED_OUTPUT *);
int SkPdFixedReceive(SK_PD_FIXED_EXCHANGE *, SK_PD_U32 Generation,
    SK_PD_U32 Now, const unsigned char *, SK_PD_U32 Bytes, SK_PD_FIXED_OUTPUT *);
int SkPdFixedObserve(SK_PD_FIXED_EXCHANGE *, SK_PD_U32 Generation,
    SK_PD_U32 Now, SK_PD_U32 RequestId, SK_PD_U32 VbusMillivolts,
    SK_PD_U32 SafeInputs, const SK_PD_FIXED_LIMITS *, SK_PD_FIXED_OUTPUT *);
int SkPdFixedPoll(SK_PD_FIXED_EXCHANGE *, SK_PD_U32 Generation,
    SK_PD_U32 Now, SK_PD_FIXED_OUTPUT *);
/* Ambiguous bus/ACK failure or detach/fault from the owning runtime. The
 * caller must act on DISABLE_FAST/OWNER_RECOVERY; no reset is synthesized. */
int SkPdFixedFault(SK_PD_FIXED_EXCHANGE *, SK_PD_U32 Generation,
    SK_PD_U32 Now, SK_PD_FIXED_OUTPUT *);
SK_PD_U32 SkPdFixedSize(void);
#endif
