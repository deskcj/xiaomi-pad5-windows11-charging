/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef SK_LN8000_H
#define SK_LN8000_H
#include <ntddk.h>

/* Per-device, PASSIVE_LEVEL, serialized by the owning hardware adapter.
 * Initialize fresh nonpaged storage once, before exposing it. The adapter
 * must own a verified I2C5 connection to the physical 7-bit address 0x51;
 * callbacks perform bounded SPB transfers and report actual byte counts.
 * This component does not create that resource or install a driver.
 * The two-phase 2:1 API below is only for an exclusive physical adapter with
 * an already verified protection profile and real PD3/ADC/battery ownership.
 * It does not create that adapter, negotiate PD, or change USB roles.
 */
typedef NTSTATUS (*SK_LN_READ)(PVOID,UCHAR,PUCHAR,ULONG,PULONG);
typedef NTSTATUS (*SK_LN_WRITE)(PVOID,UCHAR,const UCHAR *,ULONG,PULONG);
typedef ULONG (*SK_LN_CLOCK)(PVOID);
/* Serialized, nonblocking permission check. Must not perform bus work or
 * reenter this converter. A timer/PD/CC fault can revoke permission during
 * an SPB transaction even while the independent LN ADC bank is fresh. */
typedef NTSTATUS (*SK_LN_VALIDATE)(PVOID,ULONG Generation,ULONG NowMs);
typedef struct SK_LN_GATE {
    SK_LN_CLOCK Clock;
    PVOID ClockContext;
    SK_LN_VALIDATE Validate;
    PVOID ValidationContext;
    ULONG SafetyObservedAtMs;
} SK_LN_GATE;
typedef struct SK_LN_OPS { SK_LN_READ Read; SK_LN_WRITE Write; } SK_LN_OPS;
typedef struct SK_LN8000 {
    SK_LN_OPS Ops;
    PVOID Device;
    ULONG Generation, Busy, Probed, NeedsRecovery, OwnAdcPause;
    ULONG FastStartAtMs, FastLastNowMs, FastStartAdcSerial;
    ULONG FastPending, FastActive, FastObligation;
    ULONG FastLastAdcSerial;
    ULONG FastLastAdcAtMs;
    /* Fits the original ARM64 tail padding. Only the exclusive ADC event
     * owner may acquire this interrupt-update hold. A failed transfer can
     * still set it on silicon; keep the obligation until verified release. */
    ULONG OwnIntPause;
} SK_LN8000;

typedef struct SK_LN_SNAPSHOT {
    ULONG Generation, ReadAtMs, Complete;
    ULONG VinMicrovolts,VbatMicrovolts,IinMicroamps,VacMicrovolts;
    LONG DieTemperatureDeciC;
    ULONG BatteryNtcRawCode,BusNtcMicrovolts,PowerState,FaultBits;
    UCHAR Registers[16]; /* register 0x03 through 0x12, same paused ADC bank */
    /* Complete means exact transfers and successful ADC release. Hold is
     * rechecked in the acquisition RMW read and only our hold is released.
     * Exclusive physical ownership is still required for this non-atomic
     * register read/write pair. ReadAtMs
     * dates the read, NOT an ADC conversion. No SafeInputs/fast permission is
     * inferred here: owner must confirm ADC freshness, main battery thermal
     * data, calibration, voltage ratios, configured protection and limits.
     * BatteryNtcRawCode is deliberately not labelled degrees or microvolts.
     * Original nabu ELF channel 7 uses a battery-dependent thermistor table,
     * unlike the saved source; do not substitute that source's voltage.
     */
} SK_LN_SNAPSHOT;

/* Physical SYS_STS bits, not the Android software opmode enum.
 * Original ln8000_update_opmode maps bit2 to SWITCHING(3), bit3 to
 * BYPASS(2), and either low bit to STANDBY(1). SYS_CTRL bit0 selects 1:1;
 * clearing it requests 2:1, whose confirmation is SYS_STS bit2.
 */
#define SK_LN_SYS_SHUTDOWN  0x01u
#define SK_LN_SYS_STANDBY   0x02u
#define SK_LN_SYS_SWITCHING 0x04u
#define SK_LN_SYS_BYPASS    0x08u

NTSTATUS SkLn8000Initialize(SK_LN8000 *,const SK_LN_OPS *,PVOID,
                           ULONG Generation,ULONG VerifiedAddress);
NTSTATUS SkLn8000Probe(SK_LN8000 *,ULONG Generation);
NTSTATUS SkLn8000Snapshot(SK_LN8000 *,ULONG Generation,ULONG ReadAtMs,
                         SK_LN_SNAPSHOT *);
/* Confirmed ONLY after control readback AND physical SYS_STS standby/shutdown.
 * DEVICE_NOT_READY means the converter has not stopped; owner must retain
 * the shutdown obligation and schedule recovery. No ordinary charging
 * fallback/reporting is permitted merely because the write succeeded.
 * Also releases an ADC pause owned by a failed Snapshot before clearing its
 * recovery latch. External ADC pauses are never silently cleared.
 */
NTSTATUS SkLn8000Standby(SK_LN8000 *,ULONG Generation);
NTSTATUS SkLn8000Decode(const UCHAR *Registers,ULONG Length,SK_LN_SNAPSHOT *);
ULONG SkLn8000Size(VOID);

#define SK_LN_PPS_EXCLUSIVE_OWNER     0x01u
#define SK_LN_PPS_PROFILE_VERIFIED    0x02u
#define SK_LN_PPS_MAIN_QUIESCED       0x04u
#define SK_LN_PPS_PD3_CONFIRMED       0x08u
#define SK_LN_PPS_ADC_FRESH           0x10u
#define SK_LN_PPS_THERMAL_APPROVED    0x20u
#define SK_LN_PPS_ALL_PROOFS          0x3fu
typedef struct SK_LN_PPS_PROOF {
    ULONG Generation, Flags, SampleAtMs, AdcConversionSerial;
    ULONG PdMicrovolts, MaxInputMicroamps, FuelCellMicrovolts, SocPercent;
    LONG BatteryTemperatureDeciC;
    SK_LN_SNAPSHOT Snapshot;
} SK_LN_PPS_PROOF;
/* Fail closed unless the owning adapter supplies ALL proofs from hardware.
 * PROFILE_VERIFIED includes register readback of current, voltage, NTC and
 * fault protection, calibrated for this battery/board and this PD contract.
 * ADC_FRESH requires a real completed conversion, NOT just Snapshot.Complete
 * or its ReadAtMs. Serial is monotonic per attachment and must advance after
 * Begin. SampleAtMs dates that conversion, not the latest read. Reusing a
 * serial must retain its original completion time; a later conversion may
 * not move completion time backward. MAIN_QUIESCED must come from the actual
 * charger owner, not a guess.
 * Begin returns STATUS_PENDING after verified command writes. Only Poll with
 * later ADC evidence, physical switching, loaded Iin >400mA as in original
 * nabu RCP admission, acceptable Vin/Vbat/Iin/temperature
 * and verified reverse-current protection can return STATUS_SUCCESS.
 * Physical switching is SYS_STS 0x04; 0x08 is bypass and must fail.
 * Both APIs perform shutdown on revoked proof, faults, stale time or timeout.
 * Pending startup requires a conversion completed at least 10ms after Begin,
 * not an older conversion delivered later with an advancing serial.
 * Failure to confirm shutdown retains NeedsRecovery/FastObligation. Caller
 * must service that obligation before restoring the normal charging path.
 * Calls/timers are PASSIVE_LEVEL and serialized by the physical adapter.
 * These functions are NOT connected to an installed driver in research1869.
 */
NTSTATUS SkLn8000Begin2To1(SK_LN8000 *,ULONG Generation,ULONG NowMs,
                         const SK_LN_PPS_PROOF *);
NTSTATUS SkLn8000Poll2To1(SK_LN8000 *,ULONG Generation,ULONG NowMs,
                        const SK_LN_PPS_PROOF *);
/* The physical adapter must use these timed entries. Recheck the real
 * monotonic clock after bus reads, before effective converter writes and
 * after their readback. SafetyObservedAtMs dates the main-input/board grant;
 * neither a slow SPB transaction nor a fresh ADC date may renew that grant.
 * A failed/late write can still reach silicon: confirmed standby is required
 * before any success/fallback. Hardware protections remain indispensable.
 */
NTSTATUS SkLn8000Begin2To1Timed(SK_LN8000 *,ULONG Generation,ULONG NowMs,
    const SK_LN_PPS_PROOF *,SK_LN_CLOCK,PVOID,ULONG SafetyObservedAtMs);
NTSTATUS SkLn8000Poll2To1Timed(SK_LN8000 *,ULONG Generation,ULONG NowMs,
    const SK_LN_PPS_PROOF *,SK_LN_CLOCK,PVOID,ULONG SafetyObservedAtMs);
/* Physical PPS binding must additionally recheck its PD contract at every
 * command boundary. Any callback result other than STATUS_SUCCESS denies
 * the command. Failed/late writes keep the confirmed-shutdown obligation. */
NTSTATUS SkLn8000Begin2To1Gated(SK_LN8000 *,ULONG,ULONG,
    const SK_LN_PPS_PROOF *,const SK_LN_GATE *);
NTSTATUS SkLn8000Poll2To1Gated(SK_LN8000 *,ULONG,ULONG,
    const SK_LN_PPS_PROOF *,const SK_LN_GATE *);
/* Pure nabu-specific channel7 conversion, in tenths Celsius. Use the raw
 * battery NTC code and battery voltage from the SAME completed ADC bank.
 * This is a diagnostic conversion, NOT SafeInputs/permission to charge:
 * adapter must establish fresh ADC conversion, board/battery calibration,
 * independent battery temperature, protection state and thermal hysteresis.
 * Invalid circuit/table range returns failure with zeroed output; zero on
 * failure MUST NOT be interpreted as measured temperature. No bus IO.
 */
NTSTATUS SkLn8000BatteryTemperature(ULONG RawBatteryNtcCode,
    ULONG VbatMicrovolts,LONG *TemperatureDeciC);
#endif
