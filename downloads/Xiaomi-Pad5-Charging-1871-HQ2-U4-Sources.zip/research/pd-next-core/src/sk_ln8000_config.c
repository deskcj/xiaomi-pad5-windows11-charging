/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "sk_ln8000_config.h"

static void clear(void *p,ULONG n)
{ULONG i;for(i=0;i<n;++i)((volatile UCHAR *)p)[i]=0;}
static NTSTATUS valid(SK_LN_CONFIG *c,ULONG gen)
{
    if(!c || !c->Converter || !gen || !c->Converter->Ops.Read ||
       !c->Converter->Ops.Write)return STATUS_INVALID_PARAMETER;
    return gen==c->Generation && gen==c->Converter->Generation?
        STATUS_SUCCESS:STATUS_CANCELLED;
}
static NTSTATUS permit(SK_LN_CONFIG *c,ULONG gen,ULONG now,const SK_LN_CONFIG_PERMIT *p)
{
    if(now-c->LastNowMs>0x7fffffffu)return STATUS_INVALID_PARAMETER;
    c->LastNowMs=now;
    if(!p || p->Generation!=gen || p->Flags!=SK_LN_CONFIG_ALL_PROOFS ||
       now-p->ObservedAtMs>100u || p->ContractMaxMicrovolts<6500000u ||
       p->ContractMaxMicrovolts>9000000u || p->ContractMaxMicroamps<500000u ||
       p->ContractMaxMicroamps>3000000u ||
       p->MainInputBudgetMicroamps>p->ContractMaxMicroamps)return STATUS_DEVICE_NOT_READY;
    return STATUS_SUCCESS;
}
static NTSTATUS read_exact(SK_LN8000 *d,UCHAR r,PUCHAR b,ULONG n)
{
    ULONG done=0;NTSTATUS s=d->Ops.Read(d->Device,r,b,n,&done);
    if(s!=STATUS_SUCCESS)return NT_SUCCESS(s)?STATUS_IO_DEVICE_ERROR:s;
    return done==n?STATUS_SUCCESS:STATUS_DEVICE_DATA_ERROR;
}
static NTSTATUS update(SK_LN8000 *d,UCHAR r,UCHAR mask,UCHAR value)
{
    UCHAR b=0;ULONG done=0;NTSTATUS s=read_exact(d,r,&b,1);
    if(s!=STATUS_SUCCESS)return s;
    b=(UCHAR)((b&~mask)|(value&mask));
    s=d->Ops.Write(d->Device,r,&b,1,&done);
    if(s!=STATUS_SUCCESS)return NT_SUCCESS(s)?STATUS_IO_DEVICE_ERROR:s;
    if(done!=1)return STATUS_DEVICE_DATA_ERROR;
    s=read_exact(d,r,&b,1);
    return s==STATUS_SUCCESS && (b&mask)!=(value&mask)?STATUS_DEVICE_DATA_ERROR:s;
}
static NTSTATUS stop(SK_LN_CONFIG *c,ULONG gen,NTSTATUS reason)
{
    NTSTATUS s;c->Committed=0;c->ShutdownObligation=1;
    s=SkLn8000Standby(c->Converter,gen);
    if(s==STATUS_SUCCESS)c->ShutdownObligation=0;
    return s==STATUS_SUCCESS?reason:s;
}
static void field(SK_LN_CONFIG *c,UCHAR reg,UCHAR mask,UCHAR value)
{c->Masks[reg-0x1b]=mask;c->Values[reg-0x1b]=(UCHAR)(value&mask);}
ULONG SkLnConfigSize(VOID){return sizeof(SK_LN_CONFIG);}
NTSTATUS SkLnConfigInitialize(SK_LN_CONFIG *c,SK_LN8000 *d,ULONG gen,ULONG now)
{
    if(!c || !d || !gen || gen!=d->Generation || !d->Ops.Read || !d->Ops.Write)
        return STATUS_INVALID_PARAMETER;
    clear(c,sizeof(*c));c->Converter=d;c->Generation=gen;c->LastNowMs=now;
    return STATUS_SUCCESS;
}
NTSTATUS SkLnConfigStop(SK_LN_CONFIG *c,ULONG gen)
{
    NTSTATUS s=valid(c,gen);if(s!=STATUS_SUCCESS)return s;
    if(c->Converter->Busy)return STATUS_DEVICE_BUSY;
    return stop(c,gen,STATUS_SUCCESS);
}
NTSTATUS SkLnConfigApply(SK_LN_CONFIG *c,ULONG gen,ULONG now,
    const SK_LN_CONFIG_PERMIT *p,const SK_LN_CONFIG_REQUEST *q)
{
    SK_LN8000 *d;SK_LN_PROFILE_STATUS out;UCHAR hold=0,state=0;
    ULONG i,limit;NTSTATUS s=valid(c,gen);if(s!=STATUS_SUCCESS)return s;
    d=c->Converter;if(d->Busy)return STATUS_DEVICE_BUSY;
    /* Never let invalid/new input erase an existing hardware obligation. */
    s=permit(c,gen,now,p);
    if(s!=STATUS_SUCCESS)return c->ShutdownObligation || d->FastObligation?
        stop(c,gen,s):s;
    if(!q || q->FloatMicrovolts<3725000u || q->FloatMicrovolts>4450000u ||
       (q->FloatMicrovolts-3725000u)%5000u || q->InputLimitMicroamps<500000u ||
       q->InputLimitMicroamps>p->ContractMaxMicroamps-p->MainInputBudgetMicroamps ||
       q->NtcAlarmRaw>1023u)
        return c->ShutdownObligation || d->FastObligation?
            stop(c,gen,STATUS_INVALID_PARAMETER):STATUS_INVALID_PARAMETER;
    if(c->ShutdownObligation || d->NeedsRecovery || d->FastObligation)
        return stop(c,gen,STATUS_DEVICE_NOT_READY);
    /* Identity and foreign ADC pause checks are read-only before our writes. */
    s=SkLn8000Probe(d,gen);if(s!=STATUS_SUCCESS)return s;
    d->Busy=1;s=read_exact(d,0x26,&hold,1);d->Busy=0;
    if(s!=STATUS_SUCCESS)return s;
    if(hold&2)return STATUS_DEVICE_BUSY;
    c->Committed=0;c->ShutdownObligation=1;
    s=SkLn8000Standby(d,gen);if(s!=STATUS_SUCCESS)return s;
    clear(c->Masks,15);clear(c->Values,15);
    limit=q->InputLimitMicroamps/50000u;
    field(c,0x1b,0x7f,(UCHAR)limit);
    /* DIE_MAX enable is bit2, DIE_REG bit1. Do not treat the overlapping
     * 0x0c field as an independently proven NTC shutdown selector. */
    field(c,0x1c,0xf6,0xc6);
    field(c,0x1e,0x0d,0x08); /* standby, 2:1 selected, RCP off until loaded */
    field(c,0x20,0x0c,0x04); /* VAC OVP11V for accepted <=9V input */
    field(c,0x21,0x74,0); /* BAT/VAC/VIN OVP and IIN OCP enabled */
    field(c,0x22,0xff,(UCHAR)q->NtcAlarmRaw);
    /* NORMAL(6) keeps converters available for a witnessed DONE transition
     * even in standby. Auto-hibernate can leave an old bank indefinitely;
     * the ADC owner never equates a completed read with a new conversion. */
    field(c,0x23,0xe3,(UCHAR)(0xc0u|(q->NtcAlarmRaw>>8)));
    field(c,0x24,0xfe,0xfe); /* all used ADCs, including both thermistors */
    field(c,0x25,0xf3,3); /* monitors on, fault auto restart off */
    field(c,0x28,0xff,(UCHAR)((q->FloatMicrovolts-3725000u)/5000u));
    d->Busy=1;
    /* Original init shuts ADC down before channel/threshold changes. */
    s=update(d,0x23,0xe0,0x40);
    for(i=0;s==STATUS_SUCCESS && i<15;++i){
        if(!c->Masks[i] || i==8)continue;
        s=update(d,(UCHAR)(0x1b+i),c->Masks[i],c->Values[i]);
    }
    if(s==STATUS_SUCCESS)s=update(d,0x23,c->Masks[8],c->Values[8]);
    d->Busy=0;
    if(s!=STATUS_SUCCESS)return stop(c,gen,s);
    /* Read the entire configuration again, after all writes, rather than
     * trusting success from each individual transfer or a software flag. */
    s=SkLn8000ReadProfile(d,gen,now,&out);
    if(s==STATUS_SUCCESS)for(i=0;i<15;++i){
        if((out.Registers[i]&c->Masks[i])!=c->Values[i]){
            s=STATUS_DEVICE_DATA_ERROR;break;
        }
    }
    if(s!=STATUS_SUCCESS)return stop(c,gen,s);
    d->Busy=1;s=read_exact(d,3,&state,1);d->Busy=0;
    if(s!=STATUS_SUCCESS)return stop(c,gen,s);
    if((state&12) || !(state&3))return stop(c,gen,STATUS_DEVICE_NOT_READY);
    c->Committed=1;c->ShutdownObligation=0;return STATUS_SUCCESS;
}
NTSTATUS SkLnConfigCheck(SK_LN_CONFIG *c,ULONG gen,ULONG now,
    const SK_LN_CONFIG_PERMIT *p,SK_LN_PROFILE_STATUS *out)
{
    SK_LN_PROFILE_STATUS bank;ULONG i;NTSTATUS s;
    if(!out)return STATUS_INVALID_PARAMETER;
    clear(out,sizeof(*out));clear(&bank,sizeof(bank));
    s=valid(c,gen);if(s!=STATUS_SUCCESS)return s;
    if(c->Converter->Busy)return STATUS_DEVICE_BUSY;
    s=permit(c,gen,now,p);
    if(s==STATUS_SUCCESS && (!c->Committed || c->ShutdownObligation))
        s=STATUS_DEVICE_NOT_READY;
    if(s==STATUS_SUCCESS && (ULONG)(c->Values[0]&0x7f)*50000u>
        p->ContractMaxMicroamps-p->MainInputBudgetMicroamps)
        s=STATUS_DEVICE_NOT_READY;
    if(s==STATUS_SUCCESS)s=SkLn8000ReadProfile(c->Converter,gen,now,&bank);
    if(s==STATUS_SUCCESS)for(i=0;i<15;++i){
        /* During verified start/running, standby and RCP change legitimately
         * through Begin2To1/Poll2To1. Check 2:1 selection here; those routines
         * independently confirm the mode and loaded RCP state. */
        UCHAR mask=i==3?(UCHAR)1:c->Masks[i];
        if((bank.Registers[i]&mask)!=(c->Values[i]&mask)){
            s=STATUS_DEVICE_DATA_ERROR;break;
        }
    }
    if(s!=STATUS_SUCCESS){
        c->Committed=0;
        return c->ShutdownObligation || c->Converter->FastObligation?
            stop(c,gen,s):s;
    }
    *out=bank;return STATUS_SUCCESS;
}
static NTSTATUS charge(SK_LN_CONFIG *c,ULONG gen,ULONG now,
    const SK_LN_CONFIG_PERMIT *permit_data,const SK_LN_PPS_PROOF *p,ULONG poll,
    SK_LN_CLOCK clock,PVOID clock_context,const SK_LN_GATE *gate)
{
    SK_LN_PROFILE_STATUS profile;SK_LN_PPS_PROOF checked;
    NTSTATUS s=SkLnConfigCheck(c,gen,now,permit_data,&profile);
    if(s!=STATUS_SUCCESS)return s;
    if(clock){
        ULONG current=clock(clock_context);
        if(current-now>0x7fffffffu)s=STATUS_INVALID_PARAMETER;
        else {now=current;s=permit(c,gen,now,permit_data);}
        if(s!=STATUS_SUCCESS)return c->Converter->FastObligation?stop(c,gen,s):s;
    }
    if(!p || (p->Flags&~SK_LN_PPS_ALL_PROOFS) ||
       p->PdMicrovolts>permit_data->ContractMaxMicrovolts ||
       p->MaxInputMicroamps>permit_data->ContractMaxMicroamps-permit_data->MainInputBudgetMicroamps ||
       p->MaxInputMicroamps>profile.InputLimitMicroamps){
        s=STATUS_DEVICE_NOT_READY;
        return c->Converter->FastObligation?stop(c,gen,s):s;
    }
    checked=*p;checked.Flags|=SK_LN_PPS_PROFILE_VERIFIED;
    if(gate)return poll?SkLn8000Poll2To1Gated(c->Converter,gen,now,&checked,gate):
                          SkLn8000Begin2To1Gated(c->Converter,gen,now,&checked,gate);
    if(clock)return poll?SkLn8000Poll2To1Timed(c->Converter,gen,now,&checked,
        clock,clock_context,permit_data->ObservedAtMs):
        SkLn8000Begin2To1Timed(c->Converter,gen,now,&checked,
        clock,clock_context,permit_data->ObservedAtMs);
    return poll?SkLn8000Poll2To1(c->Converter,gen,now,&checked):
                SkLn8000Begin2To1(c->Converter,gen,now,&checked);
}
NTSTATUS SkLnConfigBegin2To1(SK_LN_CONFIG *c,ULONG gen,ULONG now,
    const SK_LN_CONFIG_PERMIT *permit_data,const SK_LN_PPS_PROOF *p)
{return charge(c,gen,now,permit_data,p,0,NULL,NULL,NULL);}
NTSTATUS SkLnConfigPoll2To1(SK_LN_CONFIG *c,ULONG gen,ULONG now,
    const SK_LN_CONFIG_PERMIT *permit_data,const SK_LN_PPS_PROOF *p)
{return charge(c,gen,now,permit_data,p,1,NULL,NULL,NULL);}
NTSTATUS SkLnConfigBegin2To1Timed(SK_LN_CONFIG *c,ULONG gen,ULONG now,
    const SK_LN_CONFIG_PERMIT *a,const SK_LN_PPS_PROOF *p,SK_LN_CLOCK clock,PVOID context)
{
    if(!clock)return STATUS_INVALID_PARAMETER;
    return charge(c,gen,now,a,p,0,clock,context,NULL);
}
NTSTATUS SkLnConfigPoll2To1Timed(SK_LN_CONFIG *c,ULONG gen,ULONG now,
    const SK_LN_CONFIG_PERMIT *a,const SK_LN_PPS_PROOF *p,SK_LN_CLOCK clock,PVOID context)
{
    if(!clock)return STATUS_INVALID_PARAMETER;
    return charge(c,gen,now,a,p,1,clock,context,NULL);
}

NTSTATUS SkLnConfigBegin2To1Gated(SK_LN_CONFIG *c,ULONG gen,ULONG now,
    const SK_LN_CONFIG_PERMIT *a,const SK_LN_PPS_PROOF *p,const SK_LN_GATE *gate)
{
    if(!gate || !gate->Clock || !gate->Validate || !a ||
       gate->SafetyObservedAtMs!=a->ObservedAtMs)return STATUS_INVALID_PARAMETER;
    return charge(c,gen,now,a,p,0,gate->Clock,gate->ClockContext,gate);
}
NTSTATUS SkLnConfigPoll2To1Gated(SK_LN_CONFIG *c,ULONG gen,ULONG now,
    const SK_LN_CONFIG_PERMIT *a,const SK_LN_PPS_PROOF *p,const SK_LN_GATE *gate)
{
    if(!gate || !gate->Clock || !gate->Validate || !a ||
       gate->SafetyObservedAtMs!=a->ObservedAtMs)return STATUS_INVALID_PARAMETER;
    return charge(c,gen,now,a,p,1,gate->Clock,gate->ClockContext,gate);
}
