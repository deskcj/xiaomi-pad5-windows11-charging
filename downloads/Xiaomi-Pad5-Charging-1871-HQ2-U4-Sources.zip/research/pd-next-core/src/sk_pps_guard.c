#include "sk_pps_guard.h"

static void ClearAction(SK_PPS_ACTION *Action)
{
    Action->Flags = Action->Generation = Action->RequestId = Action->Rdo = 0;
}

static void ActionFor(SK_PPS_GUARD *Guard, SK_PD_U32 Flags, SK_PPS_ACTION *Action)
{
    Action->Flags = Flags;
    Action->Generation = Guard->Generation;
    Action->RequestId = Guard->RequestId;
    Action->Rdo = Guard->Rdo;
}

static void Recover(SK_PPS_GUARD *Guard, SK_PPS_ACTION *Action)
{
    Guard->State = SK_PPS_RECOVERY_REQUIRED;
    Guard->FastPathPermitted = 0;
    ActionFor(Guard, SK_PPS_DISABLE_FAST_PATH | SK_PPS_OWNER_RECOVERY, Action);
    /* Owner chooses a protocol-correct reset/fixed fallback. The guard never
     * assumes a reset or a 5V contract has actually completed. */
}

static int CheckNow(SK_PPS_GUARD *Guard, SK_PD_U32 Now, SK_PPS_ACTION *Action)
{
    if (Now - Guard->LastNow > 0x7fffffffU) {
        Recover(Guard, Action);
        return SK_PPS_CLOCK_ERROR;
    }
    Guard->LastNow = Now;
    return SK_PD_OK;
}

/* Check before consuming an event too: a delayed timer callback must never
 * allow a late PS_RDY/ADC result to make an expired contract usable. */
static int Expired(SK_PPS_GUARD *Guard, SK_PD_U32 Now, SK_PPS_ACTION *Action)
{
    SK_PD_U32 timeout = 0;
    if (Guard->State == SK_PPS_IDLE || Guard->State == SK_PPS_RECOVERY_REQUIRED)
        return 0;
    if (Guard->FastPathPermitted &&
        (!Guard->HaveMeasurement || Now - Guard->LastMeasurement > SK_PPS_SENSOR_MAX_AGE_MS ||
         Now - Guard->LastAck >= SK_PPS_LIVENESS_LIMIT_MS)) {
        Recover(Guard, Action);
        return 1;
    }
    switch (Guard->State) {
    case SK_PPS_WAIT_TX: timeout = Guard->TxTimeoutMs; break;
    case SK_PPS_WAIT_ACCEPT: timeout = Guard->ResponseTimeoutMs; break;
    case SK_PPS_WAIT_PS_RDY:
    case SK_PPS_WAIT_MEASUREMENT: timeout = Guard->TransitionTimeoutMs; break;
    case SK_PPS_ACTIVE: break;
    default:
        Recover(Guard, Action);
        return 1;
    }
    if (timeout && Now - Guard->PhaseStart >= timeout) {
        Recover(Guard, Action);
        return 1;
    }
    return 0;
}

/* Revocation concerns the running contract independently of a replacement
 * request. Check it before parsing the new PDO/target, otherwise an invalid
 * replacement can preserve a now-unsafe ACTIVE path. The exchange also checks
 * its retained PDO's Power Limited flag and the attachment's prerequisites.
 */
static int CheckActiveLimits(SK_PPS_GUARD *Guard,
                             const SK_PPS_LIMITS *Limits,
                             SK_PPS_ACTION *Action)
{
    SK_PD_U32 power;
    if (Guard->State != SK_PPS_ACTIVE) return SK_PD_OK;
    power = Guard->Millivolts * Guard->Milliamps / 1000;
    if (!Limits || Limits->Prerequisites != SK_PPS_ALL_PREREQUISITES ||
        !Limits->MaxMillivolts || !Limits->MaxMilliamps ||
        !Limits->CableMilliamps || !Limits->MaxMilliwatts ||
        !Limits->VbusToleranceMillivolts || Limits->VbusToleranceMillivolts > 1000 ||
        Guard->Millivolts > Limits->MaxMillivolts ||
        Guard->Milliamps > Limits->MaxMilliamps ||
        Guard->Milliamps > Limits->CableMilliamps ||
        power > Limits->MaxMilliwatts ||
        (Limits->SourcePdpMilliwatts && power > Limits->SourcePdpMilliwatts)) {
        Recover(Guard, Action);
        return SK_PPS_NOT_READY;
    }
    if (Limits->MaxMillivolts < Guard->MaxObservedMillivolts)
        Guard->MaxObservedMillivolts = Limits->MaxMillivolts;
    if (Limits->VbusToleranceMillivolts < Guard->VbusTolerance)
        Guard->VbusTolerance = Limits->VbusToleranceMillivolts;
    return SK_PD_OK;
}

int SkPpsInitialize(SK_PPS_GUARD *Guard, SK_PD_U32 Generation,
                    SK_PD_U32 Now, SK_PD_U32 TxTimeoutMs,
                    SK_PD_U32 ResponseTimeoutMs, SK_PD_U32 TransitionTimeoutMs)
{
    if (!Guard || !Generation || !TxTimeoutMs || TxTimeoutMs > 1000 ||
        !ResponseTimeoutMs || ResponseTimeoutMs > 1000 ||
        !TransitionTimeoutMs || TransitionTimeoutMs > 1000)
        return SK_PD_INVALID_ARGUMENT;
    Guard->Generation = Generation;
    Guard->RequestId = 0;
    Guard->State = SK_PPS_IDLE;
    Guard->FastPathPermitted = 0;
    Guard->LastNow = Now;
    Guard->PhaseStart = Guard->LastAck = Guard->LastMeasurement = Now;
    Guard->Rdo = Guard->Millivolts = Guard->Milliamps = Guard->VbusTolerance = 0;
    Guard->TxTimeoutMs = TxTimeoutMs;
    Guard->ResponseTimeoutMs = ResponseTimeoutMs;
    Guard->TransitionTimeoutMs = TransitionTimeoutMs;
    Guard->HaveMeasurement = Guard->Refreshing = Guard->MaxObservedMillivolts = 0;
    return SK_PD_OK;
}

int SkPpsSubmit(SK_PPS_GUARD *Guard, SK_PD_U32 Now,
               SK_PD_U32 Pdo, SK_PD_U32 Position,
               SK_PD_U32 Millivolts, SK_PD_U32 Milliamps,
               const SK_PPS_LIMITS *Limits, SK_PPS_ACTION *Action)
{
    SK_PD_U32 rdo, power;
    int result;
    if (!Action) return SK_PD_INVALID_ARGUMENT;
    ClearAction(Action);
    if (!Guard || !Guard->Generation) return SK_PD_INVALID_ARGUMENT;
    /* The running path's watchdog applies even when the replacement PDO,
     * position, voltage or current is invalid. A caller can otherwise keep
     * returning an encoding error while stale sensors/liveness leave the
     * old path permitted. Validate time before any target-dependent exit. */
    result = CheckNow(Guard, Now, Action);
    if (result != SK_PD_OK) return result;
    if (Expired(Guard, Now, Action)) return SK_PPS_BAD_STATE;
    /* During a same-contract refresh the fast path can still be enabled.
     * Rejecting a busy Submit must not skip that path's timer/ADC deadlines. */
    if (Guard->State != SK_PPS_IDLE && Guard->State != SK_PPS_ACTIVE)
        return SK_PPS_BAD_STATE;
    result = CheckActiveLimits(Guard, Limits, Action);
    if (result != SK_PD_OK) return result;
    if (!Limits) return SK_PD_INVALID_ARGUMENT;
    if (Limits->Prerequisites != SK_PPS_ALL_PREREQUISITES) {
        /* A withdrawn prerequisite is a revocation of the running fast
         * path, not merely refusal of a new request. Integration must execute
         * the shutdown action even though Submit returns an error. */
        if (Guard->State == SK_PPS_ACTIVE) Recover(Guard, Action);
        return SK_PPS_NOT_READY;
    }
    result = SkPdBuildPpsRdo(Pdo, Position, 2, Millivolts, Milliamps, 0x03000000U, &rdo);
    if (result != SK_PD_OK) return result;
    if (!Limits->MaxMillivolts || !Limits->MaxMilliamps ||
        !Limits->CableMilliamps || !Limits->MaxMilliwatts ||
        Limits->VbusToleranceMillivolts == 0 || Limits->VbusToleranceMillivolts > 1000)
        return SK_PD_INVALID_ARGUMENT;
    power = Millivolts * Milliamps / 1000; /* Codec already bounded both inputs. */
    if (Millivolts > Limits->MaxMillivolts || Milliamps > Limits->MaxMilliamps ||
        Milliamps > Limits->CableMilliamps || power > Limits->MaxMilliwatts)
        return SK_PD_OUT_OF_RANGE;
    if ((Pdo & 0x08000000U) && !Limits->SourcePdpMilliwatts)
        return SK_PPS_NOT_READY;
    if (Limits->SourcePdpMilliwatts && power > Limits->SourcePdpMilliwatts)
        return SK_PD_OUT_OF_RANGE;
    if (Guard->RequestId == 0xffffffffU) {
        Recover(Guard, Action);
        return SK_PPS_BAD_STATE;
    }
    Guard->Refreshing = Guard->State == SK_PPS_ACTIVE && Guard->Rdo == rdo;
    Guard->State = SK_PPS_WAIT_TX;
    Guard->PhaseStart = Now;
    Guard->RequestId++;
    Guard->Rdo = rdo;
    Guard->Millivolts = Millivolts;
    Guard->Milliamps = Milliamps;
    Guard->VbusTolerance = Limits->VbusToleranceMillivolts;
    Guard->MaxObservedMillivolts = Limits->MaxMillivolts;
    if (!Guard->Refreshing) {
        Guard->FastPathPermitted = 0;
        Guard->HaveMeasurement = 0;
    }
    ActionFor(Guard, SK_PPS_SEND_REQUEST |
              (Guard->Refreshing ? 0U : SK_PPS_DISABLE_FAST_PATH), Action);
    return SK_PD_OK;
}

int SkPpsEvent(SK_PPS_GUARD *Guard, SK_PD_U32 Now,
              SK_PD_U32 Generation, SK_PD_U32 RequestId,
              SK_PD_U32 Event, SK_PPS_ACTION *Action)
{
    int result;
    if (!Action) return SK_PD_INVALID_ARGUMENT;
    ClearAction(Action);
    if (!Guard || !Guard->Generation) return SK_PD_INVALID_ARGUMENT;
    if (Generation != Guard->Generation) return SK_PPS_STALE;
    if (Event != SK_PPS_DETACH && Event != SK_PPS_FAULT && RequestId != Guard->RequestId)
        return SK_PPS_STALE;
    if (Event < SK_PPS_TX_ACK || Event > SK_PPS_FAULT) return SK_PD_INVALID_ARGUMENT;
    result = CheckNow(Guard, Now, Action);
    if (result != SK_PD_OK) return result;
    if (Expired(Guard, Now, Action)) return SK_PPS_BAD_STATE;
    if (Event == SK_PPS_DETACH || Event == SK_PPS_FAULT ||
        Event == SK_PPS_TRANSPORT_FAILED || Event == SK_PPS_REJECT || Event == SK_PPS_WAIT) {
        Recover(Guard, Action);
        return SK_PD_OK;
    }
    if (Guard->State == SK_PPS_WAIT_TX && Event == SK_PPS_TX_ACK) {
        Guard->LastAck = Guard->PhaseStart = Now;
        Guard->State = SK_PPS_WAIT_ACCEPT;
    } else if (Guard->State == SK_PPS_WAIT_ACCEPT && Event == SK_PPS_ACCEPT) {
        Guard->State = SK_PPS_WAIT_PS_RDY;
        Guard->PhaseStart = Now;
    } else if (Guard->State == SK_PPS_WAIT_PS_RDY && Event == SK_PPS_PS_RDY) {
        Guard->State = SK_PPS_WAIT_MEASUREMENT;
        Guard->PhaseStart = Now;
    } else {
        return SK_PPS_BAD_STATE;
    }
    return SK_PD_OK;
}

int SkPpsObserve(SK_PPS_GUARD *Guard, SK_PD_U32 Now,
                SK_PD_U32 Generation, SK_PD_U32 RequestId,
                SK_PD_U32 VbusMillivolts, SK_PD_U32 SafeInputs,
                SK_PPS_ACTION *Action)
{
    SK_PD_U32 difference;
    int result;
    if (!Action) return SK_PD_INVALID_ARGUMENT;
    ClearAction(Action);
    if (!Guard || !Guard->Generation) return SK_PD_INVALID_ARGUMENT;
    if (Generation != Guard->Generation || RequestId != Guard->RequestId)
        return SK_PPS_STALE;
    if (Guard->State == SK_PPS_IDLE || Guard->State == SK_PPS_RECOVERY_REQUIRED)
        return SK_PPS_BAD_STATE;
    result = CheckNow(Guard, Now, Action);
    if (result != SK_PD_OK) return result;
    if (Expired(Guard, Now, Action)) return SK_PPS_BAD_STATE;
    if (SafeInputs != 1) {
        Recover(Guard, Action);
        return SK_PD_OK;
    }
    if (Guard->State != SK_PPS_WAIT_MEASUREMENT && Guard->State != SK_PPS_ACTIVE &&
        !Guard->FastPathPermitted)
        return SK_PPS_BAD_STATE;
    difference = VbusMillivolts > Guard->Millivolts ?
                 VbusMillivolts - Guard->Millivolts : Guard->Millivolts - VbusMillivolts;
    if (difference > Guard->VbusTolerance || VbusMillivolts > Guard->MaxObservedMillivolts) {
        Recover(Guard, Action);
        return SK_PD_OK;
    }
    Guard->LastMeasurement = Now;
    Guard->HaveMeasurement = 1;
    if (Guard->State == SK_PPS_WAIT_MEASUREMENT) {
        Guard->State = SK_PPS_ACTIVE;
        Guard->FastPathPermitted = 1;
        ActionFor(Guard, SK_PPS_CONTRACT_CONFIRMED, Action);
    }
    return SK_PD_OK;
}

int SkPpsCheckTimers(SK_PPS_GUARD *Guard, SK_PD_U32 Now, SK_PPS_ACTION *Action)
{
    int result;
    if (!Action) return SK_PD_INVALID_ARGUMENT;
    ClearAction(Action);
    if (!Guard || !Guard->Generation) return SK_PD_INVALID_ARGUMENT;
    result = CheckNow(Guard, Now, Action);
    if (result != SK_PD_OK) return result;
    if (Expired(Guard, Now, Action)) return SK_PD_OK;
    return SK_PD_OK;
}

int SkPpsInitialRefused(SK_PPS_GUARD *Guard, SK_PD_U32 Now,
                      SK_PPS_ACTION *Action)
{
    int result;
    if (!Action) return SK_PD_INVALID_ARGUMENT;
    ClearAction(Action);
    if (!Guard || !Guard->Generation) return SK_PD_INVALID_ARGUMENT;
    result = CheckNow(Guard, Now, Action);
    if (result != SK_PD_OK) return result;
    if (Expired(Guard, Now, Action)) return SK_PPS_BAD_STATE;
    if (Guard->State != SK_PPS_WAIT_ACCEPT || Guard->Refreshing ||
        Guard->FastPathPermitted || Guard->HaveMeasurement)
        return SK_PPS_BAD_STATE;
    Guard->State = SK_PPS_IDLE;
    Guard->PhaseStart = Now;
    Guard->Rdo = Guard->Millivolts = Guard->Milliamps = 0;
    Guard->VbusTolerance = Guard->MaxObservedMillivolts = 0;
    ActionFor(Guard, SK_PPS_DISABLE_FAST_PATH, Action);
    return SK_PD_OK;
}

int SkPpsPoll(SK_PPS_GUARD *Guard, SK_PD_U32 Now, SK_PPS_ACTION *Action)
{
    int result = SkPpsCheckTimers(Guard, Now, Action);
    if (result != SK_PD_OK || Action->Flags) return result;
    if (Guard->State == SK_PPS_IDLE || Guard->State == SK_PPS_RECOVERY_REQUIRED)
        return SK_PD_OK;
    switch (Guard->State) {
    case SK_PPS_WAIT_TX:
    case SK_PPS_WAIT_ACCEPT:
    case SK_PPS_WAIT_PS_RDY:
    case SK_PPS_WAIT_MEASUREMENT: break;
    case SK_PPS_ACTIVE:
        if (Now - Guard->LastAck >= SK_PPS_REFRESH_MS) {
            if (Guard->RequestId == 0xffffffffU) {
                Recover(Guard, Action);
                return SK_PPS_BAD_STATE;
            }
            Guard->RequestId++;
            Guard->Refreshing = 1;
            Guard->State = SK_PPS_WAIT_TX;
            Guard->PhaseStart = Now;
            ActionFor(Guard, SK_PPS_SEND_REQUEST, Action);
        }
        break;
    default:
        Recover(Guard, Action);
        return SK_PPS_BAD_STATE;
    }
    return SK_PD_OK;
}
