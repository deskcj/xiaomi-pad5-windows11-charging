#include "sk_pd_pps_exchange.h"

static void zero(unsigned char *p, SK_PD_U32 n)
{SK_PD_U32 i;for(i=0;i<n;++i)((volatile unsigned char *)p)[i]=0;}
static int enter(SK_PD_PPS_EXCHANGE *e,SK_PD_U32 generation,SK_PD_PPS_OUTPUT *o)
{
    if(!o)return SK_PD_INVALID_ARGUMENT;
    zero((unsigned char *)o,sizeof(*o));
    if(!e || !generation)return SK_PD_INVALID_ARGUMENT;
    if(generation!=e->Session.Generation)return SK_PPS_STALE;
    if(!e->Session.NativeStopped)return SK_PPS_NOT_READY;
    return SK_PD_OK;
}
static void abandon(SK_PD_PPS_EXCHANGE *e)
{
    /* Clear outstanding wire tokens without reusing MessageIDs/tokens.
     * Only the complete owner may reset and begin another physical session. */
    e->Session.Faulted=1;e->Session.Lease=0;e->Session.PendingToken=0;
    e->Session.PendingBytes=0;e->WireToken=0;e->Lease=0;e->FixedReady=0;
    e->FixedRdo=0;e->AttemptFromFixed=0;e->InitialRefused=0;
    e->FixedEpoch=0;e->FixedSourceCount=0;
    zero((unsigned char *)e->FixedSourcePdos,sizeof(e->FixedSourcePdos));
    zero(e->Session.Pending,32);
}
static int recover(SK_PD_PPS_EXCHANGE *e,SK_PD_U32 now,SK_PD_PPS_OUTPUT *o)
{
    int r=SkPpsEvent(&e->Guard,now,e->Session.Generation,e->Guard.RequestId,
                     SK_PPS_FAULT,&o->Fast);
    /* Expired/clock paths can already have entered recovery. Never lose the
     * required physical disable just because Event rejects the new event. */
    o->Fast.Flags=SK_PPS_DISABLE_FAST_PATH|SK_PPS_OWNER_RECOVERY;
    o->Fast.Generation=e->Session.Generation;
    o->Fast.RequestId=e->Guard.RequestId;o->Fast.Rdo=e->Guard.Rdo;
    abandon(e);return r;
}
/* Apply revocation before AMS arbitration and during pending phases too.
 * SinkTxNG/another lease cannot postpone physical fast-path shutdown. The
 * caller must execute returned actions even when the API reports an error.
 * An invalid new target with safe existing limits remains an ordinary error.
 */
static int current_limits(SK_PD_PPS_EXCHANGE *e,SK_PD_U32 now,
    const SK_PPS_LIMITS *l,SK_PD_PPS_OUTPUT *o)
{
    SK_PD_U32 power;
    if(e->Guard.State==SK_PPS_IDLE)return l?SK_PD_OK:SK_PD_INVALID_ARGUMENT;
    if(!l){recover(e,now,o);return SK_PPS_NOT_READY;}
    power=e->Guard.Millivolts*e->Guard.Milliamps/1000;
    if(l->Prerequisites!=SK_PPS_ALL_PREREQUISITES ||
       !l->VbusToleranceMillivolts || l->VbusToleranceMillivolts>1000 ||
       e->Guard.Millivolts>l->MaxMillivolts ||
       e->Guard.Milliamps>l->MaxMilliamps ||
       e->Guard.Milliamps>l->CableMilliamps || power>l->MaxMilliwatts ||
       ((e->Pdo&0x08000000U) && !l->SourcePdpMilliwatts) ||
       (l->SourcePdpMilliwatts && power>l->SourcePdpMilliwatts)){
        recover(e,now,o);return SK_PPS_NOT_READY;
    }
    /* Tighten bounds immediately; a later request may explicitly renegotiate
     * wider ones. Do not accept an old ADC range after a stricter board limit. */
    if(l->MaxMillivolts<e->Guard.MaxObservedMillivolts)
        e->Guard.MaxObservedMillivolts=l->MaxMillivolts;
    if(l->VbusToleranceMillivolts<e->Guard.VbusTolerance)
        e->Guard.VbusTolerance=l->VbusToleranceMillivolts;
    return SK_PD_OK;
}
static int check(SK_PD_PPS_EXCHANGE *e,SK_PD_U32 now,SK_PD_PPS_OUTPUT *o)
{
    int r=SkPpsCheckTimers(&e->Guard,now,&o->Fast);
    if(o->Fast.Flags&SK_PPS_OWNER_RECOVERY)abandon(e);
    if(r || e->Guard.State==SK_PPS_RECOVERY_REQUIRED)return r?r:SK_PPS_BAD_STATE;
    if(e->Session.Faulted)return SK_PD_SESSION_RECOVERY;
    return SK_PD_OK;
}
static int emit(SK_PD_PPS_EXCHANGE *e,SK_PD_PPS_OUTPUT *o)
{
    unsigned char payload[4];SK_PD_U32 i;
    int r=SkPdSessionAcquire(&e->Session,e->Session.Generation,1);
    if(r)goto fail;
    e->Lease=1;
    for(i=0;i<4;++i)payload[i]=(unsigned char)(e->Guard.Rdo>>(8*i));
    r=SkPdSessionTransmit(&e->Session,e->Session.Generation,1,2,payload,4,&o->Tx);
    if(r)goto fail;
    e->WireToken=o->Tx.Token;return SK_PD_OK;
fail:
    recover(e,e->Guard.LastNow,o);zero((unsigned char *)&o->Tx,sizeof(o->Tx));return r;
}
SK_PD_U32 SkPdPpsExchangeSize(void){return sizeof(SK_PD_PPS_EXCHANGE);}
int SkPdPpsExchangeInitialize(SK_PD_PPS_EXCHANGE *e,SK_PD_U32 generation,
                             SK_PD_U32 now,SK_PD_U32 data,SK_PD_U32 native)
{
    int r;
    if(!e || !generation || data>1 || native!=1)return SK_PPS_NOT_READY;
    zero((unsigned char *)e,sizeof(*e));
    r=SkPdSessionInitialize(&e->Session,generation,0,data,native);if(r)return r;
    /* Conservative limits for offline coordination; complete PD owner must
     * supply normative timers and PHY completion/scheduling on integration. */
    return SkPpsInitialize(&e->Guard,generation,now,100,30,500);
}
int SkPdPpsExchangeConfirmFixed(SK_PD_PPS_EXCHANGE *e,SK_PD_U32 generation,SK_PD_U32 rdo)
{
    SK_PD_CONTRACT c;SK_PD_U32 i;int r;
    if(!e || !generation)return SK_PD_INVALID_ARGUMENT;
    if(generation!=e->Session.Generation)return SK_PPS_STALE;
    if(!e->Session.NativeStopped || !e->SourceCount)return SK_PPS_NOT_READY;
    if(e->Guard.State!=SK_PPS_IDLE || e->Session.Lease || e->Session.PendingToken || e->Session.Faulted)
        return SK_PPS_BAD_STATE;
    r=SkPdDecodeContract(e->SourcePdos,e->SourceCount,rdo,e->Session.Revision,&c);
    if(r)return r;
    if(c.IsPps || !c.Milliamps)return SK_PD_UNSUPPORTED;
    e->FixedRdo=rdo;e->FixedEpoch=e->SourceEpoch;
    e->FixedSourceCount=e->SourceCount;
    for(i=0;i<7;++i)e->FixedSourcePdos[i]=e->SourcePdos[i];
    e->FixedReady=1;return SK_PD_OK;
}
int SkPdPpsExchangeBegin(SK_PD_PPS_EXCHANGE *e,SK_PD_U32 generation,SK_PD_U32 now,
    SK_PD_U32 position,SK_PD_U32 mv,SK_PD_U32 ma,SK_PD_U32 grant,
    const SK_PPS_LIMITS *limits,SK_PD_PPS_OUTPUT *o)
{
    SK_PD_U32 from_fixed;
    int r=enter(e,generation,o);if(r)return r;
    r=check(e,now,o);if(r)return r;
    r=current_limits(e,now,limits,o);if(r)return r;
    if(grant>1 || !limits)return SK_PD_INVALID_ARGUMENT;
    if(!e->FixedReady || e->Session.Revision!=2 || e->Session.PowerRole!=0)
        return SK_PPS_NOT_READY;
    /* A refused initial attempt leaves ordinary charging available. Avoid
     * repeated requests until new Source_Capabilities permit reconsideration. */
    if(e->Guard.State==SK_PPS_IDLE && e->InitialRefused)return SK_PPS_NOT_READY;
    if(!position || position>e->SourceCount)return SK_PD_INVALID_ARGUMENT;
    if(e->Session.Lease || e->Session.PendingToken)return SK_PD_SESSION_BUSY;
    if(!grant)return SK_PPS_EXCHANGE_DEFERRED;
    from_fixed=e->Guard.State==SK_PPS_IDLE;
    r=SkPpsSubmit(&e->Guard,now,e->SourcePdos[position-1],position,mv,ma,limits,&o->Fast);
    if(o->Fast.Flags&SK_PPS_OWNER_RECOVERY)abandon(e);
    if(r)return r;
    e->Pdo=e->SourcePdos[position-1];e->Position=position;
    e->AttemptFromFixed=from_fixed;
    return emit(e,o);
}
int SkPdPpsExchangeReceive(SK_PD_PPS_EXCHANGE *e,SK_PD_U32 generation,SK_PD_U32 now,
    const unsigned char *frame,SK_PD_U32 bytes,SK_PD_PPS_OUTPUT *o)
{
    SK_PD_HEADER h;SK_PD_CONTRACT fixed;SK_PD_U32 i,value;int r,event=0;
    r=enter(e,generation,o);if(r)return r;
    r=check(e,now,o);if(r)return r;
    r=SkPdSessionReceive(&e->Session,generation,frame,bytes,&h);
    if(r==SK_PD_SESSION_DUPLICATE)return r;
    if(r!=SK_PD_OK){recover(e,now,o);return r;}
    if(e->Guard.State!=SK_PPS_IDLE && e->Session.Revision!=2){
        recover(e,now,o);return SK_PD_UNSUPPORTED;
    }
    if(h.DataObjects && h.MessageType==1){
        value=(SK_PD_U32)frame[4]|((SK_PD_U32)frame[5]<<8)|
              ((SK_PD_U32)frame[6]<<16)|((SK_PD_U32)frame[7]<<24);
        /* First Source PDO must be fixed 5V with nonzero current. */
        if((value>>30)!=0 || ((value>>10)&1023)!=100 || !(value&1023)){
            recover(e,now,o);return SK_PD_INVALID_ENCODING;
        }
        if(e->Guard.State!=SK_PPS_IDLE || e->Session.Lease || e->Session.PendingToken){
            recover(e,now,o);return SK_PPS_BAD_STATE;
        }
        if(e->SourceEpoch==0xffffffffU){recover(e,now,o);return SK_PPS_BAD_STATE;}
        for(i=0;i<h.DataObjects;++i)e->SourcePdos[i]=
            (SK_PD_U32)frame[4+4*i]|((SK_PD_U32)frame[5+4*i]<<8)|
            ((SK_PD_U32)frame[6+4*i]<<16)|((SK_PD_U32)frame[7+4*i]<<24);
        for(;i<7;++i)((volatile SK_PD_U32 *)e->SourcePdos)[i]=0;
        e->SourceCount=h.DataObjects;e->FixedReady=0;
        ++e->SourceEpoch;e->AttemptFromFixed=0;e->InitialRefused=0;
        return SK_PPS_EXCHANGE_CAPABILITIES;
    }
    if(h.DataObjects)return SK_PD_UNSUPPORTED;
    switch(h.MessageType){
    case 3:event=SK_PPS_ACCEPT;break;
    case 6:event=SK_PPS_PS_RDY;break;
    case 4:event=SK_PPS_REJECT;break;
    case 12:event=SK_PPS_WAIT;break;
    default:return SK_PD_UNSUPPORTED;
    }
    /* These responses have no RequestID on the wire. Route ONLY within the
     * outstanding local AMS, never by matching the peer's MessageID to ours. */
    if(!e->Lease || e->WireToken){recover(e,now,o);return SK_PPS_BAD_STATE;}
    /* Linux TCPM returns to SNK_READY on a refused PPS Request. Here only
     * the initial transition has a proven fixed fallback: no Accept/PS_RDY,
     * no prior active PPS voltage and no ambiguous transport completion.
     * A refused refresh still goes to owner recovery until that policy and
     * its sensor/keepalive handling are implemented. */
    if((event==SK_PPS_REJECT || event==SK_PPS_WAIT) && e->AttemptFromFixed &&
       e->FixedReady && e->FixedRdo && e->FixedEpoch==e->SourceEpoch &&
       e->Guard.State==SK_PPS_WAIT_ACCEPT){
        r=SkPdDecodeContract(e->FixedSourcePdos,e->FixedSourceCount,e->FixedRdo,
            e->Session.Revision,&fixed);
        if(r || fixed.IsPps || !fixed.Milliamps){recover(e,now,o);return SK_PPS_BAD_STATE;}
        r=SkPpsInitialRefused(&e->Guard,now,&o->Fast);
        if(r){recover(e,now,o);return r;}
        r=SkPdSessionRelease(&e->Session,generation,e->Lease);
        if(r){recover(e,now,o);return r;}
        e->Lease=0;e->AttemptFromFixed=0;e->InitialRefused=1;
        o->Fast.Flags=(SK_PD_U32)SK_PPS_DISABLE_FAST_PATH|
                      (SK_PD_U32)SK_PPS_FIXED_CONTRACT_RESTORED;
        o->Fast.Rdo=e->FixedRdo;
        return SK_PD_OK;
    }
    r=SkPpsEvent(&e->Guard,now,generation,e->Guard.RequestId,(SK_PD_U32)event,&o->Fast);
    if(r || (o->Fast.Flags&SK_PPS_OWNER_RECOVERY)){
        recover(e,now,o);return r;
    }
    if(event==SK_PPS_ACCEPT)e->AttemptFromFixed=0;
    if(event==SK_PPS_PS_RDY){
        r=SkPdSessionRelease(&e->Session,generation,e->Lease);
        if(r){recover(e,now,o);return r;}
        e->Lease=0;
    }
    return SK_PD_OK;
}
int SkPdPpsExchangeTxComplete(SK_PD_PPS_EXCHANGE *e,SK_PD_U32 generation,SK_PD_U32 now,
    SK_PD_U32 token,SK_PD_U32 result,SK_PD_PPS_OUTPUT *o)
{
    int r=enter(e,generation,o);if(r)return r;
    if(!token || token!=e->WireToken)return SK_PPS_STALE;
    r=check(e,now,o);if(r)return r;
    if(result<1 || result>3)return SK_PD_INVALID_ARGUMENT;
    r=SkPdSessionTxComplete(&e->Session,generation,token,result);
    e->WireToken=0;
    if(r){recover(e,now,o);return r;}
    r=SkPpsEvent(&e->Guard,now,generation,e->Guard.RequestId,SK_PPS_TX_ACK,&o->Fast);
    if(r || (o->Fast.Flags&SK_PPS_OWNER_RECOVERY))recover(e,now,o);
    return r;
}
int SkPdPpsExchangeObserve(SK_PD_PPS_EXCHANGE *e,SK_PD_U32 generation,SK_PD_U32 now,
    SK_PD_U32 request,SK_PD_U32 vbus,SK_PD_U32 safe,SK_PD_PPS_OUTPUT *o)
{
    int r=enter(e,generation,o);if(r)return r;
    r=SkPpsObserve(&e->Guard,now,generation,request,vbus,safe,&o->Fast);
    if(o->Fast.Flags&SK_PPS_OWNER_RECOVERY)abandon(e);
    return r;
}
int SkPdPpsExchangePoll(SK_PD_PPS_EXCHANGE *e,SK_PD_U32 generation,SK_PD_U32 now,
    SK_PD_U32 grant,const SK_PPS_LIMITS *limits,SK_PD_PPS_OUTPUT *o)
{
    int r=enter(e,generation,o);if(r)return r;
    r=check(e,now,o);if(r)return r;
    r=current_limits(e,now,limits,o);if(r)return r;
    if(grant>1 || !limits)return SK_PD_INVALID_ARGUMENT;
    if(e->Guard.State!=SK_PPS_ACTIVE)return SK_PD_OK;
    if(now-e->Guard.LastAck<SK_PPS_REFRESH_MS)return SK_PD_OK;
    if(!grant)return SK_PPS_EXCHANGE_DEFERRED;
    return SkPdPpsExchangeBegin(e,generation,now,e->Position,
        e->Guard.Millivolts,e->Guard.Milliamps,grant,limits,o);
}
int SkPdPpsExchangeFault(SK_PD_PPS_EXCHANGE *e,SK_PD_U32 generation,SK_PD_U32 now,SK_PD_PPS_OUTPUT *o)
{
    int r=enter(e,generation,o);if(r)return r;
    return recover(e,now,o);
}
