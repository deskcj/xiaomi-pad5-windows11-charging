#ifndef SK_PPS_GUARD_H
#define SK_PPS_GUARD_H
#include "sk_pd_protocol.h"

/* A serialized lifecycle guard for a future single PD owner. No transport,
 * register access, actual timer, charger control or Windows reporting.
 * Callers must disable the physical fast path before initialize/reinitialize,
 * implement every returned action and never reuse a generation for a new
 * attachment. Millisecond time is monotonic modulo 2^32, polled frequently.
 * RequestId tags transport completion/response events; it is NOT PD MessageID.
 */
enum {
    SK_PPS_STALE = -5, SK_PPS_BAD_STATE = -6,
    SK_PPS_CLOCK_ERROR = -7, SK_PPS_NOT_READY = -8,
    SK_PPS_IDLE = 0, SK_PPS_WAIT_TX, SK_PPS_WAIT_ACCEPT,
    SK_PPS_WAIT_PS_RDY, SK_PPS_WAIT_MEASUREMENT, SK_PPS_ACTIVE,
    SK_PPS_RECOVERY_REQUIRED,
    SK_PPS_TX_ACK = 1, SK_PPS_ACCEPT, SK_PPS_PS_RDY,
    SK_PPS_REJECT, SK_PPS_WAIT, SK_PPS_TRANSPORT_FAILED,
    SK_PPS_DETACH, SK_PPS_FAULT,
    SK_PPS_SEND_REQUEST = 1, SK_PPS_DISABLE_FAST_PATH = 2,
    SK_PPS_CONTRACT_CONFIRMED = 4, SK_PPS_OWNER_RECOVERY = 8,
    SK_PPS_SINGLE_OWNER = 1, SK_PPS_REPORTING_READY = 2,
    SK_PPS_CHARGE_PATH_READY = 4, SK_PPS_SAFE_INPUTS = 8,
    SK_PPS_ALL_PREREQUISITES = 15,
    SK_PPS_REFRESH_MS = 7000, SK_PPS_LIVENESS_LIMIT_MS = 9000,
    SK_PPS_SENSOR_MAX_AGE_MS = 1000
};

typedef struct SK_PPS_ACTION {
    SK_PD_U32 Flags, Generation, RequestId, Rdo;
} SK_PPS_ACTION;

typedef struct SK_PPS_LIMITS {
    SK_PD_U32 Prerequisites; /* All four are required, supplied by integration. */
    SK_PD_U32 MaxMillivolts, MaxMilliamps, CableMilliamps;
    SK_PD_U32 MaxMilliwatts, SourcePdpMilliwatts;
    SK_PD_U32 VbusToleranceMillivolts;
} SK_PPS_LIMITS;

typedef struct SK_PPS_GUARD {
    SK_PD_U32 Generation, RequestId, State, FastPathPermitted;
    SK_PD_U32 LastNow, PhaseStart, LastAck, LastMeasurement;
    SK_PD_U32 Rdo, Millivolts, Milliamps, VbusTolerance;
    SK_PD_U32 TxTimeoutMs, ResponseTimeoutMs, TransitionTimeoutMs;
    SK_PD_U32 HaveMeasurement, Refreshing, MaxObservedMillivolts;
} SK_PPS_GUARD;

/* These deadlines are supplied by the PD owner for its protocol/transport.
 * The guard's 7s refresh and 9s liveness cutoff are conservative policy choices,
 * not replacements for the PD protocol's normative timers. */
int SkPpsInitialize(SK_PPS_GUARD *Guard, SK_PD_U32 Generation,
                    SK_PD_U32 Now, SK_PD_U32 TxTimeoutMs,
                    SK_PD_U32 ResponseTimeoutMs, SK_PD_U32 TransitionTimeoutMs);
int SkPpsSubmit(SK_PPS_GUARD *Guard, SK_PD_U32 Now,
               SK_PD_U32 Pdo, SK_PD_U32 Position,
               SK_PD_U32 Millivolts, SK_PD_U32 Milliamps,
               const SK_PPS_LIMITS *Limits, SK_PPS_ACTION *Action);
/* Submit validates time, sensor/liveness deadlines and the existing ACTIVE
 * contract's limits before a new target, including invalid new targets.
 * Error returns may contain DISABLE_FAST_PATH/OWNER_RECOVERY and MUST be acted
 * on. For waiting phases, use the exchange's current-limit Begin/Poll checks
 * or explicitly fault the guard on prerequisite/limit withdrawal.
 */
int SkPpsEvent(SK_PPS_GUARD *Guard, SK_PD_U32 Now,
              SK_PD_U32 Generation, SK_PD_U32 RequestId,
              SK_PD_U32 Event, SK_PPS_ACTION *Action);
/* Supply a fresh ADC measurement and validated battery/thermal/fault status.
 * Repeated calls while active maintain the sensor freshness watchdog.
 * True confirmation follows matching TX ACK, Accept, PS_RDY AND this sample. */
int SkPpsObserve(SK_PPS_GUARD *Guard, SK_PD_U32 Now,
                SK_PD_U32 Generation, SK_PD_U32 RequestId,
                SK_PD_U32 VbusMillivolts, SK_PD_U32 SafeInputs,
                SK_PPS_ACTION *Action);
int SkPpsPoll(SK_PPS_GUARD *Guard, SK_PD_U32 Now, SK_PPS_ACTION *Action);
/* Check deadlines/sensor liveness without starting a new AMS. The exchange
 * coordinator uses this while Source advertises SinkTxNG. */
int SkPpsCheckTimers(SK_PPS_GUARD *Guard, SK_PD_U32 Now, SK_PPS_ACTION *Action);
/* Only an initial, explicitly refused Request may return to a still-valid
 * fixed contract. The coordinator verifies that contract and the response.
 * Preserve RequestId and the monotonic clock so late ADC/completions cannot
 * become observations of a new attempt. No hardware/report action is hidden. */
int SkPpsInitialRefused(SK_PPS_GUARD *Guard, SK_PD_U32 Now,
                      SK_PPS_ACTION *Action);
#endif
