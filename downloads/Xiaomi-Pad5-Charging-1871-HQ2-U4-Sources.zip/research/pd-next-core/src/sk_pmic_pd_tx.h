#ifndef SK_PMIC_PD_TX_H
#define SK_PMIC_PD_TX_H
#include <ntddk.h>
#include "sk_pd_session.h"

/* PM8150B SOP TX adapter. Every call belongs to the single PASSIVE_LEVEL
 * port consumer and its lifetime/rundown; this object is NOT independently
 * thread safe. Stop native TX/reset/header writers and drain their IRQs first.
 * These bus operations must bind to the byte-pinned provider's synchronous
 * SPMI operations, never a second side-channel transmitter.
 */
typedef NTSTATUS (*SK_PMIC_TX_READ)(PVOID,UCHAR,USHORT,PUCHAR,ULONG);
typedef NTSTATUS (*SK_PMIC_TX_WRITE)(PVOID,UCHAR,USHORT,const UCHAR *,ULONG);
typedef NTSTATUS (*SK_PMIC_TX_UPDATE)(PVOID,UCHAR,USHORT,UCHAR,UCHAR);
typedef NTSTATUS (*SK_PMIC_TX_DELAY)(PVOID,ULONG Microseconds);
typedef struct SK_PMIC_TX_OPS {
    SK_PMIC_TX_READ Read;
    SK_PMIC_TX_WRITE Write;
    SK_PMIC_TX_UPDATE Update;
    SK_PMIC_TX_DELAY Delay; /* Owning adapter stalls >= requested interval. */
} SK_PMIC_TX_OPS;
typedef struct SK_PMIC_PD_TX {
    SK_PMIC_TX_OPS Ops;
    PVOID BusContext;
    ULONG Generation, LastToken, PendingToken, Faulted, Initialized, Busy;
    USHORT Base;
    UCHAR SID, Reserved;
} SK_PMIC_PD_TX;

NTSTATUS SkPmicTxInitialize(SK_PMIC_PD_TX *,const SK_PMIC_TX_OPS *,PVOID,
    UCHAR SID,USHORT Base,ULONG Generation,ULONG NativeQuiesced);
/* Success confirms register submission only, NEVER peer GoodCRC. Busy before
 * Send leaves the token reusable; all ambiguous I/O errors fault the adapter
 * and require physical shutdown/reset by the complete port owner.
 * Caller acts on session/PPS deadlines, CC arbitration and board limits before
 * requesting TX; this adapter cannot prove them from a header or NativeQuiesced.
 */
NTSTATUS SkPmicTxSubmit(SK_PMIC_PD_TX *,const SK_PD_SESSION_TX *);
/* The pinned IRQ adapter supplies a completion only for the currently armed
 * send after clearing/draining earlier latches. Hardware IRQ has no session
 * token: THIS MODULE DOES NOT PROVE that mapping or physical GoodCRC.
 */
NTSTATUS SkPmicTxComplete(SK_PMIC_PD_TX *,ULONG Generation,ULONG Token,ULONG Result);
ULONG SkPmicTxSize(VOID);
#endif
