#ifndef SK_PMIC_PD_RX_H
#define SK_PMIC_PD_RX_H
#include <ntddk.h>

/* Replacement capture/ACK split for the PM8150B provider, not a wrapper of
 * native 6ea0 (which already ACKs success). Bind these operations to the
 * verified synchronous SPMI helpers in the provider. No live IOCTL is issued
 * by this component until the owning device adapter calls it.
 *
 * All access runs at PASSIVE_LEVEL under the runtime's exclusive RX lease.
 * Native RX readers, RX reset and RX-enable writes must be quiesced or routed
 * through that same owner. Zero storage and initialize once before exposure; retain this
 * storage until producers, worker and physical RX are fully stopped.
 */
typedef NTSTATUS (*SK_PMIC_RX_READ)(PVOID, UCHAR, USHORT, PUCHAR, ULONG);
typedef NTSTATUS (*SK_PMIC_RX_UPDATE)(PVOID, UCHAR, USHORT, UCHAR, UCHAR);
typedef struct SK_PMIC_RX_OPS {
    SK_PMIC_RX_READ Read; /* Synchronous, fills all Length bytes on success. */
    SK_PMIC_RX_UPDATE Update; /* Atomic masked update, confirmed success. */
} SK_PMIC_RX_OPS;
typedef struct SK_PMIC_PD_RX {
    SK_PMIC_RX_OPS Ops;
    PVOID BusContext;
    ULONG NextToken, ActiveToken, Faulted, Initialized;
    USHORT Base;
    UCHAR SID, Reserved;
} SK_PMIC_PD_RX;

NTSTATUS SkPmicRxInitialize(SK_PMIC_PD_RX *, const SK_PMIC_RX_OPS *, PVOID,
                          UCHAR SID, USHORT Base);
/* Runtime Read callback: canonical TCPCI count/SOP/header/payload. On every
 * post-claim failure Length=0 and Token still owns the physical buffer.
 * Only Release clears RX_ACK. NO_MORE_ENTRIES with Token=Length=0 is a normal
 * coalesced/stale IRQ, not a malformed packet.
 */
NTSTATUS SkPmicRxRead(PVOID, PUCHAR Frame, PULONG Length, PULONG Token);
NTSTATUS SkPmicRxRelease(PVOID, ULONG Token);
ULONG SkPmicRxSize(VOID);
#endif
