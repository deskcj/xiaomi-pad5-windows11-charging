/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "sk_pps_charge_path.h"

static NTSTATUS valid(SK_PPS_CHARGE_PATH *p,ULONG gen)
{
    if(!p || !p->Pps || !p->Config || !p->Config->Converter || !gen)
        return STATUS_INVALID_PARAMETER;
    return gen==p->Generation && gen==p->Pps->Session.Generation &&
        gen==p->Pps->Guard.Generation && gen==p->Config->Generation &&
        gen==p->Config->Converter->Generation?STATUS_SUCCESS:STATUS_CANCELLED;
}
static NTSTATUS off(SK_PPS_CHARGE_PATH *p,ULONG gen,NTSTATUS why,ULONG force)
{
    NTSTATUS s;
    p->BoundRdo=0;p->BoundRequestId=0;
    if(!force && !p->Config->ShutdownObligation &&
       !p->Config->Converter->FastObligation &&
       !p->Config->Converter->NeedsRecovery)return why;
    s=SkLnConfigStop(p->Config,gen);
    return s==STATUS_SUCCESS?why:s;
}
static NTSTATUS clock_check(SK_PPS_CHARGE_PATH *p,ULONG gen,ULONG now)
{
    if(now-p->LastNowMs>0x7fffffffu)
        return off(p,gen,STATUS_INVALID_PARAMETER,0);
    p->LastNowMs=now;return STATUS_SUCCESS;
}
static NTSTATUS contract_state(SK_PPS_CHARGE_PATH *p,ULONG now,SK_PD_CONTRACT *c)
{
    SK_PD_PPS_EXCHANGE *e=p->Pps;
    SK_PPS_ACTION action;int r;
    r=SkPpsCheckTimers(&e->Guard,now,&action);
    if(action.Flags){
        /* Never lose the protocol-recovery action produced by a timer check
         * inside I2C work. The complete PD owner drains this after return. */
        p->PendingAction.Flags|=action.Flags;
        p->PendingAction.Generation=action.Generation;
        p->PendingAction.RequestId=action.RequestId;
        p->PendingAction.Rdo=action.Rdo;
    }
    if(r || action.Flags || !e->Session.NativeStopped || e->Session.Faulted ||
       e->Session.Revision!=2 || e->Session.PowerRole!=0 ||
       !e->Guard.FastPathPermitted || !e->Guard.HaveMeasurement ||
       !e->Guard.RequestId || e->Guard.State==SK_PPS_RECOVERY_REQUIRED ||
       (e->Guard.State!=SK_PPS_ACTIVE && !e->Guard.Refreshing))
        return STATUS_DEVICE_NOT_READY;
    r=SkPdDecodeContract(e->SourcePdos,e->SourceCount,e->Guard.Rdo,2,c);
    if(r || !c->IsPps || c->ObjectPosition!=e->Position ||
       e->Position<1 || e->Position>e->SourceCount ||
       e->SourcePdos[e->Position-1]!=e->Pdo ||
       c->Millivolts!=e->Guard.Millivolts || c->Milliamps!=e->Guard.Milliamps ||
       c->Millivolts<6500 || c->Millivolts>9000 ||
       c->Milliamps<500 || c->Milliamps>3000)
        return STATUS_DEVICE_NOT_READY;
    return STATUS_SUCCESS;
}
static NTSTATUS contract(SK_PPS_CHARGE_PATH *p,ULONG gen,ULONG now,
                         SK_PD_CONTRACT *c)
{
    NTSTATUS s=contract_state(p,now,c);
    return s==STATUS_SUCCESS?s:off(p,gen,s,0);
}
static NTSTATUS exact_permit(SK_PPS_CHARGE_PATH *p,ULONG gen,
                             const SK_PD_CONTRACT *c,const SK_LN_CONFIG_PERMIT *a)
{
    if(!a || a->ContractMaxMicrovolts!=c->Millivolts*1000u ||
       a->ContractMaxMicroamps!=c->Milliamps*1000u)
        return off(p,gen,STATUS_DEVICE_NOT_READY,0);
    return STATUS_SUCCESS;
}
ULONG SkPpsPathSize(VOID){return sizeof(SK_PPS_CHARGE_PATH);}
NTSTATUS SkPpsPathInitialize(SK_PPS_CHARGE_PATH *p,SK_PD_PPS_EXCHANGE *e,
    SK_LN_CONFIG *c,ULONG gen,ULONG now)
{
    if(!p || !e || !c || !c->Converter || !gen || gen!=e->Session.Generation ||
       gen!=e->Guard.Generation || gen!=c->Generation ||
       gen!=c->Converter->Generation || !e->Session.NativeStopped ||
       c->ShutdownObligation || c->Converter->FastObligation ||
       c->Converter->OwnAdcPause || c->Converter->NeedsRecovery ||
       c->Converter->Busy)return STATUS_DEVICE_NOT_READY;
    p->Pps=e;p->Config=c;p->Generation=gen;p->BoundRdo=0;
    p->BoundRequestId=0;p->LastNowMs=now;
    p->PendingAction.Flags=0;p->PendingAction.Generation=0;
    p->PendingAction.RequestId=0;p->PendingAction.Rdo=0;
    return STATUS_SUCCESS;
}
NTSTATUS SkPpsPathTakeAction(SK_PPS_CHARGE_PATH *p,ULONG gen,SK_PPS_ACTION *out)
{
    NTSTATUS s;
    if(!out)return STATUS_INVALID_PARAMETER;
    out->Flags=0;out->Generation=0;out->RequestId=0;out->Rdo=0;
    s=valid(p,gen);if(s!=STATUS_SUCCESS)return s;
    *out=p->PendingAction;
    p->PendingAction.Flags=0;p->PendingAction.Generation=0;
    p->PendingAction.RequestId=0;p->PendingAction.Rdo=0;
    return STATUS_SUCCESS;
}
NTSTATUS SkPpsPathStop(SK_PPS_CHARGE_PATH *p,ULONG gen)
{
    NTSTATUS s=valid(p,gen);if(s!=STATUS_SUCCESS)return s;
    return off(p,gen,STATUS_SUCCESS,1);
}
NTSTATUS SkPpsPathConsumeAction(SK_PPS_CHARGE_PATH *p,ULONG gen,ULONG now,
    const SK_PD_PPS_OUTPUT *o)
{
    NTSTATUS s=valid(p,gen);if(s!=STATUS_SUCCESS)return s;
    s=clock_check(p,gen,now);if(s!=STATUS_SUCCESS)return s;
    if(!o)return off(p,gen,STATUS_INVALID_PARAMETER,0);
    /* A stale output must not shut down the current attachment. */
    if(o->Fast.Flags && o->Fast.Generation!=gen)return STATUS_CANCELLED;
    if(o->Fast.Flags&~((ULONG)(SK_PPS_SEND_REQUEST|SK_PPS_DISABLE_FAST_PATH|
                              SK_PPS_CONTRACT_CONFIRMED|SK_PPS_OWNER_RECOVERY)|
                      (ULONG)SK_PPS_FIXED_CONTRACT_RESTORED))
        return off(p,gen,STATUS_INVALID_PARAMETER,0);
    if(o->Fast.Flags&(SK_PPS_DISABLE_FAST_PATH|SK_PPS_OWNER_RECOVERY))
        return off(p,gen,STATUS_SUCCESS,1);
    if(o->Fast.Flags&SK_PPS_SEND_REQUEST){
        /* Never depend solely on an emitter remembering DISABLE_FAST. The
         * actual RDO and guard state determine whether a refresh is safe. */
        if(!p->BoundRdo || o->Fast.Rdo!=p->BoundRdo ||
           p->Pps->Guard.Rdo!=p->BoundRdo || !p->Pps->Guard.FastPathPermitted ||
           !p->Pps->Guard.Refreshing)
            return off(p,gen,STATUS_SUCCESS,1);
        {
            SK_PD_CONTRACT c;s=contract(p,gen,now,&c);
            if(s!=STATUS_SUCCESS)return s;
        }
    }
    if(o->Fast.Flags&SK_PPS_CONTRACT_CONFIRMED){
        SK_PD_CONTRACT c;s=contract(p,gen,now,&c);
        if(s!=STATUS_SUCCESS)return s;
        if(o->Fast.Rdo!=p->Pps->Guard.Rdo ||
           o->Fast.RequestId!=p->Pps->Guard.RequestId)
            return off(p,gen,STATUS_DEVICE_DATA_ERROR,0);
    }
    return STATUS_SUCCESS;
}
NTSTATUS SkPpsPathConfigure(SK_PPS_CHARGE_PATH *p,ULONG gen,ULONG now,
    const SK_LN_CONFIG_PERMIT *a,const SK_LN_CONFIG_REQUEST *q)
{
    SK_PD_CONTRACT c;NTSTATUS s=valid(p,gen);if(s!=STATUS_SUCCESS)return s;
    s=clock_check(p,gen,now);if(s!=STATUS_SUCCESS)return s;
    s=contract(p,gen,now,&c);if(s!=STATUS_SUCCESS)return s;
    /* A new configuration requires a settled handshake. During a refresh
     * preserve the existing converter, without rewriting its thresholds. */
    if(p->Pps->Guard.State!=SK_PPS_ACTIVE)
        return off(p,gen,STATUS_DEVICE_BUSY,0);
    s=exact_permit(p,gen,&c,a);if(s!=STATUS_SUCCESS)return s;
    s=SkLnConfigApply(p->Config,gen,now,a,q);
    if(s==STATUS_SUCCESS){
        p->BoundRdo=p->Pps->Guard.Rdo;p->BoundRequestId=p->Pps->Guard.RequestId;
    }else{p->BoundRdo=0;p->BoundRequestId=0;}
    return s;
}
static NTSTATUS run(SK_PPS_CHARGE_PATH *p,ULONG gen,ULONG now,
    const SK_LN_CONFIG_PERMIT *a,const SK_LN_PPS_PROOF *proof,ULONG poll)
{
    SK_PD_CONTRACT c;SK_LN_PPS_PROOF checked;
    NTSTATUS s=valid(p,gen);if(s!=STATUS_SUCCESS)return s;
    s=clock_check(p,gen,now);if(s!=STATUS_SUCCESS)return s;
    s=contract(p,gen,now,&c);if(s!=STATUS_SUCCESS)return s;
    if(!p->BoundRdo || p->BoundRdo!=p->Pps->Guard.Rdo)
        return off(p,gen,STATUS_DEVICE_NOT_READY,0);
    s=exact_permit(p,gen,&c,a);if(s!=STATUS_SUCCESS)return s;
    if(!proof || proof->PdMicrovolts!=c.Millivolts*1000u)
        return off(p,gen,STATUS_DEVICE_NOT_READY,0);
    checked=*proof;checked.Flags|=SK_LN_PPS_PD3_CONFIRMED;
    /* PROFILE is derived by SkLnConfig from current readback, after this
     * matching RDO check. All other physical proofs remain adapter-owned. */
    s=poll?SkLnConfigPoll2To1(p->Config,gen,now,a,&checked):
           SkLnConfigBegin2To1(p->Config,gen,now,a,&checked);
    if(s!=STATUS_SUCCESS && s!=STATUS_PENDING &&
       !p->Config->Converter->FastObligation){
        p->BoundRdo=0;p->BoundRequestId=0;
    }
    if(s==STATUS_SUCCESS && p->Pps->Guard.State==SK_PPS_ACTIVE)
        p->BoundRequestId=p->Pps->Guard.RequestId;
    return s;
}
NTSTATUS SkPpsPathBegin(SK_PPS_CHARGE_PATH *p,ULONG gen,ULONG now,
    const SK_LN_CONFIG_PERMIT *a,const SK_LN_PPS_PROOF *proof)
{return run(p,gen,now,a,proof,0);}
NTSTATUS SkPpsPathPoll(SK_PPS_CHARGE_PATH *p,ULONG gen,ULONG now,
    const SK_LN_CONFIG_PERMIT *a,const SK_LN_PPS_PROOF *proof)
{return run(p,gen,now,a,proof,1);}
typedef struct SK_PPS_COMMAND_CONTEXT {
    SK_PPS_CHARGE_PATH *Path;
    const SK_LN_CONFIG_PERMIT *Permit;
    ULONG InputLimitMicroamps;
} SK_PPS_COMMAND_CONTEXT;
static NTSTATUS command_permission(PVOID context,ULONG gen,ULONG now)
{
    SK_PPS_COMMAND_CONTEXT *b=(SK_PPS_COMMAND_CONTEXT *)context;
    SK_PPS_CHARGE_PATH *p=b->Path;
    const SK_LN_CONFIG_PERMIT *a=b->Permit;
    SK_PD_CONTRACT c;NTSTATUS s=valid(p,gen);
    if(s!=STATUS_SUCCESS)return s;
    /* Called with the converter busy. Do not call off/Stop or access I2C;
     * the low-level converter owns the one shutdown transaction on failure. */
    if(now-p->LastNowMs>0x7fffffffu)return STATUS_INVALID_PARAMETER;
    p->LastNowMs=now;
    s=contract_state(p,now,&c);if(s!=STATUS_SUCCESS)return s;
    if(!p->BoundRdo || p->BoundRdo!=p->Pps->Guard.Rdo ||
       a->Generation!=gen || a->Flags!=SK_LN_CONFIG_ALL_PROOFS ||
       now-a->ObservedAtMs>100u ||
       a->ContractMaxMicrovolts!=c.Millivolts*1000u ||
       a->ContractMaxMicroamps!=c.Milliamps*1000u ||
       a->MainInputBudgetMicroamps>=a->ContractMaxMicroamps ||
       b->InputLimitMicroamps>a->ContractMaxMicroamps-a->MainInputBudgetMicroamps)
        return STATUS_DEVICE_NOT_READY;
    return STATUS_SUCCESS;
}
static NTSTATUS sampled(SK_PPS_CHARGE_PATH *p,SK_LN_ADC *adc,ULONG gen,
    const SK_LN_CONFIG_PERMIT *permit,const SK_LN_PPS_PROOF *battery,ULONG poll)
{
    SK_LN_ADC_RESULT result;SK_LN_PPS_PROOF checked;SK_PD_CONTRACT c;
    SK_PPS_COMMAND_CONTEXT command;SK_LN_GATE gate;
    ULONG now;NTSTATUS s=valid(p,gen);if(s!=STATUS_SUCCESS)return s;
    if(!adc || adc->Converter!=p->Config->Converter || adc->Generation!=gen ||
       !battery || battery->Generation!=gen || battery->Flags!=
       (SK_LN_PPS_EXCLUSIVE_OWNER|SK_LN_PPS_MAIN_QUIESCED|SK_LN_PPS_THERMAL_APPROVED))
        return off(p,gen,STATUS_DEVICE_NOT_READY,0);
    s=SkLnAdcCopyReady(adc,gen,&result);
    if(s!=STATUS_SUCCESS)return off(p,gen,s,0);
    now=adc->LastNowMs;s=clock_check(p,gen,now);if(s!=STATUS_SUCCESS)return s;
    s=contract(p,gen,now,&c);if(s!=STATUS_SUCCESS)return s;
    if(!p->BoundRdo || p->BoundRdo!=p->Pps->Guard.Rdo)
        return off(p,gen,STATUS_DEVICE_NOT_READY,0);
    s=exact_permit(p,gen,&c,permit);if(s!=STATUS_SUCCESS)return s;
    checked=*battery;
    checked.Flags|=SK_LN_PPS_ADC_FRESH|SK_LN_PPS_PD3_CONFIRMED;
    checked.PdMicrovolts=c.Millivolts*1000u;
    checked.SampleAtMs=result.EarliestAtMs;
    checked.AdcConversionSerial=result.ConversionSerial;
    checked.Snapshot=result.Snapshot;
    command.Path=p;command.Permit=permit;command.InputLimitMicroamps=checked.MaxInputMicroamps;
    gate.Clock=adc->Clock;gate.ClockContext=adc->ClockContext;
    gate.Validate=command_permission;gate.ValidationContext=&command;
    gate.SafetyObservedAtMs=permit->ObservedAtMs;
    s=poll?SkLnConfigPoll2To1Gated(p->Config,gen,now,permit,&checked,&gate):
           SkLnConfigBegin2To1Gated(p->Config,gen,now,permit,&checked,&gate);
    if(s!=STATUS_SUCCESS && s!=STATUS_PENDING && !p->Config->Converter->FastObligation){
        p->BoundRdo=0;p->BoundRequestId=0;
    }
    if(s==STATUS_SUCCESS && p->Pps->Guard.State==SK_PPS_ACTIVE)
        p->BoundRequestId=p->Pps->Guard.RequestId;
    return s;
}
NTSTATUS SkPpsPathBeginSampled(SK_PPS_CHARGE_PATH *p,SK_LN_ADC *adc,ULONG gen,
    const SK_LN_CONFIG_PERMIT *permit,const SK_LN_PPS_PROOF *battery)
{return sampled(p,adc,gen,permit,battery,0);}
NTSTATUS SkPpsPathPollSampled(SK_PPS_CHARGE_PATH *p,SK_LN_ADC *adc,ULONG gen,
    const SK_LN_CONFIG_PERMIT *permit,const SK_LN_PPS_PROOF *battery)
{return sampled(p,adc,gen,permit,battery,1);}
