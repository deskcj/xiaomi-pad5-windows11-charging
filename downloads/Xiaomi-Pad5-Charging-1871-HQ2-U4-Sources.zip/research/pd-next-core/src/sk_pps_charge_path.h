/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef SK_PPS_CHARGE_PATH_H
#define SK_PPS_CHARGE_PATH_H
#include "sk_pd_pps_exchange.h"
#include "sk_ln8000_config.h"
#include "sk_ln8000_adc.h"

/* SINGLE serialized PASSIVE_LEVEL port consumer. This binds a converter to
 * the actual PPS exchange, not to the source APDO's advertised maximum or a
 * caller-provided "PD confirmed" flag. No second PD sender or I2C owner.
 * Hardware adapter still owns fresh main-input budget, ADC completion,
 * battery/thermal proofs, main quiescence and complete Type-C/PD policy.
 * This component is not the missing Windows device/IRQ adapter.
 */
typedef struct SK_PPS_CHARGE_PATH {
    SK_PD_PPS_EXCHANGE *Pps;
    SK_LN_CONFIG *Config;
    ULONG Generation, BoundRdo, BoundRequestId, LastNowMs;
    SK_PPS_ACTION PendingAction; /* command-boundary revocation for PD owner */
} SK_PPS_CHARGE_PATH;

NTSTATUS SkPpsPathInitialize(SK_PPS_CHARGE_PATH *,SK_PD_PPS_EXCHANGE *,
                           SK_LN_CONFIG *,ULONG Generation,ULONG NowMs);
/* Execute BEFORE acting on every PPS output, even if its originating API
 * returned an error. Changed-target SEND and DISABLE_FAST require physical
 * standby before any TX/fixed fallback. Matching refresh SEND preserves the
 * already confirmed pump only while the same guard still permits it.
 * Success is permission to continue handling the output, NOT TX submission
 * or Windows publication. A shutdown failure blocks both; obligation stays
 * in the converter/config owner. Foreign generation never touches hardware.
 */
NTSTATUS SkPpsPathConsumeAction(SK_PPS_CHARGE_PATH *,ULONG Generation,
                               ULONG NowMs,const SK_PD_PPS_OUTPUT *);
NTSTATUS SkPpsPathConfigure(SK_PPS_CHARGE_PATH *,ULONG Generation,ULONG NowMs,
                           const SK_LN_CONFIG_PERMIT *,const SK_LN_CONFIG_REQUEST *);
/* Permit contract voltage/current must equal the CONFIRMED RDO, not APDO
 * capabilities. The main-buck budget is subtracted inside config. Caller
 * cannot supply a different PdMicrovolts or grant PD3/PROFILE via flags.
 * Same-RDO refresh retains this binding; new target requires reconfiguration
 * after its own complete handshake and physical measurement.
 */
NTSTATUS SkPpsPathBegin(SK_PPS_CHARGE_PATH *,ULONG Generation,ULONG NowMs,
                      const SK_LN_CONFIG_PERMIT *,const SK_LN_PPS_PROOF *);
NTSTATUS SkPpsPathPoll(SK_PPS_CHARGE_PATH *,ULONG Generation,ULONG NowMs,
                     const SK_LN_CONFIG_PERMIT *,const SK_LN_PPS_PROOF *);
NTSTATUS SkPpsPathStop(SK_PPS_CHARGE_PATH *,ULONG Generation);
/* Drain after EVERY path API, including failure. Physical standby is handled
 * here; protocol recovery must be consumed by the complete single PD owner.
 * This does not submit TX, restore fixed charging or publish Windows state.
 * Foreign generation leaves the current attachment's pending action intact. */
NTSTATUS SkPpsPathTakeAction(SK_PPS_CHARGE_PATH *,ULONG,SK_PPS_ACTION *);
/* Physical integration entry points: ADC proof comes ONLY from this
 * converter's completed acquisition, with the real clock rechecked across
 * config/status I/O and effective converter commands. BatteryProof carries
 * independent battery/SOC/temperature/current-budget evidence; Flags must
 * be EXCLUSIVE|MAIN_QUIESCED|THERMAL_APPROVED only. Its Snapshot, ADC date,
 * serial and PD voltage cannot grant permission and are replaced here.
 * This closes the component's evidence/command boundary, not the missing
 * Windows PD3 native replacement or physical Resource Hub endpoint.
 */
NTSTATUS SkPpsPathBeginSampled(SK_PPS_CHARGE_PATH *,SK_LN_ADC *,ULONG Generation,
    const SK_LN_CONFIG_PERMIT *,const SK_LN_PPS_PROOF *BatteryProof);
NTSTATUS SkPpsPathPollSampled(SK_PPS_CHARGE_PATH *,SK_LN_ADC *,ULONG Generation,
    const SK_LN_CONFIG_PERMIT *,const SK_LN_PPS_PROOF *BatteryProof);
ULONG SkPpsPathSize(VOID);
#endif
