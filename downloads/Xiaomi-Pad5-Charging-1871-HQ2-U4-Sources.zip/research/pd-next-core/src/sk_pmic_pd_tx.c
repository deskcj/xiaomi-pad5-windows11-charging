#include "sk_pmic_pd_tx.h"

static NTSTATUS synchronous(NTSTATUS status)
{return status==STATUS_SUCCESS ? status : (NT_SUCCESS(status) ? STATUS_IO_DEVICE_ERROR : status);}
static NTSTATUS read_one(SK_PMIC_PD_TX *t,USHORT offset,PUCHAR value)
{return synchronous(t->Ops.Read(t->BusContext,t->SID,(USHORT)(t->Base+offset),value,1));}
static NTSTATUS write_bytes(SK_PMIC_PD_TX *t,USHORT offset,const UCHAR *p,ULONG length)
{return synchronous(t->Ops.Write(t->BusContext,t->SID,(USHORT)(t->Base+offset),p,length));}
static NTSTATUS update(SK_PMIC_PD_TX *t,USHORT offset,UCHAR mask,UCHAR value)
{return synchronous(t->Ops.Update(t->BusContext,t->SID,(USHORT)(t->Base+offset),mask,value));}
ULONG SkPmicTxSize(VOID){return sizeof(SK_PMIC_PD_TX);}
NTSTATUS SkPmicTxInitialize(SK_PMIC_PD_TX *t,const SK_PMIC_TX_OPS *ops,PVOID bus,
    UCHAR sid,USHORT base,ULONG generation,ULONG native)
{
    if(!t || !ops || !ops->Read || !ops->Write || !ops->Update || !ops->Delay ||
       sid!=2 || base!=0x1700 || !generation || native!=1)
        return STATUS_INVALID_PARAMETER;
    if(t->Initialized)return STATUS_INVALID_DEVICE_STATE;
    t->Ops=*ops;t->BusContext=bus;t->Generation=generation;
    t->LastToken=0;t->PendingToken=0;t->Faulted=0;t->Busy=0;
    t->SID=sid;t->Base=base;t->Reserved=0;t->Initialized=1;
    return STATUS_SUCCESS;
}
NTSTATUS SkPmicTxSubmit(SK_PMIC_PD_TX *t,const SK_PD_SESSION_TX *tx)
{
    SK_PD_HEADER h;
    UCHAR state=0,command;
    NTSTATUS status;
    ULONG payload;
    if(!t || !tx || !t->Initialized)return STATUS_INVALID_PARAMETER;
    if(tx->Generation!=t->Generation)return STATUS_CANCELLED;
    if(t->Faulted)return STATUS_INVALID_DEVICE_STATE;
    if(t->Busy || t->PendingToken)return STATUS_DEVICE_BUSY;
    if(!tx->Token || tx->Token<=t->LastToken)return STATUS_CANCELLED;
    if(tx->FrameBytes<4 || tx->FrameBytes>32 || tx->Frame[0]+1U!=tx->FrameBytes ||
       tx->Frame[1]!=0)return STATUS_INVALID_PARAMETER;
    if(SkPdDecodeHeader((SK_PD_U16)(tx->Frame[2]|((USHORT)tx->Frame[3]<<8)),&h)!=SK_PD_OK ||
       h.Extended || h.Revision==0 || !h.MessageType ||
       tx->FrameBytes!=4+4*h.DataObjects ||
       (!h.DataObjects && (h.MessageType==1 || (h.Revision==1 && h.MessageType>13))))
        return STATUS_DATA_ERROR;
    payload=tx->FrameBytes-4;
    t->Busy=1;
    /* Never ACK another receiver's pending packet or clear an active send. */
    status=read_one(t,0x4b,&state);if(status!=STATUS_SUCCESS)goto fault;
    if(state&1){status=STATUS_DEVICE_BUSY;goto done;}
    status=read_one(t,0x44,&state);if(status!=STATUS_SUCCESS)goto fault;
    if(state&3){status=STATUS_DEVICE_BUSY;goto done;}
    status=update(t,0x44,0xff,0);if(status!=STATUS_SUCCESS)goto fault;
    status=read_one(t,0x44,&state);if(status!=STATUS_SUCCESS)goto fault;
    if(state){status=STATUS_IO_DEVICE_ERROR;goto fault;}
    /* MSG_CONFIG bit3=data role, bit2=power role, bits1:0=PD revision,
     * verified against provider 6ae0 and the PM8150B upstream driver.
     */
    command=(UCHAR)((h.DataRole<<3)|(h.PowerRole<<2)|h.Revision);
    status=update(t,0x40,0x0f,command);if(status!=STATUS_SUCCESS)goto fault;
    status=write_bytes(t,0x60,tx->Frame+2,2);if(status!=STATUS_SUCCESS)goto fault;
    if(payload){
        status=write_bytes(t,0x62,tx->Frame+4,payload);if(status!=STATUS_SUCCESS)goto fault;
    }
    status=update(t,0x42,0x1f,(UCHAR)(payload+1));if(status!=STATUS_SUCCESS)goto fault;
    /* Original nabu pd_phy_write explicitly waits >=2us after TX_CONTROL
     * clear, before Send. Do not assume bus transfer time supplies the delay.
     * A real kernel adapter may use KeStallExecutionProcessor(2) here.
     */
    status=synchronous(t->Ops.Delay(t->BusContext,2));if(status!=STATUS_SUCCESS)goto fault;
    /* An RX arriving while the message is prepared wins. Prepared TX bytes
     * are not a transmission; drain RX before retrying the SAME session token.
     */
    status=read_one(t,0x4b,&state);if(status!=STATUS_SUCCESS)goto fault;
    if(state&1){status=STATUS_DEVICE_BUSY;goto done;}
    /* Reserve the token BEFORE the potentially ambiguous hardware write. */
    t->LastToken=tx->Token;t->PendingToken=tx->Token;
    command=(UCHAR)(1|((h.Revision==2 ? 2U : 3U)<<5));
    status=update(t,0x44,0x7d,command);if(status!=STATUS_SUCCESS)goto fault;
    goto done;
fault:
    t->Faulted=1;
done:
    t->Busy=0;
    return status;
}
NTSTATUS SkPmicTxComplete(SK_PMIC_PD_TX *t,ULONG generation,ULONG token,ULONG result)
{
    if(!t || !t->Initialized || !token || result<1 || result>3)
        return STATUS_INVALID_PARAMETER;
    if(generation!=t->Generation || token!=t->PendingToken)return STATUS_CANCELLED;
    if(t->Busy || t->Faulted)return STATUS_INVALID_DEVICE_STATE;
    t->PendingToken=0;
    if(result!=SK_PD_SESSION_TX_SUCCESS){t->Faulted=1;return STATUS_IO_DEVICE_ERROR;}
    return STATUS_SUCCESS;
}
