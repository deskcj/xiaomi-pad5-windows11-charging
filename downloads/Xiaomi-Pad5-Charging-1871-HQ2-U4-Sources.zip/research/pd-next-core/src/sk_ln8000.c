/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "sk_ln8000.h"
#include "sk_nabu_ntc_table.h"

static void clear(void *p,ULONG n)
{ULONG i;for(i=0;i<n;++i)((volatile UCHAR *)p)[i]=0;}
static NTSTATUS enter(SK_LN8000 *c,ULONG generation)
{
    if(!c || !generation || !c->Ops.Read || !c->Ops.Write)return STATUS_INVALID_PARAMETER;
    if(generation!=c->Generation)return STATUS_CANCELLED;
    if(c->Busy)return STATUS_DEVICE_BUSY;
    c->Busy=1;return STATUS_SUCCESS;
}
static NTSTATUS read_exact(SK_LN8000 *c,UCHAR reg,PUCHAR data,ULONG bytes)
{
    ULONG actual=0;NTSTATUS s=c->Ops.Read(c->Device,reg,data,bytes,&actual);
    if(s!=STATUS_SUCCESS)return NT_SUCCESS(s)?STATUS_IO_DEVICE_ERROR:s;
    return actual==bytes?STATUS_SUCCESS:STATUS_DEVICE_DATA_ERROR;
}
static NTSTATUS write_exact(SK_LN8000 *c,UCHAR reg,UCHAR data)
{
    ULONG actual=0;NTSTATUS s=c->Ops.Write(c->Device,reg,&data,1,&actual);
    if(s!=STATUS_SUCCESS)return NT_SUCCESS(s)?STATUS_IO_DEVICE_ERROR:s;
    return actual==1?STATUS_SUCCESS:STATUS_DEVICE_DATA_ERROR;
}
static NTSTATUS identity(SK_LN8000 *c)
{
    UCHAR id=0;NTSTATUS s=read_exact(c,0,&id,1);
    if(NT_SUCCESS(s) && id!=0x42)s=STATUS_NO_SUCH_DEVICE;
    c->Probed=NT_SUCCESS(s);return s;
}
static NTSTATUS update_verify(SK_LN8000 *c,UCHAR reg,UCHAR mask,UCHAR value)
{
    UCHAR before=0,after=0;NTSTATUS s=read_exact(c,reg,&before,1);
    if(!NT_SUCCESS(s))return s;
    s=write_exact(c,reg,(UCHAR)((before&~mask)|(value&mask)));
    if(!NT_SUCCESS(s))return s;
    s=read_exact(c,reg,&after,1);
    if(NT_SUCCESS(s) && (after&mask)!=(value&mask))s=STATUS_DEVICE_DATA_ERROR;
    return s;
}
static NTSTATUS release_adc(SK_LN8000 *c)
{
    NTSTATUS s;
    if(!c->OwnAdcPause)return STATUS_SUCCESS;
    s=update_verify(c,0x26,2,0);
    if(NT_SUCCESS(s))c->OwnAdcPause=0;
    return s;
}
static NTSTATUS acquire_adc(SK_LN8000 *c)
{
    UCHAR before=0,after=0;NTSTATUS s;
    /* The earlier timer check is not ownership. A second owner might have
     * asserted hold before this RMW read; never clear its hold on exit.
     * The physical adapter still must exclude all other bus/firmware owners:
     * a read followed by a write is not an atomic hardware test-and-set. */
    s=read_exact(c,0x26,&before,1);
    if(s!=STATUS_SUCCESS)return s;
    if(before&2)return STATUS_DEVICE_BUSY;
    /* Even a failed/short write may affect silicon. Take the cleanup
     * obligation immediately before attempting our first effective write. */
    c->OwnAdcPause=1;
    s=write_exact(c,0x26,(UCHAR)(before|2));
    if(s!=STATUS_SUCCESS)return s;
    s=read_exact(c,0x26,&after,1);
    if(s==STATUS_SUCCESS && !(after&2))s=STATUS_DEVICE_DATA_ERROR;
    return s;
}

ULONG SkLn8000Size(VOID){return sizeof(SK_LN8000);}
NTSTATUS SkLn8000BatteryTemperature(ULONG raw,ULONG vbat,LONG *temperature)
{
    ULONG ntc_mv,denominator,ohms,i,step;
    if(!temperature)return STATUS_INVALID_PARAMETER;
    *temperature=0;
    if(raw>1023 || vbat<3000000 || vbat>4500000)return STATUS_INVALID_PARAMETER;
    /* ORIGINAL nabu channel7: 2932uV/code, then integer mV. The adjacent
     * bus thermistor channel uses 2933uV/code and is a different circuit.
     * Use one coherent battery/NTC sample in the physical adapter. */
    ntc_mv=raw*2932/1000;
    if(vbat/1000<=2*ntc_mv)return STATUS_DEVICE_DATA_ERROR;
    denominator=vbat/1000-2*ntc_mv;
    ohms=ntc_mv*100000/denominator;
    if(ohms<1000)return STATUS_DEVICE_DATA_ERROR;
    ohms-=1000;
    if(ohms<SkNabuBatteryNtc[0].Ohms || ohms>SkNabuBatteryNtc[115].Ohms)
        return STATUS_DEVICE_DATA_ERROR;
    for(i=0;i<115;++i){
        if(ohms<=SkNabuBatteryNtc[i+1].Ohms){
            step=(ohms-SkNabuBatteryNtc[i].Ohms)*10/
                (SkNabuBatteryNtc[i+1].Ohms-SkNabuBatteryNtc[i].Ohms);
            /* The original ELF adds step for rows0..85 despite a descending
             * table. Keep this interpolation monotonic, subtracting it for
             * every row, rather than reproducing those temperature jumps. */
            *temperature=SkNabuBatteryNtc[i].DeciC-(LONG)step;
            return STATUS_SUCCESS;
        }
    }
    return STATUS_DEVICE_DATA_ERROR;
}
NTSTATUS SkLn8000Initialize(SK_LN8000 *c,const SK_LN_OPS *ops,PVOID device,
    ULONG generation,ULONG address)
{
    if(!c || !ops || !ops->Read || !ops->Write || !device || !generation || address!=0x51)
        return STATUS_INVALID_PARAMETER;
    clear(c,sizeof(*c));c->Ops=*ops;c->Device=device;c->Generation=generation;
    return STATUS_SUCCESS;
}
NTSTATUS SkLn8000Probe(SK_LN8000 *c,ULONG generation)
{
    NTSTATUS s=enter(c,generation);if(!NT_SUCCESS(s))return s;
    s=c->NeedsRecovery?STATUS_DEVICE_NOT_READY:identity(c);
    c->Busy=0;return s;
}
NTSTATUS SkLn8000Decode(const UCHAR *bank,ULONG length,SK_LN_SNAPSHOT *o)
{
    ULONG i,n;LONG t;
    if(!o)return STATUS_INVALID_PARAMETER;
    clear(o,sizeof(*o));
    if(!bank || length!=16)return STATUS_INVALID_PARAMETER;
    for(i=0;i<16;++i)o->Registers[i]=bank[i];
    o->PowerState=bank[0]&15;
    /* Keep alarms/faults visible, including voltage qualification bit5 of
     * FAULT2. Do not clear latched faults merely by reading their status. */
    o->FaultBits=((ULONG)(bank[1]&0x7c))|((ULONG)bank[2]<<8)|((ULONG)(bank[3]&0xa0)<<16);
    o->IinMicroamps=(((ULONG)(bank[7]&3)<<8)|bank[6])*4890;
    o->VinMicrovolts=(((ULONG)(bank[9]&63)<<4)|(bank[8]>>4))*16000;
    o->VbatMicrovolts=(((ULONG)(bank[12]&3)<<8)|bank[11])*5000;
    o->VacMicrovolts=((((ULONG)(bank[8]&15)<<6)|(bank[7]>>2))+5)*16000;
    n=((ULONG)(bank[13]&15)<<6)|(bank[12]>>2);
    t=(935-(LONG)n)*4350/1000;
    o->DieTemperatureDeciC=t>1600?1600:t<(-250)?(-250):t;
    o->BatteryNtcRawCode=((ULONG)(bank[14]&63)<<4)|(bank[13]>>4);
    o->BusNtcMicrovolts=(((ULONG)bank[15]<<2)|(bank[14]>>6))*2933;
    /* Pure decoding is not a completed, fresh hardware snapshot. */
    return STATUS_SUCCESS;
}
NTSTATUS SkLn8000Snapshot(SK_LN8000 *c,ULONG generation,ULONG now,SK_LN_SNAPSHOT *o)
{
    UCHAR timer=0,bank[16];NTSTATUS cleanup,s;
    if(!o)return STATUS_INVALID_PARAMETER;
    clear(o,sizeof(*o));
    s=enter(c,generation);if(!NT_SUCCESS(s))return s;
    if(c->NeedsRecovery){s=STATUS_DEVICE_NOT_READY;goto done;}
    s=identity(c);if(!NT_SUCCESS(s))goto done;
    s=read_exact(c,0x26,&timer,1);if(!NT_SUCCESS(s))goto done;
    if(timer&2){s=STATUS_DEVICE_BUSY;goto done;}
    s=acquire_adc(c);
    if(NT_SUCCESS(s))s=read_exact(c,3,bank,sizeof(bank));
    cleanup=release_adc(c);
    if(!NT_SUCCESS(cleanup)){
        c->NeedsRecovery=1;s=cleanup;
    }
    if(NT_SUCCESS(s)){
        s=SkLn8000Decode(bank,sizeof(bank),o);
        if(NT_SUCCESS(s)){o->Generation=generation;o->ReadAtMs=now;o->Complete=1;}
    }
done:
    c->Busy=0;return s;
}
NTSTATUS SkLn8000Standby(SK_LN8000 *c,ULONG generation)
{
    UCHAR state=0;NTSTATUS s=enter(c,generation);if(!NT_SUCCESS(s))return s;
    s=identity(c);if(!NT_SUCCESS(s))goto failed;
    s=update_verify(c,0x1e,9,8);if(!NT_SUCCESS(s))goto failed;
    s=read_exact(c,3,&state,1);if(!NT_SUCCESS(s))goto failed;
    if((state&12) || !(state&3)){s=STATUS_DEVICE_NOT_READY;goto failed;}
    if(c->OwnAdcPause){s=release_adc(c);if(!NT_SUCCESS(s))goto failed;}
    if(c->OwnIntPause){
        s=update_verify(c,0x26,1,0);if(!NT_SUCCESS(s))goto failed;
        c->OwnIntPause=0;
    }
    c->NeedsRecovery=0;c->FastPending=0;c->FastActive=0;
    c->FastObligation=0;c->Busy=0;return STATUS_SUCCESS;
failed:
    c->NeedsRecovery=1;c->Busy=0;return s;
}

static NTSTATUS proof_valid(const SK_LN_PPS_PROOF *p,ULONG generation,ULONG now)
{
    const SK_LN_SNAPSHOT *a;
    if(!p || p->Generation!=generation || p->Flags!=SK_LN_PPS_ALL_PROOFS ||
       !p->AdcConversionSerial || now-p->SampleAtMs>100u)
        return STATUS_DEVICE_NOT_READY;
    a=&p->Snapshot;
    if(!a->Complete || a->Generation!=generation ||
       now-a->ReadAtMs>100u || a->FaultBits ||
       /* Actual nabu usbpd_pm_workfunc admits only SOC <90. Keep this
        * conservative guard during operation too, until the physical
        * adapter implements verified taper/exit coordination. */
       p->SocPercent>=90 || p->BatteryTemperatureDeciC<100 ||
       p->BatteryTemperatureDeciC>400 || a->DieTemperatureDeciC<(-250) ||
       a->DieTemperatureDeciC>800 || p->MaxInputMicroamps<500000 ||
       p->MaxInputMicroamps>3000000 || a->IinMicroamps>p->MaxInputMicroamps ||
       p->FuelCellMicrovolts<3000000 || p->FuelCellMicrovolts>4300000 ||
       a->VbatMicrovolts<3000000 || a->VbatMicrovolts>4300000 ||
       a->VbatMicrovolts+150000<p->FuelCellMicrovolts ||
       p->FuelCellMicrovolts+150000<a->VbatMicrovolts ||
       p->PdMicrovolts<6500000 || p->PdMicrovolts>9000000 ||
       a->VinMicrovolts+100000<p->PdMicrovolts ||
       p->PdMicrovolts+100000<a->VinMicrovolts ||
       a->VinMicrovolts<2*p->FuelCellMicrovolts+200000 ||
       a->VinMicrovolts>2*p->FuelCellMicrovolts+600000)
        return STATUS_DEVICE_NOT_READY;
    return STATUS_SUCCESS;
}
static NTSTATUS fast_abort(SK_LN8000 *c,ULONG generation,NTSTATUS why)
{
    NTSTATUS off;
    c->Busy=0;c->FastPending=0;c->FastActive=0;
    if(!c->FastObligation)return why;
    off=SkLn8000Standby(c,generation);
    return NT_SUCCESS(off)?why:off;
}
static NTSTATUS timed_proof(const SK_LN_PPS_PROOF *p,ULONG generation,
    ULONG *now,SK_LN_CLOCK clock,PVOID clock_context,ULONG safety_at,const SK_LN_GATE *gate)
{
    ULONG current;
    if(clock){
        current=clock(clock_context);
        if(current-*now>0x7fffffffu)return STATUS_INVALID_PARAMETER;
        *now=current;
        if(current-safety_at>100u)return STATUS_DEVICE_NOT_READY;
    }
    if(gate){
        NTSTATUS permission=gate->Validate(gate->ValidationContext,generation,*now);
        if(permission!=STATUS_SUCCESS)
            return NT_SUCCESS(permission)?STATUS_DEVICE_NOT_READY:permission;
    }
    return proof_valid(p,generation,*now);
}
static NTSTATUS fast_update(SK_LN8000 *c,UCHAR mask,UCHAR value,
    const SK_LN_PPS_PROOF *p,ULONG gen,ULONG *now,SK_LN_CLOCK clock,
    PVOID clock_context,ULONG safety_at,const SK_LN_GATE *gate)
{
    UCHAR before=0,after=0;NTSTATUS s=read_exact(c,0x1e,&before,1);
    if(s==STATUS_SUCCESS)s=timed_proof(p,gen,now,clock,clock_context,safety_at,gate);
    if(s==STATUS_SUCCESS)s=write_exact(c,0x1e,(UCHAR)((before&~mask)|(value&mask)));
    if(s==STATUS_SUCCESS)s=read_exact(c,0x1e,&after,1);
    if(s==STATUS_SUCCESS && (after&mask)!=(value&mask))s=STATUS_DEVICE_DATA_ERROR;
    if(s==STATUS_SUCCESS)s=timed_proof(p,gen,now,clock,clock_context,safety_at,gate);
    return s;
}
static NTSTATUS begin(SK_LN8000 *c,ULONG generation,ULONG now,
    const SK_LN_PPS_PROOF *p,SK_LN_CLOCK clock,PVOID clock_context,ULONG safety_at,const SK_LN_GATE *gate)
{
    UCHAR state=0;NTSTATUS s=enter(c,generation);
    if(!NT_SUCCESS(s))return s;
    s=timed_proof(p,generation,&now,clock,clock_context,safety_at,gate);
    if(!NT_SUCCESS(s))return fast_abort(c,generation,s);
    if(c->NeedsRecovery){c->Busy=0;return STATUS_DEVICE_NOT_READY;}
    if(c->FastPending || c->FastActive){c->Busy=0;return STATUS_DEVICE_BUSY;}
    s=identity(c);if(!NT_SUCCESS(s)){c->Busy=0;return s;}
    s=read_exact(c,3,&state,1);
    if(!NT_SUCCESS(s)){c->Busy=0;return s;}
    if((state&12) || !(state&3)){c->Busy=0;return STATUS_DEVICE_NOT_READY;}
    s=timed_proof(p,generation,&now,clock,clock_context,safety_at,gate);
    if(s!=STATUS_SUCCESS)return fast_abort(c,generation,s);
    /* Original nabu clears reverse-current detection before starting 2:1.
     * Acquire the shutdown obligation BEFORE the first potentially effective
     * write; even an error/short transfer may have reached the converter. */
    c->FastObligation=1;
    s=fast_update(c,4,0,p,generation,&now,clock,clock_context,safety_at,gate);
    if(NT_SUCCESS(s))s=fast_update(c,9,0,p,generation,&now,clock,clock_context,safety_at,gate);
    if(!NT_SUCCESS(s))return fast_abort(c,generation,s);
    c->FastStartAtMs=now;c->FastLastNowMs=now;
    c->FastStartAdcSerial=p->AdcConversionSerial;
    c->FastLastAdcSerial=p->AdcConversionSerial;
    c->FastLastAdcAtMs=p->SampleAtMs;
    c->FastPending=1;c->Busy=0;
    return STATUS_PENDING;
}
static NTSTATUS poll(SK_LN8000 *c,ULONG generation,ULONG now,
    const SK_LN_PPS_PROOF *p,SK_LN_CLOCK clock,PVOID clock_context,ULONG safety_at,const SK_LN_GATE *gate)
{
    SK_LN_SNAPSHOT a;UCHAR mode=0;
    NTSTATUS s=enter(c,generation);ULONG elapsed;
    if(!NT_SUCCESS(s))return s;
    if(!c->FastObligation){c->Busy=0;return STATUS_DEVICE_NOT_READY;}
    if(c->NeedsRecovery)return fast_abort(c,generation,STATUS_DEVICE_NOT_READY);
    if(now-c->FastLastNowMs>0x7fffffffu)
        return fast_abort(c,generation,STATUS_INVALID_PARAMETER);
    c->FastLastNowMs=now;
    s=timed_proof(p,generation,&now,clock,clock_context,safety_at,gate);
    if(!NT_SUCCESS(s))return fast_abort(c,generation,s);
    if((LONG)(p->AdcConversionSerial-c->FastLastAdcSerial)<0)
        return fast_abort(c,generation,STATUS_DEVICE_DATA_ERROR);
    /* A second read is not a new conversion. Never let an adapter renew
     * old ADC evidence by attaching a fresh date to the same serial. The
     * same conversion can be reused within its original 100ms lifetime. */
    if((p->AdcConversionSerial==c->FastLastAdcSerial &&
        p->SampleAtMs!=c->FastLastAdcAtMs) ||
       p->SampleAtMs-c->FastLastAdcAtMs>0x7fffffffu)
        return fast_abort(c,generation,STATUS_DEVICE_DATA_ERROR);
    c->FastLastAdcSerial=p->AdcConversionSerial;
    c->FastLastAdcAtMs=p->SampleAtMs;
    elapsed=now-c->FastStartAtMs;
    if(c->FastPending && elapsed>=100u)
        return fast_abort(c,generation,STATUS_IO_TIMEOUT);
    /* Respect original nabu's 10ms settling period without sleeping inside
     * the driver. A current ADC conversion must also follow the start. */
    if(c->FastPending && (elapsed<10u ||
       !((LONG)(p->AdcConversionSerial-c->FastStartAdcSerial)>0) ||
       p->SampleAtMs-c->FastStartAtMs>0x7fffffffu ||
       p->SampleAtMs-c->FastStartAtMs<10u)){
        c->Busy=0;return STATUS_PENDING;
    }
    c->Busy=0;s=SkLn8000Snapshot(c,generation,now,&a);
    if(!NT_SUCCESS(s))return fast_abort(c,generation,s);
    s=timed_proof(p,generation,&now,clock,clock_context,safety_at,gate);
    if(!NT_SUCCESS(s))return fast_abort(c,generation,s);
    if(c->FastPending && now-c->FastStartAtMs>=100u)
        return fast_abort(c,generation,STATUS_IO_TIMEOUT);
    /* The supplied proof establishes freshness; this independent coherent
     * read establishes current physical status. Require both to agree. */
    {
        SK_LN_PPS_PROOF live=*p;live.Snapshot=a;
        s=proof_valid(&live,generation,now);
    }
    if(!NT_SUCCESS(s))return fast_abort(c,generation,s);
    /* Original nabu getter enables RCP only with Iin >400000uA. Preserve
     * that loaded-start criterion; 250mA was an unverified earlier guess. */
    if(a.PowerState!=SK_LN_SYS_SWITCHING || a.IinMicroamps<=400000){
        if(c->FastActive)return fast_abort(c,generation,STATUS_DEVICE_NOT_READY);
        if(a.PowerState&SK_LN_SYS_BYPASS)
            return fast_abort(c,generation,STATUS_DEVICE_DATA_ERROR);
        return STATUS_PENDING;
    }
    s=enter(c,generation);if(!NT_SUCCESS(s))return s;
    s=fast_update(c,4,4,p,generation,&now,clock,clock_context,safety_at,gate);
    /* RCP can itself stop a converter that has insufficient loaded current.
     * Control readback alone must not turn that shutdown into success. */
    if(NT_SUCCESS(s))s=read_exact(c,3,&mode,1);
    if(NT_SUCCESS(s))s=timed_proof(p,generation,&now,clock,clock_context,safety_at,gate);
    if(NT_SUCCESS(s) && c->FastPending && now-c->FastStartAtMs>=100u)
        s=STATUS_IO_TIMEOUT;
    if(NT_SUCCESS(s) && (mode&15)!=SK_LN_SYS_SWITCHING)s=STATUS_DEVICE_NOT_READY;
    if(!NT_SUCCESS(s))return fast_abort(c,generation,s);
    c->FastLastNowMs=now;c->FastPending=0;c->FastActive=1;c->Busy=0;
    return STATUS_SUCCESS;
}
NTSTATUS SkLn8000Begin2To1(SK_LN8000 *c,ULONG gen,ULONG now,const SK_LN_PPS_PROOF *p)
{return begin(c,gen,now,p,NULL,NULL,0,NULL);}
NTSTATUS SkLn8000Poll2To1(SK_LN8000 *c,ULONG gen,ULONG now,const SK_LN_PPS_PROOF *p)
{return poll(c,gen,now,p,NULL,NULL,0,NULL);}
NTSTATUS SkLn8000Begin2To1Timed(SK_LN8000 *c,ULONG gen,ULONG now,
    const SK_LN_PPS_PROOF *p,SK_LN_CLOCK clock,PVOID context,ULONG safety_at)
{
    if(!clock)return STATUS_INVALID_PARAMETER;
    return begin(c,gen,now,p,clock,context,safety_at,NULL);
}
NTSTATUS SkLn8000Poll2To1Timed(SK_LN8000 *c,ULONG gen,ULONG now,
    const SK_LN_PPS_PROOF *p,SK_LN_CLOCK clock,PVOID context,ULONG safety_at)
{
    if(!clock)return STATUS_INVALID_PARAMETER;
    return poll(c,gen,now,p,clock,context,safety_at,NULL);
}

NTSTATUS SkLn8000Begin2To1Gated(SK_LN8000 *c,ULONG gen,ULONG now,
    const SK_LN_PPS_PROOF *p,const SK_LN_GATE *gate)
{
    if(!gate || !gate->Clock || !gate->Validate)return STATUS_INVALID_PARAMETER;
    return begin(c,gen,now,p,gate->Clock,gate->ClockContext,
                 gate->SafetyObservedAtMs,gate);
}
NTSTATUS SkLn8000Poll2To1Gated(SK_LN8000 *c,ULONG gen,ULONG now,
    const SK_LN_PPS_PROOF *p,const SK_LN_GATE *gate)
{
    if(!gate || !gate->Clock || !gate->Validate)return STATUS_INVALID_PARAMETER;
    return poll(c,gen,now,p,gate->Clock,gate->ClockContext,
                gate->SafetyObservedAtMs,gate);
}
