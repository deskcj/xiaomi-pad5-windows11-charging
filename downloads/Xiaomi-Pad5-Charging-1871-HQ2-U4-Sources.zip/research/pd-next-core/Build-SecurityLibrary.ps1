$ErrorActionPreference='Stop'
$skCompiler='H:\Vlad\EWDK\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207\bin\Hostarm64\arm64'
$skBuild=Join-Path $PSScriptRoot 'build'
$skObjects=@('sk_pd_protocol','sk_pd_session','sk_pps_guard','sk_pd_pps_exchange',
 'sk_pd_fixed_exchange','sk_pmic_pd_tx','sk_pmic_pd_rx','sk_ln8000','sk_ln8000_profile',
 'sk_ln8000_config','sk_pps_charge_path','sk_ln8000_adc','sk_pd_frs') | ForEach-Object {Join-Path $skBuild ($_+'-analyzed.obj')}
foreach($skObject in $skObjects){if(!(Test-Path -LiteralPath $skObject)){throw 'Run Build.ps1 first'}}
& "$skCompiler\lib.exe" /nologo /MACHINE:ARM64 "/OUT:$skBuild\sk_pps_charge_binding.kernel-objects.lib" @skObjects *> (Join-Path $skBuild 'kernel-library.log')
if($LASTEXITCODE -ne 0){Get-Content -LiteralPath (Join-Path $skBuild 'kernel-library.log');throw 'Library failed'}
Get-FileHash -LiteralPath (Join-Path $skBuild 'sk_pps_charge_binding.kernel-objects.lib')
