"""Execute wire handshake + converter configuration/start/stop in one ARM64 image.

SPMI, SPB, IRQ/completed ADC and board grants are modeled. No hardware access.
Fixed baseline is established by the compiled fixed exchange, not fabricated.
"""
from pathlib import Path
import json, hashlib, struct
from unicorn.arm64_const import *
root=Path(__file__).resolve().parent
scope={'__file__':str(root/'TestFixedPpsTransport.py')}
exec(compile((root/'TestFixedPpsTransport.py').read_text().split('\nfor base in (')[0],
             scope['__file__'],'exec'),scope)
Fixed=scope['FixedTransport'];packet=scope['packet'];rows=[]

def bank(mode=2,current=300,voltage=525,cell=800,die=889):
    b=bytearray(16);b[0]=mode;b[6]=current&255;b[7]=(current>>8)&3
    b[8]=(voltage&15)<<4;b[9]=(voltage>>4)&63
    b[11]=cell&255;b[12]=(cell>>8)&3 | (die&63)<<2;b[13]=(die>>6)&15
    return b

class Binding(Fixed):
    def __init__(self,base,name):
        self.ln_ready=False
        super().__init__(base,name)
        self.u.mem_map(0x21000000,0x10000)
        self.lctx=0x21001000;self.lops=0x21000200;self.config=0x21002000
        self.path=0x21003000;self.permit=0x21004000;self.request=0x21004100
        self.proof=0x21005000;self.snap=0x21006000;self.rawbank=0x21007000
        self.lread=0x2100d000;self.lwrite=0x2100d010
        self.lregs=bytearray(256);self.lregs[0]=0x42;self.lregs[3:19]=bank()
        self.lregs[0x1e]=8;self.ln_io=[];self.fail_index=0;self.short_index=0
        self.information_index=0;self.stuck_off=False
        self.u.mem_write(self.lops,struct.pack('<2Q',self.lread,self.lwrite))
        self.ln_ready=True
        assert self.call('SkLn8000Initialize',self.lctx,self.lops,0x5678,77,0x51)==0
        assert self.call('SkLnConfigInitialize',self.config,self.lctx,77,0)==0
        assert self.call('SkPpsPathInitialize',self.path,self.s,self.config,77,0)==0
        for ptr,size in ((self.path,48),(self.config,56),(self.lctx,80)):
            self.u.mem_write(ptr-8,b'BEFORELN');self.u.mem_write(ptr+size,b'AFTERLN!')
        self.set_permit();self.set_request()
    def hook(self,u,a,n,data):
        if not self.ln_ready or a not in (self.lread,self.lwrite):
            return super().hook(u,a,n,data)
        regs=(UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3,UC_ARM64_REG_X4)
        device,reg,p,count,actual=[u.reg_read(r) for r in regs]
        assert device==0x5678 and 0<count<=16 and reg+count<=256
        index=len(self.ln_io)+1;kind='Read' if a==self.lread else 'Write'
        if a==self.lread:u.mem_write(p,bytes(self.lregs[reg:reg+count]))
        else:
            value=bytes(u.mem_read(p,count));self.lregs[reg:reg+count]=value
            if reg==0x1e:
                if value[0]&8:
                    if not self.stuck_off:self.lregs[3]=2
                else:self.lregs[3]=4
        done=count-(index==self.short_index)
        status=0xc0000185 if index==self.fail_index else 0x103 if index==self.information_index else 0
        u.mem_write(actual,struct.pack('<I',done))
        self.ln_io.append(dict(Index=index,Kind=kind,Register=reg,Count=count,Status=hex(status),
                               Value=self.lregs[reg] if a==self.lwrite else None))
        self.ret(status)
    def call(self,name,*args):
        r=super().call(name,*args)
        if self.ln_ready:
            for ptr,size in ((self.path,48),(self.config,56),(self.lctx,80)):
                # Initialization executes before installing these sentinels.
                if bytes(self.u.mem_read(ptr-8,8))==b'BEFORELN':
                    assert bytes(self.u.mem_read(ptr+size,8))==b'AFTERLN!'
        return r&0xffffffff if name.startswith(('SkPpsPath','SkLn')) else r
    def set_permit(self,now=10,mv=8400000,ma=3000000,main=1000000,flags=15,gen=77):
        self.u.mem_write(self.permit,struct.pack('<6I',gen,now,flags,mv,ma,main))
    def set_request(self,current=2000000,voltage=4450000,ntc=226):
        self.u.mem_write(self.request,struct.pack('<3I',voltage,current,ntc))
    def set_proof(self,now=11,serial=1,mode=2,flags=53,mv=8400000,ma=2000000,gen=77,
                  sample=None,cell=4000000,soc=50,temp=250,fault=False):
        raw=bank(mode=mode)
        if fault:raw[1]|=0x10
        self.lregs[3:19]=raw
        self.u.mem_write(self.rawbank,bytes(raw))
        assert self.call('SkLn8000Decode',self.rawbank,16,self.snap)==0
        snap=bytearray(self.u.mem_read(self.snap,64));struct.pack_into('<3I',snap,0,77,now,1)
        head=struct.pack('<8Ii',gen,flags,now if sample is None else sample,serial,mv,ma,cell,soc,temp)
        self.u.mem_write(self.proof,head+snap)
    def action(self,now,gen=77):return self.call('SkPpsPathConsumeAction',self.path,gen,now,self.out)
    def configure(self,now=10,gen=77):return self.call('SkPpsPathConfigure',self.path,gen,now,self.permit,self.request)
    def start(self,now=11,gen=77):return self.call('SkPpsPathBegin',self.path,gen,now,self.permit,self.proof)
    def lpoll(self,now=21,gen=77):return self.call('SkPpsPathPoll',self.path,gen,now,self.permit,self.proof)
    def fast(self):return struct.unpack('<3I',bytes(self.u.mem_read(self.lctx+56,12)))
    def binding(self):return struct.unpack('<4I',bytes(self.u.mem_read(self.path+16,16)))
    def off_assert(self):
        assert self.fast()==(0,0,0) and self.lregs[3]==2
        assert self.binding()[1:3]==(0,0)
    def pps(self,ma=3000,stop_after=None):
        self.confirmed()
        assert self.begin(now=6,pos=4,mv=8400,ma=ma)[0]==0
        assert self.action(6)==0
        if stop_after=='Request':return
        assert self.send()==0 and self.goodcrc(7)==0
        if stop_after=='GoodCRC':return
        assert self.phy_receive(packet(3,3),8)==0
        if stop_after=='Accept':return
        assert self.phy_receive(packet(6,4),9)==0
        if stop_after=='PS_RDY':return
        assert self.observe(10,vbus=8400)[0]==0 and self.state()==(5,1)
        assert self.action(10)==0
    def active_pump(self):
        self.pps();assert self.configure()==0
        self.set_permit(now=11);self.set_proof()
        assert self.start()==0x103
        self.set_permit(now=21);self.set_proof(now=21,serial=2,mode=4)
        assert self.lpoll()==0 and self.fast()==(0,1,1)
        assert self.binding()[1]==0x4303483c
    def record(self,name,**extra):
        rows.append(dict(Case=name,Base=hex(self.base),ARM64Calls=self.calls,
            Bound=self.binding(),Fast=self.fast(),ConfigObligation=struct.unpack('<I',bytes(self.u.mem_read(self.config+16,4)))[0],
            LNTransfers=len(self.ln_io),SPMIOperations=len(self.io),**extra))

for base in (0x140000000,0x180000000):
    r=Binding(base,'whole-path');r.active_pump()
    r.record('FixedHandshake_PpsHandshake_Adc_Config_Begin_Poll')
    for stage in ('Request','GoodCRC','Accept','PS_RDY'):
        r=Binding(base,stage);r.pps(stop_after=stage)
        n=len(r.ln_io);assert r.configure()!=0
        assert len(r.ln_io)==n and not any(r.fast())
        r.record('UnconfirmedStageCannotConfigurePump',Stage=stage)
    r=Binding(base,'fixed-only');r.confirmed()
    assert r.configure()==0xc00000a3 and not r.ln_io
    r.record('FixedContractCannotMasqueradeAsPps')
    for mv,ma in ((8400001,3000000),(8400000,3000001),(9000000,3000000)):
        r=Binding(base,'contract mismatch');r.pps();r.set_permit(mv=mv,ma=ma)
        n=len(r.ln_io);assert r.configure()==0xc00000a3 and len(r.ln_io)==n
        r.record('PermitMustEqualConfirmedRdo',Microvolts=mv,Microamps=ma)
    r=Binding(base,'APDO limit is not contract');r.pps(ma=1500)
    r.set_permit(ma=3000000,main=500000);r.set_request(current=1000000)
    assert r.configure()==0xc00000a3
    r.set_permit(ma=1500000,main=500000);assert r.configure()==0
    assert r.lregs[0x1b]&127==20
    r.record('Rdo1_5A_Main0_5A_Pump1A_Within3A_Apdo')
    for main in (1000001,2000000,3000000,3000001):
        r=Binding(base,'main budget');r.pps();r.set_permit(main=main)
        assert r.configure()!=0 and not any(r.fast())
        r.record('MainInputBudgetCannotBeIgnored',MainBudget=main)
    for mismatch in ('pd_voltage','permission','adc_age','generation','fault','soc','temperature'):
        r=Binding(base,mismatch);r.active_pump();r.set_permit(now=22)
        changes=dict(now=22,serial=3,mode=4)
        if mismatch=='pd_voltage':changes['mv']=8399999
        if mismatch=='permission':r.set_permit(now=22,flags=11)
        if mismatch=='adc_age':changes['sample']=0;changes['now']=122;r.set_permit(now=122)
        if mismatch=='generation':changes['gen']=76
        if mismatch=='fault':changes['fault']=True
        if mismatch=='soc':changes['soc']=90
        if mismatch=='temperature':changes['temp']=401
        r.set_proof(**changes)
        assert r.lpoll(now=changes['now']) not in (0,0x103);r.off_assert()
        r.record('RevokedRunningProofStopsPhysicalPump',Mismatch=mismatch)
    r=Binding(base,'deadline');r.active_pump()
    assert r.lpoll(now=1011)==0xc00000a3;r.off_assert()
    r.record('GuardSensorDeadlineStopsPumpBeforeLaterPoll')
    r=Binding(base,'lost PD owner');r.active_pump()
    r.u.mem_write(r.s+16,struct.pack('<I',0))
    assert r.lpoll(now=22)==0xc00000a3;r.off_assert()
    r.record('NativeOwnerReactivationStopsPump')
    r=Binding(base,'stale output');r.active_pump()
    before=bytes(r.u.mem_read(r.path,32));n=len(r.ln_io)
    r.u.mem_write(r.out,struct.pack('<4I',10,76,1,0x4303483c))
    assert r.action(22)==0xc0000120 and r.fast()==(0,1,1) and len(r.ln_io)==n
    r.record('ForeignOutputCannotStopCurrentAttachment')
    r=Binding(base,'current RDO changes');r.active_pump()
    assert r.begin(now=22,pos=4,mv=8420,ma=3000)[0]==0
    # Even if the emitter omits DISABLE_FAST, a changed SEND must stop first.
    raw=bytearray(r.u.mem_read(r.out,16));struct.pack_into('<I',raw,0,1);r.u.mem_write(r.out,bytes(raw))
    writes=len(r.io);assert r.action(22)==0;r.off_assert()
    assert len(r.io)==writes and r.send()==0
    r.record('ChangedRequestStopsPumpBeforePmicTx')
    r=Binding(base,'fault result action');r.active_pump()
    assert r.call('Fault',r.s,77,22,r.out)==0
    assert r.output()[0][0]==10 and r.action(22)==0;r.off_assert()
    r.record('ErrorPathActionPhysicallyDisablesPump')
    r=Binding(base,'failed physical stop');r.active_pump();r.stuck_off=True
    assert r.call('Fault',r.s,77,22,r.out)==0
    assert r.action(22)==0xc00000a3 and r.fast()[2]==1
    assert struct.unpack('<I',bytes(r.u.mem_read(r.config+16,4)))[0]==1
    r.record('FailedStopRetainsObligationAndBlocksTxFallback')
    r.stuck_off=False;assert r.call('SkPpsPathStop',r.path,77)==0;r.off_assert()
    r.record('ExplicitPhysicalRecoveryClearsObligation')
    r=Binding(base,'same RDO refresh');r.active_pump()
    for now in range(1000,7001,1000):assert r.observe(now,vbus=8400)[0]==0
    r.set_permit(now=7000);r.set_proof(now=7000,serial=10,mode=4)
    assert r.lpoll(now=7000)==0
    assert r.poll(7007)[0]==0 and r.output()[0][0]==1
    n=len(r.ln_io);assert r.action(7007)==0 and r.fast()==(0,1,1) and len(r.ln_io)==n
    assert r.send()==0 and r.goodcrc(7008)==0
    assert r.phy_receive(packet(3,5),7009)==0 and r.phy_receive(packet(6,6),7010)==0
    assert r.observe(7011,vbus=8400)[0]==0 and r.action(7011)==0
    r.set_permit(now=7017);r.set_proof(now=7017,serial=11,mode=4)
    assert r.lpoll(now=7017)==0 and r.fast()==(0,1,1) and r.binding()[2]==2
    assert not any(e['Kind']=='Write' and e['Register']==0x1e and e['Value']&8 for e in r.ln_io[n:])
    r.record('MatchingPpsRefreshPreservesRunningConverter')
    r=Binding(base,'IO boundary baseline');r.pps();start=len(r.ln_io);assert r.configure()==0
    boundaries=len(r.ln_io)-start
    for kind in ('fail_index','short_index','information_index'):
        for boundary in range(1,boundaries+1):
            r=Binding(base,f'{kind}{boundary}');r.pps();start=len(r.ln_io)
            setattr(r,kind,start+boundary)
            assert r.configure() not in (0,0x103) and not any(r.fast())
            assert r.binding()[1]==0
            r.record('ConfigBusFailureCannotBindRdo',Kind=kind,Boundary=boundary)

image=root/'build/sk_pps_charge_binding.component.dll'
report=dict(Passed=True,Scenarios=len(rows),ARM64Calls=sum(r['ARM64Calls'] for r in rows),
 ImageSHA256=hashlib.sha256(image.read_bytes()).hexdigest(),HardwareIO=False,
 PhysicalAdapterBound=False,NativePolicyReplacementIntegrated=False,
 FastChargingFixProven=False,HubContinuityFixProven=False,
 SourcePins=[dict(File=str(p.relative_to(root)),SHA256=hashlib.sha256(p.read_bytes()).hexdigest())
             for p in sorted((root/'src').glob('*'))],Cases=rows)
(root/'binding-qa.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('SourcePins','Cases')},indent=2))
