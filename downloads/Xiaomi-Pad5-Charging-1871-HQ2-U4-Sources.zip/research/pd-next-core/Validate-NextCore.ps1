$ErrorActionPreference='Stop'
$skBuild=Join-Path $PSScriptRoot 'build'
$skPrior=Join-Path $PSScriptRoot 'history\before-pending-deadline'
if(!(Test-Path -LiteralPath $skPrior)){
 New-Item -ItemType Directory -Path $skPrior -Force | Out-Null
 foreach($skFile in @('sk_pps_charge_binding.component.dll','sk_pps_charge_binding.kernel-objects.lib')){
  $skPath=Join-Path $skBuild $skFile
  if(Test-Path -LiteralPath $skPath){Copy-Item -LiteralPath $skPath -Destination (Join-Path $skPrior $skFile)}
 }
 Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*qa.json' | Copy-Item -Destination $skPrior
}
& (Join-Path $PSScriptRoot 'Build.ps1') | Out-File -LiteralPath (Join-Path $PSScriptRoot 'build-console.txt') -Encoding utf8
& (Join-Path $PSScriptRoot 'Build-SecurityLibrary.ps1') | Out-File -LiteralPath (Join-Path $PSScriptRoot 'library-console.txt') -Encoding utf8
$skPairs=@(
 @('TestPpsTransport.py','pps-transport-qa.json'),
 @('TestPpsExchange.py','pps-exchange-qa.json'),
 @('TestFixedPpsTransport.py','fixed-pps-transport-qa.json'),
 @('TestStartupDeadline.py','startup-deadline-qa.json'),
 @('TestGateResults.py','gate-results-qa.json'),
 @('TestCommandAdmission.py','command-admission-qa.json'),
 @('TestBinding.py','binding-qa.json'),
 @('TestAdc.py','adc-completion-qa.json'),
 @('TestFrsTransport.py','frs-transport-qa.json'),
 @('TestFrsDeadline.py','deadline-fixed-qa.json')
)
$skHash=(Get-FileHash -LiteralPath (Join-Path $skBuild 'sk_pps_charge_binding.component.dll')).Hash
$skResults=@()
foreach($skPair in $skPairs){
 & python (Join-Path $PSScriptRoot $skPair[0]) *> (Join-Path $PSScriptRoot ($skPair[0]+'.console.txt'))
 if($LASTEXITCODE -ne 0){throw ('Regression failed: '+$skPair[0])}
 $skResult=Get-Content -LiteralPath (Join-Path $PSScriptRoot $skPair[1]) -Raw | ConvertFrom-Json
 if(!$skResult.Passed -or $skResult.ImageSHA256 -ine $skHash){throw ('Stale/failed report: '+$skPair[1])}
 $skResults+=[ordered]@{Test=$skPair[0];Report=$skPair[1];Passed=$true;Scenarios=$skResult.Scenarios;ARM64Calls=$skResult.ARM64Calls;ImageSHA256=$skResult.ImageSHA256}
}
$skReport=[ordered]@{At=(Get-Date -Format o);Passed=$true;Tests=$skResults;
 ComponentSHA256=$skHash;KernelLibrarySHA256=(Get-FileHash -LiteralPath (Join-Path $skBuild 'sk_pps_charge_binding.kernel-objects.lib')).Hash;
 Installable=$false;HardwareIO=$false;InstalledDriverChanged=$false;
 PhysicalPPSConfirmed=$false;HubContinuityFixed=$false;
 Scope='Freestanding ARM64 component regression; kernel/transport/sensor boundaries are modeled. Kernel library is analyzed GS/CFG object code, not an activated Windows driver.'}
$skReport | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'validation-final.json') -Encoding utf8
$skReport | ConvertTo-Json -Depth 6
