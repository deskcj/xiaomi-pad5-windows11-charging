"""A PD sensor deadline can expire inside otherwise fresh LN8000 bus work.

Run compiled ARM64. Bus delay and electrical ADC/IRQ events are simulated.
No hardware is accessed. --expect-before documents the original defect.
"""
from pathlib import Path
import hashlib
import json
import struct
import sys
import os

root = Path(__file__).resolve().parent
scope = {'__file__': str(root / 'TestAdc.py')}
exec(compile((root / 'TestAdc.py').read_text().split('\nfor base in (')[0],
             scope['__file__'], 'exec'), scope)
Adc = scope['Adc']
before = '--expect-before' in sys.argv
rows = []


def drain(r, expected=10):
    out = r.rawbank
    assert r.call('SkPpsPathSize') == 48
    assert r.call('SkPpsPathTakeAction', r.path, 76, out) == 0xc0000120
    assert bytes(r.u.mem_read(out, 16)) == bytes(16)
    assert r.call('SkPpsPathTakeAction', r.path, 77, out) == 0
    flags, generation, request, rdo = struct.unpack('<4I', bytes(r.u.mem_read(out, 16)))
    assert flags == expected and generation == 77 and request == 1
    assert rdo == 0x4303483c
    assert r.call('SkPpsPathTakeAction', r.path, 77, out) == 0
    assert bytes(r.u.mem_read(out, 16)) == bytes(16)

for base in (0x140000000, 0x180000000):
    r = Adc(base, 'PD observation expires during converter start')
    r.now = 1005
    r.fresh()
    r.set_permit(now=r.now)
    # Wire PPS measurement was confirmed at10; now1009 it is still valid.
    last_pd_sample = struct.unpack('<I', bytes(r.u.mem_read(r.s + 148, 4)))[0]
    assert last_pd_sample == 10 and r.now == 1009
    r.delay_index = len(r.ln_io) + 4
    r.delay_ms = 4
    s = r.sampled_start()
    if before:
        assert s == 0x103 and r.fast() == (1, 0, 1)
    else:
        assert s == 0xc00000a3 and r.fast() == (0, 0, 0)
        assert r.lregs[3] == 2 and r.state() == (6, 0)
        drain(r)
    rows.append(dict(Base=hex(base), Result=hex(s), NowMs=r.now,
                     PdSampleMs=last_pd_sample, AdcEarliestMs=1007,
                     MainSafetyObservedMs=1009, Fast=r.fast(),
                     GuardState=r.state(), ARM64Calls=r.calls))

    if before:
        continue
    pilot = Adc(base, 'start boundaries')
    pilot.now = 1005
    pilot.fresh()
    pilot.set_permit(now=pilot.now)
    first = len(pilot.ln_io)
    assert pilot.sampled_start() == 0x103
    transfers = len(pilot.ln_io) - first
    for boundary in range(1, transfers + 1):
        r = Adc(base, 'expire sensor at every start boundary')
        r.now = 1005
        r.fresh()
        r.set_permit(now=r.now)
        r.delay_index = len(r.ln_io) + boundary
        r.delay_ms = 4
        assert r.sampled_start() == 0xc00000a3
        assert r.fast() == (0, 0, 0) and r.lregs[3] == 2
        assert r.state() == (6, 0)
        drain(r)
        rows.append(dict(Base=hex(base), Case='EveryStartTransferDeadline',
                         Boundary=boundary, ARM64Calls=r.calls))

    for obligation_failure in (False, True):
        r = Adc(base, 'deadline during running converter status')
        r.fresh()
        assert r.sampled_start() == 0x103
        r.now += 10
        r.fresh()
        r.set_permit(now=r.now)
        assert r.sampled_poll() == 0
        r.now = 1005
        r.fresh()
        r.set_permit(now=r.now)
        r.stuck_off = obligation_failure
        r.delay_index = len(r.ln_io) + 4
        r.delay_ms = 4
        assert r.sampled_poll() == 0xc00000a3
        assert r.state() == (6, 0)
        if obligation_failure:
            assert r.fast() == (0, 0, 1)
            assert int.from_bytes(r.u.mem_read(r.lctx + 36, 4), 'little') == 1
        else:
            assert r.fast() == (0, 0, 0) and r.lregs[3] == 2
        drain(r)
        if obligation_failure:
            r.stuck_off = False
            assert r.call('SkPpsPathStop', r.path, 77) == 0
            assert r.fast() == (0, 0, 0)
        rows.append(dict(Base=hex(base), Case='RunningConverterDeadlineAndRecovery',
                         ShutdownInitiallyFailed=obligation_failure, ARM64Calls=r.calls))

    r = Adc(base, 'PPS liveness crosses during bus work')
    r.now = 9000
    # Refresh only a real-model voltage observation; the wire ACK remains9.
    for observed_at in range(900, 9000, 900):
        assert r.observe(observed_at, vbus=8400)[0] == 0
    assert r.observe(9000, vbus=8400)[0] == 0
    r.fresh()
    r.set_permit(now=r.now)
    r.delay_index = len(r.ln_io) + 4
    r.delay_ms = 6
    assert r.sampled_start() == 0xc00000a3 and r.state() == (6, 0)
    assert r.fast() == (0, 0, 0)
    drain(r)
    rows.append(dict(Base=hex(base), Case='WireAckLivenessNotRenewedByAdc', ARM64Calls=r.calls))

report = dict(Passed=True, Counterexample=before, Scenarios=len(rows),
              ARM64Calls=sum(x['ARM64Calls'] for x in rows),
              ImageSHA256=hashlib.sha256(Path(os.environ.get('SK_PPS_REPLAY_IMAGE',str(root / 'build/sk_pps_charge_binding.component.dll'))).read_bytes()).hexdigest(),
              HardwareIO=False, FastChargingFixProven=False,
              HubContinuityFixProven=False, Cases=rows)
name = 'command-admission-before.json' if before else 'command-admission-qa.json'
(root / name).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
