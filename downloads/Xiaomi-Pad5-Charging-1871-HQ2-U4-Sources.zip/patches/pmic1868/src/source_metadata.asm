        AREA |.text|, CODE, READONLY, ALIGN=2
        EXPORT SourceMetadataChanged
        EXPORT SourceMetadataChangedEnd
; Called at the existing 7654 predicate. Equal NZCV.Z means process event.
; X19 owns the battery context, X20 the validated notification; W3 current.
; Existing 7650 handles changed current. Never accept unknown current -1.
; No stack, nonvolatile registers, calls, writes or new PMIC operation.
SourceMetadataChanged PROC
        cmp w3, #900
        b.eq complete
        cmn w3, #1
        b.eq unchanged
        ldr w16, [x19, #0x8a8]
        ldr w17, [x20, #0x28]
        cmp w16, w17
        b.ne changed
        ldr w16, [x19, #0x8ac]
        ldr w17, [x20, #0x2c]
        cmp w16, w17
        b.ne changed
unchanged
        cmp w3, #900
        ret
changed
        cmp w3, w3
complete
        ret
        ENDP
SourceMetadataChangedEnd
        END
