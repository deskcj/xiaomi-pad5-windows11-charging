$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$assembler='H:\Vlad\EWDK\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207\bin\Hostarm64\arm64\armasm64.exe'
& $assembler -nologo -o (Join-Path $root 'build\source_metadata.obj') (Join-Path $root 'src\source_metadata.asm') *> (Join-Path $root 'build\compile.log')
if($LASTEXITCODE){Get-Content -LiteralPath (Join-Path $root 'build\compile.log');throw 'Assembly failed'}
& 'C:\Users\Xiaomi\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' (Join-Path $PSScriptRoot 'Build.py')
if($LASTEXITCODE){throw 'Build failed'}
