"""One pinned predicate patch. All original loader/ABI/unwind data are retained."""
from pathlib import Path
import sys,struct,hashlib,json
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,r'H:\Vlad\Charging\Build1867\offline-deps')
import pefile
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_ARM
sha=lambda x:hashlib.sha256(x).hexdigest()
align=lambda x,a:(x+a-1)//a*a
original=(R/'reference/qcbattmngr8150.sys').read_bytes()
assert sha(original)=='a0cd3d2d5c680039b7b53202cd0f25e94d635944e3d8b5d78669a6575dc2a72c'
p=pefile.PE(data=original); assert p.FILE_HEADER.Machine==0xaa64
obj=(R/'build/source_metadata.obj').read_bytes()
machine,count,_,symoff,symcount,opt,_=struct.unpack_from('<HHIIIHH',obj)
assert machine==0xaa64 and opt==0
strings=obj[symoff+18*symcount:]
def name(x):
 return strings[struct.unpack_from('<I',x,4)[0]:].split(b'\0',1)[0].decode() if x[:4]==b'\0'*4 else x.rstrip(b'\0').decode()
sections=[]
for i in range(count):
 nm,_,_,sz,off,_,_,nr,_,flags=struct.unpack_from('<8sIIIIIIHHI',obj,20+40*i)
 assert nr==0
 sections.append((name(nm),obj[off:off+sz],flags))
assert all(not data or nm in ('.text','.debug$S') for nm,data,flags in sections)
idx=next(i+1 for i,s in enumerate(sections) if s[0]=='.text')
code=sections[idx-1][1];syms={};i=0
while i<symcount:
 nm,val,sec,typ,storage,aux=struct.unpack_from('<8sIhHBB',obj,symoff+18*i)
 if sec==idx:syms[name(nm)]=val
 i+=1+aux
assert syms['SourceMetadataChanged']==0 and syms['SourceMetadataChangedEnd']==len(code)
md=Cs(CS_ARCH_ARM64,CS_MODE_ARM); md.detail=True
rva=align(p.OPTIONAL_HEADER.SizeOfImage,p.OPTIONAL_HEADER.SectionAlignment)
ins=list(md.disasm(code,rva));assert len(ins)*4==len(code)
proof=[]
for op in ins:
 assert op.mnemonic in ('cmp','cmn','ldr','b.eq','b.ne','ret')
 if op.mnemonic.startswith('b.'):assert rva<=op.operands[-1].imm<rva+len(code)
 _,written=op.regs_access(); names={md.reg_name(x) for x in written}
 # Capstone marks the first CMP/CMN source as written for these aliases.
 # They encode SUBS/ADDS WZR,source,operand and only update NZCV.
 if op.mnemonic in ('cmp','cmn'):
  word=struct.unpack('<I',op.bytes)[0];assert word&31==31
  names.discard(op.op_str.split(',')[0])
 assert names <= {'nzcv','w16','w17','x16','x17'},(op.mnemonic,op.op_str,names)
 assert 'sp' not in op.op_str
 proof.append(dict(RVA=op.address,Instruction=op.mnemonic+' '+op.op_str,Written=sorted(names)))
site=0x7654; old=p.get_data(site,4)
assert old==bytes.fromhex('63100e71') or (list(md.disasm(old,site))[0].mnemonic=='cmp' and list(md.disasm(old,site))[0].op_str=='w3, #0x384')
assert list(md.disasm(p.get_data(0x7658,4),0x7658))[0].op_str=='#0x7970'
delta=rva-site;assert delta%4==0 and -(1<<27)<=delta<(1<<27)
patch=struct.pack('<I',0x94000000|((delta//4)&0x3ffffff))
rawend=max(s.PointerToRawData+s.SizeOfRawData for s in p.sections)
out=bytearray(original[:rawend]);out[p.get_offset_from_rva(site):p.get_offset_from_rva(site)+4]=patch
header=p.sections[0].get_file_offset()+len(p.sections)*40
assert header+40<=p.OPTIONAL_HEADER.SizeOfHeaders and out[header:header+40]==b'\0'*40
ptr=align(len(out),p.OPTIONAL_HEADER.FileAlignment);rawsize=align(len(code),p.OPTIONAL_HEADER.FileAlignment)
out.extend(b'\0'*(ptr-len(out))+code+b'\0'*(rawsize-len(code)))
out[header:header+40]=struct.pack('<8sIIIIIIHHI',b'.skpwr\0\0',len(code),rva,rawsize,ptr,0,0,0,0,0x60000020)
struct.pack_into('<H',out,p.FILE_HEADER.get_field_absolute_offset('NumberOfSections'),len(p.sections)+1)
def opt(field,val):struct.pack_into('<I',out,p.OPTIONAL_HEADER.get_field_absolute_offset(field),val)
opt('SizeOfImage',align(rva+len(code),p.OPTIONAL_HEADER.SectionAlignment));opt('SizeOfCode',p.OPTIONAL_HEADER.SizeOfCode+rawsize)
struct.pack_into('<II',out,p.OPTIONAL_HEADER.DATA_DIRECTORY[4].get_file_offset(),0,0)
opt('CheckSum',0);opt('CheckSum',pefile.PE(data=bytes(out)).generate_checksum())
b=pefile.PE(data=bytes(out));assert b.verify_checksum()
changed=[]
for s in p.sections:
 before=s.get_data();after=b.get_data(s.VirtualAddress,len(before))
 changed += [s.VirtualAddress+j for j in range(0,len(before),4) if before[j:j+4]!=after[j:j+4]]
assert changed==[site],changed
for n in range(16):
 if n==4:continue
 before=p.OPTIONAL_HEADER.DATA_DIRECTORY[n];after=b.OPTIONAL_HEADER.DATA_DIRECTORY[n]
 assert (before.VirtualAddress,before.Size)==(after.VirtualAddress,after.Size)
 assert p.get_data(before.VirtualAddress,before.Size)==b.get_data(after.VirtualAddress,after.Size)
assert b.OPTIONAL_HEADER.AddressOfEntryPoint==p.OPTIONAL_HEADER.AddressOfEntryPoint
assert all(not(s.Characteristics&0x20000000 and s.Characteristics&0x80000000) for s in b.sections)
report=dict(Build=1868,PackageVersion='1.0.10732.0',InputSHA256=sha(original),UnsignedSHA256=sha(out),ObjectSHA256=sha(obj),HookRVA=site,OldHex=old.hex(),NewHex=patch.hex(),LeafLow=rva,LeafHigh=rva+len(code),Instructions=proof,OriginalDirectoriesRetained=True,OnlyOneOriginalInstructionChanged=True,NewImports=False,NewKernelState=False,Installed=False,HubContinuityFixed=False,PPSImplemented=False)
(R/'build/qcbattmngr8150.sys').write_bytes(out)
(R/'build/build.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='Instructions'},indent=2))
