"""Run actual before/after ARM64 callback with mocked OS/WPP boundaries."""
from pathlib import Path
import sys,struct,json,hashlib,itertools,random
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,r'H:\Vlad\Charging\Build1867\offline-deps')
import pefile
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE,UC_HOOK_MEM_WRITE
from unicorn.arm64_const import *
DATA,STACK,STOP=0x50000000,0x207000,0x60000000
CTX,NOTICE,CONTROL=DATA,DATA+0x4000,DATA+0xc000
manifest=json.loads((R/'build/build.json').read_text())
fixtures={}
class Callback:
 def __init__(self,path,base,tracing,curr=1500,volts=9000,power=18000,guid=bytes(16),enabled=1):
  binary=path.read_bytes();p=pefile.PE(data=binary);p.relocate_image(base)
  self.u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);self.base=base;self.path=[];self.wakes=[];self.logs=[];self.writes=[]
  for at,sz in [(base,p.OPTIONAL_HEADER.SizeOfImage),(DATA,0x10000),(STACK,0x2000),(STOP,0x1000)]:self.u.mem_map(at,sz)
  self.u.mem_write(base,p.get_memory_mapped_image())
  self.qword(base+0x28168,CONTROL);self.dword(CONTROL+0x2c,0x10 if tracing else 0);self.u.mem_write(CONTROL+0x29,b'\x05')
  self.dword(base+0x29b44,8 if tracing else 0)
  self.dword(CTX+0x9c8,enabled);self.dword(CTX+0x88c,curr);self.dword(CTX+0x8a8,volts);self.dword(CTX+0x8ac,power);self.u.mem_write(CTX+0x890,guid)
  self.u.hook_add(UC_HOOK_CODE,self.hook);self.u.hook_add(UC_HOOK_MEM_WRITE,self.write)
  self.fixed=path.parent.name!='reference'
 def dword(self,at,val):self.u.mem_write(at,struct.pack('<I',val&0xffffffff))
 def qword(self,at,val):self.u.mem_write(at,struct.pack('<Q',val))
 def read32(self,at):return struct.unpack('<I',self.u.mem_read(at,4))[0]
 def ret(self,result=0):
  lr=self.u.reg_read(UC_ARM64_REG_LR)
  for reg in [UC_ARM64_REG_X0+i for i in range(18)]:self.u.reg_write(reg,0xcccccccccccccccc)
  self.u.reg_write(UC_ARM64_REG_X0,result&0xffffffffffffffff);self.u.reg_write(UC_ARM64_REG_PC,lr)
 def write(self,u,access,at,sz,val,_):self.writes.append((at,sz,val))
 def hook(self,u,at,sz,_):
  rva=at-self.base
  if at==STOP:u.emu_stop();return
  if rva==0xa1c8:
   self.wakes.append(u.reg_read(UC_ARM64_REG_W0));self.ret();return
  if rva==0x240b8:
   a,b,n=[u.reg_read(UC_ARM64_REG_X0+i) for i in range(3)];assert n==16
   self.ret(0 if u.mem_read(a,n)==u.mem_read(b,n) else 1);return
  if rva in [0x18e0,0x1940,0x6870,0x67b0,0x1780]:
   self.logs.append(rva);self.ret();return
  assert 0x7300<=rva<0x79b0 or manifest['LeafLow']<=rva<manifest['LeafHigh'],hex(rva)
  self.path.append(rva)
  if self.fixed and self.base==0x140000000:
   sp=u.reg_read(UC_ARM64_REG_SP);regs=[u.reg_read(UC_ARM64_REG_X0+i) for i in range(29)]+[u.reg_read(UC_ARM64_REG_FP),u.reg_read(UC_ARM64_REG_LR)]
   key=(rva,sp,tuple(regs[18:]));fixtures.setdefault(key,(rva,sp-STACK,regs,bytes(u.mem_read(STACK,0x2000))))
 def notify(self,current,volts,power,guid=bytes(16),kind=5):
  u=self.u;self.dword(NOTICE+4,kind);self.dword(NOTICE+0xc,current);self.dword(NOTICE+0x28,volts);self.dword(NOTICE+0x2c,power);u.mem_write(NOTICE+0x10,guid)
  self.wakes=[];self.logs=[];self.writes=[];self.path=[]
  expected={UC_ARM64_REG_X19+i:0xabc0000000000000+i for i in range(10)};expected[UC_ARM64_REG_FP]=0xabc1234567890000;expected[UC_ARM64_REG_X18]=0xabcdef9876543210
  for reg,val in expected.items():u.reg_write(reg,val)
  u.reg_write(UC_ARM64_REG_SP,STACK+0x1000);u.reg_write(UC_ARM64_REG_LR,STOP);u.reg_write(UC_ARM64_REG_X0,CTX);u.reg_write(UC_ARM64_REG_X1,NOTICE)
  u.emu_start(self.base+0x7300,STOP+4,count=5000)
  assert u.reg_read(UC_ARM64_REG_PC)==STOP and u.reg_read(UC_ARM64_REG_SP)==STACK+0x1000
  assert all(u.reg_read(reg)==val for reg,val in expected.items())
  assert all(STACK<=at<STACK+0x2000 or CTX<=at<CTX+0x1000 for at,_,_ in self.writes),'Unexpected write'
  return dict(Status=u.reg_read(UC_ARM64_REG_W0),Current=self.read32(CTX+0x88c),Voltage=self.read32(CTX+0x8a8),Power=self.read32(CTX+0x8ac),Wakes=list(self.wakes),GUID=bytes(u.mem_read(CTX+0x890,16)).hex())
before=R/'reference/qcbattmngr8150.sys';after=R/'build/qcbattmngr8150.sys'
rows=[];passed=0;defect_reproductions=0
cases=[]
for current,volts,power in itertools.product([0,500,900,1500,3000,0xffffffff],[5000,9000,12000],[0,15000,18000]):cases.append((current,volts,power))
rng=random.Random(1868)
cases += [(rng.choice([0,500,900,1500,3000]),rng.choice([5000,9000,12000]),rng.randrange(0,36001)) for _ in range(40)]
for base,tracing,(current,volts,power) in itertools.product([0x140000000,0x7ffb12340000],[False,True],cases):
 ref=Callback(before,base,tracing);fixed=Callback(after,base,tracing)
 old=ref.notify(current,volts,power);new=fixed.notify(current,volts,power)
 change=current!=0xffffffff and (current!=1500 or current==900 or volts!=9000 or power!=18000)
 assert new['Status']==0
 assert new['Current']==(current if change else 1500)
 assert new['Voltage']==(volts if change else 9000) and new['Power']==(power if change else 18000)
 assert new['Wakes']==([8] if change else [])
 if old!=new:
  assert current==1500 and (volts!=9000 or power!=18000)
  defect_reproductions+=1
 else:assert current!=1500 or volts==9000 and power==18000
 passed+=2
 # A duplicate accepted notification must be idempotent, except retained 900mA behavior.
 old2=ref.notify(current,volts,power);new2=fixed.notify(current,volts,power)
 assert new2['Wakes']==([8] if current==900 else [])
 passed+=2
 if base==0x140000000 and not tracing and current==1500:rows.append(dict(Input=[current,volts,power],Reference=old,Candidate=new))
for base,tracing,enabled,guid,kind in itertools.product([0x140000000,0x7ffb12340000],[False,True],[0,1],[bytes(16),bytes(range(1,17))],[1,2,3,4,5,0,6]):
 old=Callback(before,base,tracing,enabled=enabled).notify(1500,9000,18000,guid,kind)
 new=Callback(after,base,tracing,enabled=enabled).notify(1500,9000,18000,guid,kind)
 assert old==new,(base,tracing,enabled,guid,kind,old,new)
 passed+=2
with (R/'build/metadata-unwind.bin').open('wb') as f:
 f.write(struct.pack('<II',0x3257444e,len(fixtures)))
 for rva,sp,regs,memory in fixtures.values():
  f.write(struct.pack('<II31Q',rva,sp,*regs)+memory+struct.pack('<12Q',*[0xabc0000000000000+i for i in range(10)],0xabc1234567890000,0xabcdef9876543210))
report=dict(PassedARM64Callbacks=passed,ReferenceDefectReproductions=defect_reproductions,NativeFixtures=len(fixtures),SHA256=hashlib.sha256(after.read_bytes()).hexdigest(),ExternalBoundariesMocked=['Event wake','WPP','GUID comparison'],HardwareAccess=False,KernelLoaded=False,NativeUnwindPassed=False,Failures=0,Examples=rows)
assert defect_reproductions>0
(R/'build/emulation.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='Examples'},indent=2))
