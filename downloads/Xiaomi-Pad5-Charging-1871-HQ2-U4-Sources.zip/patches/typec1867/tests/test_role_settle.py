"""Execute actual1859 role/read/worker code with recorded-style PMIC inputs.
Only NT/WDF and the external port-info result are modeled. No device is opened.
"""
import itertools,json,struct,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(next(p for p in Path(__file__).resolve().parents if (p/'offline-deps').is_dir())/'offline-deps'))
from test_backend_pe import Machine,SYMS,CTX,TABLE,STUB,fixtures
from test_error_alerts import AlertMachine
from unicorn.arm64_const import *
KUSER=0xfffff78000000000

class RoleMachine(AlertMachine):
 def __init__(self,base=0x140000000,wpp=False):
  self.port=3;self.raw_port_type=3;self.info_status=0;self.role_status=0;self.mode_calls=[];self.thread=0x11223344
  super().__init__(base,wpp)
  self.u.mem_map(KUSER,4096);self.tick(100000000)
  self.call(SYMS['RepairThreadIdentity'],args=[])
  self.capture=True
 def tick(self,t):self.qword(KUSER+8,t)
 def hook(self,u,a,n,unused):
  r=a-self.base
  if r==0x1ce0:self.ret();return # Formatting-only WPP helper in source CC path.
  if r==0x6088:return # Execute actual class ROLE_CONTROL translation.
  if r==0xab48:
   self.mode_calls.append(u.reg_read(UC_ARM64_REG_W1));self.ret(self.role_status);return
  if r==0xb4a8:self.ret();return # External Rp-current configuration boundary.
  if r==0xa160:
   args=[u.reg_read(UC_ARM64_REG_X0+i) for i in range(8)]
   if self.info_status==0:
    # A160 returns orientation,sink-partner,source-partner; its first
    # field is not the separate802A0FA4 port-type result.
    for ptr,value in zip(args[1:4],(self.port,3,4)):u.mem_write(ptr,struct.pack('<I',value))
    for ptr in args[4:]:u.mem_write(ptr,b'\0')
   self.ret(self.info_status);return
  if self.stubs.get(a)=='ioctl' and u.reg_read(UC_ARM64_REG_W3)==0x802a0fa4:
   desc=u.reg_read(UC_ARM64_REG_X5);ptr=struct.unpack('<Q',u.mem_read(desc+8,8))[0]
   u.mem_write(ptr,struct.pack('<II',0,self.raw_port_type))
   self.qword(u.reg_read(UC_ARM64_REG_X7),8);self.ret();return
  if self.stubs.get(a)=='KeGetCurrentThread':self.ret(self.thread);return
  super().hook(u,a,n,unused)
 def role(self,role=0x15,cc=6):
  self.u.mem_write(CTX+0x2a,bytes([role]));self.u.mem_write(CTX+0x2d,bytes([cc]))
  self.u.mem_write(CTX+0x210,struct.pack('<I',2))
  # Real cache pending-ack function is unnecessary for this command boundary.
  return self.call(SYMS['RepairExecutePending'],args=[CTX,2])
 def info(self):
  out=CTX+0x1800;self.u.mem_write(out,b'\xa5'*32)
  return self.call(SYMS['RepairReadPortInfo'],args=[CTX+0x1600,out,out+4,out+8,out+12,out+13,out+14,out+15])
 def pending_guard(self):return struct.unpack('<Q',self.u.mem_read(self.base+SYMS['RoleSettlingContext'],8))[0]
 def until(self):return struct.unpack('<Q',self.u.mem_read(self.base+SYMS['RoleSettleUntil'],8))[0]

def main():
 rows=[]
 for base,wpp in itertools.product([0x140000000,0x180000000,0x7ffb12340000],[False,True]):
  m=RoleMachine(base,wpp);assert m.role()==0 and m.mode_calls==[4]
  deadline=m.until();assert deadline==110000000
  for tick in (100000001,101000000,109999999):
   m.tick(tick);assert m.info()==0xc00000a3;assert m.until()==deadline
  m.tick(deadline);assert m.info()==0 and not m.pending_guard()
  rows.append({'case':'transient-deferred-real-detach-published-at-deadline','base':hex(base),'wpp':wpp,'deadlineFixed':True})
  for port in (1,2,0,4):
   m=RoleMachine(base,wpp);m.role();m.port=port
   assert m.info()==0 and not m.pending_guard()
   rows.append({'case':'non-none-orientation-not-suppressed','orientation':port,'base':hex(base),'wpp':wpp})
  for role,cc in [(0x5a,6),(0x0a,6),(0,6),(0x15,0),(0x15,0x26),(0x15,0x12),(0x15,1)]:
   m=RoleMachine(base,wpp);assert m.role(role,cc)==0
   assert not m.pending_guard() and m.info()==0
   rows.append({'case':'guard-needs-known-source-attachment-and-fixed-rp','role':role,'cc':cc,'base':hex(base),'wpp':wpp})
  m=RoleMachine(base,wpp);m.role_status=0xc0000185
  assert m.role()==0xc0000185 and not m.pending_guard()
  rows.append({'case':'failed-role-write-not-guarded','base':hex(base),'wpp':wpp})
  m=RoleMachine(base,wpp);m.role();m.info_status=0xc0000185
  assert m.info()==0xc0000185
  assert bytes(m.u.mem_read(CTX+0x1800,4))==b'\xa5'*4
  rows.append({'case':'read-error-preserved-no-invented-data','base':hex(base),'wpp':wpp})
  m=RoleMachine(base,wpp);m.role();m.role(0x5a,6)
  assert not m.pending_guard() and m.mode_calls==[4,0] and m.info()==0
  rows.append({'case':'explicit-drp-cancels-guard','base':hex(base),'wpp':wpp})
  m=RoleMachine(base,wpp);m.thread=0x99887766;m.role()
  assert not m.pending_guard()
  rows.append({'case':'non-worker-cannot-arm-guard','base':hex(base),'wpp':wpp})
  for voltage in (0,800000,800001,5000000):
   m=RoleMachine(base,wpp);m.role();m.voltage=voltage
   assert m.command(0x77)==0
   # Simulate dispatcher returning the read's retry status, then execute
   # the actual compiled process_power through RepairDispatch.
   m.repeat_error=True;m.pd_error=0xc00000a3
   assert m.dispatch()==0xc00000a3
   assert m.otg()==([1] if voltage<=800000 else [])
   assert not m.held
   rows.append({'case':'guard-does-not-bypass-adc-safe0','uv':voltage,'otg':m.otg(),'base':hex(base),'wpp':wpp})
  m=RoleMachine(base,wpp);m.role()
  assert m.call(0x107a8,args=[CTX])==0xc0000184 # Worker may not join itself.
  m.thread=0x99887766
  assert m.call(0x107a8,args=[CTX])==0
  m.timer()
  assert not m.pending_guard() and not m.held and m.otg()==[0]
  rows.append({'case':'stop-clears-guard-and-drains','base':hex(base),'wpp':wpp})
  # Real40B0 + real CC cache writer: retry leaves the previous measured
  # source CC intact; a fresh source sample is then published normally.
  m=RoleMachine(base,wpp);m.role();m.u.mem_write(CTX+0x2d,b'\x06');m.port=3
  assert m.call(0x40b0,args=[CTX])==0xc00000a3
  assert bytes(m.u.mem_read(CTX+0x2d,1))==b'\x06'
  m.port=1;m.raw_port_type=1;m.tick(102000000)
  assert m.call(0x40b0,args=[CTX])==0
  assert not m.pending_guard()
  assert bytes(m.u.mem_read(CTX+0x2d,1))==b'\x06'
  rows.append({'case':'actual40B0-defers-transient-without-writing-fake-cc','base':hex(base),'wpp':wpp})
  m=RoleMachine(base,wpp);m.role();m.port=3
  original_branch=0x94000000|(((0xa160-0x433c)//4)&0x3ffffff)
  m.u.mem_write(base+0x433c,struct.pack('<I',original_branch))
  assert m.call(0x40b0,args=[CTX])==0
  assert bytes(m.u.mem_read(CTX+0x2d,1))!=b'\x06'
  rows.append({'case':'negative-control-original-snapshot-call-publishes-detach','base':hex(base),'wpp':wpp})
 with (ROOT/'build/role-settle-unwind.bin').open('wb') as f:
  f.write(struct.pack('<II',0x3157444e,len(fixtures)))
  for pc,sp,regs,mem in fixtures.values():f.write(struct.pack('<II31Q',pc,sp,*regs)+mem)
 report={'cases':len(rows),'actualCandidatePE':True,'hardwareAccess':False,'hardwareCausalityProven':False,'failures':0,'results':rows}
 (ROOT/'build/role-settle-tests.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
 print(json.dumps({k:v for k,v in report.items() if k!='results'}))
if __name__=='__main__':main()
