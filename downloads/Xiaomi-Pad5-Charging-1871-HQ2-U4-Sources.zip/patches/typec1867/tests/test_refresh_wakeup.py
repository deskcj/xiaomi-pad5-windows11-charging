"""Run compiled timer + real stock dispatcher; external hardware is mocked.

Reproduce1861's empty-queue stall and verify bounded real status refresh,
pending-power completion, ADC safe0, cancellation, and inactive callbacks.
"""
import itertools,json,struct
from test_role_settle import RoleMachine,ROOT,SYMS,CTX
from test_backend_pe import Machine,fixtures
from unicorn.arm64_const import *

class Refresh(RoleMachine):
    def __init__(self,base,wpp):self.port_reads=0;super().__init__(base,wpp)
    def hook(self,u,a,n,unused):
        if a-self.base==0xa160:self.port_reads+=1
        super().hook(u,a,n,unused)
    def event(self,index):
        self.u.mem_write(CTX+0x260,struct.pack('<I',index));return self.dispatch()
    def fire(self):
        self.signals=[];before=(len(self.io),self.port_reads,len(self.events))
        self.timer_armed=False;self.timer()
        assert (len(self.io),self.port_reads,len(self.events))==before
        assert self.signals==[CTX+0x338] and not self.held
        return self.event(3)

rows=[]
def save(name,base,wpp,**kw):rows.append(dict(Case=name,Base=hex(base),WPP=wpp,**kw))
for base,wpp in itertools.product([0x140000000,0x180000000,0x7ffb12340000],[False,True]):
    m=Refresh(base,wpp);assert m.role()==0
    m.port=1;m.u.mem_write(CTX+0x210,b'\0'*4)
    before=m.port_reads;m.fire()
    assert m.port_reads==before+1 and not m.pending_guard() and not m.timer_armed
    save('empty-command-queue-still-refreshes-port',base,wpp,PortReads=1)

    m=Refresh(base,wpp);m.role();deadline=m.until();m.u.mem_write(CTX+0x210,b'\0'*4)
    for tick in (101000000,103000000,109000000):
        m.tick(tick);assert m.fire()==0xc00000a3
        assert m.until()==deadline and m.timer_armed
    m.port=1;m.tick(109999999);m.fire()
    assert not m.pending_guard() and not m.timer_armed and m.port_reads==4
    save('transient-retries-read-fresh-orientation-without-extending-deadline',base,wpp)

    m=Refresh(base,wpp);m.role();deadline=m.until();m.u.mem_write(CTX+0x210,b'\0'*4)
    m.tick(deadline);m.fire()
    assert not m.pending_guard() and m.timer_armed and m.port_reads==1
    #1867 publishes this real detach and separately arms a finite resync.
    assert struct.unpack('<I',m.u.mem_read(base+SYMS['ResyncRemaining'],4))[0]==8
    for n in range(1,9):
        m.tick(deadline+n*1000000);m.fire()
    assert not m.timer_armed and m.port_reads==9
    save('real-detach-after-deadline-does-not-poll-forever',base,wpp)

    for state in ['inactive','null-context']:
        m=Refresh(base,wpp)
        if state=='inactive':m.u.mem_write(base+0x1a81c,b'\0')
        else:m.context_valid=False
        m.signals=[];before=len(m.io);m.timer()
        assert not m.signals and not m.held and len(m.io)==before and m.port_reads==0
        save('timer-'+state+'-no-wake-or-io',base,wpp)

    for voltage in (0,800000,800001,5000000):
        m=Refresh(base,wpp);m.port=1;m.voltage=voltage
        assert m.command(0x77)==0
        m.fire()
        assert m.otg()==([1] if voltage<=800000 else [])
        attempts=struct.unpack('<I',m.u.mem_read(base+SYMS['Attempts'],4))[0]
        assert attempts==(0 if voltage<=800000 else 1)
        save('single-event-retries-power-with-safe0-preserved',base,wpp,Microvolts=voltage,Attempts=attempts)

    m=Refresh(base,wpp);m.port=1;m.adc_vendor=1;m.command(0x77)
    for n in range(10):
        m.fire()
        assert 1 not in m.otg()
    assert not m.u.mem_read(base+SYMS['Pending'],1)[0] and m.otg()==[0] and not m.timer_armed
    save('invalid-adc-ten-single-wake-attempts-then-off-no-new-poll',base,wpp)

    m=Refresh(base,wpp);m.port=1;m.voltage=5000000;m.command(0x77);m.fire()
    assert not m.otg();m.command(0x66);m.voltage=0;m.fire()
    assert m.otg()==[0] and not m.u.mem_read(base+SYMS['Pending'],1)[0]
    save('off-cancels-stale-source-retry',base,wpp)

with (ROOT/'build/refresh-unwind.bin').open('wb') as f:
    f.write(struct.pack('<II',0x3157444e,len(fixtures)))
    for pc,sp,regs,mem in fixtures.values():f.write(struct.pack('<II31Q',pc,sp,*regs)+mem)
report=dict(Cases=len(rows),Failures=0,ActualCompiled1862Executed=True,HardwareAccess=False,
    StatusRefreshFromRealDispatcher=True,PhysicalCausalityNotYetProven=True,Results=rows,
    NativeUnwindFixtures=len(fixtures))
(ROOT/'build/refresh-wakeup-tests.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='Results'}))
