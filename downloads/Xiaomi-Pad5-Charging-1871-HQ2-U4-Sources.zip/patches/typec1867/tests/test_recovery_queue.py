"""Real1865 ARM64 recovery entry/producer/ack/event dispatcher, offline.

Snapshot is a successful mocked provider boundary; kernel/WDF calls are mocks.
Optional four-byte mask experiment changes EMULATED memory only, no SYS output.
"""
import hashlib
import itertools
import json
import struct
import sys
from pathlib import Path
OUT = Path(__file__).resolve().parent
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'tests'))
from test_backend_pe import Machine, SYMS, CTX, STACK, fixtures
from test_original_backend import STOP
from unicorn.arm64_const import (UC_ARM64_REG_PC, UC_ARM64_REG_X0, UC_ARM64_REG_W0,
                               UC_ARM64_REG_SP, UC_ARM64_REG_FP, UC_ARM64_REG_LR)

class Recovery(Machine):
    def __init__(self, base, wpp, preserve=False):
        self.pause_at = None
        self.pause_after_unlock = False
        self.paused = False
        self.context_held = False
        self.snapshot_status = 0
        self.actual = set()
        self.ack_masks = []
        super().__init__(base, wpp)
        self.qword(base+0x1a790, base+0x3550)
        self.qword(CTX+0x278, CTX+0x9000)
        self.capture=True
        self.u.mem_write(CTX+0x133, b'\x01')
        self.u.mem_write(CTX+0x268, struct.pack('<I', 4))
        # Exact stock instruction: mov w1,#0xffffffff, immediately before BL.
        expected=bytes.fromhex('01028012' if ROOT.name in ('Build1866','Build1867') else '01008012')
        assert bytes(self.u.mem_read(base+0x12344,4)) == expected
        if ROOT.name not in ('Build1866','Build1867') and preserve:
            # mov w1,#0xffffffef; F988 still owns the context spinlock.
            self.u.mem_write(base+0x12344, bytes.fromhex('01028012'))

    def hook(self, u, a, n, unused):
        if self.pause_at == a:
            self.pause_at = None
            self.paused = True
            u.emu_stop()
            return
        r = a-self.base
        if self.capture and self.base==0x140000000 and 0x121c0<=r<0x12950:
            sp=u.reg_read(UC_ARM64_REG_SP)
            regs=[u.reg_read(UC_ARM64_REG_X0+i) for i in range(29)]
            regs += [u.reg_read(UC_ARM64_REG_FP),u.reg_read(UC_ARM64_REG_LR)]
            fixtures.setdefault((r,sp,tuple(regs[19:])),
                                (r,sp-0x207000,regs,bytes(u.mem_read(0x207000,8192))))
        name = self.stubs.get(a)
        if r in (0x121c0,0x12380,0xeb68,0xf988,0xf178,0x1b28,0x3550):
            self.actual.add(r)
            if r == 0xf988:
                self.ack_masks.append(u.reg_read(UC_ARM64_REG_X0+1)&0xffffffff)
            return  # Run real instructions; do not use original producer mock.
        if r == 0x19e8:
            assert not self.context_held
            self.ret(self.snapshot_status)
            return
        if name == 'lock':
            assert not self.context_held
            self.context_held = True
            self.ret()
            return
        if name == 'unlock':
            assert self.context_held
            self.context_held = False
            self.ret()
            if self.pause_after_unlock:
                self.pause_after_unlock = False
                self.paused = True
                u.emu_stop()
            return
        if name == 'KeGetCurrentIrql':
            self.ret(2 if self.context_held else 0)
            return
        if name in ('KeWaitForMultipleObjects','ioctl','KeSetEvent','timer_start'):
            assert not self.context_held
        super().hook(u,a,n,unused)

    def produce(self, command):
        buf=CTX+0x1800
        self.u.mem_write(buf,bytes([command]))
        return self.call(0xeb68,args=[CTX,0x23,1,buf])
    def entry(self): return self.call(0x121c0,args=[CTX])
    def event4(self):
        self.u.mem_write(CTX+0x260,struct.pack('<I',4))
        return self.call(0x12380,args=[CTX,0,0,0,0])
    def flags(self): return struct.unpack('<I',self.u.mem_read(CTX+0x210,4))[0]
    def byte(self): return self.u.mem_read(CTX+0x33,1)[0]
    def epoch(self): return struct.unpack('<I',self.u.mem_read(self.base+SYMS['Epoch'],4))[0]
    def suspended(self, action):
        self.paused=False
        try: action()
        except AssertionError:
            if not self.paused: raise
        assert self.paused
        return self.u.context_save(),bytes(self.u.mem_read(STACK,0x10000))
    def resume(self,state):
        context,stack=state
        self.u.mem_write(STACK,stack)
        self.u.context_restore(context)
        self.u.emu_start(self.u.reg_read(UC_ARM64_REG_PC),STOP,count=100000)
        assert self.u.reg_read(UC_ARM64_REG_PC)==STOP
        assert not self.context_held and not self.held
        return self.u.reg_read(UC_ARM64_REG_W0)

def main():
    rows=[]
    commands=(0x66,0x77,0x44,0x55,0x99)
    built=ROOT.name in ('Build1866','Build1867')
    for base,wpp,preserve,command,point in itertools.product(
        (0x140000000,0x180000000,0x7ffb12340000),(False,True),((True,) if built else (False,True)),
        commands,('before-timer','before-ack','byte-before-flag','queued-at-entry')):
        m=Recovery(base,wpp,preserve)
        if point=='queued-at-entry':
            assert m.produce(command)==0
            assert not m.entry()&0x80000000
        elif point=='byte-before-flag':
            m.pause_after_unlock=True
            producer=m.suspended(lambda:m.produce(command))
            assert m.byte()==command and not m.flags()
            assert not m.entry()&0x80000000
            assert m.resume(producer)==0
        else:
            m.pause_at=base+(0x108a0 if point=='before-timer' else 0x12344)
            entry=m.suspended(m.entry)
            assert not m.context_held and not m.held
            assert m.produce(command)==0
            assert m.flags()==0x10 and m.byte()==command
            status=m.resume(entry)
            assert not status&0x80000000, (hex(status),point,hex(base),wpp,preserve,command)
        before=m.flags()
        assert m.byte()==command
        assert m.event4()==0
        lost=point!='byte-before-flag' and not preserve
        assert (m.epoch()==0)==lost
        assert m.byte()==(command if lost else 0)
        if not lost:
            assert m.epoch()==1 and not m.flags()
            if command!=0x99:
                assert m.u.mem_read(base+SYMS['Desired'],1)[0]==int(command==0x77)
        rows.append(dict(Base=hex(base),Wpp=wpp,MaskExperiment=preserve,Command=hex(command),
                         Injection=point,FlagsBeforeEvent4=hex(before),CommandLost=lost,
                         EpochAfterEvent4=m.epoch(),RealRvas=[hex(x) for x in sorted(m.actual)],
                         AckMasks=[hex(x) for x in m.ack_masks]))
    boundary=[]
    if built:
        # Other register bits are still reset, and failures never become success.
        for base,wpp in itertools.product((0x140000000,0x180000000,0x7ffb12340000),(False,True)):
            for other in (1,2,4,8,0x20,0x100,0xffffffef):
                m=Recovery(base,wpp,True)
                assert m.produce(0x77)==0
                m.u.mem_write(CTX+0x210,struct.pack('<I',0x10|other))
                assert not m.entry()&0x80000000
                assert m.flags()==0x10 and m.byte()==0x77 and m.epoch()==0
                assert m.event4()==0 and m.epoch()==1 and not m.flags()
                boundary.append(dict(Case='other-bits-retain-stock-reset',Other=hex(other),Base=hex(base),Wpp=wpp))
            m=Recovery(base,wpp,True)
            assert m.produce(0x66)==0
            ack_count=len(m.ack_masks)
            m.snapshot_status=0xc0000185
            assert m.entry()==0xc0000185
            assert m.flags()==0x10 and m.byte()==0x66 and len(m.ack_masks)==ack_count
            boundary.append(dict(Case='snapshot-error-no-ack',Base=hex(base),Wpp=wpp))
            m=Recovery(base,wpp,True)
            assert m.produce(0x77)==0
            assert not m.entry()&0x80000000
            m.u.mem_write(base+0x1aa28,b'\0')
            assert m.event4()==0xc00000a3 and m.flags()==0x10 and m.byte()==0x77
            assert not m.epoch() and not m.io
            boundary.append(dict(Case='provider-not-ready-retains-command',Base=hex(base),Wpp=wpp))
    report=dict(Cases=len(rows)+len(boundary),ScheduleCases=len(rows),BoundaryCases=len(boundary),
                Failures=0,Build=int(ROOT.name.removeprefix('Build')) if built else 1865,ActualCompiledPE=True,
                ActualRecoveryEntry=True,ActualProducer=True,ActualAck=True,ActualEvent4=True,
                RuntimeCauseProven=False,HardwareAccess=False,KernelExecution=False,
                RealSMPTested=False,SnapshotProviderMocked=True,InMemoryExperiment=not built,
                BackendSHA256=hashlib.sha256((ROOT/'build/qcpmictcc8150.sys').read_bytes()).hexdigest(),
                LostUnmodified=sum(x['CommandLost'] for x in rows if not x['MaskExperiment']),
                LostExperiment=sum(x['CommandLost'] for x in rows if x['MaskExperiment']),Results=rows+boundary)
    output=ROOT/'build/recovery-queue-tests.json' if built else OUT/'recovery-queue-replay.json'
    if built:
        with (ROOT/'build/recovery-unwind.bin').open('wb') as f:
            f.write(struct.pack('<II',0x3157444e,len(fixtures)))
            for pc,sp,regs,memory in fixtures.values():
                f.write(struct.pack('<II31Q',pc,sp,*regs)+memory)
        report['NativeFixtures']=len(fixtures)
    output.write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='Results'}))
if __name__=='__main__': main()

