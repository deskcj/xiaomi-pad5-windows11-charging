"""Execute candidate role/snapshot instructions; electrical response modeled.
Verify same-source lock avoids1544 while real detach, new roles, transport
errors, stale evidence and ADC source protection retain their behavior.
"""
import json,itertools,struct
from test_role_settle import RoleMachine,CTX,SYMS,fixtures
from unicorn.arm64_const import *
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

class LockMachine(RoleMachine):
 def __init__(self,base,wpp):
  self.sink=0;self.source=4;self.force_mode_drops_cc=False;self.rp_calls=[]
  super().__init__(base,wpp)
  self.qword(base+0x1aa00,CTX+0x2000)
 def hook(self,u,a,n,x):
  r=a-self.base
  if r==0xa160:
   args=[u.reg_read(UC_ARM64_REG_X0+i) for i in range(8)]
   if self.info_status==0:
    for ptr,value in zip(args[1:4],(self.port,self.sink,self.source)):u.mem_write(ptr,struct.pack('<I',value))
    for ptr in args[4:]:u.mem_write(ptr,b'\0')
   self.ret(self.info_status);return
  if r==0xab48:
   mode=u.reg_read(UC_ARM64_REG_W1);self.mode_calls.append(mode)
   if mode==4 and self.force_mode_drops_cc:self.port=3;self.raw_port_type=3
   self.ret(self.role_status);return
  if r==0xb4a8:
   self.rp_calls.append(u.reg_read(UC_ARM64_REG_W1));self.ret();return
  super().hook(u,a,n,x)
 def sample(self,port=1,source=4):
  self.port=port;self.source=source;self.raw_port_type=1
  self.u.mem_write(CTX+0x2d,b'\x06')
  assert self.call(0x40b0,args=[CTX])==0
 def known(self):return self.u.mem_read(self.base+SYMS['SourceSampleKnown'],1)[0]
 def mode(self,mode,target=None,context=CTX):
  return self.call(SYMS['RepairRoleModeWrite'],args=[target or CTX+0x2000,mode,context])

rows=[]
for base,wpp in itertools.product((0x140000000,0x180000000,0x7ffb12340000),(False,True)):
 for source,orientation in itertools.product((4,5),(1,2)):
  m=LockMachine(base,wpp);m.sample(orientation,source)
  assert m.known();m.force_mode_drops_cc=True
  assert m.role()==0 and m.mode_calls==[] and m.port==orientation
  # Rp-current continues through the original handler after mode suppression.
  assert m.role(0x25,6)==0 and m.mode_calls==[] and m.rp_calls==[1]
  m.tick(112000000);assert m.call(0x40b0,args=[CTX])==0
  assert m.u.mem_read(CTX+0x2d,1)[0]&0xf!=0
  rows.append({'case':'measured-same-source-does-not-rewrite-mode','source':source,'orientation':orientation,'base':hex(base),'wpp':wpp})
 for reason in ('no-sample','stale','none','sink','failed-read','non-worker','wrong-target','looking','cc-open','unattached-state'):
  m=LockMachine(base,wpp);m.sample()
  if reason=='no-sample':m.u.mem_write(base+SYMS['SourceSampleKnown'],b'\0')
  if reason=='stale':m.tick(101000001)
  if reason=='none':m.port=3;assert m.info()==0
  if reason=='sink':m.sink=3;assert m.info()==0
  if reason=='failed-read':m.info_status=0xc0000185;assert m.info()==0xc0000185
  if reason=='non-worker':m.thread=0x99887766
  if reason=='wrong-target':m.qword(base+0x1aa00,CTX+0x5000)
  if reason=='looking':m.u.mem_write(CTX+0x2d,b'\x26')
  if reason=='cc-open':m.u.mem_write(CTX+0x2d,b'\0')
  if reason=='unattached-state':m.u.mem_write(CTX+0x268,bytes(4))
  # Role value initialized explicitly: direct helper call tests evidence gate.
  m.u.mem_write(CTX+0x2a,b'\x15')
  assert m.mode(4)==0 and m.mode_calls==[4]
  rows.append({'case':'uncertain-lock-keeps-original-mode-write','reason':reason,'base':hex(base),'wpp':wpp})
 for role,expected in ((0x5a,0),(0x0a,3)):
  m=LockMachine(base,wpp);m.sample();assert m.role(role,6)==0 and m.mode_calls==[expected]
  rows.append({'case':'new-role-keeps-write','mode':expected,'base':hex(base),'wpp':wpp})
 m=LockMachine(base,wpp);m.sample();m.role();m.tick(112000000);m.port=3;m.raw_port_type=3
 assert m.call(0x40b0,args=[CTX])==0
 assert not m.known() and m.u.mem_read(CTX+0x2d,1)[0]&0xf==0
 assert m.command(0x66)==0;m.repeat_error=True;m.pd_error=0
 assert m.dispatch()==0 and m.otg()==[0]
 rows.append({'case':'real-detach-invalidates-evidence-and-power-off-still-works','base':hex(base),'wpp':wpp})
 m=LockMachine(base,wpp);m.sample();m.role_status=0xc0000185
 m.tick(101000001);assert m.role()==0xc0000185 and m.mode_calls==[4]
 rows.append({'case':'mode-write-error-propagates','base':hex(base),'wpp':wpp})
 for voltage in (0,800000,800001,5000000):
  m=LockMachine(base,wpp);m.sample();m.role();m.voltage=voltage
  assert m.command(0x77)==0;m.repeat_error=True;m.pd_error=0
  m.dispatch();assert m.otg()==([1] if voltage<=800000 else [])
  rows.append({'case':'safe0-unchanged','uv':voltage,'base':hex(base),'wpp':wpp})
 m=LockMachine(base,wpp);m.sample();m.thread=0x99887766
 assert m.call(0x107a8,args=[CTX])==0 and not m.known()
 rows.append({'case':'stop-clears-source-evidence','base':hex(base),'wpp':wpp})
 # Negative control executes original63F8->AB48 on the same candidate image.
 m=LockMachine(base,wpp);m.sample();m.force_mode_drops_cc=True
 word=0x94000000|(((0xab48-0x63f8)//4)&0x3ffffff)
 m.u.mem_write(base+0x63f8,struct.pack('<I',word))
 assert m.role()==0 and m.mode_calls==[4] and m.port==3
 m.tick(112000000);assert m.call(0x40b0,args=[CTX])==0
 assert m.u.mem_read(CTX+0x2d,1)[0]&0xf==0
 rows.append({'case':'negative-control-role-write-recreates-mode-induced-cc-loss-model','base':hex(base),'wpp':wpp})
assert all(not m.held for _ in (0,))
with (ROOT/'build/same-source-lock-unwind.bin').open('wb') as f:
 f.write(struct.pack('<II',0x3157444e,len(fixtures)))
 for pc,sp,regs,mem in fixtures.values():f.write(struct.pack('<II31Q',pc,sp,*regs)+mem)
result={'Cases':len(rows),'Failures':0,'HardwareAccess':False,'ActualCandidatePE':True,
        'ElectricalResponseModeled':True,'HardwareCausalityProven':False,
        'NativeFixtures':len(fixtures),'Results':rows}
(ROOT/'build/same-source-lock-tests.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='Results'}))
