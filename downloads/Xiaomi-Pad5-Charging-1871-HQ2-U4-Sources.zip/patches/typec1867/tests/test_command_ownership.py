"""Real ARM64 producer, repaired consumer and stock ack; offline only.
Cooperative instruction schedules, mocked kernel/DDI, no hardware or real SMP.
"""
import hashlib
import itertools
import json
import struct
from test_backend_pe import Machine, ROOT, SYMS, CTX, STACK, fixtures
from test_original_backend import STOP
from unicorn.arm64_const import UC_ARM64_REG_PC, UC_ARM64_REG_X0, UC_ARM64_REG_W0

POWER = (0x66, 0x77, 0x44, 0x55)
COMMANDS = POWER + (0x99, 0x11, 0)
ROWS = []


class Queue(Machine):
    def __init__(self, base, wpp):
        self.pause_at = None
        self.pause_after_unlock = False
        self.pause_gate_release = False
        self.paused = False
        self.context_held = False
        self.command99_error = 0
        self.irql = 0
        super().__init__(base, wpp)
        # Stock constructor143F0 uses the patched3550 entry, not a stale
        # relocated helper address belonging to some earlier build.
        self.qword(base + 0x1a790, base + 0x3550)
        self.u.mem_write(CTX + 0x133, b'\x01')
        self.capture = True

    def hook(self, u, a, n, unused):
        if self.pause_at == a:
            self.pause_at = None
            self.paused = True
            u.emu_stop()
            return
        r = a - self.base
        name = self.stubs.get(a)
        if self.pause_gate_release and name == 'KeSetEvent' and u.reg_read(UC_ARM64_REG_X0) == self.base + SYMS['PowerGate']:
            self.pause_gate_release = False
            self.paused = True
            u.emu_stop()
            return
        if name == 'lock':
            assert not self.context_held
            self.context_held = True
            self.ret()
            return
        if name == 'unlock':
            assert self.context_held
            self.context_held = False
            self.ret()
            if self.pause_after_unlock:
                self.pause_after_unlock = False
                self.paused = True
                u.emu_stop()
            return
        if name == 'KeGetCurrentIrql':
            self.ret(2 if self.context_held else self.irql)
            return
        if name in ('KeWaitForMultipleObjects', 'ioctl', 'KeSetEvent'):
            assert not self.context_held, 'wait/I/O/wake while spinlock held'
        if r in (0xeb68, 0x1b28):
            return  # Execute stock producer and its synchronousE0 dispatcher.
        if r == 0xf178:
            if self.command99_error:
                self.ret(self.command99_error)
            # Otherwise execute the real virtual-register update (also locks).
            return
        super().hook(u, a, n, unused)

    def produce(self, command):
        buf = CTX + 0x1800
        self.u.mem_write(buf, bytes([command]))
        return self.call(0xeb68, args=[CTX, 0x23, 1, buf])

    def consume(self, mask=0x10):
        return self.call(0x3550, args=[CTX, mask])

    def flags(self):
        return struct.unpack('<I', self.u.mem_read(CTX + 0x210, 4))[0]

    def byte(self):
        return self.u.mem_read(CTX + 0x33, 1)[0]

    def epoch(self):
        return struct.unpack('<I', self.u.mem_read(self.base + SYMS['Epoch'], 4))[0]

    def suspended(self, action):
        self.paused = False
        try:
            action()
        except AssertionError:
            if not self.paused:
                raise
        assert self.paused
        return self.u.context_save(), bytes(self.u.mem_read(STACK, 0x10000))

    def resume(self, state):
        context, stack = state
        self.u.mem_write(STACK, stack)
        self.u.context_restore(context)
        self.u.emu_start(self.u.reg_read(UC_ARM64_REG_PC), STOP, count=100000)
        assert self.u.reg_read(UC_ARM64_REG_PC) == STOP
        assert not self.context_held and not self.held
        return self.u.reg_read(UC_ARM64_REG_W0)


for base, wpp in itertools.product((0x140000000, 0x180000000, 0x7ffb12340000), (False, True)):
    # Exact old failing schedule, plus identical commands and generic commands.
    for old, new in itertools.product(COMMANDS, COMMANDS):
        m = Queue(base, wpp)
        assert m.produce(old) == 0
        m.pause_at = base + 0xf988
        saved = m.suspended(m.consume)
        assert not m.held and not m.context_held
        old_epoch = m.epoch()
        assert m.produce(new) == 0 and m.flags() == 0x10 and m.byte() == new
        assert m.resume(saved) == 0
        assert m.flags() == 0x10 and m.byte() == new
        assert m.consume() == 0 and m.flags() == 0 and m.byte() == 0
        assert m.epoch() == old_epoch + int(new in POWER or new == 0x99)
        if new in POWER:
            assert m.u.mem_read(base + SYMS['Desired'], 1)[0] == int(new == 0x77)
        ROWS.append(dict(case='new-command-before-old-ack', old=old, new=new, base=hex(base), wpp=wpp))

    for point in ('before-gate', 'after-claim'):
        for old, new in itertools.product(POWER, POWER):
            m = Queue(base, wpp)
            assert m.produce(old) == 0
            if point == 'before-gate': m.pause_at = base + SYMS['gate']
            else: m.pause_gate_release = True  # compiler inlines ungate()
            saved = m.suspended(m.consume)
            assert not m.context_held
            assert m.produce(new) == 0
            assert m.resume(saved) == 0
            if point == 'before-gate':
                assert m.epoch() == 1 and m.flags() == 0 and m.byte() == 0
            else:
                assert m.epoch() == 1 and m.flags() == 0x10 and m.byte() == new
                assert m.consume() == 0 and m.epoch() == 2
            assert m.u.mem_read(base + SYMS['Desired'], 1)[0] == int(new == 0x77)
            ROWS.append(dict(case=point, old=old, new=new, base=hex(base), wpp=wpp))

    # Producer's byte and flag are NOT published in one critical section.
    # Latest byte can be admitted under the old flag; its late flag is empty.
    for old, new in itertools.product(POWER, POWER):
        m = Queue(base, wpp)
        assert m.produce(old) == 0
        m.pause_after_unlock = True
        saved = m.suspended(lambda: m.produce(new))
        assert not m.context_held and m.flags() == 0x10 and m.byte() == new
        assert m.consume() == 0 and m.epoch() == 1 and m.flags() == 0
        assert m.resume(saved) == 0 and m.flags() == 0x10 and m.byte() == 0
        assert m.consume() == 0 and m.epoch() == 1 and m.flags() == 0
        assert m.u.mem_read(base + SYMS['Desired'], 1)[0] == int(new == 0x77)
        ROWS.append(dict(case='byte-before-flag', old=old, new=new, base=hex(base), wpp=wpp))

    for reason in ('inactive', 'pmic', 'adc', 'other-context'):
        for command in POWER:
            m = Queue(base, wpp)
            assert m.produce(command) == 0
            if reason == 'inactive': m.u.mem_write(base + 0x1a81c, b'\0')
            if reason == 'pmic': m.u.mem_write(base + 0x1aa28, b'\0')
            if reason == 'adc': m.u.mem_write(base + 0x1aa40, b'\0')
            if reason == 'other-context':
                m.u.mem_write(base + SYMS['Pending'], b'\1')
                m.qword(base + SYMS['PendingContext'], CTX + 0x4000)
            rejected = reason != 'adc' or command == 0x77
            status = m.consume()
            assert bool(status) == rejected
            assert m.flags() == (0x10 if rejected else 0)
            assert m.byte() == (command if rejected else 0)
            assert m.epoch() == (0 if rejected else 1)
            assert not m.io and not m.held and not m.context_held
            ROWS.append(dict(case='admission-' + reason, command=command, rejected=rejected, base=hex(base), wpp=wpp))

    # Execute real99 -> realF178 in unattached state; preserve CC bits and
    # errors. A fresh99 must also survive when its predecessor fails.
    for error, new in itertools.product((0, 0xc0000185, 0x103), (None, 0x99, 0x77, 0x66)):
        m = Queue(base, wpp)
        m.u.mem_write(CTX + 0x268, bytes(4))
        m.u.mem_write(CTX + 0x2d, b'\x06')
        m.command99_error = error
        assert m.produce(0x99) == 0
        if new is not None:
            m.pause_at = base + 0x8f08
            saved = m.suspended(m.consume)
            assert m.flags() == 0 and m.byte() == 0
            assert m.produce(new) == 0
            status = m.resume(saved)
        else:
            status = m.consume()
        # ExecutePending preserves the existing NT_SUCCESS acceptance ABI:
        # positive99 status remains queued for retry while dispatcher returns0.
        assert status == (error if error & 0x80000000 else 0)
        expected = new if new is not None else (0x99 if error else 0)
        assert m.byte() == expected
        assert m.flags() == (0x10 if new is not None or error else 0)
        if not error: assert m.u.mem_read(CTX + 0x2d, 1)[0] == 0x26
        assert not m.held and not m.context_held and not m.io
        ROWS.append(dict(case='generic99-retain-or-restore', error=hex(error), new=new, base=hex(base), wpp=wpp))

    for voltage in (0, 800000, 800001, 5000000):
        m = Queue(base, wpp)
        m.voltage = voltage
        assert m.produce(0x77) == 0 and m.consume() == 0
        m.dispatch()
        assert m.otg() == ([1] if voltage <= 800000 else [])
        ROWS.append(dict(case='source-safe0', uv=voltage, base=hex(base), wpp=wpp))

    m = Queue(base, wpp)
    assert m.produce(0x77) == 0
    m.irql = 2
    assert m.call(0x69d0, args=[CTX]) == 0xc000000d
    assert m.byte() == 0x77 and m.flags() == 0x10 and not m.held
    ROWS.append(dict(case='dispatch-irql-command-rejected', base=hex(base), wpp=wpp))

with (ROOT / 'build/command-ownership-unwind.bin').open('wb') as output:
    output.write(struct.pack('<II', 0x3157444e, len(fixtures)))
    for pc, sp, regs, memory in fixtures.values():
        output.write(struct.pack('<II31Q', pc, sp, *regs) + memory)
report = dict(Build=1867, Cases=len(ROWS), Failures=0, ActualCompiledPE=True,
              RealProducerRVA='0xEB68', RealAckRVA='0xF988', RealConsumerRVA='0x3550',
              HardwareAccess=False, KernelExecution=False, RealSMPTested=False,
              RuntimeCauseProven=False, AllRegisterPendingRacesFixed=False,
              BackendSHA256=hashlib.sha256((ROOT / 'build/qcpmictcc8150.sys').read_bytes()).hexdigest(),
              NativeFixtures=len(fixtures), Results=ROWS)
(ROOT / 'build/command-ownership-tests.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps({k: v for k, v in report.items() if k != 'Results'}))

