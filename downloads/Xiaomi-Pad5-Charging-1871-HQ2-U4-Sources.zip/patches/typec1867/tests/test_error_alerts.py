"""Run real dispatch/state/status/alert code; mock external WDF/PD only."""
import itertools,json,struct,sys
from pathlib import Path
import sys
sys.path.insert(0,str(next(p for p in Path(__file__).resolve().parents if (p/'offline-deps').is_dir())/'offline-deps'))
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(Path(__file__).resolve().parent))
from test_backend_pe import Machine,SYMS,CTX,TABLE,STUB,fixtures
from test_original_backend import Backend
from unicorn.arm64_const import *

class AlertMachine(Machine):
 def __init__(self,base=0x140000000,tracing=False):
  super().__init__(base,tracing)
  # Loader relocations for original function/metadata pointers used by the
  # real state dispatcher and register map; leave mock DDI addresses alone.
  delta=base-0x140000000
  for block in self.pe.DIRECTORY_ENTRY_BASERELOC:
   for e in block.entries:
    if e.type==10:
     addr=base+e.rva;v=struct.unpack('<Q',self.u.mem_read(addr,8))[0]
     if 0x140000000<=v<0x140030000:self.qword(addr,v+delta)
  self.qword(base+0x1a780,base+0x5a20)
  self.qword(base+0x1a788,base+0x40b0)
  self.u.mem_write(base+0x1a7a0,b'\1') # completed stock init, as after boot
  self.u.mem_write(base+0x1a81d,b'\1')
  self.u.mem_write(CTX+0x260,struct.pack('<I',3)) # actual interrupt work
  self.u.mem_write(CTX+0x268,struct.pack('<I',2)) # attached state
  self.u.mem_write(CTX+0x2d,b'\x12\x0d\x00')
  self.u.mem_write(CTX+0x24,b'\xff')
  self.u.mem_write(CTX+0x22,b'\x03\x00')
  self.u.mem_write(base+0x1a819,b'\x00\x12\x0d')
  self.qword(base+0x1aa00,CTX+0x2000)
  self.qword(base+0x1aa78,CTX+0x7000)
  self.qword(CTX+0x7020,CTX+0x7100)
  self.qword(CTX+0x7108,STUB+0x1f100)
  self.stubs[STUB+0x1f100]='pd_receive'
  self.qword(base+0x1a808,0x10101010)
  self.u.mem_write(base+0x1a818,b'\1')
  self.pd_error=0xc0000185
  self.delivered=[];self.actual_path=[];self.stop_on_error=False;self.callback_command=None
  self.repeat_error=False
 def hook(self,u,a,n,unused):
  r=a-self.base
  if r in (0x10c68,0x11d50,0x11070,0x5a20,0x40b0,0x45e8,0x49c0,0x4c48,0xfad8,0x10e48,0xf328):
   self.actual_path.append(hex(r))
  if r==0x10c68 and self.repeat_error:self.ret(self.pd_error);return
  if r in (0x10c68,0xf178):return # execute original, not old harness shortcut
  if r in (0x1d98,0x1f48,0xe268,0xe350,0xe448,0x1e70,0xe2f0):self.ret();return
  if r==0xa160:
   args=[u.reg_read(UC_ARM64_REG_X0+i) for i in range(8)]
   for ptr,value in zip(args[1:4],(3,3,0)):u.mem_write(ptr,struct.pack('<I',value))
   for ptr in args[4:]:u.mem_write(ptr,b'\0')
   self.ret();return
  if r==0xe108:
   count=u.reg_read(UC_ARM64_REG_X0);ptr=u.reg_read(UC_ARM64_REG_X1)
   self.delivered.append({'count':count,'bytes':bytes(u.mem_read(ptr,count*16)).hex()})
   if self.callback_command is not None:
    command=self.callback_command;self.callback_command=None
    saved=u.context_save()
    outer_capture=self.capture;self.capture=False
    u.mem_write(CTX+0x33,bytes([command]))
    u.reg_write(UC_ARM64_REG_SP,0x204000);u.reg_write(UC_ARM64_REG_LR,0x60000004)
    u.reg_write(UC_ARM64_REG_X0,CTX)
    u.emu_start(self.base+SYMS['RepairCommand'],0x60000004,count=30000)
    assert u.reg_read(UC_ARM64_REG_PC)==0x60000004
    assert u.reg_read(UC_ARM64_REG_W0)==0
    u.context_restore(saved)
    self.capture=outer_capture
   self.ret();return
  name=self.stubs.get(a)
  if name=='pd_receive':
   if self.stop_on_error:u.mem_write(self.base+0x1a81c,b'\0')
   self.ret(self.pd_error);return
  if name=='ioctl' and u.reg_read(UC_ARM64_REG_W3)==0x802a0fa4:
   desc=u.reg_read(UC_ARM64_REG_X5)
   ptr=struct.unpack('<Q',u.mem_read(desc+8,8))[0]
   u.mem_write(ptr,struct.pack('<II',0,3))
   self.qword(u.reg_read(UC_ARM64_REG_X7),8)
   self.ret();return
  super().hook(u,a,n,unused)

def main():
 fixed='--fixed' in sys.argv
 results=[]
 for base,wpp,error in itertools.product([0x140000000,0x180000000,0x7ffb12340000],[False,True],[0xc0000185,0xc00000a3,0xc000000e]):
  m=AlertMachine(base,wpp);m.capture=True;m.pd_error=error
  status=m.dispatch()
  assert status==error,hex(status)
  cc,power=bytes(m.u.mem_read(CTX+0x2d,2))
  assert (cc,power)==(0x10,0x08),(cc,power)
  previous=bytes(m.u.mem_read(base+0x1a81a,2))
  assert bool(m.delivered)==fixed,(previous,m.delivered,m.actual_path)
  assert previous==(b'\x10\x08' if fixed else b'\x12\x0d'),previous
  assert all(hex(r) in m.actual_path for r in (0x10c68,0x11d50,0x11070,0x5a20,0x40b0))
  assert not m.otg() and not m.held
  results.append({'base':hex(base),'WPP':wpp,'status':hex(status),'CC':hex(cc),'Power':hex(power),
                  'ClassDelivery':m.delivered,'PreviousStatus':previous.hex(),'actualPath':m.actual_path})
 if fixed:
  for base,wpp in itertools.product([0x140000000,0x180000000,0x7ffb12340000],[False,True]):
   for case in ['unchanged','consumer-not-ready','stop-during-failure','repeat-error','callback-source-unsafe','callback-source-safe','callback-off']:
    m=AlertMachine(base,wpp);m.capture=True
    if case=='unchanged':m.u.mem_write(base+0x1a81a,b'\x10\x08')
    if case=='consumer-not-ready':m.u.mem_write(base+0x1a818,b'\0')
    if case=='stop-during-failure':m.stop_on_error=True
    if case.startswith('callback-'):
     m.callback_command=0x66 if case=='callback-off' else 0x77
     m.voltage=0 if case=='callback-source-safe' else 5000000
    assert m.dispatch()==m.pd_error
    if case in ('unchanged','consumer-not-ready','stop-during-failure'):assert not m.delivered
    if case=='consumer-not-ready':assert struct.unpack('<H',m.u.mem_read(CTX+0x20,2))[0]&3==3
    if case=='stop-during-failure':assert bytes(m.u.mem_read(base+0x1a81a,2))==b'\x12\x0d'
    if case=='repeat-error':
     assert len(m.delivered)==1;m.repeat_error=True
     assert m.dispatch()==m.pd_error and len(m.delivered)==1
    if case=='callback-source-unsafe':assert not m.otg()
    elif case=='callback-source-safe':assert m.otg()==[1]
    elif case=='callback-off':assert m.otg()==[0]
    else:assert not m.otg()
    assert not m.held
    results.append({'base':hex(base),'WPP':wpp,'case':case,'deliveries':len(m.delivered),'OTG':m.otg()})
  with (ROOT/'build/error-alerts-unwind.bin').open('wb') as stream:
   stream.write(struct.pack('<II',0x3157444e,len(fixtures)))
   for pc,sp,regs,mem in fixtures.values():stream.write(struct.pack('<II31Q',pc,sp,*regs)+mem)
 out={'mode':'fixed' if fixed else 'broken1855','cases':len(results),'actualPE':True,'kernelExecution':False,
      'hardwareAccess':False,'fullChargingFixProven':False,'results':results}
 (ROOT/'build'/('error-alerts-fixed.json' if fixed else 'error-alerts-broken1855.json')).write_text(json.dumps(out,indent=2),encoding='utf-8')
 print(json.dumps({k:v for k,v in out.items() if k!='results'},indent=2))
if __name__=='__main__':main()
