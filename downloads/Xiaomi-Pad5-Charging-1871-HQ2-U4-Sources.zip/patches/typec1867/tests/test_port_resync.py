"""Execute compiled1867 and original dispatcher; mock external PMIC/WDF only."""
import itertools,json,struct
from test_role_settle import RoleMachine,ROOT,SYMS,CTX
from test_backend_pe import fixtures
from unicorn.arm64_const import *

class Resync(RoleMachine):
    def __init__(self,base,wpp):
        self.reads=0;self.stop_at_read=False
        super().__init__(base,wpp)
    def hook(self,u,a,n,unused):
        if a-self.base==0xa160:
            self.reads+=1
            if self.stop_at_read:u.mem_write(self.base+0x1a81c,b'\0')
        super().hook(u,a,n,unused)
    def event(self):
        self.u.mem_write(CTX+0x260,struct.pack('<I',3))
        self.timer_armed=False
        return self.dispatch()
    def fire(self):
        before=(self.reads,len(self.io));self.signals=[];self.timer_armed=False
        self.timer()
        assert before==(self.reads,len(self.io)) and self.signals==[CTX+0x338]
        return self.event()
    def field(self,name,size=4):return int.from_bytes(self.u.mem_read(self.base+SYMS[name],size),'little')

rows=[]
def save(case,base,wpp,**kw):rows.append(dict(Case=case,Base=hex(base),WPP=wpp,**kw))
for base,wpp in itertools.product([0x140000000,0x180000000,0x7ffb12340000],[False,True]):
    m=Resync(base,wpp);m.port=3;m.event()
    assert m.timer_armed and m.field('ResyncRemaining')==8
    assert m.u.mem_read(CTX+0x2d,1)==b'\x10' # Actual None published, not hidden.
    deadline=m.field('ResyncUntil',8)
    for n in range(1,9):
        m.tick(100000000+n*1000000);m.fire()
        assert m.field('ResyncRemaining')==8-n
        assert bool(m.timer_armed)==(n<8)
        assert m.field('ResyncUntil',8)==deadline
    before=m.reads;m.event()
    assert not m.timer_armed and m.reads==before+1
    assert m.field('ResyncUntil',8)==0
    save('initial-none-eight-retries-no-permanent-poll-no-fake-cc',base,wpp,ExtraReads=8)

    for orientation in (1,2):
        m=Resync(base,wpp);m.port=3;m.event();m.port=orientation;m.raw_port_type=1;m.tick(101000000);m.fire()
        assert not m.timer_armed and m.field('ResyncRemaining')==0
        assert m.field('ResyncLastOrientation',1)==orientation
        m.port=3;m.tick(102000000);m.event()
        assert m.timer_armed and m.field('ResyncRemaining')==8
        save('fresh-attachment-stops-poll-next-real-detach-gets-new-budget',base,wpp,Orientation=orientation)

    m=Resync(base,wpp);m.port=3;m.event();deadline=m.field('ResyncUntil',8)
    m.tick(deadline);m.fire()
    assert not m.timer_armed and m.field('ResyncRemaining')==0
    save('fixed-deadline-not-extended',base,wpp)

    m=Resync(base,wpp);m.port=3;m.event();m.info_status=0xc0000185
    for n in range(1,9):m.tick(100000000+n*1000000);m.fire()
    assert not m.timer_armed and m.field('ResyncRemaining')==0
    save('transport-errors-consume-finite-budget',base,wpp)

    m=Resync(base,wpp);m.port=3;m.event();m.repeat_error=True;m.pd_error=0xc0000185
    for n in range(1,9):
        m.tick(100000000+n*1000000);assert m.fire()==0xc0000185
    assert not m.timer_armed and m.reads==1
    save('failure-before-snapshot-keeps-error-and-is-bounded',base,wpp)

    m=Resync(base,wpp);m.port=3;m.stop_at_read=True;m.event()
    assert not m.timer_armed
    save('active-cleared-during-read-does-not-arm-timer',base,wpp)

    m=Resync(base,wpp);m.port=3;m.event();m.thread=0x99887766
    assert m.call(0x107a8,args=[CTX])==0
    assert m.field('ResyncRemaining')==0 and m.field('ResyncContext',8)==0
    before=m.reads;m.timer();assert m.reads==before
    save('stop-clears-resync-context-before-timer-drain',base,wpp)

    m=Resync(base,wpp);m.thread=0x99887766;m.port=3;m.event()
    assert not m.timer_armed and m.field('ResyncContext',8)==0
    save('other-thread-cannot-start-poll',base,wpp)

    for voltage in (0,800000,800001,5000000):
        m=Resync(base,wpp);m.port=3;m.voltage=voltage;m.command(0x77);m.event()
        assert m.otg()==([1] if voltage<=800000 else [])
        save('resync-does-not-bypass-adc-safe0',base,wpp,Microvolts=voltage)

with (ROOT/'build/resync-unwind.bin').open('wb') as f:
    f.write(struct.pack('<II',0x3157444e,len(fixtures)))
    for pc,sp,regs,mem in fixtures.values():f.write(struct.pack('<II31Q',pc,sp,*regs)+mem)
result=dict(Build=1867,Cases=len(rows),Failures=0,CompiledDriverExecutedInEmulator=True,
    HardwareAccess=False,UninterruptedSSDProven=False,NativeUnwindFixtures=len(fixtures),Results=rows)
(ROOT/'build/port-resync-tests.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='Results'}))
