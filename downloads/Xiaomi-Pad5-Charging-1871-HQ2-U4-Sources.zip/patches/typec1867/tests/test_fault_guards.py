"""Exercise current-fault OFF, failed OFF and one-shot-token cleanup in PE.

Device calls are modeled. These are not electrical or real-SMP tests.
"""
import itertools
import json
import struct

from test_fault_generation import Interleaved
from test_backend_pe import Machine, SYMS, ROOT, CTX, fixtures
from test_original_backend import STOP
from unicorn.arm64_const import UC_ARM64_REG_PC


def byte(machine, name):
    return machine.u.mem_read(machine.base + SYMS[name], 1)[0]


def qword(machine, name):
    return struct.unpack('<Q', machine.u.mem_read(machine.base + SYMS[name], 8))[0]


def main():
    rows = []
    for base, wpp, kind in itertools.product(
        (0x140000000, 0x180000000, 0x7ffb12340000),
        (False, True), ('invalid-adc', 'vbus-above-safe0', 'failed-off', 'pmic-not-ready-at-off')
    ):
        m = Interleaved(base, wpp, 'before-off') if kind == 'pmic-not-ready-at-off' else Machine(base, wpp)
        m.capture = True
        m.adc_vendor = 0 if kind == 'vbus-above-safe0' else 1
        m.voltage = 5000000 if kind == 'vbus-above-safe0' else 0
        if kind == 'failed-off':
            m.pmic_vendor = 1
        assert m.command(0x77) == 0
        for _ in range(9):
            m.dispatch()
            m.timer()
        #1862 retry polling also wakes338. Only signals emitted by the final
        #fault/OFF completion establish confirmed-off refresh ownership here.
        m.signals=[]
        if kind == 'pmic-not-ready-at-off':
            m.pause_enabled = True
            try:
                m.dispatch()
            except AssertionError:
                if not m.paused:
                    raise
            assert m.paused and qword(m, 'FaultThread') != 0
            m.u.mem_write(base + 0x1aa28, b'\0')
            m.u.emu_start(m.u.reg_read(UC_ARM64_REG_PC), STOP, count=100000)
            assert m.u.reg_read(UC_ARM64_REG_PC) == STOP
        else:
            m.dispatch()
        fault = bool(m.u.mem_read(CTX + 0x2f, 1)[0] & 0x10)
        off_confirmed = kind in ('invalid-adc', 'vbus-above-safe0')
        assert not m.held and not byte(m, 'Pending') and qword(m, 'FaultThread') == 0
        assert 1 not in m.otg()
        assert not fault
        assert (CTX + 0x338 in m.signals) == off_confirmed
        assert not (struct.unpack('<H', m.u.mem_read(CTX + 0x20, 2))[0] & 0x200)
        assert m.otg() == ([0] if off_confirmed else [])
        reason = struct.unpack('<I', m.u.mem_read(base + SYMS['LastFault'], 4))[0]
        assert reason != 0
        rows.append({'base': hex(base), 'wpp': wpp, 'case': kind,
                     'no_synthetic_hardware_fault': not fault,
                     'confirmed_off_refresh_preserved': (CTX + 0x338 in m.signals) == off_confirmed,
                     'one_shot_token_cleared': True, 'source_on_attempted': False})
    with (ROOT / 'build' / 'guard-unwind-fixtures.bin').open('wb') as out:
        out.write(struct.pack('<II', 0x3157444e, len(fixtures)))
        for pc, sp, regs, memory in fixtures.values():
            out.write(struct.pack('<II31Q', pc, sp, *regs) + memory)
    report = {'cases': len(rows), 'fixtures': len(fixtures), 'failures': 0,
              'actualCompiledPE': True, 'hardwareAccess': False, 'SMPTested': False,
              'results': rows}
    (ROOT / 'build' / 'fault-guards.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps({k: v for k, v in report.items() if k != 'results'}))


if __name__ == '__main__':
    main()
