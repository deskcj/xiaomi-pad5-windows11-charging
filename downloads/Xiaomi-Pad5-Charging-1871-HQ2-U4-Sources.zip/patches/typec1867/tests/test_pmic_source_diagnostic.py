"""Real PMIC dispatcher/getter -> consumer, native fixtures, no bus access."""
import itertools,json,struct
from test_port_contract import Producer,Consumer,pm,ROOT,PBASE,native,dump
from unicorn.arm64_const import *
new_native={}
class SourceProducer(Producer):
 def __init__(self,*args,source=4,**kw):
  self.source_raw=source;self.status_writes=[]
  super().__init__(*args,**kw)
 def hook(self,u,at,n,x):
  r=at-self.base
  if self.capture and self.base==0x140000000 and (0x8410<=r<0x88f0 or 0x140e8<=r<0x140f4):
   sp=u.reg_read(UC_ARM64_REG_SP)
   regs=[u.reg_read(UC_ARM64_REG_X0+i) for i in range(29)]+[u.reg_read(UC_ARM64_REG_FP),u.reg_read(UC_ARM64_REG_LR)]
   new_native.setdefault((r,sp,tuple(regs[19:])),(r,sp-0x207000,regs,bytes(u.mem_read(0x207000,8192))))
  if r==0xb780 and u.reg_read(UC_ARM64_REG_W1)==0x1508:
   assert u.reg_read(UC_ARM64_REG_W2)==31
   u.mem_write(u.reg_read(UC_ARM64_REG_X3),bytes([self.source_raw&31]))
   self.reads.append([u.reg_read(UC_ARM64_REG_W0),0x1508,31]);self.ret();return
  if r==0xb948:
   args=[u.reg_read(UC_ARM64_REG_W0+i) for i in range(4)]
   assert args==[2,0x1153,2,2 if self.source_raw==8 else 0]
   self.status_writes.append(args);self.ret();return
  super().hook(u,at,n,x)
rows=[]
for base,wpp,source in itertools.product((0x140000000,0x180000000,0x7ffb12340000),(False,True),range(32)):
 p=SourceProducer(PBASE/'build/qcpmicext8150.sys',base,wpp,source=source);p.capture=True
 old=SourceProducer(ROOT.parent/'Build1863/pmic/build/qcpmicext8150.sys',base,wpp,source=source)
 result,data=p.status_reply();old_result,old_data=old.status_reply()
 assert result==old_result and len(data)==28
 expected=bytearray(old_data)
 struct.pack_into('<I',expected,16,source)
 if source==2:struct.pack_into('<I',expected,12,1)
 assert data==bytes(expected),(base,wpp,source,result,data,old_data)
 assert p.reads==old.reads # No added SPMI calls, including diagnostic path.
 assert p.status_writes==old.status_writes
 p.completions=[];m=Consumer(base,wpp,p);status,reply=m.read()
 assert status==0 and reply[8:12]==data[12:16] # Spare remains ignored.
 rows.append({'base':hex(base),'wpp':wpp,'sourceRaw':source,'readCallsUnchanged':True})
dump(PBASE/'build/source-diagnostic-unwind.bin',new_native.values())
report={'Cases':len(rows),'Failures':0,'HardwareAccess':False,'ActualPMICGetterAndConsumer':True,
        'NativeFixtures':len(new_native),'ExtraHardwareReads':0,'Results':rows}
(ROOT/'build/pmic-source-diagnostic-tests.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='Results'}))
