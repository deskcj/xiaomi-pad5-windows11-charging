"""Execute cooperative interleavings in the actual ARM64 PE; no hardware I/O.

A second compiled command runs with its own saved stack/context while an old
fault's OFF path is paused. This checks a real admission/publication race,
not electrical behavior or Windows SMP scheduling.
"""
import argparse
import itertools
import json
import struct
from pathlib import Path
import sys
sys.path.insert(0,str(next(p for p in Path(__file__).resolve().parents if (p/'offline-deps').is_dir())/'offline-deps'))

from test_backend_pe import Machine, SYMS, ROOT, CTX, STACK, fixtures
from test_original_backend import STOP
from unicorn.arm64_const import UC_ARM64_REG_PC, UC_ARM64_REG_X1, UC_ARM64_REG_LR


class Interleaved(Machine):
    def __init__(self, base, wpp, stage):
        self.pause_enabled = False
        self.pause_at = None
        self.paused = False
        self.stage = stage
        super().__init__(base, wpp)
        self.capture = True

    def hook(self, u, address, size, unused):
        if self.pause_enabled:
            if address == self.base + 0x8af8 and u.reg_read(UC_ARM64_REG_X1) == 0:
                self.pause_at = address if self.stage == 'before-off' else u.reg_read(UC_ARM64_REG_LR)
            if address == self.pause_at:
                self.pause_enabled = False
                self.paused = True
                u.emu_stop()
                return
        super().hook(u, address, size, unused)

    def newer_command_then_resume(self, command):
        assert self.paused and not self.held
        saved_context = self.u.context_save()
        saved_stack = bytes(self.u.mem_read(STACK, 0x10000))
        assert self.command(command) == 0
        expected_epoch = struct.unpack('<I', self.u.mem_read(self.base + SYMS['Epoch'], 4))[0]
        assert self.u.mem_read(self.base + SYMS['Pending'], 1) == b'\x01'
        self.u.mem_write(STACK, saved_stack)
        self.u.context_restore(saved_context)
        self.u.emu_start(self.u.reg_read(UC_ARM64_REG_PC), STOP, count=100000)
        assert self.u.reg_read(UC_ARM64_REG_PC) == STOP and not self.held
        pending = self.u.mem_read(self.base + SYMS['Pending'], 1) == b'\x01'
        actual_epoch = struct.unpack('<I', self.u.mem_read(self.base + SYMS['Epoch'], 4))[0]
        stale_fault = bool(self.u.mem_read(CTX + 0x2f, 1)[0] & 0x10)
        return expected_epoch, actual_epoch, pending, stale_fault


def main():
    args = argparse.ArgumentParser()
    args.add_argument('--expect', choices=('broken', 'fixed'), required=True)
    options = args.parse_args()
    rows = []
    for base, wpp, stage, command in itertools.product(
        (0x140000000, 0x180000000, 0x7ffb12340000),
        (False, True), ('before-off', 'before-publish'), (0x77, 0x66, 0x44, 0x55)
    ):
        machine = Interleaved(base, wpp, stage)
        machine.adc_vendor = 1
        assert machine.command(0x77) == 0
        for _ in range(9):
            machine.dispatch()
            machine.timer()
        machine.pause_enabled = True
        try:
            machine.dispatch()
        except AssertionError:
            if not machine.paused:
                raise
        assert machine.paused
        expected, actual, pending, stale_fault = machine.newer_command_then_resume(command)
        protected = pending and expected == actual and not stale_fault
        assert protected == (options.expect == 'fixed'), (stage, command, expected, actual, pending, stale_fault)
        if options.expect == 'fixed':
            # Finish the new accepted intent with a fresh, valid ADC result.
            machine.adc_vendor = 0
            machine.voltage = 0
            machine.dispatch()
            assert machine.u.mem_read(base + SYMS['Pending'], 1) == b'\0'
            assert machine.otg()[-1] == (1 if command == 0x77 else 0)
        rows.append({'base': hex(base), 'wpp': wpp, 'stage': stage,
                     'new_command': hex(command), 'pending_preserved': pending,
                     'epoch_preserved': expected == actual,
                     'stale_fault_published': stale_fault})
    report = {'expect': options.expect, 'cases': len(rows), 'actual_compiled_PE': True,
              'hardware_access': False, 'SMP_tested': False, 'results': rows}
    if options.expect == 'fixed':
        with (ROOT / 'build' / 'fault-unwind-fixtures.bin').open('wb') as output:
            output.write(struct.pack('<II', 0x3157444e, len(fixtures)))
            for pc, sp, regs, memory in fixtures.values():
                output.write(struct.pack('<II31Q', pc, sp, *regs) + memory)
        report['unwind_fixtures'] = len(fixtures)
    (ROOT / 'build' / ('fault-generation-' + options.expect + '.json')).write_text(
        json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps({key: value for key, value in report.items() if key != 'results'}))


if __name__ == '__main__':
    main()
