"""Execute the NEW compiled1862 start/stop/notification/ADC code.

NT/WDF objects, thread scheduling and electrical values are controlled mocks.
No kernel code is loaded. Actual ABI, gates and instruction flow are checked.
"""
import itertools,json,struct,uuid
from test_backend_pe import Machine,SYMS,ROOT,CTX,TABLE,STUB,fixtures
from unicorn.arm64_const import *
ADC='45aed534-c318-4f72-b94b-dd525eb3baf1'
ARRIVAL='cb3a4004-46f0-11d0-b08f-00609713053f'
REMOVAL='cb3a4005-46f0-11d0-b08f-00609713053f'
OFFSETS=[0x320,0x338,0x350,0x368,0x380,0x3b0,0x398]

class Life(Machine):
    def __init__(self,base,wpp):
        self.objects={};self.threads={};self.timers={};self.life=[];self.next_obj=1
        self.timer_error=0;self.thread_error=0;self.open_error=0;self.interface_error=0
        self.join_error=0;self.close_error=0;self.early_death=False
        self.interface_calls=0;self.enables=[];self.after_io=None;self.inject_code=0;self.event_init=set()
        super().__init__(base,wpp)
        self.qword(CTX,0x10101010);self.qword(CTX+0x238,0x33335555)
        self.qword(CTX+0x278,0);self.u.mem_write(CTX+0x288,b'\0')
        self.u.mem_write(base+0x1a81c,b'\0')
        for at in [0x1aa10,0x1aa28,0x1aa70,0x1a7a5]:self.u.mem_write(base+at,b'\1')
        self.qword(base+0x1a760,base+0x2400);self.qword(base+0x1a768,base+0x2ce0)
        self.objects[CTX+0x1000]=dict(refs=1,deleted=False,open=True)
        for off,name in [(0x538,'target-create'),(0x540,'target-open'),(0x550,'target-close'),
                         (0x680,'object-delete'),(0x9f0,'timer-create'),(0x268,'interface-create'),(0x270,'interface-state')]:
            stub=STUB+0x1b000+off;self.stubs[stub]=name;self.qword(TABLE+off,stub)
    def field(self,offset):return struct.unpack('<Q',self.u.mem_read(CTX+offset,8))[0]
    def global64(self,name):return struct.unpack('<Q',self.u.mem_read(self.base+SYMS[name],8))[0]
    def active(self):return self.u.mem_read(self.base+0x1a81c,1)[0]
    def started(self):return self.u.mem_read(CTX+0x288,1)[0]
    def handle(self):return struct.unpack('<Q',self.u.mem_read(self.base+0x1a820,8))[0]
    def adc_ready(self):return self.u.mem_read(self.base+0x1aa40,1)[0]
    def adc_target(self):return struct.unpack('<Q',self.u.mem_read(self.base+0x1aa30,8))[0]
    def clear_adc(self):self.u.mem_write(self.base+0x1aa40,b'\0');self.qword(self.base+0x1aa30,0)
    def event(self,arrival,guid=ADC):
        at,us,text=CTX+0x5000,CTX+0x5300,CTX+0x5400
        self.u.mem_write(at,struct.pack('<HH',1,0x30)+uuid.UUID(ARRIVAL if arrival else REMOVAL).bytes_le+uuid.UUID(guid).bytes_le+b'\0'*12)
        self.qword(at+0x28,us);data=('\\\\?\\ACPI#QCOM0512#1#{'+guid+'}').encode('utf-16-le')
        self.u.mem_write(text,data+b'\0\0');self.u.mem_write(us,struct.pack('<HHIQ',len(data),len(data)+2,0,text))
        return at
    def notify(self,arrival,guid=ADC):return self.call(SYMS['RepairProviderNotification'],args=[self.event(arrival,guid),CTX])
    def start(self):return self.call(SYMS['RepairBackendStart'],args=[CTX])
    def stop(self):return self.call(0x107a8,args=[CTX])
    def nested_remove(self):
        saved=self.u.context_save();outer_capture=self.capture;self.capture=False
        self.u.reg_write(UC_ARM64_REG_SP,0x204000)
        self.u.reg_write(UC_ARM64_REG_LR,0x60000008)
        self.u.reg_write(UC_ARM64_REG_X0,self.event(False));self.u.reg_write(UC_ARM64_REG_X1,CTX)
        self.u.emu_start(self.base+SYMS['RepairProviderNotification'],0x60000008,count=100000)
        assert self.u.reg_read(UC_ARM64_REG_PC)==0x60000008 and self.u.reg_read(UC_ARM64_REG_W0)==0
        self.u.context_restore(saved)
        self.capture=outer_capture
    def hook(self,u,a,n,unused):
        if self.after_io==a:
            self.after_io=None;self.nested_remove()
        name=self.stubs.get(a)
        if name=='KeInitializeEvent':self.event_init.add(u.reg_read(UC_ARM64_REG_X0))
        if name=='KeSetEvent' and CTX<=u.reg_read(UC_ARM64_REG_X0)<CTX+0x400:
            assert u.reg_read(UC_ARM64_REG_X0) in self.event_init,'signal before event init'
        if name in ['reference','dereference']:
            h=u.reg_read(UC_ARM64_REG_X1);o=self.objects[h]
            if name=='reference':
                assert self.base+SYMS['PowerGate'] in self.held and not o['deleted'];o['refs']+=1
            else:
                assert self.base+SYMS['PowerGate'] not in self.held;o['refs']-=1
            assert o['refs']>=0;self.life.append((name,hex(h),o['refs']));self.ret();return
        if name=='target-create':
            h=CTX+0x9000+self.next_obj*0x100;self.next_obj+=1
            self.objects[h]=dict(refs=1,deleted=False,open=False)
            self.qword(u.reg_read(UC_ARM64_REG_X3),h);self.ret();return
        if name=='target-open':
            self.objects[u.reg_read(UC_ARM64_REG_X1)]['open']=not self.open_error
            self.ret(self.open_error);return
        if name=='target-close':
            h=u.reg_read(UC_ARM64_REG_X1);self.objects[h]['open']=False
            assert not self.adc_ready() and not self.adc_target()
            assert self.base+SYMS['PowerGate'] not in self.held
            self.life.append(('target-close',hex(h)));self.ret();return
        if name=='object-delete':
            h=u.reg_read(UC_ARM64_REG_X1)
            if h in self.objects:
                o=self.objects[h];assert not o['deleted'];o['deleted']=True;o['refs']-=1
            else:assert h in self.timers;self.timers[h]['deleted']=True
            assert self.base+SYMS['PowerGate'] not in self.held
            self.life.append(('delete',hex(h)));self.ret();return
        if name=='timer-create':
            config=u.reg_read(UC_ARM64_REG_X1);output=u.reg_read(UC_ARM64_REG_X3)
            assert struct.unpack('<I',u.mem_read(config,4))[0]==40
            assert struct.unpack('<Q',u.mem_read(config+8,8))[0]==self.base+0x10a30
            assert struct.unpack('<III',u.mem_read(config+16,12))==(0,1,0)
            assert u.mem_read(config+32,1)==b'\1'
            self.life.append(('timer-create',self.timer_error))
            if self.timer_error:self.qword(output,0xdeadbeef);self.ret(self.timer_error);return
            h=0x71000000+len(self.timers)*0x100;self.timers[h]=dict(deleted=False)
            self.qword(output,h);self.ret();return
        if name=='PsCreateSystemThread':
            assert self.u.mem_read(self.base+SYMS['StopSettled'],1)==b'\0'
            assert not self.global64('StoppedContext') and self.field(0x278) in self.timers
            self.life.append(('create-thread',self.thread_error))
            output=u.reg_read(UC_ARM64_REG_X0)
            if self.thread_error:self.qword(output,0xdeadbeef);self.ret(self.thread_error);return
            assert u.reg_read(UC_ARM64_REG_X5)==self.base+0xfe40 and u.reg_read(UC_ARM64_REG_X6)==CTX
            h=0x70000000+len(self.threads)*0x100;self.threads[h]=dict(alive=not self.early_death,closed=False)
            self.qword(output,h);self.ret();return
        if name=='join':
            h=u.reg_read(UC_ARM64_REG_X0);assert h in self.threads
            if u.reg_read(UC_ARM64_REG_X2):self.ret(0x102 if self.threads[h]['alive'] else 0);return
            self.life.append(('join',hex(h)))
            if self.join_error:self.ret(self.join_error);return
            self.threads[h]['alive']=False;self.ret();return
        if name=='ZwClose':
            h=u.reg_read(UC_ARM64_REG_X0);assert h in self.threads
            self.life.append(('close',hex(h)))
            if not self.close_error:self.threads[h]['closed']=True
            self.ret(self.close_error);return
        if name=='timer_stop':
            assert u.reg_read(UC_ARM64_REG_W2)==1
            assert self.base+SYMS['PowerGate'] not in self.held
            self.life.append(('timer-stop',hex(u.reg_read(UC_ARM64_REG_X1))));self.ret();return
        if name=='interface-create':self.interface_calls+=1;self.ret(self.interface_error);return
        if name=='interface-state':self.enables.append(u.reg_read(UC_ARM64_REG_W4));self.ret();return
        if name=='ioctl' and u.reg_read(UC_ARM64_REG_W3) in [0x8adc2000,0x8adc2004]:
            h=u.reg_read(UC_ARM64_REG_X1);o=self.objects[h]
            assert not o['deleted'] and o['open'] and o['refs']>=2
            if self.inject_code==u.reg_read(UC_ARM64_REG_W3):
                self.after_io=u.reg_read(UC_ARM64_REG_LR);self.inject_code=0
        super().hook(u,a,n,unused)

rows=[]
def save(m,name):
    assert not m.held
    assert sum(t['alive'] for t in m.threads.values())<=1
    assert all(o['refs']==(0 if o['deleted'] else 1) for o in m.objects.values())
    rows.append(dict(Case=name,Base=hex(m.base),WPP=m.trace_enabled,Life=m.life))

for base,wpp in itertools.product([0x140000000,0x180000000,0x7ffb12340000],[False,True]):
    m=Life(base,wpp);m.capture=True;m.clear_adc()
    assert m.start()==0xc00000a3 and not m.threads and not m.timers;save(m,'start-requires-adc')
    for kind in ['timer_error','thread_error']:
        m=Life(base,wpp);m.capture=True;setattr(m,kind,0xc000009a)
        assert m.start()==0xc000009a and not m.active() and not m.started() and not m.handle() and not m.field(0x278)
        assert not m.threads and all(t['deleted'] for t in m.timers.values())
        setattr(m,kind,0);assert m.start()==0;assert m.stop()==0;save(m,kind+'-real-status-cleanup-poison-output-and-retry')
    m=Life(base,wpp);m.capture=True
    m.u.mem_write(base+SYMS['StopSettled'],b'\1');m.qword(base+SYMS['StoppedContext'],CTX)
    assert m.start()==0 and m.start()==0 and len(m.threads)==1 and len(m.timers)==1
    assert m.stop()==0 and not m.handle() and not m.started()
    assert [x[1] for x in m.life if x[0]=='timer-stop']==[hex(m.field(0x230)),hex(m.field(0x238)),'0x71000000']
    n=len(m.life);assert m.stop()==0 and len(m.life)==n;save(m,'old-latch-duplicate-start-and-join-drain-all-three-timers')
    m=Life(base,wpp);m.capture=True;assert m.stop()==0
    assert CTX+0x320 not in m.signals;save(m,'cold-stop-no-uninitialized-event')
    m=Life(base,wpp);m.capture=True;m.early_death=True
    assert m.start()==0xc000004b and not m.active() and not m.handle() and not m.field(0x278)
    save(m,'early-death-cleanup')
    for kind in ['join_error','close_error','pmic_status']:
        m=Life(base,wpp);m.capture=True;assert m.start()==0;setattr(m,kind,0xc0000185)
        assert m.stop()==0xc0000185 and m.start()==0xc0000185 and len(m.threads)==1
        setattr(m,kind,0);assert m.start()==0 and len(m.threads)==2;assert m.stop()==0
        save(m,'failed-'+kind+'-blocks-restart-and-retains-ownership')
    m=Life(base,wpp);m.capture=True
    assert m.notify(True)==0 and m.enables==[1]
    h=m.adc_target();assert m.notify(True)==0 and m.adc_target()==h and m.interface_calls==1
    assert m.notify(False)==0 and not m.adc_ready() and m.objects[h]['deleted']
    assert m.notify(True)==0 and m.adc_ready();save(m,'actual-wrapper-adc-remove-return-and-duplicate')
    m=Life(base,wpp);m.capture=True;assert m.start()==0;m.clear_adc();m.open_error=0xc00000a3
    assert m.notify(True)==0xc00000a3
    failed=[o for o in m.objects.values() if o['deleted']];assert len(failed)==1 and failed[0]['refs']==0
    m.open_error=0;before=list(m.signals);assert m.notify(True)==0 and CTX+0x350 in m.signals[len(before):]
    save(m,'failed-open-retired-and-late-arrival-wakes-worker')
    for code in [0x8adc2000,0x8adc2004]:
        m=Life(base,wpp);m.capture=True;assert m.start()==0;m.inject_code=code
        out=CTX+0x1800;m.u.mem_write(out,struct.pack('<I',0xdeadbeef))
        assert m.call(0xa578,args=[m.adc_target(),out])==0xc0000120
        assert struct.unpack('<I',m.u.mem_read(out,4))[0]==0xdeadbeef
        if code==0x8adc2000:assert m.io.count(0x8adc2004)==0
        save(m,'removal-after-api-return-'+hex(code)+'-no-stale-io-or-publication')
    for error in [0xc000009a,0xc0000185]:
        m=Life(base,wpp);m.capture=True;m.interface_error=error
        assert m.notify(True)==error and not m.started() and not m.active() and not m.handle()
        assert m.interface_calls==1 and not m.enables
        m.interface_error=0;assert m.notify(True)==0 and m.started() and m.enables==[1] and m.interface_calls==2
        assert m.notify(True)==0 and m.interface_calls==2 and sum(t['alive'] for t in m.threads.values())==1
        save(m,'class-publication-failure-rollback-and-retry-'+hex(error))

with (ROOT/'build/lifecycle-unwind.bin').open('wb') as f:
    f.write(struct.pack('<II',0x3157444e,len(fixtures)))
    for pc,sp,regs,mem in fixtures.values():f.write(struct.pack('<II31Q',pc,sp,*regs)+mem)
report=dict(Cases=len(rows),Failures=0,ActualCompiled1862Executed=True,KernelExecution=False,
    HardwareAccess=False,DDIObjectsAndSchedulingModeled=True,NativeUnwindFixtures=len(fixtures),Results=rows,
    FullHardwareFixProven=False,MulticoreKernelTested=False)
(ROOT/'build/lifecycle-tests.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='Results'}))
