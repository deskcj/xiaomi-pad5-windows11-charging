"""Execute candidate PMIC queue and Type-C PE, transfer ONLY completed bytes.
No devices or driver services are opened. SPMI/NT/WDF transport are modeled.
"""
import importlib.util,itertools,json,struct,sys,hashlib
from pathlib import Path
from test_backend_pe import Machine,ROOT,SYMS,CTX,fixtures
from unicorn.arm64_const import *
spec=importlib.util.spec_from_file_location('pmic_model',ROOT/'pmic/tests/test_reply.py')
pm=importlib.util.module_from_spec(spec);spec.loader.exec_module(pm)
PBASE=ROOT/'pmic'
BASES=[0x140000000,0x180000000,0x7ffb12340000]
ERROR=0xc0000185
native={}

class Producer(pm.Pmic):
    def __init__(self,*args,raw=2,vendor=0,**kwargs):
        self.raw=raw;self.lower=vendor;self.reads=[]
        super().__init__(*args,**kwargs)
        self.qword(self.base+0xd558,pm.CTX+0xa000);self.qword(self.base+0xd550,1)
        self.qword(pm.CTX+0xa000,self.base+0x8410);self.qword(self.base+0xd578,pm.CTX+0x3000)
    def hook(self,u,at,n,x):
        r=at-self.base
        if self.capture and self.base==BASES[0] and (0x7dd0<=r<0x82a4 or 0x9690<=r<0x9820 or 0x14098<=r<0x140e8):
            sp=u.reg_read(UC_ARM64_REG_SP)
            regs=[u.reg_read(UC_ARM64_REG_X0+i) for i in range(29)]+[u.reg_read(UC_ARM64_REG_FP),u.reg_read(UC_ARM64_REG_LR)]
            native.setdefault((r,sp,tuple(regs[19:])),(r,sp-0x207000,regs,bytes(u.mem_read(0x207000,8192))))
        if r==0xb780:
            args=[u.reg_read(UC_ARM64_REG_X0+i) for i in range(4)]
            if args[1]==0x110d:
                assert args[:3]==[2,0x110d,7],args
                raw,error=self.raw,self.lower
            else:
                assert args[0]==2
                # A genuine Rd/Ra consumer is raw4. Raw2 is Ra-only and no
                # longer masquerades as that consumer in PMIC1864.
                raw={(0x1506,15):8,(0x1508,31):4,(0x150b,1):1,(0x150b,2):0,(0x150b,32):1}[(args[1],args[2])]
                error=0
            self.reads.append(args[:3]);u.mem_write(args[3],bytes([raw]));self.ret(error);return
        if r==0xb858:
            assert u.reg_read(UC_ARM64_REG_W1)==0x150b
            u.mem_write(u.reg_read(UC_ARM64_REG_X2),b'\x10');self.ret();return
        if r==0xb948:
            assert [u.reg_read(UC_ARM64_REG_X0+i) for i in range(4)]==[2,0x1153,2,0]
            self.ret();return # modeled GET_STATUS side-effect; no live bus
        if r==0x15f8:self.ret();return
        super().hook(u,at,n,x)
    def reply(self,capacity=8,input_len=0):
        result=self.call(0x801c0fc4,out_len=capacity,in_len=input_len)
        full=bytes(self.u.mem_read(pm.CTX+0x2000,32))
        assert full[8:]==b'\xa5'*24,'Write beyond GET_OTG reply'
        return result,full
    def status_reply(self):
        self.completions=[]
        result=self.call(0x802a0fa0,value=1,out_len=28,in_len=4)
        data=bytes(self.u.mem_read(pm.CTX+0x2000,28))
        self.completions=[]
        return result,data

class Consumer(Machine):
    def __init__(self,base,wpp,producer=None):
        self.producer=producer;self.codes=[]
        self.port=struct.pack('<5I8B',0,1,3,4,0,1,0,0,1,0,0,0,0)
        self.otg=struct.pack('<II',0,1)
        self.port_count=28;self.otg_count=8;self.port_status=0;self.otg_status=0
        self.irql=0;self.block_gate=False
        super().__init__(base,wpp);self.capture=True
    def hook(self,u,at,n,x):
        name=self.stubs.get(at)
        if name=='KeGetCurrentIrql':self.ret(self.irql);return
        if name=='ioctl':
            args=[u.reg_read(UC_ARM64_REG_X0+i) for i in range(8)]
            code=args[3]
            if code==0x802a0fa4:
                ptr=struct.unpack('<Q',u.mem_read(args[5]+8,8))[0]
                u.mem_write(ptr,struct.pack('<II',0,1));self.qword(args[7],8);self.ret();return
            if code in (0x802a0fa0,0x801c0fc4):
                ptr,cap=struct.unpack('<QQ',u.mem_read(args[5]+8,16))
                assert args[2]==0
                opt,flags,timeout=struct.unpack('<IIq',u.mem_read(args[6],16))
                assert flags&1 and timeout==-10000000
                self.codes.append(code)
                if code==0x802a0fa0:
                    assert cap==28 and args[1]==CTX+0x2000
                    inp,size=struct.unpack('<QQ',u.mem_read(args[4]+8,16))
                    assert size==4 and struct.unpack('<I',u.mem_read(inp,4))[0]==1
                    data,count,status=self.port,self.port_count,self.port_status
                    if self.producer:
                        result,data=self.producer.status_reply();count=result['information'];status=result['status']
                else:
                    assert cap==8 and args[1]==CTX+0x3000 and args[4]==0
                    data,count,status=self.otg,self.otg_count,self.otg_status
                    if self.producer:
                        result,full=self.producer.reply();count=result['information'];status=result['status'];data=full[:8]
                # WDF METHOD_BUFFERED model copies at most output capacity,
                # but reports original Information to test invalid counts.
                if count:u.mem_write(ptr,data[:min(count,cap)])
                self.qword(args[7],count);self.ret(status);return
        super().hook(u,at,n,x)
    def read(self,wrapper=False,null_arg=None):
        table=CTX+0x1600;out=CTX+0x1800
        self.qword(table,CTX+0x2000);self.qword(table+24,CTX+0x3000)
        self.u.mem_write(out,b'\xa5'*32)
        args=[table,out,out+4,out+8,out+12,out+13,out+14,out+15]
        if null_arg is not None:args[null_arg]=0
        if self.block_gate:self.u.mem_write(self.base+SYMS['GateReady'],bytes(4))
        status=self.call(SYMS['RepairReadPortInfo'] if wrapper else 0xa160,args=args)
        data=bytes(self.u.mem_read(out,32))
        assert data[16:]==b'\xa5'*16
        assert not self.held
        return status,data

def dump(path,values):
    with path.open('wb') as f:
        f.write(struct.pack('<II',0x3157444e,len(values)))
        for pc,sp,regs,mem in values:f.write(struct.pack('<II31Q',pc,sp,*regs)+mem)

def main():
    rows=[]
    def record(case,base,wpp,**kw):rows.append(dict(case=case,base=hex(base),wpp=wpp,**kw))
    for base,wpp in itertools.product(BASES,[False,True]):
        for raw,vendor in itertools.product(range(8),[0,0x6d,0xffffffff]):
            p=Producer(PBASE/'build/qcpmicext8150.sys',base,wpp,raw=raw,vendor=vendor);p.capture=True
            r,data=p.reply()
            expected=[0,2,1,2,3,3,3,3][raw]
            assert r['status']==0 and r['information']==8
            assert struct.unpack('<II',data[:8])==(vendor,0 if vendor else expected)
            # Producer has one completion; use a fresh producer for the pair.
            p=Producer(PBASE/'build/qcpmicext8150.sys',base,wpp,raw=raw,vendor=vendor);p.capture=True
            m=Consumer(base,wpp,p);status,out=m.read(wrapper=True)
            assert status==(ERROR if vendor else 0)
            assert out[:16]==(b'\xa5'*16 if vendor else struct.pack('<3I4B',1,3,4,1,int(expected==1),1,0))
            assert m.codes==[0x802a0fa0,0x801c0fc4]
            record('real-producer-to-real-consumer',base,wpp,raw=raw,vendor=vendor,status=status)
        for cap in [0,1,4,7,8,16]:
            p=Producer(PBASE/'build/qcpmicext8150.sys',base,wpp);p.capture=True
            r,out=p.reply(cap)
            assert r['information']==(8 if cap>=8 else 0)
            assert r['status']==(0 if cap>=8 else 0xc000000d)
            assert len(p.reads)==int(cap>=8)
            if cap<8:assert out==b'\xa5'*32
            record('producer-short-buffer-and-canary',base,wpp,capacity=cap)
        # Current1858 is deliberately rejected by the repaired consumer.
        p=Producer(PBASE/'reference/qcpmicext8150.sys',base,wpp)
        m=Consumer(base,wpp,p);status,out=m.read()
        assert status==ERROR and out==b'\xa5'*32
        record('old-pmic-information-zero-negative-control',base,wpp)
        for field,values in [
            ('port_count',[0,1,4,24,27,29,0xffffffffffffffff]),('otg_count',[0,1,4,7,9,0xffffffffffffffff]),
            ('port_status',[0x102,0x103,1,0x40000000,0x80000005,ERROR,0xc0000120]),
            ('otg_status',[0x102,0x103,1,0x40000000,0x80000005,ERROR,0xc0000120])]:
            for value in values:
                for wrapper in [False,True]:
                    m=Consumer(base,wpp);setattr(m,field,value);status,out=m.read(wrapper)
                    expected=value if field.endswith('status') and value&0x80000000 else ERROR
                    assert status==expected and out==b'\xa5'*32,(field,value,status,out)
                    assert len(m.codes)==(1 if field.startswith('port') else 2)
                    record('invalid-transport-preserves-outputs',base,wpp,field=field,value=value,wrapper=wrapper)
        for offset,value in [(0,1),(4,4),(8,4),(12,6),(4,0xffffffff),(8,0xffffffff),(12,0xffffffff)]:
            m=Consumer(base,wpp);port=bytearray(m.port);struct.pack_into('<I',port,offset,value);m.port=bytes(port)
            status,out=m.read(True);assert status==ERROR and out==b'\xa5'*32 and len(m.codes)==1
            record('invalid-port-vendor-enum',base,wpp,offset=offset,value=value)
        for vendor,state in [(1,1),(0x6d,1),(0xffffffff,0),(0,4),(0,0xffffffff)]:
            m=Consumer(base,wpp);m.otg=struct.pack('<II',vendor,state)
            status,out=m.read(True);assert status==ERROR and out==b'\xa5'*32
            record('invalid-otg-vendor-enum',base,wpp,vendor=vendor,state=state)
        m=Consumer(base,wpp);m.capture=False
        for orientation,sink,source,state in itertools.product(range(4),range(4),range(6),range(4)):
            m.codes=[]
            m.port=struct.pack('<5I8B',0,orientation,sink,source,0xffffffff,2,255,255,255,2,255,255,255)
            m.otg=struct.pack('<II',0,state);status,out=m.read()
            assert status==0 and out[:16]==struct.pack('<3I4B',orientation,sink,source,1,int(state==1),1,1)
            record('valid-enum-and-boolean-mapping',base,wpp)
        for wrapper,null_arg in itertools.product([False,True],range(8)):
            m=Consumer(base,wpp);status,out=m.read(wrapper,null_arg)
            assert status==0xc000000d and out==b'\xa5'*32 and not m.codes
            record('null-parameter-rejected',base,wpp,argument=null_arg,wrapper=wrapper)
        m=Consumer(base,wpp);m.irql=2;status,out=m.read()
        assert status==0xc00000a3 and out==b'\xa5'*32 and not m.codes
        record('wrong-irql-no-io',base,wpp)
        m=Consumer(base,wpp);m.block_gate=True;status,out=m.read(True)
        assert status==0xc00000a3 and out==b'\xa5'*32
        record('wrapper-gate-unavailable-no-publication',base,wpp)
        # Real40B0 must preserve cached CC on an invalid snapshot.
        m=Consumer(base,wpp);m.port_count=0;m.u.mem_write(CTX+0x2d,b'\x06\x0d')
        m.qword(base+0x1aa00,CTX+0x2000);m.qword(base+0x1aa18,CTX+0x3000)
        assert m.call(0x40b0,args=[CTX])==ERROR
        assert bytes(m.u.mem_read(CTX+0x2d,2))==b'\x06\x0d'
        record('actual40B0-error-preserves-cc-power-cache',base,wpp)
    dump(PBASE/'build/otg-unwind.bin',native.values())
    dump(ROOT/'build/port-contract-unwind.bin',fixtures.values())
    report=dict(Cases=len(rows),Failures=0,ActualCandidatePMICAndBackendExecuted=True,HardwareAccess=False,
        ProducerSHA256=hashlib.sha256((PBASE/'build/qcpmicext8150.sys').read_bytes()).hexdigest(),
        ConsumerSHA256=hashlib.sha256((ROOT/'build/qcpmictcc8150.sys').read_bytes()).hexdigest(),
        ProducerUnwindFixtures=len(native),ConsumerUnwindFixtures=len(fixtures),Results=rows)
    (ROOT/'build/port-contract-tests.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='Results'}))
if __name__=='__main__':main()
