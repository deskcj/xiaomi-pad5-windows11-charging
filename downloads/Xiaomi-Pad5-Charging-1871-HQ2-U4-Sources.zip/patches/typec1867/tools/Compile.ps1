param([switch]$Analyze)
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$vc='H:\Vlad\EWDK\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207'
$wdk='H:\Vlad\EWDK\Program Files\Windows Kits\10\Include'
$includes=@("/I$vc\include","/I$wdk\10.0.26100.0\shared","/I$wdk\10.0.26100.0\km","/I$wdk\10.0.26100.0\ucrt","/I$wdk\wdf\kmdf\1.23")
[string[]]$extra=if($Analyze){@('/analyze','/analyze:external-')}else{@()}
$log=if($Analyze){'analyze.log'}else{'compile.log'}
$object=if($Analyze){'backend_repair.analyze.obj'}else{'backend_repair.obj'}
& "$vc\bin\Hostarm64\arm64\cl.exe" /nologo /c /kernel /W4 /WX /O2 /Oi /forceInterlockedFunctions- /GS /guard:cf /Gy- /Zl /external:anglebrackets /external:W0 /D_ARM64_ @extra @includes "$root\src\backend_repair.c" "/Fo:$root\build\$object" *> "$root\build\$log"
if($LASTEXITCODE){Get-Content -LiteralPath "$root\build\$log";throw 'Backend compilation failed'}
Get-Content -LiteralPath "$root\build\$log"
if(!$Analyze){
 & 'C:\Users\Xiaomi\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' "$root\tools\link_backend.py" backend *> "$root\build\bind.log"
 if($LASTEXITCODE){Get-Content -LiteralPath "$root\build\bind.log";throw 'Backend binding failed'}
}
