import hashlib,json
from pathlib import Path
root=Path(r'H:\Vlad\Charging\Build1867')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
files=('backend-emulation.json','error-alerts-fixed.json','fault-generation-fixed.json','fault-guards.json','lifecycle-tests.json',
    'role-settle-tests.json','same-source-lock-tests.json','refresh-wakeup-tests.json','port-contract-tests.json',
    'command-ownership-tests.json','recovery-queue-tests.json','port-resync-tests.json')
rows=[]
for name in files:
    path=root/'build'/name
    if not path.exists():
        # Existing test names are checked explicitly, never replaced with copied1866 results.
        print('Missing',name,'Available',sorted(p.name for p in (root/'build').glob('*.json')))
        raise FileNotFoundError(path)
    data=read(path);count=data.get('Cases',data.get('cases'))
    assert count and data.get('Failures',data.get('failures',0))==0
    rows.append(dict(Suite=name,Cases=count,SHA256=hashlib.sha256(path.read_bytes()).hexdigest()))
native=[]
for path in sorted((root/'build').glob('*.bin.native.json'))+list((root/'pmic/build').glob('*.bin.native.json')):
    r=read(path);assert r['failures']==0 and not r['kernelDriverLoaded'] and not r['mappedDriverMemoryExecutable']
    native.append(dict(Suite=str(path.relative_to(root)),Cases=r['nativeARM64UnwindCases'],SHA256=hashlib.sha256(path.read_bytes()).hexdigest()))
assert len(native)==13,len(native)
assert read(root/'build/rebuild.json')['Identical']
structural=read(root/'build/structural-audit.json')
assert structural['UnsignedSHA256']==hashlib.sha256((root/'build/qcpmictcc8150.sys').read_bytes()).hexdigest()
qa=dict(Build=1867,Failures=0,FunctionalCases=sum(r['Cases'] for r in rows),Suites=rows,
    NativeARM64UnwindCases=sum(r['Cases'] for r in native),NativeSuites=native,
    BackendUnsignedSHA256=structural['UnsignedSHA256'],RebuildIdentical=True,StaticAnalysisPassed=True,
    INFValidated=True,ReadyForAuthorizedTrial=True,HardwareAccepted=False,DriverLoadedDuringQA=False,
    UninterruptedHubFixed=False,DelayFixedOnHardware=False,RealSMPTested=False,
    Fix='Eight bounded100ms CC resamples through existing worker after real None; fixed1sec deadline',
    Limits=['Does not suppress actual detach or change PMIC/client/PD/safe0.',
        'No proof that physical Rd was restored within the retry window in the49sec capture.',
        'First USB port disconnect before PMIC None remains unresolved.'])
(root/'build/qa-1867.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in qa.items() if k not in ('Suites','NativeSuites')},indent=2))
