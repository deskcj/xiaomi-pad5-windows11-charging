#include <ntddk.h>
#include <wdf.h>

/* Bound by the hash-pinned PE linker to THIS driver's WDF globals, never
 * handles belonging to another driver. Original discovery/PD remain in place. */
extern PVOID *SkWdfTable;
extern PWDF_DRIVER_GLOBALS SkWdfGlobals;
extern const WDF_OBJECT_CONTEXT_TYPE_INFO *SkContextType;
extern WDFIOTARGET SkAdcTarget;
extern WDFIOTARGET SkPmicTarget;
extern WDFIOTARGET SkTypeCTarget;
extern volatile UCHAR SkPmicReady;
extern volatile UCHAR SkAdcReady, SkDriverActive;
extern HANDLE SkThreadHandle;
NTSYSAPI NTSTATUS NTAPI ZwWaitForSingleObject(HANDLE,BOOLEAN,PLARGE_INTEGER);
extern NTSTATUS OriginalSetPower(PVOID context,UCHAR on);
extern NTSTATUS OriginalCommand99(PVOID context);
extern NTSTATUS OriginalDispatch(PVOID context);
extern NTSTATUS OriginalBuildStatusAlerts(PVOID context);
extern VOID OriginalPublishAlerts(PVOID context);
/* Names follow the TCPCI register actually read by each pinned handler:
 * 7618 TX,7148 RX_DETECT,6EC8 MSG_HDR_INFO,64A0 POWER_CONTROL,
 * 6088 ROLE_CONTROL,7388 TCPC_CONTROL. Older source labels were misleading. */
extern NTSTATUS OriginalTransmit(PVOID),OriginalReceiveDetect(PVOID),OriginalMessageHeader(PVOID);
extern NTSTATUS OriginalPowerControl(PVOID),OriginalRoleControl(PVOID),OriginalTcpcControl(PVOID);
extern NTSTATUS OriginalReadPortInfo(PVOID,PULONG,PULONG,PULONG,PVOID,PVOID,PVOID,PVOID);
extern NTSTATUS OriginalWriteTypeCMode(WDFIOTARGET,ULONG);
extern NTSTATUS OriginalPendingAck(PVOID,ULONG);
extern NTSTATUS OriginalWriteVirtual(PVOID,ULONG,UCHAR,PVOID);
extern NTSTATUS OriginalResetBackend(PVOID);
/*1862 candidate. Provider originals remain unmodified; new BL
 * adapters replace14B84/14DC8. The14C80 adapter replaces103A8 construction,
 * reusing its original FE40 worker and10A30 timer callback. */
extern NTSTATUS OriginalProviderArrival(PVOID,PVOID,PBOOLEAN);
extern NTSTATUS OriginalProviderRemoval(PVOID,PBOOLEAN);
extern NTSTATUS OriginalProviderNotification(PVOID,PVOID);
extern KSTART_ROUTINE OriginalWorkerEntry;
extern EVT_WDF_TIMER OriginalWorkerTimer;
extern const GUID SkAdcInterfaceGuid;
NTSTATUS RepairStop(PVOID c);
extern ULONG_PTR OriginalWppInitialize(ULONG_PTR,ULONG_PTR,ULONG_PTR,ULONG_PTR,
                                      ULONG_PTR,ULONG_PTR,ULONG_PTR,ULONG_PTR);

static KEVENT PowerGate;
static KEVENT StopGate;
static KEVENT AdcUpdateGate;
/* One complete provider callback owns start -> class-interface publication.
 * Parent cleanup drains registrations with Ex before acquiring StopGate. */
static KEVENT NotificationGate;
/* Protected by PowerGate; never hold it over ADC I/O, close, delete or wake. */
static ULONGLONG AdcGeneration;
static UCHAR AdcUpdating;
static UCHAR AdcStarting;
static volatile LONG GateReady;
static ULONG Epoch,PendingEpoch,Attempts;
static UCHAR Pending,Desired;
static PVOID PendingContext;
static PKTHREAD ApplyingThread;
static ULONG ApplyingEpoch;
/* One-shot ownership for the next stock OFF transport call. It is consumed
 * inside PowerGate, so a delayed fault cannot cancel a newer accepted intent.
 * The pinned FE40 system thread is the only process_power/fault producer. */
static PKTHREAD FaultThread;
static ULONG FaultEpoch;
static NTSTATUS LastFault;
static PKTHREAD volatile WorkerThread;
static PVOID StoppedContext;
static UCHAR StopSettled;
/* Android smb5 suppresses role-lock notifications for up to1000ms. Here
 * the worker still reads real hardware; only a transient Unattached result
 * CC-orientation None result (enum3 in the pinned PMIC ABI) is deferred
 * while locking an already measured Source attachment.
 * Stop joins this worker before its context can be released. */
static PVOID RoleSettlingContext;
static ULONGLONG RoleSettleUntil;
/* A worker-measured source attachment, never a class desired-role value.
 * Any failed/None/sink snapshot invalidates this evidence; Stop clears it.
 * Only the ROLE_CONTROL6088 -> AB48 callsite may use it. */
static ULONGLONG LastSourceSample;
static UCHAR SourceSampleKnown;
/*1867: a real None snapshot can be the final IRQ during a role transition.
 * Resample through the existing FE40 event338 path, at most eight times.
 * These fields belong to the one system worker and are cleared before join.
 * The actual None/error result remains visible; no CC/VBUS is synthesized. */
static PVOID ResyncContext;
static ULONG ResyncRemaining;
static ULONGLONG ResyncUntil;
static UCHAR ResyncLastOrientation=0xff;
static UCHAR SnapshotSeen,SnapshotOrientation;
static NTSTATUS SnapshotStatus;
static VOID retry(PVOID c);
static NTSTATUS stop_locked(PVOID c);
static NTSTATUS backend_construct_locked(PVOID c);

static NTSTATUS gate(void)
{
    PVOID objects[1]={&PowerGate};
    if(!GateReady || KeGetCurrentIrql()!=PASSIVE_LEVEL)return STATUS_DEVICE_NOT_READY;
    return KeWaitForMultipleObjects(1,objects,WaitAny,Executive,KernelMode,FALSE,NULL,NULL);
}
static VOID ungate(void) { KeSetEvent(&PowerGate,IO_NO_INCREMENT,FALSE); }
static VOID lock_context(PVOID c)
{
    ((PFN_WDFSPINLOCKACQUIRE)SkWdfTable[0x9e0/8])
        (SkWdfGlobals,*(WDFSPINLOCK *)((PUCHAR)c+0x218));
}
static VOID unlock_context(PVOID c)
{
    ((PFN_WDFSPINLOCKRELEASE)SkWdfTable[0x9e8/8])
        (SkWdfGlobals,*(WDFSPINLOCK *)((PUCHAR)c+0x218));
}
static VOID wake(PVOID c)
{
    if(SkDriverActive==1)KeSetEvent((PKEVENT)((PUCHAR)c+0x350),IO_NO_INCREMENT,FALSE);
}

ULONG_PTR RepairInitialize(ULONG_PTR a,ULONG_PTR b,ULONG_PTR c,ULONG_PTR d,
                          ULONG_PTR e,ULONG_PTR f,ULONG_PTR g,ULONG_PTR h)
{
    KeInitializeEvent(&PowerGate,SynchronizationEvent,TRUE);
    KeInitializeEvent(&StopGate,SynchronizationEvent,TRUE);
    KeInitializeEvent(&AdcUpdateGate,SynchronizationEvent,TRUE);
    KeInitializeEvent(&NotificationGate,SynchronizationEvent,TRUE);
    /* DriverEntry finishes this initialization before device callbacks exist. */
    GateReady=1;
    return OriginalWppInitialize(a,b,c,d,e,f,g,h);
}

static NTSTATUS exchange(WDFIOTARGET target,ULONG code,PVOID in,ULONG in_size,
                         PVOID out,ULONG out_size)
{
    WDF_MEMORY_DESCRIPTOR input,output;
    WDF_REQUEST_SEND_OPTIONS options;
    ULONG_PTR returned=0;
    NTSTATUS status;
    if(!target || KeGetCurrentIrql()!=PASSIVE_LEVEL)return STATUS_DEVICE_NOT_READY;
    WDF_MEMORY_DESCRIPTOR_INIT_BUFFER(&input,in,in_size);
    WDF_MEMORY_DESCRIPTOR_INIT_BUFFER(&output,out,out_size);
    WDF_REQUEST_SEND_OPTIONS_INIT(&options,WDF_REQUEST_SEND_OPTION_TIMEOUT);
    options.Timeout=-10000000LL;
    status=((PFN_WDFIOTARGETSENDIOCTLSYNCHRONOUSLY)SkWdfTable[0x5d0/8])
        (SkWdfGlobals,target,NULL,code,&input,&output,&options,&returned);
    if(status!=STATUS_SUCCESS)return NT_SUCCESS(status)?STATUS_IO_DEVICE_ERROR:status;
    if(returned!=out_size || *(ULONG *)out!=0)return STATUS_IO_DEVICE_ERROR;
    return STATUS_SUCCESS;
}

#include "adc_lifecycle.inc"
#include "port_reply.inc"

/* All stock AF20 callers bind here. The gate covers PMIC I/O only; class
 * callbacks in OriginalSetPower run after this function releases it. */
NTSTATUS RepairPowerIo(WDFIOTARGET target,UCHAR mode,UCHAR on)
{
    ULONG value=mode,result=MAXULONG;
    NTSTATUS status=gate();
    if(status!=STATUS_SUCCESS)return status;
    if(!SkPmicReady) {ungate();return STATUS_DEVICE_NOT_READY;}
    if(on) {
        if(!SkDriverActive || !Pending || !Desired ||
           ApplyingThread!=KeGetCurrentThread() || ApplyingEpoch!=Epoch) {
            ungate();return STATUS_CANCELLED;
        }
    } else if(FaultThread==KeGetCurrentThread()) {
        ULONG fault_epoch=FaultEpoch;
        FaultThread=NULL;
        if(!SkDriverActive || Epoch!=fault_epoch || Pending) {
            ungate();return STATUS_CANCELLED;
        }
        /* This OFF belongs to the already reserved fault generation. Do not
         * increment Epoch or discard a command accepted after that fault. */
    } else {
        if(!(Pending && !Desired && ApplyingThread==KeGetCurrentThread() && ApplyingEpoch==Epoch)) {
            ++Epoch;Pending=0;
        }
    }
    status=exchange(target,0x801c0fa8,&value,4,&result,4);
    if(status==STATUS_SUCCESS) {
        value=on;result=MAXULONG;
        status=exchange(target,0x801c0fac,&value,4,&result,4);
    }
    ungate();return status;
}

NTSTATUS RepairCommand(PVOID context)
{
    UCHAR command;
    NTSTATUS status;
    if(!context || KeGetCurrentIrql()!=PASSIVE_LEVEL)return STATUS_INVALID_PARAMETER;
    /*1865: COMMAND and its pending bit have one owner. Acquire the passive
     * power gate BEFORE the spinlock, sample the latest byte and consume both
     * fields in that same critical section. No wait, I/O or wake at spin IRQL.
     * The producer EB68 publishes byte and flag in separate locked sections;
     * its late flag can therefore describe an already consumed zero byte.
     * That harmless empty notification must not create a new power intent. */
    status=gate();if(status!=STATUS_SUCCESS)return status;
    lock_context(context);command=*((PUCHAR)context+0x33);
    if(command==0x77 || command==0x66 || command==0x44 || command==0x55) {
        if(!SkDriverActive || !SkPmicReady || (command==0x77 && !SkAdcReady)) {
            unlock_context(context);ungate();return STATUS_DEVICE_NOT_READY;
        }
        if(Pending && PendingContext!=context) {
            unlock_context(context);ungate();return STATUS_DEVICE_BUSY;
        }
        PendingEpoch=++Epoch;Attempts=0;Desired=(command==0x77);
        PendingContext=context;Pending=1;
    } else if(command==0x99) {
        ++Epoch;Pending=0;
    }
    *((PUCHAR)context+0x33)=0;
    *(ULONG *)((PUCHAR)context+0x210)&=~0x10u;
    unlock_context(context);
    if(command==0x99) {
        /* Pinned8F08 only updates virtual CC_STATUS through F178; it does
         * not wait, perform device I/O, publish alerts or acquire PowerGate.
         * Keep command consumers serialized, but release the context lock
         * before this original handler takes it. A newer producer, including
         * an identical99 or its byte-before-flag phase, must survive failure.
         * Restore a failed99 only if the slot is still completely empty. */
        status=OriginalCommand99(context);
        if(status!=STATUS_SUCCESS) {
            lock_context(context);
            if(*((PUCHAR)context+0x33)==0 &&
               !(*(ULONG *)((PUCHAR)context+0x210)&0x10u)) {
                *((PUCHAR)context+0x33)=command;
                *(ULONG *)((PUCHAR)context+0x210)|=0x10u;
            }
            unlock_context(context);ungate();return status;
        }
    }
    ungate();
    if(command==0)return STATUS_SUCCESS;
    wake(context);
    return STATUS_SUCCESS;
}

static NTSTATUS set_role(PVOID c)
{
    UCHAR role,cc;
    NTSTATUS status;
    lock_context(c);
    role=*((PUCHAR)c+0x2a);cc=*((PUCHAR)c+0x2d);
    unlock_context(c);
    if(gate()!=STATUS_SUCCESS)return STATUS_DEVICE_NOT_READY;
    RoleSettlingContext=NULL;RoleSettleUntil=0;
    ungate();
    status=OriginalRoleControl(c);
    if(status==STATUS_SUCCESS && !(role&0x40) &&
       ((role&3)==1 || ((role>>2)&3)==1) && !(cc&0x30) &&
       ((cc&3)==2 || ((cc>>2)&3)==2)) {
        if(gate()==STATUS_SUCCESS) {
            if(SkDriverActive==1 && WorkerThread==KeGetCurrentThread()) {
                RoleSettlingContext=c;
                RoleSettleUntil=KeQueryInterruptTime()+10000000ULL;
            }
            ungate();
            retry(c);
        }
    }
    return status;
}

/* The original6088 keeps Rp-current translation and real errors. Its mode
 * call arrives through a pinned leaf adapter passing6088's context in X21.
 * Re-locking an already measured source by writing1544=4 is followed by CC
 * loss in the saved trace. Like Qualcomm's Linux set_cc, leave the hardware
 * role in place for this same-role lock. Real new roles, uncertain/stale CC,
 * DRP/sink commands and5A20's detach recovery keep the original mode write.
 * This does not suppress detach, extend its deadline or bypass ADC safe0. */
NTSTATUS RepairRoleModeWrite(WDFIOTARGET target,ULONG mode,PVOID c)
{
    UCHAR cc,role;
    ULONG state;
    ULONGLONG now;
    BOOLEAN keep=FALSE;
    NTSTATUS status;
    if(!c)return STATUS_INVALID_PARAMETER;
    lock_context(c);
    cc=*((PUCHAR)c+0x2d);role=*((PUCHAR)c+0x2a);
    state=*(ULONG *)((PUCHAR)c+0x268);
    unlock_context(c);
    status=gate();if(status!=STATUS_SUCCESS)return status;
    if(!SkDriverActive || !SkPmicReady) {ungate();return STATUS_DEVICE_NOT_READY;}
    now=KeQueryInterruptTime();
    if(mode==4 && target==SkTypeCTarget && WorkerThread==KeGetCurrentThread() &&
       SourceSampleKnown && now>=LastSourceSample && now-LastSourceSample<=1000000ULL &&
       state==2 && !(role&0x40) && ((role&3)==1 || ((role>>2)&3)==1) &&
       !(cc&0x30) && ((cc&3)==2 || ((cc>>2)&3)==2))keep=TRUE;
    ungate();
    return keep?STATUS_SUCCESS:OriginalWriteTypeCMode(target,mode);
}

/* Only the40B0 snapshot-builder call to A160 is redirected here. Class
 * GET_STATUS continues to return the last genuine cached measurement;
 * no fabricated CC or VBUS value is written. Errors are propagated. A
 * fresh non-None orientation ends the guard immediately; a real detach
 * is published after the fixed deadline, which polling cannot extend. */
NTSTATUS RepairReadPortInfo(PVOID table,PULONG orientation,PULONG sink,PULONG source,
                           PVOID a,PVOID b,PVOID d,PVOID e)
{
    ULONG local_orientation=0,local_sink=0,local_source=0;
    UCHAR local_a=0,local_b=0,local_d=0,local_e=0;
    NTSTATUS status;
    PVOID context=NULL;
    if(!orientation || !sink || !source || !a || !b || !d || !e)return STATUS_INVALID_PARAMETER;
    status=OriginalReadPortInfo(table,&local_orientation,&local_sink,&local_source,
                                &local_a,&local_b,&local_d,&local_e);
    if(gate()!=STATUS_SUCCESS)return status==STATUS_SUCCESS?STATUS_DEVICE_NOT_READY:status;
    if(WorkerThread==KeGetCurrentThread()) {
        SnapshotSeen=1;SnapshotOrientation=(UCHAR)local_orientation;
        SnapshotStatus=status;
        SourceSampleKnown=(status==STATUS_SUCCESS &&
                          (local_orientation==1 || local_orientation==2) && local_sink==0 &&
                          (local_source==4 || local_source==5));
        LastSourceSample=SourceSampleKnown?KeQueryInterruptTime():0;
    }
    if(status!=STATUS_SUCCESS) {ungate();return status;}
    if(RoleSettlingContext && SkDriverActive==1 &&
       WorkerThread==KeGetCurrentThread()) {
        if(local_orientation==3 && KeQueryInterruptTime()<RoleSettleUntil)context=RoleSettlingContext;
        else {RoleSettlingContext=NULL;RoleSettleUntil=0;}
    }
    ungate();
    if(context) {retry(context);return STATUS_DEVICE_NOT_READY;}
    *orientation=local_orientation;*sink=local_sink;*source=local_source;
    *(PUCHAR)a=local_a;*(PUCHAR)b=local_b;*(PUCHAR)d=local_d;*(PUCHAR)e=local_e;
    return status;
}

/* The old 3550 discarded every handler failure by returning F988's success.
 * Keep failed bits pending and return the first failure. Source commands now
 * report acceptance of the worker intent; ADC returns an actual valid sample.
 * Existing PHY/PD handlers retain their original nonnegative acceptance ABI. */
NTSTATUS RepairExecutePending(PVOID c,ULONG mask)
{
    ULONG pending,accepted=0,voltage=0;
    USHORT encoded;
    NTSTATUS first=STATUS_SUCCESS,s,ack;
    if(!c)return STATUS_INVALID_PARAMETER;
    lock_context(c);pending=*(ULONG *)((PUCHAR)c+0x210)&mask;unlock_context(c);
#define EXECUTE(bit,call) do { if(pending&(bit)) {s=(call); if(NT_SUCCESS(s))accepted|=(bit); else if(first==STATUS_SUCCESS)first=s;} } while(0)
    EXECUTE(0x80,OriginalTransmit(c));
    EXECUTE(0x40,OriginalReceiveDetect(c));
    EXECUTE(0x20,OriginalMessageHeader(c));
    EXECUTE(0x08,OriginalPowerControl(c));
    EXECUTE(0x02,set_role(c));
    EXECUTE(0x01,OriginalTcpcControl(c));
    if(pending&4)accepted|=4; /* already copied software register */
    /* COMMAND was already consumed under its owning context lock. Sending
     * 0x10 to F988 here would erase a new command queued during this pass. */
    if(pending&0x10) {
        s=RepairCommand(c);
        if(!NT_SUCCESS(s) && first==STATUS_SUCCESS)first=s;
    }
    if(pending&0x100) {
        s=SkAdcReady?RepairReadAdc(SkAdcTarget,&voltage):STATUS_DEVICE_NOT_READY;
        if(s==STATUS_SUCCESS) {
            encoded=(USHORT)((voltage/25000u)&0x3ff);
            s=OriginalWriteVirtual(c,0x70,2,&encoded);
        }
        if(s==STATUS_SUCCESS)accepted|=0x100;
        else if(first==STATUS_SUCCESS)first=NT_SUCCESS(s)?STATUS_IO_DEVICE_ERROR:s;
    }
    ack=OriginalPendingAck(c,accepted);
    return first==STATUS_SUCCESS?ack:first;
#undef EXECUTE
}

/* One-shot wake only: no I/O, blocking gate or class callback at timer IRQL.
 * The role-settle retry needs the worker's hardware/status event338. Event350
 * alone drains pending commands and never refreshes a settled port when that
 * queue is empty. RepairDispatch processes power after either event, so one338
 * wake also retries power without doubling ADC attempts. Ordinary commands
 * retain350. Active clears before worker/timer drain. No new polling loop. */
VOID RepairSourceTimer(WDFTIMER timer)
{
    WDFOBJECT parent;
    PVOID context;
    parent=((PFN_WDFTIMERGETPARENTOBJECT)SkWdfTable[0xa08/8])(SkWdfGlobals,timer);
    context=((PFN_WDFOBJECTGETTYPEDCONTEXTWORKER)SkWdfTable[0x650/8])
        (SkWdfGlobals,parent,SkContextType);
    if(context && SkDriverActive==1) {
        KeSetEvent((PKEVENT)((PUCHAR)context+0x338),IO_NO_INCREMENT,FALSE);
    }
}

static VOID retry(PVOID c)
{
    ((PFN_WDFTIMERSTART)SkWdfTable[0x9f8/8])
        (SkWdfGlobals,*(WDFTIMER *)((PUCHAR)c+0x230),-1000000LL);
}

static VOID power_fault(PVOID c,NTSTATUS reason,ULONG epoch)
{
    PKTHREAD thread=KeGetCurrentThread();
    if(gate()!=STATUS_SUCCESS)return;
    if(!SkDriverActive || Epoch!=epoch || Pending || FaultThread) {
        ungate();return;
    }
    FaultThread=thread;FaultEpoch=epoch;
    ungate();
    /* Stock8AF8 calls patchedAF20 first. AF20 checks/consumes this token under
     * the same gate as PMIC I/O, including a newer command arriving here. */
    (void)OriginalSetPower(c,0);
    if(gate()!=STATUS_SUCCESS)return;
    if(FaultThread==thread && FaultEpoch==epoch)FaultThread=NULL;
    /* Stock completion can synchronously deliver an alert and accept a new
     * command. A result for the old generation must not fault that command. */
    if(!SkDriverActive || Epoch!=epoch || Pending) {ungate();return;}
    LastFault=reason;
    /* ADC/transport failure is not evidence of a TCPCI discharge, OCP, OVP
     * or external ForceOffVbus fault. Preserve FAULT_STATUS and ALERT.Fault.
     * Stock8AF8 already records confirmed OFF and wakes338 only on success;
     * its ordinary worker refreshes actual CC/POWER/OTG status. The caller
     * retains the real NTSTATUS. Do not fabricate a hardware fault or VBUS=0. */
    ungate();
}

static NTSTATUS process_power(PVOID c)
{
    ULONG epoch,voltage=MAXULONG;
    UCHAR on;
    NTSTATUS status=gate();
    if(status!=STATUS_SUCCESS)return status;
    if(!Pending || PendingContext!=c || !SkDriverActive) {ungate();return STATUS_SUCCESS;}
    epoch=PendingEpoch;on=Desired;
    ungate();
    status=STATUS_SUCCESS;
    if(on)status=SkAdcReady?RepairReadAdc(SkAdcTarget,&voltage):STATUS_DEVICE_NOT_READY;
    if(gate()!=STATUS_SUCCESS)return STATUS_DEVICE_NOT_READY;
    if(!SkDriverActive || !Pending || Epoch!=epoch || PendingEpoch!=epoch || Desired!=on) {
        ungate();return STATUS_CANCELLED;
    }
    if(on && (status!=STATUS_SUCCESS || voltage>800000)) {
        if(++Attempts<10) {ungate();retry(c);return STATUS_SUCCESS;}
        Pending=0;epoch=++Epoch;ungate();
        power_fault(c,status==STATUS_SUCCESS?STATUS_IO_TIMEOUT:status,epoch);
        return status==STATUS_SUCCESS?STATUS_IO_TIMEOUT:status;
    }
    ApplyingThread=KeGetCurrentThread();ApplyingEpoch=epoch;
    ungate();
    status=OriginalSetPower(c,on);
    if(gate()!=STATUS_SUCCESS)return STATUS_DEVICE_NOT_READY;
    ApplyingThread=NULL;
    if(PendingEpoch==epoch) {
        if(status==STATUS_SUCCESS)Pending=0;
        else if(++Attempts<10) {ungate();retry(c);return status;}
        else {Pending=0;epoch=++Epoch;ungate();power_fault(c,status,epoch);return status;}
    }
    ungate();return status;
}

/* Inserted at the actual FE40 system-thread dispatch call. */
NTSTATUS RepairDispatch(PVOID context)
{
    NTSTATUS original,power;
    BOOLEAN poll=FALSE,worker=FALSE;
    ULONGLONG now;
    if(context && gate()==STATUS_SUCCESS) {
        worker=(SkDriverActive==1 && WorkerThread==KeGetCurrentThread());
        if(worker)SnapshotSeen=0;
        ungate();
    }
    original=OriginalDispatch(context);
    if(worker && gate()==STATUS_SUCCESS) {
        if(SkDriverActive==1 && WorkerThread==KeGetCurrentThread()) {
            now=KeQueryInterruptTime();
            if(ResyncContext!=context) {
                ResyncContext=context;ResyncLastOrientation=0xff;
                ResyncRemaining=0;ResyncUntil=0;
            }
            if(SnapshotSeen && SnapshotStatus==STATUS_SUCCESS &&
               (SnapshotOrientation==1 || SnapshotOrientation==2)) {
                ResyncRemaining=0;ResyncUntil=0;
                ResyncLastOrientation=SnapshotOrientation;
            } else if(SnapshotSeen && SnapshotStatus==STATUS_SUCCESS &&
                      SnapshotOrientation==3 && ResyncLastOrientation!=3) {
                ResyncLastOrientation=3;ResyncRemaining=8;
                ResyncUntil=now+10000000ULL;poll=TRUE;
            } else if(ResyncRemaining && now<ResyncUntil) {
                --ResyncRemaining;poll=(ResyncRemaining!=0);
            } else {
                ResyncRemaining=0;ResyncUntil=0;
            }
        }
        ungate();
    }
    /* Worker/context remain owned until stop joins this thread. Timer callback
     * only wakes338; all PMIC access occurs in the ordinary passive worker.
     * Same100ms interval as existing safe0/role retries, never a periodic timer. */
    if(poll)retry(context);
    /* A state entry can fail after a successful CC/POWER snapshot. Stock
     * 10C68 then exits before FAD8/10E48, leaving UcmTcpciCx with the old
     * attachment until another hardware event. Publish only the stock
     * cached-status delta; do not retry PD, invent a reading, or mask the
     * original error. FE40 owns this context until Stop joins its thread.
     * No PowerGate is held across the synchronous class callback. */
    if(context && !NT_SUCCESS(original) && SkDriverActive==1 &&
       KeGetCurrentIrql()==PASSIVE_LEVEL) {
        if(NT_SUCCESS(OriginalBuildStatusAlerts(context)) && SkDriverActive==1)
            OriginalPublishAlerts(context);
    }
    power=process_power(context);
    return original!=STATUS_SUCCESS?original:power;
}

/* Hooked into FE40's first KeGetCurrentThread call, before any class alert. */
PKTHREAD RepairThreadIdentity(VOID)
{
    PKTHREAD thread=KeGetCurrentThread();
    /* The constructor invalidates the old stop latch BEFORE thread creation.
     * A delayed first worker instruction must not decide restart ownership. */
    if(gate()==STATUS_SUCCESS) {WorkerThread=thread;ungate();}
    return thread;
}

#include "start_stop.inc"
