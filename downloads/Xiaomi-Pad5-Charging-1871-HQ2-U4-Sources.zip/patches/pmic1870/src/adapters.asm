        AREA |.text|, CODE, READONLY, ALIGN=2
        IMPORT SkHostQuietApply
        IMPORT NativeReadTarget
        IMPORT NativeUpdateTarget
        IMPORT NativeProviderGlobal
        IMPORT NativeTraceTarget
        IMPORT NativeWppControl
        IMPORT NativeWppLogger
        IMPORT NativeWppGuid
        IMPORT HqIrqlIat
        EXPORT HeaderAdapter
        EXPORT ReadAdapter
        EXPORT NativeRead
        EXPORT NativeUpdate
        EXPORT NativeProvider
        EXPORT NativeIrql
        EXPORT NativeEvent
        EXPORT _InterlockedCompareExchange
        EXPORT _InterlockedExchange
HeaderAdapter
        mov w0,w20
        mov w1,#0x1740
        mov w2,#1
        b SkHostQuietApply
ReadAdapter
        csel w0,w8,wzr,ne
        cbnz w0,ReadReturn
        lsr w0,w19,#16
        and w1,w19,#0xffff
        mov w2,#0
        b SkHostQuietApply
ReadReturn
        ret
NativeRead
        b NativeReadTarget
NativeUpdate
        b NativeUpdateTarget
NativeProvider
        adrp x8,NativeProviderGlobal
        ldr x0,[x8,NativeProviderGlobal]
        ret
NativeIrql
        adrp x8,HqIrqlIat
        ldr x16,[x8,HqIrqlIat]
        br x16
NativeEvent
        adrp x8,NativeWppControl
        add x9,x8,NativeWppControl
        ldr x8,[x9]
        cmp x8,x9
        b.eq EventReturn
        mov w3,w0
        adrp x8,NativeWppLogger
        ldr x8,[x8,NativeWppLogger]
        cbz x8,EventReturn
        ldr x0,[x8,#0x40]
        mov w1,#4
        mov w2,#2
        adrp x4,NativeWppGuid
        add x4,x4,NativeWppGuid
        b NativeTraceTarget
EventReturn
        ret
_InterlockedCompareExchange
CompareRetry
        ldaxr w8,[x0]
        cmp w8,w2
        b.ne CompareMismatch
        stlxr w9,w1,[x0]
        cbnz w9,CompareRetry
        mov w0,w8
        ret
CompareMismatch
        clrex
        mov w0,w8
        ret
_InterlockedExchange
ExchangeRetry
        ldaxr w8,[x0]
        stlxr w9,w1,[x0]
        cbnz w9,ExchangeRetry
        mov w0,w8
        ret
        END
