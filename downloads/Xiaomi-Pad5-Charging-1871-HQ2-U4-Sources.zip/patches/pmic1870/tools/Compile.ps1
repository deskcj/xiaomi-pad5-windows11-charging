$ErrorActionPreference='Stop'
$skRoot=Split-Path -Parent $PSScriptRoot
$skCompiler='H:\Vlad\EWDK\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207\bin\Hostarm64\arm64'
$skKit='H:\Vlad\EWDK\Program Files\Windows Kits\10'
$skInclude=@('/external:W0','/analyze:external-',
 '/external:IH:\Vlad\EWDK\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207\include',
 "/external:I$skKit\Include\10.0.26100.0\km","/external:I$skKit\Include\10.0.26100.0\shared","/external:I$skKit\Include\10.0.26100.0\ucrt")
& "$skCompiler\cl.exe" /nologo /c /TC /kernel /GS /guard:cf /O2 /Oi /W4 /WX /analyze /Zl /D_ARM64_ /DARM64 @skInclude "$skRoot\src\hostquiet.c" "/Fo$skRoot\build\hostquiet.obj" *> "$skRoot\build\compile.log"
if($LASTEXITCODE){Get-Content -LiteralPath "$skRoot\build\compile.log";throw 'HostQuiet kernel compilation failed'}
& "$skCompiler\armasm64.exe" -nologo -o "$skRoot\build\adapters.obj" "$skRoot\src\adapters.asm" *> "$skRoot\build\asm.log"
if($LASTEXITCODE){Get-Content -LiteralPath "$skRoot\build\asm.log";throw 'HostQuiet adapters failed'}
