$ErrorActionPreference='Stop'
$skRoot=Split-Path -Parent $PSScriptRoot
$skVc='H:\Vlad\EWDK\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207'
$skKit='H:\Vlad\EWDK\Program Files\Windows Kits\10'
& "$skVc\bin\Hostarm64\arm64\cl.exe" /nologo /TC /O2 /W4 /WX /MT "/I$skVc\include" "/I$skKit\Include\10.0.26100.0\um" "/I$skKit\Include\10.0.26100.0\shared" "/I$skKit\Include\10.0.26100.0\ucrt" "$skRoot\tests\native_unwind.c" "/Fo$skRoot\build\native_unwind.obj" "/Fe$skRoot\build\native_unwind.exe" /link "/LIBPATH:$skVc\lib\arm64" "/LIBPATH:$skKit\Lib\10.0.26100.0\um\arm64" "/LIBPATH:$skKit\Lib\10.0.26100.0\ucrt\arm64" *> "$skRoot\build\native-compile.log"
if($LASTEXITCODE){Get-Content -LiteralPath "$skRoot\build\native-compile.log";throw 'Native unwind helper compilation failed'}
& "$skRoot\build\native_unwind.exe" "$skRoot\build\qcpmicext8150.sys" "$skRoot\build\unwind-fixtures.bin" > "$skRoot\build\native.json"
if($LASTEXITCODE){Get-Content -LiteralPath "$skRoot\build\native.json";throw 'Native unwind validation failed'}
Get-Content -LiteralPath "$skRoot\build\native.json"
