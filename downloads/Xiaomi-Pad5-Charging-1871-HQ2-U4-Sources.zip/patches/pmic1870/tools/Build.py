"""Map checked ARM64 COFF objects into the pinned working image.

Only the two hook words change in old mapped sections. New W^X sections
contain code, state/IAT, and read-only xdata/pdata/import metadata. Native
runtime functions (including compiler fragments) are merged and sorted.
Unknown relocations, external symbols or allocated sections fail closed.
"""
import hashlib,json,struct,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'offline-deps'))
import pefile
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_ARM
sha=lambda x:hashlib.sha256(x).hexdigest().upper()
align=lambda x,a:(x+a-1)//a*a
def sext(x,n): return x-(1<<n) if x&(1<<(n-1)) else x

class Coff:
    def __init__(self,path):
        self.path=path; b=path.read_bytes(); self.bytes=b
        machine,n,_,so,ns,opt,_=struct.unpack_from('<HHIIIHH',b)
        assert machine==0xaa64 and opt==0
        st=b[so+18*ns:]
        def name(x):
            return (st[struct.unpack_from('<I',x,4)[0]:].split(b'\0',1)[0].decode()
                    if x[:4]==bytes(4) else x.rstrip(b'\0').decode())
        self.sections=[]
        for i in range(n):
            nm,vs,_,sz,ptr,rp,_,nr,_,flags=struct.unpack_from('<8sIIIIIIHHI',b,20+i*40)
            # BSS is represented with a size but no raw bytes.
            data=bytearray(b[ptr:ptr+sz] if ptr else bytes(sz))
            self.sections.append(dict(name=name(nm),data=data,flags=flags,
                rel=[struct.unpack_from('<IIH',b,rp+j*10) for j in range(nr)]))
        self.symbols={};i=0
        while i<ns:
            nm,v,s,t,c,a=struct.unpack_from('<8sIhHBB',b,so+i*18)
            self.symbols[i]=dict(name=name(nm),value=v,section=s,storage=c)
            i+=a+1

raw=(R/'reference/qcpmicext8150.sys').read_bytes()
assert sha(raw)=='0F17DEB53590BD84E16F7EED372F592FEAAA5B00F59443E0DA99479C572316AE'
p=pefile.PE(data=raw); assert p.FILE_HEADER.Machine==0xaa64
objs=[Coff(R/'build/adapters.obj'),Coff(R/'build/hostquiet.obj')]
groups={'code':bytearray(),'data':bytearray(),'unwind':bytearray()}
rvas={'code':align(p.OPTIONAL_HEADER.SizeOfImage,4096)}
mapped=[]
for o in objs:
    for i,s in enumerate(o.sections):
        nm=s['name']
        if nm.startswith('.text'):g='code';a=4
        elif nm in ('.data','.bss'):g='data';a=8
        elif nm in ('.pdata','.xdata','.rdata'):g='unwind';a=4
        else:
            assert nm in ('.debug$S','.drectve','.chks64','.gfids$y','.giats$y','.gljmp$y'),nm
            # No new indirect C targets: guard lists must be empty.
            if nm.startswith(('.gfid','.giat','.gljmp')):assert not s['data']
            assert not s['rel'],nm
            continue
        off=align(len(groups[g]),a);groups[g].extend(bytes(off-len(groups[g]))+s['data'])
        s.update(group=g,offset=off);mapped.append((o,i+1,s))
commons={}
for o in objs:
    for s in o.symbols.values():
        if s['section']==0 and s['storage']==2 and s['value']:
            assert s['name'] not in commons
            off=align(len(groups['data']),16)
            groups['data'].extend(bytes(off-len(groups['data'])+s['value']))
            commons[s['name']]=off
rvas['data']=align(rvas['code']+len(groups['code']),4096)
rvas['unwind']=align(rvas['data']+len(groups['data'])+16,4096)
iatOff=align(len(groups['data']),8)
groups['data'].extend(bytes(iatOff-len(groups['data']))+bytes(16))
external={'NativeReadTarget':0xb858,'NativeUpdateTarget':0xb7d8,
 'NativeProviderGlobal':0xd508,'NativeTraceTarget':0x1510,
 'NativeWppControl':0xd098,'NativeWppLogger':0xd090,'NativeWppGuid':0xc340,
 'HqIrqlIat':rvas['data']+iatOff}
external.update({k:rvas['data']+v for k,v in commons.items()})
symout={}
for o,idx,s in mapped: s['rva']=rvas[s['group']]+s['offset']
for o in objs:
    for s in o.symbols.values():
        if s['section']>0:
            sec=o.sections[s['section']-1]
            if 'rva' in sec and s['storage']==2:
                assert s['name'] not in external,s['name']
                external[s['name']]=sec['rva']+s['value']
        if s['section']>0 and 'rva' in o.sections[s['section']-1]:
            if s['storage'] in (2,3) and not s['name'].startswith('.'):
                symout[o.path.stem+':'+s['name']]=o.sections[s['section']-1]['rva']+s['value']
proof=[]
for o,idx,s in mapped:
    data=s['data']
    for off,si,typ in s['rel']:
        sy=o.symbols[si]
        if sy['section']>0: target=o.sections[sy['section']-1]['rva']+sy['value']
        elif sy['section']==-1: target=sy['value']
        else: target=external[sy['name']]
        site=s['rva']+off;ins=struct.unpack_from('<I',data,off)[0]
        if typ==3: # BRANCH26
            assert ins&0x7c000000==0x14000000
            delta=target+sext(ins&0x3ffffff,26)*4-site
            assert delta%4==0 and -(1<<27)<=delta<(1<<27)
            new=(ins&0xfc000000)|((delta//4)&0x3ffffff)
        elif typ==4: # PAGEBASE_REL21
            assert ins&0x9f000000==0x90000000
            # COFF PAGEBASE addend is a byte offset encoded in the ADRP
            # immediate fields, not an already-linked page displacement.
            addend=sext(((ins>>29)&3)|(((ins>>5)&0x7ffff)<<2),21)
            delta=(target+addend)//4096-site//4096
            assert -(1<<20)<=delta<(1<<20)
            new=(ins&~0x60ffffe0)|((delta&3)<<29)|(((delta>>2)&0x7ffff)<<5)
        elif typ==6: # PAGEOFFSET_12A
            assert ins&0x7f000000==0x11000000 and not ins&0x400000
            offset=(target+(ins>>10&0xfff))&0xfff
            new=(ins&~0x3ffc00)|(offset<<10)
        elif typ==7: # PAGEOFFSET_12L
            assert ins&0x3b000000==0x39000000
            scale=ins>>30
            offset=(target+((ins>>10&0xfff)<<scale))&0xfff
            assert offset%(1<<scale)==0
            new=(ins&~0x3ffc00)|((offset>>scale)<<10)
        elif typ==2: # ADDR32NB
            new=target+ins;assert new<1<<32
        else: raise AssertionError(('unsupported relocation',typ,sy))
        struct.pack_into('<I',data,off,new)
        proof.append(dict(Object=o.path.name,RVA=site,Type=typ,Symbol=sy['name'],Target=target))
    g=groups[s['group']];g[s['offset']:s['offset']+len(data)]=data

# Merge the original and new runtime functions. Fragment unwind flag2
# remains exactly as emitted by MSVC; no guessed prolog or stack records.
dd=p.OPTIONAL_HEADER.DATA_DIRECTORY[3]
entries=[struct.unpack_from('<II',p.get_data(dd.VirtualAddress,dd.Size),i) for i in range(0,dd.Size,8)]
for o,idx,s in mapped:
    if s['name']=='.pdata':entries += [struct.unpack_from('<II',s['data'],i) for i in range(0,len(s['data']),8)]
entries.sort(); assert len({e[0] for e in entries})==len(entries)
u=groups['unwind']
def append(data,a=4):
    off=align(len(u),a);u.extend(bytes(off-len(u))+data);return rvas['unwind']+off
pd=append(b''.join(struct.pack('<II',*e) for e in entries),4)
# Append a standard HAL import while retaining every old descriptor and IAT.
hint=append(b'\0\0KeGetCurrentIrql\0',2)
hal=append(b'HAL.dll\0',1)
ilt=append(struct.pack('<QQ',hint,0),8)
struct.pack_into('<Q',groups['data'],iatOff,hint)
id=p.OPTIONAL_HEADER.DATA_DIRECTORY[1]
oldimports=p.get_data(id.VirtualAddress,id.Size)
assert oldimports[-20:]==bytes(20)
imports=append(oldimports[:-20]+struct.pack('<IIIII',ilt,0,0,hal,external['HqIrqlIat'])+bytes(20),4)
header=p.sections[0].get_file_offset()+len(p.sections)*40
assert header+120<=p.OPTIONAL_HEADER.SizeOfHeaders and raw[header:header+120]==bytes(120)
end=max(s.PointerToRawData+s.SizeOfRawData for s in p.sections)
out=bytearray(raw[:end]);md=Cs(CS_ARCH_ARM64,CS_MODE_ARM)
hooks=[]
for site,nm,mn,op in [(0x6c44,'HeaderAdapter','mov','w0, #0'),(0xb8b4,'ReadAdapter','csel','w0, w8, wzr, ne')]:
    old=p.get_data(site,4);ix=list(md.disasm(old,site));assert len(ix)==1 and (ix[0].mnemonic,ix[0].op_str)==(mn,op)
    d=external[nm]-site;assert d%4==0 and -(1<<27)<=d<(1<<27)
    new=struct.pack('<I',0x94000000|((d//4)&0x3ffffff))
    off=p.get_offset_from_rva(site);out[off:off+4]=new
    hooks.append(dict(RVA=site,Target=external[nm],Before=old.hex(),After=new.hex()))
specs=[('code',b'.skhq',0x60000020),('data',b'.skhqd',0xc0000040),('unwind',b'.skhqu',0x40000040)]
added=[]
for n,(g,nm,flags) in enumerate(specs):
    payload=groups[g];ptr=align(len(out),512);size=align(len(payload),512)
    out.extend(bytes(ptr-len(out))+payload+bytes(size-len(payload)))
    out[header+n*40:header+(n+1)*40]=struct.pack('<8sIIIIIIHHI',nm,len(payload),rvas[g],size,ptr,0,0,0,0,flags)
    added.append(dict(Name=nm.decode(),RVA=rvas[g],Length=len(payload),Characteristics=flags))
struct.pack_into('<H',out,p.FILE_HEADER.get_field_absolute_offset('NumberOfSections'),len(p.sections)+3)
def opt(k,v):struct.pack_into('<I',out,p.OPTIONAL_HEADER.get_field_absolute_offset(k),v)
def directory(n,a,s):struct.pack_into('<II',out,p.OPTIONAL_HEADER.DATA_DIRECTORY[n].get_file_offset(),a,s)
opt('SizeOfImage',align(rvas['unwind']+len(u),4096))
opt('SizeOfCode',p.OPTIONAL_HEADER.SizeOfCode+align(len(groups['code']),512))
opt('SizeOfInitializedData',p.OPTIONAL_HEADER.SizeOfInitializedData+align(len(groups['data']),512)+align(len(u),512))
directory(1,imports,len(oldimports)+20);directory(3,pd,len(entries)*8);directory(4,0,0)
# Existing IAT directory cannot describe discontiguous old/new tables.
# The loader uses import descriptors; a zero IAT directory is legal.
directory(12,0,0)
opt('CheckSum',0);opt('CheckSum',pefile.PE(data=bytes(out)).generate_checksum())
q=pefile.PE(data=bytes(out));assert q.verify_checksum()
changed=[]
for s in p.sections:
    before=s.get_data();after=q.get_data(s.VirtualAddress,len(before))
    changed.extend(s.VirtualAddress+i for i in range(0,len(before),4) if before[i:i+4]!=after[i:i+4])
assert changed==[0x6c44,0xb8b4],changed
for n in range(16):
    if n in (1,3,4,12):continue
    a=p.OPTIONAL_HEADER.DATA_DIRECTORY[n];b=q.OPTIONAL_HEADER.DATA_DIRECTORY[n]
    assert (a.VirtualAddress,a.Size)==(b.VirtualAddress,b.Size)
    assert p.get_data(a.VirtualAddress,a.Size)==q.get_data(a.VirtualAddress,a.Size)
for a,b in zip(p.DIRECTORY_ENTRY_IMPORT,q.DIRECTORY_ENTRY_IMPORT):
    assert a.dll==b.dll
    assert [(i.name,i.ordinal,i.address) for i in a.imports]==[(i.name,i.ordinal,i.address) for i in b.imports]
assert q.DIRECTORY_ENTRY_IMPORT[-1].dll==b'HAL.dll'
assert [i.name for i in q.DIRECTORY_ENTRY_IMPORT[-1].imports]==[b'KeGetCurrentIrql']
assert q.OPTIONAL_HEADER.AddressOfEntryPoint==p.OPTIONAL_HEADER.AddressOfEntryPoint
assert not any(s.Characteristics&0x20000000 and s.Characteristics&0x80000000 for s in q.sections)
(R/'build/qcpmicext8150.sys').write_bytes(out)
report=dict(Build=1870,Name='1870-HQ1',InputSHA256=sha(raw),UnsignedSHA256=sha(out),Hooks=hooks,
 NewSections=added,Symbols=external,LocalSymbols=symout,Relocations=proof,RuntimeFunctions=entries,
 OldChangedWords=changed,AddedImport='HAL.dll!KeGetCurrentIrql',NativeMasks=[['0x1358','0x80'],['0x1362','0x08']],
 Prior1869FixesRetained=True,PD013Changed=False,HardwareAccepted=False,Installed=False)
(R/'build/build.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('Relocations','RuntimeFunctions','LocalSymbols','Symbols')},indent=2))
