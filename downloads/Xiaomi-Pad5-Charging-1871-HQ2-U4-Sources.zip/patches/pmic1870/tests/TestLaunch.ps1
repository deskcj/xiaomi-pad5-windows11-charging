$ErrorActionPreference='Stop'
$skRoot=Split-Path -Parent $PSScriptRoot
$skTest=Join-Path $skRoot ('build\cmd bridge test '+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $skTest|Out-Null
$skStandIn=@'
param([string]$Action)
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'action.txt'),$Action)
if($Action -eq 'Restore'){exit 7}
exit 0
'@
[IO.File]::WriteAllText((Join-Path $skTest 'Launch.ps1'),$skStandIn,[Text.UTF8Encoding]::new($true))
$skResults=@()
foreach($skAction in @('Install','Verify','Diagnose','Restore')){
 $skCmd=Join-Path $skTest ($skAction+'.cmd')
 Copy-Item -LiteralPath (Join-Path $skRoot ($skAction+'.cmd')) -Destination $skCmd
 $skProcess=Start-Process -FilePath $env:ComSpec -ArgumentList ('/d /c ""'+$skCmd+'""') -WindowStyle Hidden -Wait -PassThru
 $skActual=[IO.File]::ReadAllText((Join-Path $skTest 'action.txt'))
 $skExit=if($skAction -eq 'Restore'){7}else{0}
 if($skActual -cne $skAction -or $skProcess.ExitCode -ne $skExit){throw 'Real CMD bridge action/exit propagation failed'}
 $skResults+=@{Action=$skAction;RecordedAction=$skActual;ExitCode=$skProcess.ExitCode}
}
@{Passed=$true;Cases=$skResults;DriverMutations=$false;ElevationMutations=$false}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $skRoot 'build\cmd-qa.json') -Encoding UTF8
'Four real CMD bridges passed with a stand-in PowerShell launcher, including exit7 and a path containing spaces.'
