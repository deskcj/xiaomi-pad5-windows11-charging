        AREA |.text|, CODE, READONLY, ALIGN=2
        EXPORT AiclCurrentMilliamps
        EXPORT AiclStatusComplete
        EXPORT AiclStatusEnd
; Called in the existing dispatcher frame. X19 is the 12-byte response.
; W8 is the completed single-byte SPMI read. Preserve args X0..X4, SP,
; nonvolatile registers and NZCV; use only volatile W16. No hardware I/O.
AiclCurrentMilliamps PROC
        mov w16, #50
        mul w16, w8, w16
        str w16, [x19, #4]
        ret
        ENDP
AiclStatusComplete PROC
        and w16, w8, #1
        str w16, [x19]
        str wzr, [x19, #8]
        ret
        ENDP
AiclStatusEnd
        END
