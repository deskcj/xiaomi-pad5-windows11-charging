"""Execute PMIC dispatcher + original battery wrapper/control ARM64 bodies.

SPMI, WDF descriptor forwarding and sensor calls are simulated. Original
code executes in Unicorn, never loaded into Windows. Native unwind fixture
records cover the two new leaves and their real dispatcher caller.
"""
import hashlib, itertools, json, struct, sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R.parent/'offline-deps'))
import pefile
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE,UC_HOOK_MEM_WRITE
from unicorn.arm64_const import *
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_ARM
manifest=json.loads((R/'build/build.json').read_text())
STACK=0x207000;SP=STACK+0x1000;END=0x60000000;MEM=0x50000000
fixtures={}
class Replay:
    def __init__(self,fixed,base=0x140000000,*,raw=30,flags=1,fail=0,poison=0,
                 wrapper=False,control=False,budget=4000,percent=100,voltage=12000,
                 status_state=3,system_status=4,sensor_error=0):
        self.fixed=fixed;self.base=base;self.raw=raw;self.flags=flags;self.fail=fail
        self.wrapper=wrapper or control;self.control=control;self.poison=poison
        self.sensor_error=sensor_error;self.voltage=voltage
        self.calls=[];self.path=[];self.writes=[];self.forwarded=[]
        path=R/('build' if fixed else 'reference')/'qcpmicext8150.sys'
        p=pefile.PE(str(path));p.relocate_image(base)
        self.u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
        self.u.mem_map(base,(p.OPTIONAL_HEADER.SizeOfImage+4095)&~4095)
        self.u.mem_write(base,p.get_memory_mapped_image())
        for at,length in ((STACK,0x2000),(MEM,0x10000),(END,0x1000)):
            self.u.mem_map(at,length)
        self.q(base+0xd098,base+0xd098)
        self.out=MEM+0x1000;self.input=MEM+0x2000;self.ctx=MEM+0x3000
        self.count=MEM+0x4000
        self.u.mem_write(self.out,bytes([poison])*32)
        self.u.mem_write(self.input,struct.pack('<I',1))
        self.u.reg_write(UC_ARM64_REG_SP,SP)
        self.expected={UC_ARM64_REG_X19+i:0xabc0000000000000+i for i in range(10)}
        self.expected.update({UC_ARM64_REG_FP:0xabc1234567890000,UC_ARM64_REG_X18:0xabcdef9876543210})
        for reg,val in self.expected.items():self.u.reg_write(reg,val)
        self.u.reg_write(UC_ARM64_REG_LR,END)
        self.qbase=0x1a0000000
        self.qspans={}
        if self.wrapper:
            qp=pefile.PE(str(R.parent/'reference/qcbatt1868-active.sys'))
            qp.relocate_image(self.qbase)
            self.u.mem_map(self.qbase,(qp.OPTIONAL_HEADER.SizeOfImage+4095)&~4095)
            self.u.mem_write(self.qbase,qp.get_memory_mapped_image())
            self.q(self.qbase+0x28168,MEM+0x5000)
            self.q(self.qbase+0x28958,MEM+0x6000)
            self.q(MEM+0x6000+0x5d0,END+0x100)
            self.q(self.qbase+0x26110,END+0x110)
            self.d(self.qbase+0x291f4,status_state)
            self.d(self.qbase+0x291c8,budget)
            self.d(self.qbase+0x291f8,percent)
            self.d(self.qbase+0x291e0,5000)
            self.q(self.qbase+0x291b0,self.ctx)
            # Security cookie helpers are real code, including SP changes.
            for a,l in ((0x1050,24),(0x1068,36),(0x21280,292),(0x206b0,880)):
                self.qspans[a]=l
            self.system_status=system_status
        self.u.hook_add(UC_HOOK_CODE,self.hook)
        self.u.hook_add(UC_HOOK_MEM_WRITE,self.write)
    def d(self,at,v):self.u.mem_write(at,struct.pack('<I',v&0xffffffff))
    def q(self,at,v):self.u.mem_write(at,struct.pack('<Q',v))
    def args(self):return [self.u.reg_read(UC_ARM64_REG_X0+i) for i in range(8)]
    def ret(self,status=0):
        lr=self.u.reg_read(UC_ARM64_REG_LR)
        for i in range(18):self.u.reg_write(UC_ARM64_REG_X0+i,0xcccccccccccccccc)
        self.u.reg_write(UC_ARM64_REG_W0,status&0xffffffff)
        self.u.reg_write(UC_ARM64_REG_PC,lr)
    def write(self,u,access,at,size,value,_):self.writes.append((at,size,value))
    def hook(self,u,at,size,_):
        if at==END:u.emu_stop();return
        rva=at-self.base
        if at==self.base+0x5ae0:
            x=self.args();reg=x[2]
            assert reg in (0x1108,0x110a),hex(reg)
            assert x[0]==self.ctx+0xe8
            self.calls.append(reg)
            status=0xc0000185 if len(self.calls)==self.fail else 0
            if not status:u.mem_write(x[3],bytes([self.raw if reg==0x1108 else self.flags]))
            self.ret(status);return
        if at==END+0x110:
            assert u.reg_read(UC_ARM64_REG_X15)==END+0x100
            self.ret();return
        if at==END+0x100:
            x=self.args()
            assert x[3]==0x801b0fd8,hex(x[3])
            def desc(at):
                typ,pad,ptr,n=struct.unpack('<IIQQ',bytes(u.mem_read(at,24)))
                assert typ==1 and pad==0
                return ptr,n
            ip,ilen=desc(x[4]);op,olen=desc(x[5])
            assert ilen==4 and olen==12
            # Simulated transport must expose original incomplete outputs;
            # all three fields are poisoned before running the dispatcher.
            u.mem_write(op,bytes([self.poison])*12)
            self.forwarded.append(dict(IOCTL=hex(x[3]),InputBytes=ilen,OutputBytes=olen))
            for reg,value in zip((UC_ARM64_REG_X0+i for i in range(7)),
                                 (self.ctx,x[3],ip,ilen,op,olen,x[7])):
                u.reg_write(reg,value)
            u.reg_write(UC_ARM64_REG_PC,self.base+0x2800);return
        if self.control and at==self.qbase+0xc5b8:
            x=self.args()
            assert bytes(u.mem_read(x[0],7))==b'USB_IN\0'
            if not self.sensor_error:self.d(x[1],self.voltage)
            self.ret(self.sensor_error);return
        if self.control and at==self.qbase+0x21168:
            x=self.args();self.d(x[1],self.system_status);self.ret();return
        allowed=0x2800<=rva<0x3050 or manifest['LeafLow']<=rva<manifest['LeafHigh']
        if self.wrapper:
            allowed|=any(self.qbase+a<=at<self.qbase+a+l for a,l in self.qspans.items())
        assert allowed,hex(at)
        self.path.append(at)
        if self.fixed and not self.wrapper and self.base==0x140000000:
            sp=u.reg_read(UC_ARM64_REG_SP)
            regs=[u.reg_read(UC_ARM64_REG_X0+i) for i in range(29)]
            regs += [u.reg_read(UC_ARM64_REG_FP),u.reg_read(UC_ARM64_REG_LR)]
            key=(rva,sp,tuple(regs[18:]))
            if key not in fixtures:
                fixtures[key]=(rva,sp-STACK,regs,bytes(u.mem_read(STACK,0x2000)))
    def call(self):
        u=self.u
        if self.wrapper:
            entry=self.qbase+(0x206b0 if self.control else 0x21280)
            x=(self.ctx,self.out,self.out+4)
        else:
            entry=self.base+0x2800
            x=(self.ctx,0x801b0fd8,self.input,4,self.out,12,self.count)
        for i,v in enumerate(x):u.reg_write(UC_ARM64_REG_X0+i,v)
        u.emu_start(entry,END+4,count=20000)
        assert u.reg_read(UC_ARM64_REG_PC)==END and u.reg_read(UC_ARM64_REG_SP)==SP
        assert all(u.reg_read(reg)==v for reg,v in self.expected.items())
        assert all(STACK<=a<STACK+0x2000 or MEM<=a<MEM+0x10000 or (
            self.control and self.qbase+0x291b0<=a<self.qbase+0x29210) for a,_,_ in self.writes)
        status=u.reg_read(UC_ARM64_REG_W0)
        fields=list(struct.unpack('<III',bytes(u.mem_read(self.out,12))))
        budget=struct.unpack('<I',bytes(u.mem_read(self.qbase+0x291e0,4)))[0] if self.control else None
        return dict(Status=hex(status),Fields=fields,Reads=[hex(v) for v in self.calls],
                    Forwarded=self.forwarded,ChargeBudget_mA=budget)

def main():
    rows=[];counts={};defects=0
    # Decode every possible status byte and physical ICL boundary values,
    # at two image bases with clean and poisoned caller buffers.
    vectors=[(30,f) for f in range(256)]+[(r,f) for r in (0,1,2,9,10,18,20,29,31,40,59,60,61,120,255)
                                                    for f in (0,1,0x40,0x41,0xff)]
    for base,poison,(raw,flags) in itertools.product((0x140000000,0x180000000),(0,0xaa),vectors):
        v=Replay(True,base,raw=raw,flags=flags,poison=poison).call()
        assert v['Status']=='0x0' and v['Fields']==[flags&1,raw*50,0]
        assert v['Reads']==['0x1108','0x110a']
        rows.append(dict(Kind='Dispatcher',Base=hex(base),Raw=raw,Flags=flags,Poison=poison,**v))
    counts['Dispatcher']=len(rows)
    for fixed,base,fail,poison in itertools.product((False,True),(0x140000000,0x180000000),(1,2),(0,0xaa)):
        v=Replay(fixed,base,fail=fail,poison=poison,wrapper=True).call()
        assert v['Status']=='0xc0000001' and v['Fields'][:2]==[poison*0x1010101]*2
        rows.append(dict(Kind='WrapperError',Fixed=fixed,Fail=fail,**v))
    counts['WrapperError']=16
    for base,poison,raw,flags in itertools.product((0x140000000,0x180000000),(0,0xaa),(0,1,10,30,40,60),(0,1,0x40,0x41)):
        v=Replay(True,base,raw=raw,flags=flags,poison=poison,wrapper=True).call()
        assert v['Status']=='0x0' and v['Fields'][0]&255==flags&1 and v['Fields'][1]==raw*50
        # Wrapper contract is a BYTE done flag + DWORD current. It must not
        # write the three bytes following that flag or unrelated outputs.
        assert v['Fields'][0]>>8==poison*0x10101 and v['Fields'][2]==poison*0x1010101
        rows.append(dict(Kind='OriginalBatteryWrapper',**v))
    counts['OriginalBatteryWrapper']=192
    for flags,poison in itertools.product((0,1,0x40,0x41),(0,0xaa)):
        old=Replay(False,flags=flags,poison=poison,wrapper=True).call()
        new=Replay(True,flags=flags,poison=poison,wrapper=True).call()
        assert old!=new
        if poison==0:assert old['Fields'][:2]==[0,flags] and old['Status']=='0x0'
        else:assert old['Status']=='0xc0000001'
        defects+=1;rows.append(dict(Kind='OriginalDefect',Reference=old,Candidate=new))
    counts['OriginalDefect']=8
    for raw,flags,budget,percent,voltage in itertools.product((10,30,60),(1,0x41),(1000,6000),(0,50,100),(5000,9000,12000)):
        v=Replay(True,raw=raw,flags=flags,control=True,budget=budget,percent=percent,voltage=voltage).call()
        expected=min(5000,budget*percent//100)
        if budget*percent:expected=min(expected,voltage*(raw*50)//4450)
        expected=expected//25*25
        assert v['Status']=='0x0' and v['ChargeBudget_mA']==expected,(v,expected)
        rows.append(dict(Kind='OriginalChargePolicy',**v))
    counts['OriginalChargePolicy']=108
    for fixed in (False,True):
        v=Replay(fixed,raw=30,flags=1,control=True,budget=6000,voltage=12000).call()
        assert v['ChargeBudget_mA']==(4025 if fixed else 0),v
        rows.append(dict(Kind='ChargePolicyCounterexample',Fixed=fixed,**v))
    counts['ChargePolicyCounterexample']=2
    # Existing thermal states/error behavior and zero allocation are retained.
    for state,supply,fault in ((2,4,0),(2,0,0),(4,4,0),(3,4,0xc0000185)):
        old=Replay(False,control=True,status_state=state,system_status=supply,sensor_error=fault).call()
        new=Replay(True,control=True,status_state=state,system_status=supply,sensor_error=fault).call()
        assert old['Status']==new['Status'] and old['ChargeBudget_mA']==new['ChargeBudget_mA']
        rows.append(dict(Kind='PolicyRegression',State=state,**new))
    counts['PolicyRegression']=4
    with (R/'build/aicl-unwind.bin').open('wb') as f:
        f.write(struct.pack('<II',0x3257444e,len(fixtures)))
        for rva,sp,regs,memory in fixtures.values():
            expected=[0xabc0000000000000+i for i in range(10)]+[0xabc1234567890000,0xabcdef9876543210]
            f.write(struct.pack('<II31Q',rva,sp,*regs)+memory+struct.pack('<12Q',*expected))
    report=dict(Passed=True,Failures=0,Executions=len(rows),Counts=counts,NativeFixtures=len(fixtures),
                ReferenceDefectReproductions=defects,UnsignedSHA256=hashlib.sha256((R/'build/qcpmicext8150.sys').read_bytes()).hexdigest(),
                SPMIReadsMocked=True,WDFForwardingMocked=True,SensorReadsMocked=True,HardwareAccepted=False,
                Scope='Byte-pinned native dispatcher, battery wrapper and budget worker; physical linkage/charging untested.',Cases=rows)
    (R/'build/emulation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='Cases'},indent=2))
if __name__=='__main__':main()
