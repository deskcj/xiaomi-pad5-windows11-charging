"""Two leaf calls in the existing PMIC dispatcher; preserve all old patches."""
import hashlib, json, struct, sys
from pathlib import Path
R = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(R.parent / 'offline-deps'))
import pefile
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_ARM
sha = lambda x: hashlib.sha256(x).hexdigest()
align = lambda x,a: (x+a-1)//a*a
original = (R/'reference/qcpmicext8150.sys').read_bytes()
assert sha(original) == 'ac79e695d905015908e3853e6a35dcfc16b22a81e99d1fd35be08aed99a8e2ba'
p = pefile.PE(data=original)
assert p.FILE_HEADER.Machine == 0xaa64
obj = (R/'build/aicl_status.obj').read_bytes()
machine,count,_,symoff,symcount,opt,_ = struct.unpack_from('<HHIIIHH',obj)
assert machine == 0xaa64 and opt == 0
strings = obj[symoff+18*symcount:]
def name(x):
    return (strings[struct.unpack_from('<I',x,4)[0]:].split(b'\0',1)[0].decode()
            if x[:4] == bytes(4) else x.rstrip(b'\0').decode())
sections=[]
for i in range(count):
    nm,_,_,sz,off,_,_,nr,_,flags = struct.unpack_from('<8sIIIIIIHHI',obj,20+40*i)
    assert nr == 0
    sections.append((name(nm),obj[off:off+sz],flags))
assert all(not data or nm in ('.text','.debug$S') for nm,data,flags in sections)
idx = next(i+1 for i,s in enumerate(sections) if s[0] == '.text')
code = sections[idx-1][1]
syms={};i=0
while i<symcount:
    nm,val,sec,typ,storage,aux = struct.unpack_from('<8sIhHBB',obj,symoff+18*i)
    if sec == idx: syms[name(nm)] = val
    i += 1+aux
assert syms == {'.text':0,'AiclCurrentMilliamps':0,'AiclStatusComplete':16,'AiclStatusEnd':32} or (
    syms['AiclCurrentMilliamps']==0 and syms['AiclStatusComplete']==16 and syms['AiclStatusEnd']==32)
assert len(code)==32
md = Cs(CS_ARCH_ARM64,CS_MODE_ARM);md.detail=True
rva = align(p.OPTIONAL_HEADER.SizeOfImage,p.OPTIONAL_HEADER.SectionAlignment)
proof=[]
for ins in md.disasm(code,rva):
    assert ins.mnemonic in ('mov','mul','str','and','ret')
    _,writes=ins.regs_access()
    names={md.reg_name(x) for x in writes}
    assert names <= {'w16','x16'}
    assert 'sp' not in ins.op_str
    if ins.mnemonic=='str':
        assert ins.op_str in ('w16, [x19, #4]','w16, [x19]','wzr, [x19, #8]')
    proof.append(dict(RVA=hex(ins.address),Assembly=ins.mnemonic+' '+ins.op_str))
assert len(proof)==8
header = p.sections[0].get_file_offset()+len(p.sections)*40
assert header+40<=p.OPTIONAL_HEADER.SizeOfHeaders
rawend=max(s.PointerToRawData+s.SizeOfRawData for s in p.sections)
out=bytearray(original[:rawend]);assert out[header:header+40]==bytes(40)
hooks=[]
for site,offset in ((0x2b2c,0),(0x2b3c,16)):
    old=p.get_data(site,4)
    ins=list(md.disasm(old,site))
    assert len(ins)==1 and ins[0].mnemonic=='str' and ins[0].op_str=='w8, [x19, #4]'
    delta=rva+offset-site;assert delta%4==0 and -(1<<27)<=delta<(1<<27)
    replacement=struct.pack('<I',0x94000000|((delta//4)&0x3ffffff))
    out[p.get_offset_from_rva(site):p.get_offset_from_rva(site)+4]=replacement
    hooks.append(dict(RVA=hex(site),OldHex=old.hex(),NewHex=replacement.hex(),LeafRVA=hex(rva+offset)))
ptr=align(len(out),p.OPTIONAL_HEADER.FileAlignment)
rawsize=align(len(code),p.OPTIONAL_HEADER.FileAlignment)
out.extend(bytes(ptr-len(out))+code+bytes(rawsize-len(code)))
out[header:header+40]=struct.pack('<8sIIIIIIHHI',b'.skaicl\0',len(code),rva,rawsize,ptr,0,0,0,0,0x60000020)
struct.pack_into('<H',out,p.FILE_HEADER.get_field_absolute_offset('NumberOfSections'),len(p.sections)+1)
def opt(field,val):struct.pack_into('<I',out,p.OPTIONAL_HEADER.get_field_absolute_offset(field),val)
opt('SizeOfImage',align(rva+len(code),p.OPTIONAL_HEADER.SectionAlignment))
opt('SizeOfCode',p.OPTIONAL_HEADER.SizeOfCode+rawsize)
struct.pack_into('<II',out,p.OPTIONAL_HEADER.DATA_DIRECTORY[4].get_file_offset(),0,0)
opt('CheckSum',0);opt('CheckSum',pefile.PE(data=bytes(out)).generate_checksum())
b=pefile.PE(data=bytes(out));assert b.verify_checksum()
changed=[]
for s in p.sections:
    before=s.get_data();after=b.get_data(s.VirtualAddress,len(before))
    changed += [s.VirtualAddress+j for j in range(0,len(before),4) if before[j:j+4]!=after[j:j+4]]
assert changed==[0x2b2c,0x2b3c],changed
for n in range(16):
    if n==4:continue
    before=p.OPTIONAL_HEADER.DATA_DIRECTORY[n];after=b.OPTIONAL_HEADER.DATA_DIRECTORY[n]
    assert (before.VirtualAddress,before.Size)==(after.VirtualAddress,after.Size)
    assert p.get_data(before.VirtualAddress,before.Size)==b.get_data(after.VirtualAddress,after.Size)
assert b.OPTIONAL_HEADER.AddressOfEntryPoint==p.OPTIONAL_HEADER.AddressOfEntryPoint
assert b.get_data(0x14000,244)==p.get_data(0x14000,244)
assert not any(s.Characteristics&0x20000000 and s.Characteristics&0x80000000 for s in b.sections)
(R/'build/qcpmicext8150.sys').write_bytes(out)
report=dict(Build=1869,PackageVersion='1.0.1869.0',InputSHA256=sha(original),UnsignedSHA256=sha(out),
    Hooks=hooks,LeafLow=rva,LeafHigh=rva+len(code),Instructions=proof,OldSectionsChangedWords=changed,
    OldPmicEncodingRepairRetained=True,OriginalDirectoriesRetained=True,NewImports=False,
    Installed=False,HardwareAccepted=False,PPSImplemented=False,HubContinuityFixed=False)
(R/'build/build.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='Instructions'},indent=2))
