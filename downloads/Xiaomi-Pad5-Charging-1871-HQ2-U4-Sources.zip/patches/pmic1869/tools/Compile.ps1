$ErrorActionPreference='Stop'
$skRoot=Split-Path -Parent $PSScriptRoot
$skAssembler='H:\Vlad\EWDK\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207\bin\Hostarm64\arm64\armasm64.exe'
& $skAssembler -nologo -o (Join-Path $skRoot 'build\aicl_status.obj') (Join-Path $skRoot 'src\aicl_status.asm') *> (Join-Path $skRoot 'build\compile.log')
if($LASTEXITCODE){Get-Content -LiteralPath (Join-Path $skRoot 'build\compile.log');throw 'AICL assembly failed'}
& python (Join-Path $PSScriptRoot 'Build.py')
if($LASTEXITCODE){throw 'AICL build failed'}
