import hashlib, json, sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R.parent/'offline-deps'))
import pefile
unsigned=pefile.PE(str(R/'build/qcpmicext8150.sys'))
signed=pefile.PE(str(R/'package/qcpmicext8150.sys'))
assert len(unsigned.sections)==len(signed.sections)
for a,b in zip(unsigned.sections,signed.sections):
    assert (a.Name,a.VirtualAddress,a.Misc_VirtualSize,a.Characteristics)==(b.Name,b.VirtualAddress,b.Misc_VirtualSize,b.Characteristics)
    assert a.get_data()==b.get_data()
qa=json.loads((R/'build/emulation.json').read_text())
native=json.loads((R/'build/signed-native.json').read_text(encoding='utf-8-sig'))
assert qa['Passed'] and qa['Failures']==0 and native['failures']==0
assert native['nativeARM64UnwindCases']==qa['NativeFixtures']
report=dict(Build=1869,ReadyForAuthorizedTrial=True,Failures=0,ARM64Executions=qa['Executions'],
    ReferenceDefectReproductions=qa['ReferenceDefectReproductions'],NativeUnwindCases=native['nativeARM64UnwindCases'],
    SignedMappedSectionsIdentical=True,SignedSHA256=hashlib.sha256((R/'package/qcpmicext8150.sys').read_bytes()).hexdigest(),
    HardwareAccepted=False,PPSImplemented=False,HubContinuityFixed=False)
(R/'build/qa-1869.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
