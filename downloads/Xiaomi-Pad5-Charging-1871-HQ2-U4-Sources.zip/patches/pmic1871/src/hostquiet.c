/* Experimental PM8150B detector policy inside the existing PMIC owner.
 * No boost, current, PD, IRQ acknowledgement, rerun command or USB reset.
 * The original synchronous provider call has completed before this runs.
 * This is a reconciliation policy, not an exclusive claim against all other
 * firmware/driver users of SPMI. Electrical hub continuity is unproven.
 */
#include <ntddk.h>
#include <intrin.h>
#pragma intrinsic(_InterlockedCompareExchange, _InterlockedExchange)

extern ULONG NativeRead(ULONG sid, ULONG reg, PUCHAR value);
extern ULONG NativeUpdate(ULONG sid, ULONG reg, ULONG mask, ULONG value);
extern ULONG NativeIrql(VOID);
extern ULONG_PTR NativeProvider(VOID);
extern VOID NativeEvent(ULONG event);

typedef struct {
    UCHAR attach, misc, header;
} SNAPSHOT;
typedef struct {
    volatile LONG busy;
    ULONG owned;
    UCHAR originalCc, originalApsd;
    ULONG_PTR provider;
    ULONG entries, quiet, restored, errors, skipped, lastEvent, lastVendor;
    ULONG dispatchSeen, lastSkipIrql;
} HQ_STATE;
HQ_STATE HqState;

static VOID event(ULONG code) {
    if (HqState.lastEvent==code) return;
    HqState.lastEvent=code;
    NativeEvent(code);
}
static BOOLEAN read(ULONG reg, PUCHAR value) {
    ULONG s;
    if (NativeProvider()!=HqState.provider) return FALSE;
    s=NativeRead(2,reg,value);
    if (s!=0) { HqState.lastVendor=s; return FALSE; }
    return NativeProvider()==HqState.provider;
}
static BOOLEAN snapshot(SNAPSHOT *p) {
    UCHAR second=0;
    /* 150b.bit0 is CC_ATTACHED, NOT VBUS. bit4 is VBUS_ERROR. */
    if (!read(0x1740,&p->header) || !read(0x1509,&p->attach) ||
        !read(0x150b,&p->misc) || !read(0x1740,&second)) return FALSE;
    return ((p->header^second)&0x0c)==0;
}
static ULONG desired(const SNAPSHOT *p) {
    BOOLEAN a=(p->attach&0x20)!=0, b=(p->misc&1)!=0;
    if (!a && !b) return 2; /* detached: return native defaults before attach */
    if (!a || !b || (p->misc&0x10)) return 0;
    /* Original nabu LPD checks (misc & 0x88) == 0x80. Bit7 alone is
     * not an active floating/moisture state once CC debounce completed.
     * Do not change any moisture enable, interrupt or acknowledgement. */
    if ((p->misc&0x88)==0x80) return 0;
    if (p->header&8) return 1; /* DFP data role, independent of source/sink */
    if (!(p->header&4) && !(p->misc&0x40)) return 2;
    return 0; /* UFP/source or contradictory observations: do not enable */
}
static BOOLEAN update(ULONG reg, ULONG mask, ULONG value, ULONG want) {
    SNAPSHOT p;
    UCHAR actual=0;
    ULONG s;
    if (!snapshot(&p) || desired(&p)!=want) return FALSE;
    s=NativeUpdate(2,reg,mask,value);
    if (s!=0) { HqState.lastVendor=s; return FALSE; }
    if (!read(reg,&actual) || (actual&mask)!=value) return FALSE;
    return TRUE;
}

ULONG SkHostQuietApply(ULONG sid, ULONG reg, ULONG trigger) {
    SNAPSHOT p;
    UCHAR cc=0, apsd=0;
    ULONG want, irql;
    UNREFERENCED_PARAMETER(trigger);
    if (sid!=2 || (reg!=0x1509 && reg!=0x150b && reg!=0x1740)) return 0;
    /* No wait, allocation, deferred callback or new bus handle. Recursive
     * reads through the native helper and concurrent callbacks skip safely.
     * A later native role/status callback retries incomplete reconciliation. */
    if (_InterlockedCompareExchange(&HqState.busy,1,0)!=0) return 0;
    HqState.entries++;
    irql=NativeIrql();
    /* These native synchronous, resident helpers already execute in the
     * successful header/read caller. No wait, allocation, paging or new
     * handle is introduced here. Keep DIRQL callers excluded. */
    if (irql>DISPATCH_LEVEL) {
        HqState.skipped++; event(7005);
        if (HqState.lastSkipIrql!=irql) {
            HqState.lastSkipIrql=irql; NativeEvent(7100+irql);
        }
        goto done;
    }
    if (irql==DISPATCH_LEVEL && !HqState.dispatchSeen) {
        HqState.dispatchSeen=1; NativeEvent(7006);
    }
    if (!HqState.owned) HqState.provider=NativeProvider();
    if (!HqState.provider || !snapshot(&p)) goto error;
    want=desired(&p);
    if (!want) { HqState.skipped++; goto done; }
    if (want==1) {
        if (!read(0x1358,&cc) || !read(0x1362,&apsd)) goto error;
        if (!HqState.owned) {
            HqState.originalCc=cc&0x80;
            HqState.originalApsd=apsd&8;
            /* Record recovery obligation BEFORE any write, including failed
             * writes whose effect is unknown. Keep baseline through swaps. */
            HqState.owned=3;
            event(7000);
        }
        HqState.owned=3; /* reacquire both obligations after partial restore */
        if ((cc&0x80) && !update(0x1358,0x80,0,1)) goto error;
        if ((apsd&8) && !update(0x1362,8,0,1)) goto error;
        if (!snapshot(&p) || desired(&p)!=1 ||
            !read(0x1358,&cc) || !read(0x1362,&apsd) ||
            (cc&0x80) || (apsd&8)) goto error;
        HqState.quiet++; event(7001);
    } else if (HqState.owned) {
        /* Restore APSD first, then auto-start. Each step is read back and
         * admitted against fresh CC and data-role observations. */
        if ((HqState.owned&2)!=0) {
            if (!update(0x1362,8,HqState.originalApsd,2)) goto error;
            HqState.owned&=~2u;
        }
        if ((HqState.owned&1)!=0) {
            if (!update(0x1358,0x80,HqState.originalCc,2)) goto error;
            HqState.owned&=~1u;
        }
        HqState.restored++; event(7002);
    }
    goto done;
error:
    HqState.errors++; event(7003);
done:
    _InterlockedExchange(&HqState.busy,0);
    return 0; /* preserve original successful header/read result */
}
