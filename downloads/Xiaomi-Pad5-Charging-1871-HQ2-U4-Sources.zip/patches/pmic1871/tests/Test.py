"""Execute the exact candidate and original caller/provider helpers in Unicorn.
Only SPMI transfers, HAL IRQL and WPP logging are simulated. No kernel load.
Exercise restoration, all provider failure positions, partial restore, ASLR,
recursion, busy entry, role changes and original argument/error behavior.
"""
import hashlib,itertools,json,struct,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'offline-deps'))
import pefile
from unicorn import *
from unicorn.arm64_const import *
M=json.loads((R/'build/build.json').read_text());SY=M['Symbols']
STACK=0x207000;SP=STACK+0x1000;MEM=0x50000000;END=0x400000
fixtures={};scenarios=[]
class Replay:
    def __init__(self,base=0x140000000,original=False,irql=0):
        self.base=base;self.irql=irql;self.calls=[];self.events=[];self.failat=0;self.failcode=1
        self.mutate=None;self.capture=False;self.original=original
        p=pefile.PE(str(R/('reference' if original else 'build')/'qcpmicext8150.sys'));p.relocate_image(base)
        self.p=p;self.u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
        self.u.mem_map(base,(p.OPTIONAL_HEADER.SizeOfImage+4095)&~4095)
        self.u.mem_write(base,p.get_memory_mapped_image())
        for at,n in [(STACK,0x2000),(MEM,0x20000),(END,0x1000)]:self.u.mem_map(at,n)
        self.q(base+0xd098,MEM+0x7000)
        self.q(base+0xd090,MEM+0x8000)
        self.q(MEM+0x8040,0xabcdef)
        self.u.mem_write(base+0xd668,struct.pack('<I',0x1700))
        self.provider=MEM+0x1000
        self.q(base+0xd508,self.provider)
        self.q(self.provider+0x90,MEM+0x2000)
        self.q(self.provider+0x98,END+0x100)
        self.q(self.provider+0xa8,END+0x110)
        self.q(base+0xc0a8,END+0x120)
        if not original:self.q(base+SY['HqIrqlIat'],END+0x130)
        self.regs={0x1740:9,0x1509:0x20,0x150b:1,0x1358:0xc0,0x1362:0x18}
        self.u.hook_add(UC_HOOK_CODE,self.hook)
    def q(self,a,v):self.u.mem_write(a,struct.pack('<Q',v))
    def state(self):return struct.unpack('<II2B6xQ7I4x',bytes(self.u.mem_read(self.base+SY['HqState'],56)))
    def ret(self,status=0,clobber=True):
        lr=self.u.reg_read(UC_ARM64_REG_LR)
        if clobber:
            for i in range(18):self.u.reg_write(UC_ARM64_REG_X0+i,0xcccccccccccccccc)
        self.u.reg_write(UC_ARM64_REG_W0,status&0xffffffff);self.u.reg_write(UC_ARM64_REG_PC,lr)
    def hook(self,u,at,n,_):
        if at==END:u.emu_stop();return
        if at==END+0x120:
            assert u.reg_read(UC_ARM64_REG_X15) in (END+0x100,END+0x110)
            self.ret(0,False);return
        if at==END+0x130:self.ret(self.irql);return
        if at==self.base+0x1510:
            args=[u.reg_read(UC_ARM64_REG_X0+i) for i in range(5)]
            assert args[1:3]==[4,2] and args[4]==self.base+0xc340
            self.events.append(args[3]);self.ret();return
        if at in (END+0x100,END+0x110):
            x=[u.reg_read(UC_ARM64_REG_X0+i) for i in range(6)]
            sid=x[2]>>16;reg=x[2]&0xffff
            assert x[0]==MEM+0x2000 and x[1]==0
            writing=at==END+0x110
            call=dict(Kind='write' if writing else 'read',SID=sid,Register=reg)
            if writing:
                assert x[3]&~x[4]==0
                call.update(Mask=x[4],Value=x[3]);self.regs[reg]=(self.regs.get(reg,0)&~x[4])|x[3]
            else:
                assert x[4]==1;u.mem_write(x[3],bytes([self.regs.get(reg,0)]))
            self.calls.append(call)
            if self.mutate:self.mutate(self,call,len(self.calls))
            # Failure after side effect covers uncertain bus completion.
            status=self.failcode if len(self.calls)==self.failat else 0
            u.mem_write(x[5],struct.pack('<I',0 if status else 1));self.ret(status);return
        rva=at-self.base
        if self.capture and (0x6ae0<=rva<0x6c5c or 0xb780<=rva<0xb8c8 or 0x16000<=rva<0x16800):
            lr=u.reg_read(UC_ARM64_REG_LR)
            # Stop snapshots at real instructions, excluding mocked trace/HAL.
            key=(rva,lr,u.reg_read(UC_ARM64_REG_SP))
            if key not in fixtures:
                # Unicorn numbers X29/FP and X30/LR separately from X0..X28.
                regs=[u.reg_read(UC_ARM64_REG_X0+i) for i in range(29)]
                regs += [u.reg_read(UC_ARM64_REG_FP),u.reg_read(UC_ARM64_REG_LR)]
                fixtures[key]=(rva,u.reg_read(UC_ARM64_REG_SP)-STACK,regs,bytes(u.mem_read(STACK,0x2000)))
    def invoke(self,entry,*args):
        self.u.mem_write(STACK,bytes(0x2000));self.u.reg_write(UC_ARM64_REG_SP,SP)
        expected={UC_ARM64_REG_X19+i:0xabc0000000000000+i for i in range(10)}
        expected.update({UC_ARM64_REG_FP:0xabc1234567890000,UC_ARM64_REG_X18:0xabcdef9876543210})
        for k,v in expected.items():self.u.reg_write(k,v)
        for i,v in enumerate(args):self.u.reg_write(UC_ARM64_REG_X0+i,v)
        self.u.reg_write(UC_ARM64_REG_LR,END)
        try:self.u.emu_start(self.base+entry,END,count=100000)
        except UcError:
            print('emulation error',hex(self.u.reg_read(UC_ARM64_REG_PC)-self.base),'failat',self.failat,'calls',self.calls,
                  'registers',[hex(self.u.reg_read(UC_ARM64_REG_X0+i)) for i in range(8)],flush=True)
            raise
        assert self.u.reg_read(UC_ARM64_REG_PC)==END,'instruction budget exceeded'
        assert self.u.reg_read(UC_ARM64_REG_SP)==SP
        for k,v in expected.items():assert self.u.reg_read(k)==v,(entry,k)
        assert self.u.reg_read(UC_ARM64_REG_X18)==expected[UC_ARM64_REG_X18]
        return self.u.reg_read(UC_ARM64_REG_W0)
    def poll(self,reg=0x1509,sid=2):return self.invoke(0xb858,sid,reg,MEM+0x3000)
    def header(self,data=1,power=0,rev=1,sid=2):
        self.u.mem_write(MEM+0x4000,bytes([data,power,rev]));return self.invoke(0x6ae0,sid,MEM+0x4000)
    def detached(self):self.regs.update({0x1509:0,0x150b:0})
    def host(self,power=0):self.regs.update({0x1509:0x20,0x150b:1|(power<<6),0x1740:9|(power<<2)})
    def sink(self):self.regs.update({0x1509:0x20,0x150b:1,0x1740:1})
    def quiet(self):assert not self.regs[0x1358]&0x80 and not self.regs[0x1362]&8
    def restored(self,cc=0xc0,apsd=0x18):assert self.regs[0x1358]==cc and self.regs[0x1362]==apsd

def record(name,fn):fn();scenarios.append(name)
for base in (0x140000000,0x180000000,0x1c0000000):
    for power in (0,1):
        for entry in ('poll','header'):
            t=Replay(base);assert getattr(t,entry)(**({'power':power} if entry=='header' else {}))==0;t.quiet()
            # Charger removal must not restore APSD while USB remains DFP.
            t.host(1-power);assert t.header(1,1-power)==0;t.quiet()
            t.detached();assert t.poll()==0;t.restored()
            t.sink();assert t.header(0,0)==0;t.restored()
            t.host();assert t.poll()==0;t.quiet()
            scenarios.append(f'host-power-detach-legacy-rehost:{base:x}:{power}:{entry}')
for cc,apsd in itertools.product((0,0x40,0x80,0xc0,0xff),(0,8,0x10,0x18,0xff)):
    t=Replay();t.regs.update({0x1358:cc,0x1362:apsd});assert t.header()==0;t.quiet()
    t.detached();assert t.poll()==0;t.restored(cc,apsd);scenarios.append('baseline-masks')
# Original public return codes remain exact for all header arguments.
for data,power,rev in itertools.product((0,1,2,255),(0,1,2,255),(0,1,2,3,4,255)):
    a=Replay(original=True);b=Replay();assert a.header(data,power,rev)==b.header(data,power,rev)
    if data>1 or power>1 or rev>3:assert not b.calls and b.state()[1]==0
    scenarios.append('header-original-validation')
for sid in (0,1,3,255):
    t=Replay();assert t.poll(sid=sid)==0;t.restored();assert len(t.calls)==1;scenarios.append('sid-scope')
for reg in (0x1310,0x1307,0x1341,0x1362,0x1358,0x1744,0xffff):
    t=Replay();assert t.poll(reg)==0;t.restored();assert len(t.calls)==1;scenarios.append('register-scope')
for irql in (3,15):
    t=Replay(irql=irql);assert t.poll()==0;t.restored();assert len(t.calls)==1;scenarios.append('irql-no-IO')
for attach,misc,header in [(0,1,9),(0x20,0,9),(0x20,0x11,9),(0x20,0x81,9),(0x20,0x41,5)]:
    t=Replay();t.regs.update({0x1509:attach,0x150b:misc,0x1740:header});assert t.poll()==0;t.restored();assert not any(c['Kind']=='write' for c in t.calls);scenarios.append('contradictory-or-error-CC')
t=Replay();t.u.mem_write(t.base+SY['HqState'],struct.pack('<I',1));assert t.poll()==0;t.restored();assert len(t.calls)==1;scenarios.append('busy-nonblocking')
# Genuine new code recursively enters through NativeRead's real patched body;
# its busy guard limits depth without mocking the internal read helper.
t=Replay();assert t.poll()==0;t.quiet();assert t.state()[0]==0;scenarios.append('native-recursion')
# Reproduce the actual HQ1 attach/header sequence, including the final
# callback above APC_LEVEL and the direct DFP/source 0xc9 observation.
for irql in (0,1,2):
    t=Replay(irql=irql)
    t.regs.update({0x1509:0x23,0x150b:0x29,0x1740:0x0d})
    assert t.poll()==0;t.quiet()
    assert t.header(0,0)==0;t.restored()
    assert t.header(1,0)==0;t.quiet()
    t.regs.update({0x1509:0x26,0x150b:0xc9,0x1740:0x0d})
    assert t.header(1,1)==0;t.quiet()
    t.detached();assert t.poll()==0;t.restored()
    t.sink();assert t.header(0,0)==0;t.restored()
    scenarios.append('captured-hub-header-and-source-sequence:'+str(irql))
for irql in (0,2):
    for misc in (0x81,0xc1,0x91,0xd9):
        t=Replay(irql=irql)
        t.regs.update({0x1509:0x26,0x150b:misc,0x1740:0x0d})
        assert t.poll()==0;t.restored()
        assert not any(c['Kind']=='write' for c in t.calls)
        scenarios.append('floating-water-or-vbus-error-remains-blocked')
normal=Replay();normal.header();n=len(normal.calls)
for pos,code in itertools.product(range(1,n+1),(1,0x6d,0xc0000185)):
    t=Replay();t.failat=pos;t.failcode=code;s=t.header()
    assert s==(0xc0000001 if pos==1 else 0)
    t.failat=0;t.detached();assert t.poll()==0;t.restored();assert t.state()[0]==0
    scenarios.append('all-quiet-provider-failures')
normal.detached();normal.calls=[];normal.poll();n=len(normal.calls)
for pos in range(1,n+1):
    t=Replay();t.header();t.detached();t.calls=[];t.failat=pos;s=t.poll()
    assert s==(0x6d if pos==1 else 0)
    t.failat=0;t.poll();t.restored()
    # Rehost before another restore also recovers both partial obligations.
    t.host();t.header();t.quiet();t.detached();t.poll();t.restored()
    scenarios.append('all-restore-provider-failures')
for cutoff in range(2,34):
    t=Replay()
    def change(obj,call,count):
        if count==cutoff:obj.detached()
    t.mutate=change;assert t.header()==0;t.mutate=None;t.detached();t.poll();t.restored();scenarios.append('physical-detach-during-quiet')
for cutoff in range(2,30):
    t=Replay();t.header();t.detached();t.calls=[]
    def change(obj,call,count):
        if count==cutoff:obj.host()
    t.mutate=change;assert t.poll()==0;t.mutate=None;t.host();t.header();t.quiet();t.detached();t.poll();t.restored();scenarios.append('rehost-during-restore')
# Capture native unwind states over quiet, detached restore, legacy and errors.
t=Replay();t.capture=True;t.header();t.detached();t.poll();t.sink();t.header(0,0);t.host();t.poll()
t=Replay(irql=2);t.capture=True
t.regs.update({0x1509:0x23,0x150b:0x29,0x1740:0x0d})
t.header(0,0);t.header(1,0)
t.regs.update({0x1509:0x26,0x150b:0xc9,0x1740:0x0d})
t.header(1,1);t.detached();t.poll();t.sink();t.header(0,0)
t=Replay(irql=3);t.capture=True;t.header()
for pos in (1,6,12,19):
    t=Replay();t.capture=True;t.failat=pos;t.header();t.failat=0;t.detached();t.poll()
f=bytearray(struct.pack('<II',0x3157444e,len(fixtures)))
for rva,sp,regs,stack in fixtures.values():f.extend(struct.pack('<II31Q',rva,sp,*regs)+stack)
(R/'build/unwind-fixtures.bin').write_bytes(f)
report=dict(Passed=True,Failures=0,Scenarios=len(scenarios),NativeFixtures=len(fixtures),
 UnsignedSHA256=M['UnsignedSHA256'],ModelServices=['SPMI','HAL IRQL','WPP'],
 OriginalNativeReadAndMaskedUpdateExecuted=True,ElectricalContinuityTested=False,ScenarioNames=sorted(set(scenarios)))
(R/'build/emulation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='ScenarioNames'},indent=2))
