import hashlib,json,struct,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'offline-deps'))
import pefile
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_ARM
a=pefile.PE(str(R/'build/qcpmicext8150.sys'));b=pefile.PE(str(R/'package/qcpmicext8150.sys'))
assert a.FILE_HEADER.Machine==b.FILE_HEADER.Machine==0xaa64
assert a.OPTIONAL_HEADER.AddressOfEntryPoint==b.OPTIONAL_HEADER.AddressOfEntryPoint
assert a.OPTIONAL_HEADER.DllCharacteristics==b.OPTIONAL_HEADER.DllCharacteristics
assert len(a.sections)==len(b.sections)==13
for x,y in zip(a.sections,b.sections):
    assert (x.Name,x.VirtualAddress,x.Misc_VirtualSize,x.Characteristics)==(y.Name,y.VirtualAddress,y.Misc_VirtualSize,y.Characteristics)
    assert x.get_data()==y.get_data()
for n in range(16):
    if n==4:continue
    x=a.OPTIONAL_HEADER.DATA_DIRECTORY[n];y=b.OPTIONAL_HEADER.DATA_DIRECTORY[n]
    assert (x.VirtualAddress,x.Size)==(y.VirtualAddress,y.Size)
md=Cs(CS_ARCH_ARM64,CS_MODE_ARM);md.detail=True
layout=json.loads((R/'build/build.json').read_text())
symbols=layout['Symbols'];locals=layout['LocalSymbols']
leaf_ranges=[(symbols['HeaderAdapter'],symbols['SkHostQuietApply']),
             (locals['hostquiet:desired'],locals['hostquiet:event'])]
for start,end in leaf_ranges:
    assert 0<end-start<4096 and start%4==end%4==0
    code=list(md.disasm(b.get_data(start,end-start),start))
    assert len(code)*4==end-start
    for i in code:
        _,writes=i.regs_access();names={md.reg_name(x) for x in writes}
        assert not names.intersection({'sp','fp','lr','x18'}|{f'x{j}' for j in range(19,30)})
        assert i.mnemonic!='bl'
unsigned=hashlib.sha256((R/'build/qcpmicext8150.sys').read_bytes()).hexdigest().upper()
signed=hashlib.sha256((R/'package/qcpmicext8150.sys').read_bytes()).hexdigest().upper()
report=dict(Passed=True,UnsignedSHA256=unsigned,SignedSHA256=signed,MappedSectionsIdentical=True,
 UnwindDirectoriesIdentical=True,ASLRAndLoadConfigurationPreserved=True,LeafRangesStaticallyVerified=True)
report['LeafRangesFromBuildSymbols']=leaf_ranges
(R/'build/signed-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
