"""Publish new project artifacts and ZIP only. Never installs a driver."""
import hashlib, json, shutil, zipfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
PROJECT = Path(r'H:\Vlad\Charging')
TARGET = PROJECT/'candidate-1851-stock-repair'
OUTPUT = ROOT.parents[1]/'outputs/SK-Charging-1851-stock-repair.zip'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def main():
    if TARGET.exists() or OUTPUT.exists():
        raise RuntimeError('New release target already exists; refusing overwrite')
    manifest = read(ROOT/'package-manifest.json')
    if manifest['installed'] or manifest['hardwareTested']:
        raise RuntimeError('Unexpected hardware status')
    for row in manifest['files']:
        if sha((ROOT/row['path']).read_bytes()) != row['sha256'].lower():
            raise RuntimeError('Signed package identity changed')
    qa_path = ROOT/'build/qa-identity.json'
    signed_path = ROOT/'build/signed-payload-identity.json'
    if sha(qa_path.read_bytes()) != manifest['qaIdentitySHA256'].lower() or \
       sha(signed_path.read_bytes()) != manifest['signedPayloadIdentitySHA256'].lower():
        raise RuntimeError('QA identity changed')
    qa = read(qa_path)
    for name, expected in {**qa['evidence'], **qa['qaReports']}.items():
        if sha((ROOT/name).read_bytes()) != expected:
            raise RuntimeError('Audited evidence changed: ' + name)
    latest = PROJECT/'LATEST-CHARGING-RESEARCH-RU.md'
    previous = latest.read_bytes()
    (ROOT/'reference/previous-LATEST-CHARGING-RESEARCH-RU.md').write_bytes(previous)
    files = [p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts
             and p.name != 'FILES-SHA256.json']
    index = {p.relative_to(ROOT).as_posix(): sha(p.read_bytes()) for p in sorted(files)}
    (ROOT/'FILES-SHA256.json').write_text(json.dumps(index, indent=2), encoding='utf-8')
    files.append(ROOT/'FILES-SHA256.json')
    shutil.copytree(ROOT, TARGET, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    for name, expected in index.items():
        if sha((TARGET/name).read_bytes()) != expected:
            raise RuntimeError('Project copy differs: ' + name)
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(OUTPUT, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for p in files:
            archive.write(p, 'SK-Charging-1851/' + p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(OUTPUT) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('ZIP CRC failed')
        for name, expected in index.items():
            if sha(archive.read('SK-Charging-1851/' + name)) != expected:
                raise RuntimeError('ZIP payload differs: ' + name)
        if archive.read('SK-Charging-1851/FILES-SHA256.json') != (ROOT/'FILES-SHA256.json').read_bytes():
            raise RuntimeError('ZIP index differs')
    archive_sha = sha(OUTPUT.read_bytes())
    OUTPUT.with_suffix('.zip.sha256').write_text(archive_sha+'  '+OUTPUT.name+'\n', encoding='ascii')
    header = '''# SK-Charging 1851: готов новый кандидат SYS/INF/CAT — 27.10.2026

<!-- CANDIDATE-1851-STOCK-REPAIR-READY-20261027 -->
Готов тестово подписанный комплект: qcpmictcc8150/qcusbctcpm8150 1.0.1851.0
и qcbattmngr8150 manager 1.0.10731.0. Файлы и описание:
candidate-1851-stock-repair/package, README-RU.md, REPORT-RU.md,
package-manifest.json. Это новый SYS-кандидат, не прежняя research LIB.

Actual PE с DDI mocks: backend282, client3528 + cleanup90 + D0-exit270,
battery93. Native ARM64 RtlVirtualUnwind4832, failures0. EWDK kernel
compile и MSVC static analysis пройдены. QA связана с точными SHA; все
mapped sections signed/unsigned совпадают. InfVerif/Inf2Cat/подписи и
catalog membership SYS/INF проверены. Подпись development, не WHQL.

Сохранён исходный Qualcomm PD/PHY/discovery, интегрирован ограниченный
ремонт command/ADC/OTG cancellation/rundown/battery cache. Полная новая
votes/owner архитектура не внедрялась. Hardware/SMP/real WDF не проверены;
полное исправление конкретного отказа и отсутствие BSOD не гарантированы.

Установки, отката, перезагрузки, USB reset и аппаратного опроса не было.
Камера, API, PMIC1849/miniclass и C:\\Charging-Recovery-PMIC1849 не менялись.
Последний аппаратно подтверждённый рабочий baseline остаётся историческим:
27.10.2026 11:29:46 +05:00, зарядка и Kingston XS2000 работали через хаб.
Автоматические Install/Capture/Restore из старых записей не запускать.

Внутренняя копия: C:\\Users\\Xiaomi\\Documents\\Codex\\2026-10-27\\new-chat\\work\\candidate1851-stock-repair
ZIP: C:\\Users\\Xiaomi\\Documents\\Codex\\2026-10-27\\new-chat\\outputs\\SK-Charging-1851-stock-repair.zip

---

Исторические записи ниже. Готовность кандидата выше актуальна;
прежние ограничения аппаратных действий сохранены.

'''
    latest.write_text(header + previous.decode('utf-8-sig'), encoding='utf-8')
    result = dict(project=str(TARGET), archive=str(OUTPUT), archiveSHA256=archive_sha,
                  indexedFiles=len(index), zipCRCAndSHA256Passed=True,
                  installed=False, hardwareTested=False)
    OUTPUT.with_suffix('.publication.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
