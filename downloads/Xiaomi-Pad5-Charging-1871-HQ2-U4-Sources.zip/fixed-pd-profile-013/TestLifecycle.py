"""Execute SYS entry/add/unload with WDF, registry and ETW leaves mocked."""
from pathlib import Path
from datetime import datetime,timezone
import json,re,struct,hashlib
R=Path(__file__).resolve().parent
scope={'__file__':str(R/'TestCallbacks.py')}
exec(compile((R/'TestCallbacks.py').read_text().split('rows=[]')[0], 'Callback harness definitions','exec'),scope)
globals().update({k:v for k,v in scope.items() if k not in ('__file__','__builtins__')})
extra=('WdfDriverCreate','WdfFdoInitSetFilter','WdfDeviceCreate','WdfDeviceOpenRegistryKey',
       'WdfRegistryQueryULong','WdfRegistryClose','WdfIoQueueCreate')
class Lifecycle(CallbackReplay):
    def __init__(self,base,reg=0,wdf=0,open_=0,query=0,device=0,queue=0,mode=1):
        super().__init__(base,mode=0)
        self.regstatus,self.wdfstatus,self.openstatus,self.querystatus=reg,wdf,open_,query
        self.devstatus,self.queuestatus,self.mode=device,queue,mode
        self.q(base+symbols['SkEtw'],0)
        for name,stub in (('EtwRegister',0x30012010),('EtwUnregister',0x30012020),('RtlInitUnicodeString',0x30012030)):
            self.q(base+symbols['__imp_'+name],stub)
        for name in extra:
            index=int(re.search(name+r'TableIndex\s*=\s*(\d+)',header.read_text()).group(1))
            stub=0x30010000+index*4;self.stubnames[stub]=name;self.q(0x3000c000+index*8,stub)
    def hook(self,u,at,size,unused):
        v=[u.reg_read(UC_ARM64_REG_X0+i) for i in range(8)]
        if at==0x30012010:
            assert v[1]==v[2]==0
            self.q(v[3],0xabcdef) # deliberately nonzero even on failed registration
            self.events.append(dict(Name='EtwRegister'));self.ret(self.regstatus);return
        if at==0x30012020:
            assert v[0]==0xabcdef
            self.events.append(dict(Name='EtwUnregister'));self.ret();return
        if at==0x30012030:
            raw=bytes(u.mem_read(v[1],48));assert raw.decode('utf-16-le')=='SkExperimentalFixed9V3A\0'
            u.mem_write(v[0],struct.pack('<HHIQ',44,46,0,v[1]));self.ret();return
        name=self.stubnames.get(at)
        if name not in extra:return super().hook(u,at,size,unused)
        assert v[0]==0x505050
        self.events.append(dict(Name=name))
        if name=='WdfDriverCreate':
            config=bytes(u.mem_read(v[4],32))
            assert struct.unpack_from('<I',config)[0]==32
            assert struct.unpack_from('<QQ',config,8)==(self.base+symbols['SkAdd'],self.base+symbols['SkUnload'])
            self.ret(self.wdfstatus)
        elif name=='WdfFdoInitSetFilter':self.ret()
        elif name=='WdfDeviceCreate':
            if not self.devstatus:self.q(v[3],self.device)
            self.ret(self.devstatus)
        elif name=='WdfDeviceOpenRegistryKey':
            assert v[1]==self.device and v[2]==1 and v[3]==0x20019
            if not self.openstatus:self.q(v[5],0x989898)
            self.ret(self.openstatus)
        elif name=='WdfRegistryQueryULong':
            assert v[1]==0x989898
            if not self.querystatus:self.d(v[3],self.mode)
            self.ret(self.querystatus)
        elif name=='WdfRegistryClose':assert v[1]==0x989898;self.ret()
        elif name=='WdfIoQueueCreate':
            assert v[1]==self.device
            self.ret(self.queuestatus)
    def invoke(self,name,args):
        u=self.u;self.writes=[]
        saved={UC_ARM64_REG_X19+i:0xabc0000000000000+i for i in range(10)}
        saved.update({UC_ARM64_REG_FP:0xabc1234567890000,UC_ARM64_REG_X18:0x123456789})
        for reg,value in saved.items():u.reg_write(reg,value)
        u.reg_write(UC_ARM64_REG_SP,0x70010000);u.reg_write(UC_ARM64_REG_LR,self.end)
        for i,value in enumerate(args):u.reg_write(UC_ARM64_REG_X0+i,value)
        u.emu_start(self.base+symbols[name],self.end,count=50000)
        assert u.reg_read(UC_ARM64_REG_PC)==self.end and u.reg_read(UC_ARM64_REG_SP)==0x70010000
        assert all(u.reg_read(reg)==value for reg,value in saved.items())
        for at,n in self.writes:
            assert (0x70000000<=at and at+n<=0x70020000 or
                    self.dc<=at and at+n<=self.dc+4 or
                    self.base+symbols['SkEtw']<=at and at+n<=self.base+symbols['SkEtw']+8),(hex(at),n)
        return u.reg_read(UC_ARM64_REG_W0)
rows=[]
for base in (0x140000000,0x180000000):
    for reg,wdf in ((0,0),(0xc000009a,0),(0,0xc000009a),(0xc000009a,0xc000009a)):
        r=Lifecycle(base,reg=reg,wdf=wdf)
        status=r.invoke('DriverEntry',(0xababab,0x898989))
        assert status==wdf
        handle=struct.unpack('<Q',r.u.mem_read(base+symbols['SkEtw'],8))[0]
        assert handle==(0xabcdef if not reg and not wdf else 0)
        calls=[x['Name'] for x in r.events]
        traces=[x for x in r.events if x['Name']=='EtwWrite']
        if not reg:
            assert [x['Kind'] for x in traces]==[3,4]
            assert traces[0]['Status']==hex(0) and traces[1]['Status']==hex(wdf)
        else:
            assert not traces
        assert calls.count('EtwUnregister')==int(not reg and bool(wdf))
        if not wdf:
            r.invoke('SkUnload',(0xababab,))
            assert struct.unpack('<Q',r.u.mem_read(base+symbols['SkEtw'],8))[0]==0
        rows.append(dict(Kind='EntryAndUnload',Base=hex(base),RegistrationStatus=hex(reg),WdfStatus=hex(wdf)))
    for mode,open_,query,device,queue in ((0,0,0,0,0),(1,0,0,0,0),(2,0,0,0,0),
        (1,0xc0000022,0,0,0),(1,0,0xc0000034,0,0),(1,0,0,0xc000009a,0),(1,0,0,0,0xc000009a)):
        r=Lifecycle(base,mode=mode,open_=open_,query=query,device=device,queue=queue)
        r.q(base+symbols['SkEtw'],0xabcdef)
        status=r.invoke('SkAdd',(0xababab,0x898989))
        assert status==(device or queue)
        calls=[x['Name'] for x in r.events]
        assert calls.count('WdfRegistryClose')==int(not device and not open_)
        expected=int(mode==1 and not open_ and not query)
        if not device:
            assert struct.unpack('<I',r.u.mem_read(r.dc,4))[0]==expected
            trace=next(x for x in r.events if x['Name']=='EtwWrite')
            assert trace['Kind']==1 and trace['Mode']==expected
        rows.append(dict(Kind='Add',Base=hex(base),Mode=mode,OpenStatus=hex(open_),QueryStatus=hex(query),DeviceStatus=hex(device),QueueStatus=hex(queue)))
report=dict(AtUTC=datetime.now(timezone.utc).isoformat(),Passed=True,Executions=len(rows),
    SYS_SHA256=sha(R/'build/skpdprofile.sys'),WdfRegistryAndEtwModeled=True,
    DriverEntryAddAndUnloadExecuted=True,PhysicalKernelOrPnPTest=False,Installed=False,Cases=rows)
(R/'lifecycle-qa.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='Cases'},indent=2))
