/* Read an existing ETL only. No controller APIs, IOCTLs, or device handles. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <evntrace.h>
#include <evntcons.h>
#include <stdio.h>

static FILE *Output;
static unsigned long long Records;

static VOID WINAPI Record(PEVENT_RECORD r)
{
    const GUID *g = &r->EventHeader.ProviderId;
    const unsigned char *bytes = (const unsigned char *)r->UserData;
    unsigned int i;
    fprintf(Output, "{\"FileTime\":%lld,\"Guid\":\"%08lx-%04x-%04x-%02x%02x-%02x%02x%02x%02x%02x%02x\","
            "\"Id\":%u,\"Version\":%u,\"Opcode\":%u,\"Flags\":%u,\"PID\":%lu,\"TID\":%lu,\"Bytes\":%u,\"Hex\":\"",
            r->EventHeader.TimeStamp.QuadPart, g->Data1, g->Data2, g->Data3,
            g->Data4[0], g->Data4[1], g->Data4[2], g->Data4[3],
            g->Data4[4], g->Data4[5], g->Data4[6], g->Data4[7],
            r->EventHeader.EventDescriptor.Id, r->EventHeader.EventDescriptor.Version, r->EventHeader.EventDescriptor.Opcode,
            r->EventHeader.Flags, r->EventHeader.ProcessId, r->EventHeader.ThreadId,
            r->UserDataLength);
    for(i=0; i<r->UserDataLength; ++i) fprintf(Output, "%02x", bytes[i]);
    fputs("\"}\n", Output);
    ++Records;
}

int wmain(int argc, wchar_t **argv)
{
    EVENT_TRACE_LOGFILEW log;
    TRACEHANDLE trace;
    ULONG status;
    if(argc!=3){fputs("Usage: Read-Etl-Raw input.etl output.jsonl\n", stderr);return 2;}
    if(_wfopen_s(&Output,argv[2],L"wb") || !Output) return 3;
    ZeroMemory(&log,sizeof(log));
    log.LogFileName=argv[1];
    log.ProcessTraceMode=PROCESS_TRACE_MODE_EVENT_RECORD;
    log.EventRecordCallback=Record;
    trace=OpenTraceW(&log);
    if(trace==INVALID_PROCESSTRACE_HANDLE){fprintf(stderr,"OpenTrace error:%lu\n",GetLastError());fclose(Output);return 4;}
    status=ProcessTrace(&trace,1,NULL,NULL);
    CloseTrace(trace);
    if(ferror(Output)){fclose(Output);return 5;}
    if(fclose(Output))return 6;
    printf("{\"Status\":%lu,\"Records\":%llu,\"EventsLost\":%lu}\n",status,Records,log.EventsLost);
    return status==ERROR_SUCCESS?0:7;
}
