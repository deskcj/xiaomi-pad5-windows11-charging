/* SPDX-License-Identifier: MIT */
#include "profile.h"
#define SK_MAX_RESPONSE 65536
#define SK_OUTPUT_SIGNATURE 0x426f6541UL
#define SK_INPUT_SIGNATURE_EX 0x41696541UL
typedef struct SK_ARG {ULONG Offset,Data,Length,Next;USHORT Type;} SK_ARG;
static ULONG word(const UCHAR *p)
{return (ULONG)p[0]|((ULONG)p[1]<<8)|((ULONG)p[2]<<16)|((ULONG)p[3]<<24);}
static USHORT half(const UCHAR *p)
{return (USHORT)((USHORT)p[0]|((USHORT)p[1]<<8));}
static BOOLEAN arg(const UCHAR *b,ULONG at,ULONG end,SK_ARG *a)
{
    ULONG n,padded;
    if(at>end || end-at<8)return FALSE;
    n=half(b+at+2);padded=n<4?4:n;
    if(padded>end-at-4)return FALSE;
    a->Offset=at;a->Data=at+4;a->Length=n;a->Next=at+4+padded;
    a->Type=half(b+at);return TRUE;
}
static BOOLEAN integer(const UCHAR *b,const SK_ARG *a,ULONG *v)
{
    if(a->Type!=0 || (a->Length!=4 && a->Length!=8))return FALSE;
    if(a->Length==8 && word(b+a->Data+4)!=0)return FALSE;
    *v=word(b+a->Data);return TRUE;
}
/* Every sibling is bounded. Only legacy PACKAGE serialization consumed by
 * this pinned UcmCx is accepted; unsupported encodings pass through intact. */
static BOOLEAN array(const UCHAR *b,const SK_ARG *p,ULONG *values,ULONG wanted,ULONG *change)
{
    ULONG at=p->Data,end=at+p->Length,i;SK_ARG a;
    if(p->Type!=3)return FALSE;
    for(i=0;i<wanted;++i){
        if(!arg(b,at,end,&a) || !integer(b,&a,&values[i]))return FALSE;
        if(i==1 && change)*change=a.Data;
        at=a.Next;
    }
    return at==end;
}
ULONG SkPdProfileMatchInput(_In_reads_bytes_(n) const UCHAR *b,SIZE_T n)
{
    /* ACPI_ENUM_CHILD.Name is a fully qualified namespace path. UcmCx
     * appends ._DSD without removing the prefix. Accept only this tablet's
     * connector, including Windows' two spellings of the _SB NameSeg. */
    static const UCHAR names[][32]={"CON0._DSD","\\_SB_.UCP0.CON0._DSD","\\_SB.UCP0.CON0._DSD"};
    ULONG i,j;
    if(!b || n<260 || word(b)!=SK_INPUT_SIGNATURE_EX)return 0;
    for(i=0;i<sizeof(names)/sizeof(names[0]);++i){
        for(j=0;j<sizeof(names[0]);++j){
            if(b[4+j]!=names[i][j])break;
            if(names[i][j]==0)return 1;
        }
    }
    return 0;
}
ULONG SkPdProfileApply(_Inout_updates_bytes_(capacity) UCHAR *b,SIZE_T capacity,SIZE_T information,ULONG mode)
{
    static const UCHAR guid[16]={0x62,0x6e,0x85,0x6b,0xf4,0x40,0x88,0x46,
        0xbd,0x46,0x5e,0x88,0x8a,0x22,0x60,0xde};
    SK_ARG g,p,pair,key,value;ULONG length,at,end,i,k,n=0,seen=0;
    ULONG source[1],sink[3],changed=0;
    if(mode!=1 || !b || information>capacity || information<12 ||
       information>SK_MAX_RESPONSE)return 0;
    if(word(b)!=SK_OUTPUT_SIGNATURE || word(b+8)!=2)return 0;
    length=word(b+4);
    if(length!=information || !arg(b,12,length,&g) || g.Type!=2 || g.Length!=16)return 0;
    for(i=0;i<16;++i)if(b[g.Data+i]!=guid[i])return 0;
    if(!arg(b,g.Next,length,&p) || p.Type!=3 || p.Next!=length)return 0;
    at=p.Data;end=at+p.Length;
    while(at<end){
        if(++n>32 || !arg(b,at,end,&pair) || pair.Type!=3 ||
           !arg(b,pair.Data,pair.Data+pair.Length,&key) || !integer(b,&key,&k) ||
           !arg(b,key.Next,pair.Data+pair.Length,&value) ||
           value.Next!=pair.Data+pair.Length)return 0;
        if(k==6){
            if(seen&1 || !array(b,&value,source,1,NULL) || source[0]!=0x19096)return 0;
            seen|=1;
        }else if(k==7){
            if(seen&2 || !array(b,&value,sink,3,&changed) ||
               sink[0]!=0x1912c || sink[2]!=0x3c096 ||
               (sink[1]!=0x2d0c8 && sink[1]!=0x2d12c))return 0;
            seen|=2;
        }
        at=pair.Next;
    }
    if(at!=end || seen!=3 || n!=10 || !changed)return 0;
    if(word(b+changed)==0x2d12c)return 2;
    /* Only 9V's current field: 2A -> 3A. Preserve 5V, 12V, all flags,
     * source capabilities, response size and unrelated properties. */
    b[changed]=0x2c;b[changed+1]=0xd1;b[changed+2]=2;b[changed+3]=0;
    return 1;
}

