param(
 [Parameter(Mandatory=$true)][string]$EWDKRoot,
 [string]$VCVersion='14.44.35207',
 [string]$KitVersion='10.0.26100.0',
 [ValidateSet('arm64','x64')][string]$HostArchitecture='arm64'
)
$ErrorActionPreference='Stop'
$skEwdk=[IO.Path]::GetFullPath($EWDKRoot)
$skVC=Join-Path $skEwdk ('Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\'+$VCVersion)
$skKit=Join-Path $skEwdk 'Program Files\Windows Kits\10'
$skCompiler=Join-Path $skVC ('bin\Host'+$HostArchitecture+'\arm64')
foreach($skRequired in @((Join-Path $skCompiler 'cl.exe'),(Join-Path $skCompiler 'link.exe'),(Join-Path $skKit ('Include\'+$KitVersion+'\km\ntddk.h')))) {
 if(!(Test-Path -LiteralPath $skRequired)){throw ('EWDK component is missing: '+$skRequired)}
}
$skOut=Join-Path $PSScriptRoot 'build'
New-Item -ItemType Directory -Path $skOut -Force|Out-Null
$skInc=@('/external:W0','/analyze:external-',"/external:I$skVC\include","/external:I$skKit\Include\$KitVersion\km","/external:I$skKit\Include\$KitVersion\shared","/external:I$skKit\Include\$KitVersion\ucrt","/external:I$skKit\Include\wdf\kmdf\1.33")
$skObjects=@()
$skWdfDefines=@('/DKMDF_VERSION_MAJOR=1','/DKMDF_VERSION_MINOR=33','/DKMDF_MINIMUM_VERSION_REQUIRED=33')
foreach($skUnit in @('profile','driver')){
 & "$skCompiler\cl.exe" /nologo /c /TC /kernel /GS /guard:cf /O2 /W4 /WX /analyze /Zl /D_ARM64_ /DARM64 @skWdfDefines @skInc (Join-Path $PSScriptRoot ($skUnit+'.c')) "/Fo$skOut\$skUnit.obj" *> "$skOut\$skUnit-analysis.log"
 if($LASTEXITCODE){Get-Content -LiteralPath "$skOut\$skUnit-analysis.log";throw 'Profile driver compile failed'}
 $skObjects+="$skOut\$skUnit.obj"
}
& "$skCompiler\link.exe" /nologo /DRIVER /SUBSYSTEM:NATIVE,10.00 /ENTRY:FxDriverEntry /NODEFAULTLIB /MACHINE:ARM64 /INCREMENTAL:NO /DYNAMICBASE /NXCOMPAT /GUARD:CF /INTEGRITYCHECK "/OUT:$skOut\skpdprofile.sys" "/MAP:$skOut\driver.map" "/LIBPATH:$skKit\Lib\$KitVersion\km\arm64" "/LIBPATH:$skKit\Lib\wdf\kmdf\arm64\1.33" @skObjects ntoskrnl.lib hal.lib BufferOverflowFastFailK.lib libcntpr.lib WdfLdr.lib WdfDriverEntry.lib *> "$skOut\link.log"
if($LASTEXITCODE){Get-Content -LiteralPath "$skOut\link.log";throw 'Profile driver link failed'}
$null=& (Join-Path $PSScriptRoot 'Verify-Bind.ps1') -Image "$skOut\skpdprofile.sys" -Map "$skOut\driver.map"
& "$skCompiler\cl.exe" /nologo /c /TC /kernel /GS- /O2 /W4 /WX /Zl /D_ARM64_ /DARM64 @skInc (Join-Path $PSScriptRoot 'profile.c') "/Fo$skOut\profile-model.obj" *> "$skOut\model-compile.log"
if($LASTEXITCODE){throw 'Parser model compile failed'}
& "$skCompiler\link.exe" /nologo /DLL /NOENTRY /NODEFAULTLIB /MACHINE:ARM64 /INCREMENTAL:NO "/OUT:$skOut\profile-model.dll" /EXPORT:SkPdProfileMatchInput /EXPORT:SkPdProfileApply "$skOut\profile-model.obj" *> "$skOut\model-link.log"
if($LASTEXITCODE){throw 'Parser model link failed'}
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'skpdprofile.inf') -Destination $skOut
[ordered]@{Architecture='ARM64';Version='0.1.3.0';HardwareId='ACPI\QCOM057D';SYS_SHA256=(Get-FileHash -LiteralPath "$skOut\skpdprofile.sys").Hash;Model_SHA256=(Get-FileHash -LiteralPath "$skOut\profile-model.dll").Hash;RealDriverEntry=$true;WdfBindVerified=$true;WDFHeader=(Join-Path $skKit 'Include\wdf\kmdf\1.33\wdffuncenum.h');DefaultMode=0;Signed=$false;Installed=$false;PPSImplemented=$false;HubContinuityFixed=$false;HardwareChargingImprovementProven=$false}|ConvertTo-Json|Set-Content -LiteralPath "$skOut\manifest.json" -Encoding utf8
Get-Content -LiteralPath "$skOut\manifest.json"

