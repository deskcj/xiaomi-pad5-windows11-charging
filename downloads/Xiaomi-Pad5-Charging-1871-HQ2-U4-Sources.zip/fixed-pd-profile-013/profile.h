/* SPDX-License-Identifier: MIT */
#pragma once
#pragma warning(push)
#pragma warning(disable:28301)
#include <ntddk.h>
#pragma warning(pop)
/* Only a memory response to CON0._DSD is changed. No PD packets or PMIC I/O. */
ULONG SkPdProfileMatchInput(_In_reads_bytes_(Length) const UCHAR *Bytes, SIZE_T Length);
ULONG SkPdProfileApply(_Inout_updates_bytes_(Capacity) UCHAR *Bytes,
    SIZE_T Capacity, SIZE_T Information, ULONG Mode);

