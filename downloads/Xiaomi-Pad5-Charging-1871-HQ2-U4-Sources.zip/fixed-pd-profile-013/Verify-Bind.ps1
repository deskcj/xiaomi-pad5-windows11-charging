param([Parameter(Mandatory)][string]$Image,[Parameter(Mandatory)][string]$Map)
$ErrorActionPreference='Stop'
$skBytes=[IO.File]::ReadAllBytes($Image)
$skPe=[BitConverter]::ToInt32($skBytes,0x3c)
if([BitConverter]::ToUInt32($skBytes,$skPe) -ne 0x4550 -or [BitConverter]::ToUInt16($skBytes,$skPe+4) -ne 0xaa64){throw 'Expected an ARM64 PE image'}
$skOptional=$skPe+24
if([BitConverter]::ToUInt16($skBytes,$skOptional) -ne 0x20b){throw 'Expected PE32+'}
$skBase=[BitConverter]::ToUInt64($skBytes,$skOptional+24)
$skSectionCount=[BitConverter]::ToUInt16($skBytes,$skPe+6)
$skSectionStart=$skOptional+[BitConverter]::ToUInt16($skBytes,$skPe+20)
function Get-SkFileOffset([UInt64]$Address,[int]$Length){
    if($Address -lt $skBase){throw 'Symbol lies below the image base'}
    $skRva=$Address-$skBase
    for($skI=0;$skI -lt $skSectionCount;$skI++){
        $skAt=$skSectionStart+40*$skI
        $skVa=[BitConverter]::ToUInt32($skBytes,$skAt+12)
        $skSize=[BitConverter]::ToUInt32($skBytes,$skAt+16)
        $skRaw=[BitConverter]::ToUInt32($skBytes,$skAt+20)
        if($skRva -ge $skVa -and $skRva+$Length -le [UInt64]$skVa+$skSize){
            $skOffset=[UInt64]$skRaw+$skRva-$skVa
            if($skOffset+$Length -gt $skBytes.Length){throw 'Symbol crosses the file boundary'}
            return [int]$skOffset
        }
    }
    throw 'Symbol is not backed by file data'
}
$skSymbols=@{}
foreach($skMatch in [regex]::Matches([IO.File]::ReadAllText($Map),'(?m)^\s*\S+:\S+\s+(\S+)\s+([0-9A-Fa-f]{16})\s')){
    $skSymbols[$skMatch.Groups[1].Value]=[Convert]::ToUInt64($skMatch.Groups[2].Value,16)
}
foreach($skName in @('WdfBindInfo','WdfMinimumVersionRequired','FxDriverEntry')){
    if(!$skSymbols.ContainsKey($skName)){throw ('Missing linker symbol '+$skName)}
}
$skBindOffset=Get-SkFileOffset $skSymbols.WdfBindInfo 88
$skMinimumOffset=Get-SkFileOffset $skSymbols.WdfMinimumVersionRequired 4
$skTargetMajor=[BitConverter]::ToUInt32($skBytes,$skBindOffset+16)
$skTargetMinor=[BitConverter]::ToUInt32($skBytes,$skBindOffset+20)
$skMinimum=[BitConverter]::ToUInt32($skBytes,$skMinimumOffset)
$skPointer=[BitConverter]::ToUInt64($skBytes,$skBindOffset+48)
$skEntry=$skBase+[BitConverter]::ToUInt32($skBytes,$skOptional+16)
if([BitConverter]::ToUInt32($skBytes,$skBindOffset) -ne 88 -or $skTargetMajor -ne 1 -or $skTargetMinor -ne 33 -or $skMinimum -ne 33 -or $skPointer -ne $skSymbols.WdfMinimumVersionRequired -or $skEntry -ne $skSymbols.FxDriverEntry){
    throw ('Invalid KMDF binding: target='+$skTargetMajor+'.'+$skTargetMinor+' minimum='+$skMinimum)
}
[ordered]@{Image=$Image;SHA256=(Get-FileHash -LiteralPath $Image -Algorithm SHA256).Hash;Target='1.33';MinimumRequired=33;EntryPoint='FxDriverEntry';Passed=$true;WindowsBootTest=$false}|ConvertTo-Json
