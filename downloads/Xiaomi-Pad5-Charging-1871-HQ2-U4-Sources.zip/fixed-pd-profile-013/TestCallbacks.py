"""Exact SYS callbacks with explicit WDF mocks; not a full kernel/driver test."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,struct
R=Path(__file__).resolve().parent
scope={'__file__':str(R/'Test.py')}
exec(compile((R/'Test.py').read_text().split('cases=[')[0],'Pinned parser harness setup','exec'),scope)
globals().update({k:v for k,v in scope.items() if k not in ('__file__','__builtins__')})
header=Path(manifest['WDFHeader'])
names=('WdfDeviceGetIoTarget','WdfIoQueueGetDevice','WdfObjectGetTypedContextWorker',
    'WdfObjectAllocateContext','WdfRequestFormatRequestUsingCurrentType',
    'WdfRequestSend','WdfRequestGetStatus','WdfRequestSetCompletionRoutine',
    'WdfRequestComplete','WdfRequestCompleteWithInformation',
    'WdfRequestRetrieveInputBuffer','WdfRequestRetrieveOutputBuffer')
indexes={name:int(re.search(name+r'TableIndex\s*=\s*(\d+)',header.read_text()).group(1)) for name in names}
class CallbackReplay(Replay):
    def __init__(self,base,mode=1,getter=0,allocation=0,send=True):
        self.stubnames={};self.events=[];self.getter=getter;self.allocation=allocation;self.send=send
        super().__init__('skpdprofile.sys',base)
        self.queue,self.request,self.device,self.target=0x101010,0x202020,0x303030,0x404040
        self.dc,self.rc,self.params=0x3000d000,0x3000d100,0x3000e000
        self.buffer=0x30008000-len(baseline);self.input=0x30006000
        self.q(base+symbols['WdfFunctions_01033'],0x3000c000)
        self.q(base+symbols['WdfDriverGlobals'],0x505050)
        self.q(base+symbols['__guard_check_icall_fptr'],0x30011000)
        self.q(base+symbols['SkEtw'],0xabcdef)
        self.q(base+symbols['__imp_EtwWrite'],0x30012000)
        for name,index in indexes.items():
            stub=0x30010000+index*4
            self.stubnames[stub]=name;self.q(0x3000c000+index*8,stub)
        self.d(self.dc,mode);self.d(self.rc,mode)
        self.u.mem_write(self.buffer,baseline);self.u.mem_write(self.input,input_)
    def q(self,at,v):self.u.mem_write(at,struct.pack('<Q',v))
    def d(self,at,v):self.u.mem_write(at,struct.pack('<I',v&0xffffffff))
    def ret(self,value=0):
        lr=self.u.reg_read(UC_ARM64_REG_LR)
        for i in range(18):self.u.reg_write(UC_ARM64_REG_X0+i,0xcccccccccccccccc)
        self.u.reg_write(UC_ARM64_REG_X0,value&0xffffffffffffffff);self.u.reg_write(UC_ARM64_REG_PC,lr)
    def hook(self,u,at,size,_):
        if at==0x30012000:
            v=[u.reg_read(UC_ARM64_REG_X0+i) for i in range(5)]
            assert v[0]==0xabcdef and v[2]==0 and v[3]==5
            descriptor=bytes(u.mem_read(v[1],16))
            assert descriptor==struct.pack('<HBBBBHQ',1,1,0,4,0,0,1)
            pieces=[]
            for i,n in enumerate((4,4,4,8,4)):
                ptr,length,reserved=struct.unpack('<QII',u.mem_read(v[4]+16*i,16))
                assert length==n and reserved==0
                pieces.append(bytes(u.mem_read(ptr,n)))
            kind,mode,status,information,result=struct.unpack('<IIIQI',b''.join(pieces))
            self.events.append(dict(Name='EtwWrite',Kind=kind,Mode=mode,
                Status=hex(status),Information=information,Result=result))
            self.ret(0xc0000001) # even telemetry failure must preserve completion
            return
        if at==self.base+symbols.get('_guard_check_icall',-1) or at==0x30011000:
            u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_LR));return
        if at not in self.stubnames:return super().hook(u,at,size,_)
        name=self.stubnames[at];v=[u.reg_read(UC_ARM64_REG_X0+i) for i in range(8)]
        self.events.append(dict(Name=name,Arguments=[hex(x) for x in v[:5]]))
        if name=='WdfObjectGetTypedContextWorker':
            assert v[0]==0x505050 and v[1] in (self.device,self.request),(name,v)
            self.ret(self.dc if v[1]==self.device else self.rc)
        else:
            assert v[0]==0x505050,(name,v)
            if name=='WdfIoQueueGetDevice':assert v[1]==self.queue;self.ret(self.device)
            elif name=='WdfDeviceGetIoTarget':assert v[1]==self.device;self.ret(self.target)
            elif name=='WdfObjectAllocateContext':
                assert v[1]==self.request
                if not self.allocation:self.q(v[3],self.rc)
                self.ret(self.allocation)
            elif name in ('WdfRequestRetrieveInputBuffer','WdfRequestRetrieveOutputBuffer'):
                assert v[1]==self.request
                if not self.getter:
                    self.q(v[3],self.input if name.endswith('InputBuffer') else self.buffer)
                    self.q(v[4],len(input_) if name.endswith('InputBuffer') else len(baseline))
                self.ret(self.getter)
            elif name=='WdfRequestSetCompletionRoutine':
                assert v[1]==self.request and v[2]==self.base+symbols['SkComplete'] and v[3]==0
                self.ret()
            elif name=='WdfRequestSend':
                assert v[1]==self.request and v[2]==self.target
                self.ret(int(self.send))
            elif name=='WdfRequestGetStatus':assert v[1]==self.request;self.ret(0xc0000185)
            elif name in ('WdfRequestComplete','WdfRequestCompleteWithInformation'):
                assert v[1]==self.request
                self.events[-1]['Status']=hex(v[2]&0xffffffff)
                self.events[-1]['Information']=v[3] if name.endswith('WithInformation') else None
                self.ret()
            elif name=='WdfRequestFormatRequestUsingCurrentType':
                assert v[1]==self.request;self.ret()
            else:raise AssertionError(name)
    def invoke(self,name,args):
        u=self.u;self.writes=[];saved={UC_ARM64_REG_X19+i:0xabc0000000000000+i for i in range(10)}
        saved.update({UC_ARM64_REG_FP:0xabc1234567890000,UC_ARM64_REG_X18:0x123456789})
        for reg,v in saved.items():u.reg_write(reg,v)
        u.reg_write(UC_ARM64_REG_SP,0x70010000);u.reg_write(UC_ARM64_REG_LR,self.end)
        for i,v in enumerate(args):u.reg_write(UC_ARM64_REG_X0+i,v)
        u.emu_start(self.base+symbols[name],self.end,count=50000)
        assert u.reg_read(UC_ARM64_REG_PC)==self.end and u.reg_read(UC_ARM64_REG_SP)==0x70010000
        assert all(u.reg_read(reg)==v for reg,v in saved.items())
        for at,n in self.writes:
            assert (self.buffer<=at and at+n<=self.buffer+len(baseline) or
                    0x70000000<=at and at+n<=0x70020000 or
                    self.rc<=at and at+n<=self.rc+4),(hex(at),n)
        return bytes(u.mem_read(self.buffer,len(baseline)))
rows=[]
for base in (0x140000000,0x180000000):
    for status,information,getter,mode in ((0,len(baseline),0,1),(0,len(baseline),0,0),
        (0,len(baseline)+1,0,1),(0,11,0,1),(0,len(baseline),0xc0000023,1),
        (0x80000005,12,0,1),(0xc0000185,0,0,1),(0xc0000120,0,0,1)):
        r=CallbackReplay(base,mode=mode,getter=getter)
        r.d(r.params+8,status);r.q(r.params+16,information)
        out=r.invoke('SkComplete',(r.request,r.target,r.params,0))
        completions=[x for x in r.events if x['Name'].startswith('WdfRequestComplete')]
        assert len(completions)==1 and completions[0]['Status']==hex(status)
        assert completions[0]['Information']==information
        traces=[x for x in r.events if x['Name']=='EtwWrite']
        assert len(traces)==1 and traces[0]['Kind']==2 and traces[0]['Mode']==mode
        assert traces[0]['Status']==hex(status) and traces[0]['Information']==information
        patched=status==0 and information==len(baseline) and not getter and mode==1
        assert out==(payload(sink=(0x1912c,0x2d12c,0x3c096)) if patched else baseline)
        assert traces[0]['Result']==int(patched)
        rows.append(dict(Kind='Completion',Base=hex(base),Status=hex(status),Info=information,
            GetterError=hex(getter),Mode=mode,Patched=patched,Calls=[x['Name'] for x in r.events]))
    for mode,code,matched,getter,allocation,send in (
        (1,0x32c018,True,0,0,True),(0,0x32c018,True,0,0,True),
        (1,0x32c014,True,0,0,True),(1,0x32c018,False,0,0,True),
        (1,0x32c018,True,0xc0000023,0,True),
        (1,0x32c018,True,0,0xc000009a,True),(1,0x32c018,True,0,0,False),
        (0,0x32c018,True,0,0,False)):
        r=CallbackReplay(base,mode=mode,getter=getter,allocation=allocation,send=send)
        if not matched:r.u.mem_write(r.input,input_.replace(b'CON0',b'CON1'))
        out=r.invoke('SkIoctl',(r.queue,r.request,len(baseline),len(input_),code))
        assert out==baseline
        calls=[x['Name'] for x in r.events]
        assert calls.count('WdfRequestSend')==1
        checks=[x for x in r.events if x['Name']=='EtwWrite' and x['Kind']==5]
        assert len(checks)==int(mode==1 and code==0x32c018)
        if checks:
            assert checks[0]['Result']==int(matched and not getter)
            assert checks[0]['Status']==hex(getter)
        expect_callback=mode==1 and code==0x32c018 and matched and not getter and not allocation
        assert ('WdfRequestSetCompletionRoutine' in calls)==expect_callback
        completions=[x for x in r.events if x['Name'].startswith('WdfRequestComplete')]
        assert len(completions)==int(not send)
        if completions:assert completions[0]['Status']=='0xc0000185'
        rows.append(dict(Kind='Ioctl',Base=hex(base),Mode=mode,IOCTL=hex(code),Matched=matched,
            GetterError=hex(getter),AllocationError=hex(allocation),Sent=send,
            CompletionInstalled=expect_callback,Calls=calls))
    for path in (b'\\_SB_.UCP0.CON0._DSD',b'\\_SB.UCP0.CON0._DSD'):
        for mode in (0,1):
            r=CallbackReplay(base,mode=mode)
            wire=struct.pack('<I',0x41696541)+(path+b'\0').ljust(256,b'\0')
            r.u.mem_write(r.input,wire)
            out=r.invoke('SkIoctl',(r.queue,r.request,len(baseline),len(wire),0x32c018))
            calls=[x['Name'] for x in r.events]
            assert out==baseline and calls.count('WdfRequestSend')==1
            assert ('WdfRequestSetCompletionRoutine' in calls)==bool(mode)
            checks=[x for x in r.events if x['Name']=='EtwWrite' and x['Kind']==5]
            assert len(checks)==mode
            if checks:assert checks[0]['Result']==1
            rows.append(dict(Kind='AbsolutePathIoctl',Base=hex(base),Path=path.decode(),Mode=mode,
                             CompletionInstalled=bool(mode),Calls=calls))
result=dict(AtUTC=datetime.now(timezone.utc).isoformat(),Passed=True,Executions=len(rows),
    SYS_SHA256=sha(R/'build/skpdprofile.sys'),WdfHeaderSHA256=sha(header),WdfIndexes=indexes,
    WdfFrameworkMocked=True,ActualDriverCallbacksExecuted=True,FullPnpBootOrKernelTest=False,
    HardwareIO=False,Installed=False,Cases=rows)
(R/'callback-qa.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='Cases'},indent=2))

