/* SPDX-License-Identifier: MIT */
#include "profile.h"
#if !defined(KMDF_VERSION_MAJOR) || !defined(KMDF_VERSION_MINOR) || !defined(KMDF_MINIMUM_VERSION_REQUIRED)
#error The WDF target and minimum version must be explicitly specified by the build.
#endif
#if KMDF_VERSION_MAJOR != 1 || KMDF_VERSION_MINOR != 33 || KMDF_MINIMUM_VERSION_REQUIRED != 33
#error This research candidate is pinned to KMDF 1.33.
#endif
#pragma warning(push)
#pragma warning(disable:4324)
#include <wdf.h>
#pragma warning(pop)
#include <acpiioct.h>
typedef struct SK_DEVICE {ULONG Mode;} SK_DEVICE;
typedef struct SK_REQUEST {ULONG Mode;} SK_REQUEST;
WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(SK_DEVICE,SkDevice);
WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(SK_REQUEST,SkRequest);
DRIVER_INITIALIZE DriverEntry;
EVT_WDF_DRIVER_DEVICE_ADD SkAdd;
EVT_WDF_IO_QUEUE_IO_DEVICE_CONTROL SkIoctl;
EVT_WDF_REQUEST_COMPLETION_ROUTINE SkComplete;
EVT_WDF_DRIVER_UNLOAD SkUnload;
static REGHANDLE SkEtw;
static const GUID SkProvider={0xd29867a8,0xda45,0x4c29,{0x8e,0x9c,0x47,0x7d,0x72,0xac,0xa1,0x06}};
/* ID 1/version 1, keyword 1. Payload: kind/u32, mode/u32, status/u32,
 * information/u64, parser-result/u32. No device identifiers or raw data.
 * EtwWrite is nonblocking at completion IRQL; telemetry failures are ignored. */
static VOID SkTrace(ULONG kind,ULONG mode,NTSTATUS status,ULONGLONG information,ULONG result)
{
    static const EVENT_DESCRIPTOR event={1,1,0,4,0,0,1};
    EVENT_DATA_DESCRIPTOR data[5];
    ULONG values[4]={kind,mode,(ULONG)status,result};
    ULONG i;
    if(!SkEtw)return;
    for(i=0;i<3;++i){data[i].Ptr=(ULONGLONG)(ULONG_PTR)&values[i];data[i].Size=4;data[i].Reserved=0;}
    data[3].Ptr=(ULONGLONG)(ULONG_PTR)&information;data[3].Size=8;data[3].Reserved=0;
    data[4].Ptr=(ULONGLONG)(ULONG_PTR)&values[3];data[4].Size=4;data[4].Reserved=0;
    (VOID)EtwWrite(SkEtw,&event,NULL,5,data);
}
static VOID forward(WDFQUEUE queue,WDFREQUEST request)
{
    WDF_REQUEST_SEND_OPTIONS options;
    WdfRequestFormatRequestUsingCurrentType(request);
    WDF_REQUEST_SEND_OPTIONS_INIT(&options,WDF_REQUEST_SEND_OPTION_SEND_AND_FORGET);
    if(!WdfRequestSend(request,WdfDeviceGetIoTarget(WdfIoQueueGetDevice(queue)),&options))
        WdfRequestComplete(request,WdfRequestGetStatus(request));
}
_Use_decl_annotations_
VOID SkComplete(WDFREQUEST request,WDFIOTARGET target,
    PWDF_REQUEST_COMPLETION_PARAMS params,WDFCONTEXT context)
{
    NTSTATUS status=params->IoStatus.Status;ULONG_PTR information=params->IoStatus.Information;
    PVOID bytes=NULL;SIZE_T capacity=0;
    ULONG result=0,mode=SkRequest(request)->Mode;
    UNREFERENCED_PARAMETER(target);UNREFERENCED_PARAMETER(context);
    /* Nonpaged parser: no allocation, registry access, locks, waits, hardware
     * handles, timers or additional requests on completion. Lower failures
     * and buffer-overflow responses always retain original status/data. */
    if(status==STATUS_SUCCESS &&
       NT_SUCCESS(WdfRequestRetrieveOutputBuffer(request,12,&bytes,&capacity))){
        result=SkPdProfileApply(bytes,capacity,information,mode);
    }
    SkTrace(2,mode,status,information,result);
    WdfRequestCompleteWithInformation(request,status,information);
}
_Use_decl_annotations_
VOID SkIoctl(WDFQUEUE queue,WDFREQUEST request,SIZE_T outputLength,
    SIZE_T inputLength,ULONG code)
{
    WDFDEVICE device=WdfIoQueueGetDevice(queue);
    WDF_OBJECT_ATTRIBUTES attributes;SK_REQUEST *r=NULL;NTSTATUS status;
    PVOID input=NULL;SIZE_T length=0;ULONG matched=0;
    UNREFERENCED_PARAMETER(outputLength);UNREFERENCED_PARAMETER(inputLength);
    if(!SkDevice(device)->Mode || code!=IOCTL_ACPI_EVAL_METHOD_EX){
        forward(queue,request);return;
    }
    status=WdfRequestRetrieveInputBuffer(request,260,&input,&length);
    if(NT_SUCCESS(status))matched=SkPdProfileMatchInput(input,length);
    /* Kind 5 records a bounded ACPI EX input check; no raw namespace data.
     * Completion kind 2/result 1 remains the live mutation proof. */
    SkTrace(5,SkDevice(device)->Mode,status,(ULONGLONG)length,matched);
    if(!matched){
        forward(queue,request);return;
    }
    WDF_OBJECT_ATTRIBUTES_INIT_CONTEXT_TYPE(&attributes,SK_REQUEST);
    status=WdfObjectAllocateContext(request,&attributes,(PVOID*)&r);
    if(!NT_SUCCESS(status)){forward(queue,request);return;}
    r->Mode=SkDevice(device)->Mode;
    WdfRequestFormatRequestUsingCurrentType(request);
    WdfRequestSetCompletionRoutine(request,SkComplete,NULL);
    if(!WdfRequestSend(request,WdfDeviceGetIoTarget(device),NULL))
        WdfRequestComplete(request,WdfRequestGetStatus(request));
}
_Use_decl_annotations_
NTSTATUS SkAdd(WDFDRIVER driver,PWDFDEVICE_INIT init)
{
    WDFDEVICE device;WDF_OBJECT_ATTRIBUTES attributes;WDF_IO_QUEUE_CONFIG queue;
    WDFKEY key;NTSTATUS status;ULONG mode=0;UNICODE_STRING name;
    UNREFERENCED_PARAMETER(driver);
    WdfFdoInitSetFilter(init);
    WDF_OBJECT_ATTRIBUTES_INIT_CONTEXT_TYPE(&attributes,SK_DEVICE);
    status=WdfDeviceCreate(&init,&attributes,&device);
    if(!NT_SUCCESS(status))return status;
    /* Explicit per-device opt-in; default 0 leaves native PD policy intact. */
    status=WdfDeviceOpenRegistryKey(device,PLUGPLAY_REGKEY_DEVICE,KEY_READ,
                                   WDF_NO_OBJECT_ATTRIBUTES,&key);
    if(NT_SUCCESS(status)){
        RtlInitUnicodeString(&name,L"SkExperimentalFixed9V3A");
        status=WdfRegistryQueryULong(key,&name,&mode);
        WdfRegistryClose(key);
        if(!NT_SUCCESS(status))mode=0;
    }
    SkDevice(device)->Mode=(mode==1)?1:0;
    SkTrace(1,SkDevice(device)->Mode,status,0,0);
    WDF_IO_QUEUE_CONFIG_INIT_DEFAULT_QUEUE(&queue,WdfIoQueueDispatchParallel);
    queue.PowerManaged=WdfFalse;
    queue.EvtIoDeviceControl=SkIoctl;
    /* Pinned UcmCx uses ordinary DeviceControl for _DSD. Internal requests
     * are left to KMDF's automatic filter forwarding. */
    return WdfIoQueueCreate(device,&queue,WDF_NO_OBJECT_ATTRIBUTES,WDF_NO_HANDLE);
}
_Use_decl_annotations_
NTSTATUS DriverEntry(PDRIVER_OBJECT object,PUNICODE_STRING path)
{
    WDF_DRIVER_CONFIG config;NTSTATUS status;REGHANDLE trace=0;
    if(NT_SUCCESS(EtwRegister(&SkProvider,NULL,NULL,&trace)))SkEtw=trace;
    SkTrace(3,0,STATUS_SUCCESS,0,0);
    WDF_DRIVER_CONFIG_INIT(&config,SkAdd);
    config.EvtDriverUnload=SkUnload;
    status=WdfDriverCreate(object,path,WDF_NO_OBJECT_ATTRIBUTES,&config,WDF_NO_HANDLE);
    SkTrace(4,0,status,0,0);
    if(!NT_SUCCESS(status) && SkEtw){(VOID)EtwUnregister(SkEtw);SkEtw=0;}
    return status;
}
_Use_decl_annotations_
VOID SkUnload(WDFDRIVER driver)
{
    UNREFERENCED_PARAMETER(driver);
    if(SkEtw){(VOID)EtwUnregister(SkEtw);SkEtw=0;}
}

