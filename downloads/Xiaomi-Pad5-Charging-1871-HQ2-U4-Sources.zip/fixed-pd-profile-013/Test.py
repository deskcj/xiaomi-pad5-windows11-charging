"""Execute the exact new SYS parser and model at two bases; never load the SYS."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,random,re,struct,sys
R=Path(__file__).resolve().parent
import pefile
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE,UC_HOOK_MEM_WRITE
from unicorn.arm64_const import *
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
mapping=(R/'build/driver.map').read_text()
symbols={name:int(address,16)-0x140000000 for name,address in
    re.findall(r'^\s+[0-9a-fA-F]{4}:[0-9a-fA-F]{8}\s+(\S+)\s+([0-9a-fA-F]{16})\s',mapping,re.M)
    if int(address,16)>=0x140000000}
def a(typ,data):
    return struct.pack('<HH',typ,len(data))+data.ljust(4,b'\0')
def integer(value,width=4):return a(0,value.to_bytes(width,'little'))
def pack(*args):return a(3,b''.join(args))
GUID=bytes.fromhex('626e856bf4408846bd465e888a2260de')
def payload(sink=(0x1912c,0x2d0c8,0x3c096),source=(0x19096,),guid=GUID,width=4,extra=()):
    props=[(1,integer(4,width)),(2,integer(3,width)),(3,integer(0,width)),
           (4,integer(1,width)),(5,integer(3,width)),
           (6,pack(*(integer(v,width) for v in source))),
           (7,pack(*(integer(v,width) for v in sink))),
           (8,pack(integer(0xff01,width),integer(0x3c86,width))),
           (9,integer(1,width)),(10,integer(1,width))]+list(extra)
    body=a(2,guid)+pack(*(pack(integer(k,width),v) for k,v in props))
    return struct.pack('<III',0x426f6541,12+len(body),2)+body
baseline=payload()
input_=struct.pack('<I',0x41696541)+b'CON0._DSD\0'.ljust(256,b'\0')
manifest=json.loads((R/'build/manifest.json').read_text(encoding='utf-8-sig'))
assert manifest['SYS_SHA256'].lower()==sha(R/'build/skpdprofile.sys')
assert manifest['Model_SHA256'].lower()==sha(R/'build/profile-model.dll')
# All helper accesses are isolated in Unicorn. Framework entry/IRPs/ACPI are
# not executed by this parser harness, and the serialized response is a fixture.
class Replay:
    def __init__(self,name,base):
        self.name=name;self.base=base
        self.raw=(R/'build'/name).read_bytes();p=pefile.PE(data=self.raw)
        self.entries=symbols if name.endswith('.sys') else {x.name.decode():x.address for x in p.DIRECTORY_ENTRY_EXPORT.symbols}
        p.relocate_image(base);image=p.get_memory_mapped_image()
        self.u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
        self.u.mem_map(base,(len(image)+4095)&~4095);self.u.mem_write(base,image)
        self.u.mem_map(0x30000000,0x20000);self.u.mem_map(0x70000000,0x20000)
        self.end=0x3001f000;self.u.hook_add(UC_HOOK_CODE,self.hook)
        self.writes=[];self.u.hook_add(UC_HOOK_MEM_WRITE,self.write)
    def hook(self,u,at,size,_):
        if at==self.end:u.emu_stop();return
        assert self.base<=at<self.base+0x10000,hex(at)
    def write(self,u,kind,at,size,value,_):self.writes.append((at,size))
    def call(self,method,b,capacity=None,information=None,mode=1):
        u=self.u;length=len(b);at=0x30008000-length
        u.mem_write(at,b);self.writes=[]
        saved={UC_ARM64_REG_X19+i:0xabc0000000000000+i for i in range(10)}
        saved.update({UC_ARM64_REG_FP:0xabc1234567890000,UC_ARM64_REG_X18:0x123456789})
        for reg,v in saved.items():u.reg_write(reg,v)
        u.reg_write(UC_ARM64_REG_SP,0x70010000);u.reg_write(UC_ARM64_REG_LR,self.end)
        args=(at,length) if method=='SkPdProfileMatchInput' else (
            at,length if capacity is None else capacity,length if information is None else information,mode)
        for i,v in enumerate(args):u.reg_write(UC_ARM64_REG_X0+i,v)
        u.emu_start(self.base+self.entries[method],self.end,count=50000)
        assert u.reg_read(UC_ARM64_REG_PC)==self.end
        assert u.reg_read(UC_ARM64_REG_SP)==0x70010000
        assert all(u.reg_read(reg)==v for reg,v in saved.items())
        for start,n in self.writes:
            assert at<=start and start+n<=at+length or 0x70000000<=start and start+n<=0x70020000,(start,n)
        return u.reg_read(UC_ARM64_REG_W0),bytes(u.mem_read(at,length))
cases=[('baseline',baseline,{},1),
       ('integer64',payload(width=8),{},1),
       ('already3A',payload(sink=(0x1912c,0x2d12c,0x3c096)),{},2),
       ('disabled',baseline,dict(mode=0),0),
       ('unknownMode',baseline,dict(mode=2),0),
       ('infoPastCapacity',baseline,dict(information=len(baseline)+1),0),
       ('shortInfo',baseline,dict(information=11),0),
       ('unsupportedSource',payload(source=(0x1912c,)),{},0),
       ('unsupportedSink',payload(sink=(0x1912c,0x2d064,0x3c096)),{},0),
       ('modified12V',payload(sink=(0x1912c,0x2d0c8,0x3c0fa)),{},0),
       ('wrongGuid',payload(guid=bytes(16)),{},0),
       ('duplicate7',payload(extra=((7,pack(integer(0x1912c),integer(0x2d0c8),integer(0x3c096))),)),{},0),
       ('missingThirdSink',payload(sink=(0x1912c,0x2d0c8)),{},0)]
for n in range(len(baseline)):cases.append(('truncated'+str(n),baseline[:n],{},0))
# Deterministic mutations of lengths, types, IDs and payload. Unrelated bytes
# may retain a valid expected descriptor; model validation decides whether to
# skip or apply, while bounds, ABI and write confinement are always checked.
rng=random.Random(20261103)
fuzz=[]
for i in range(300):
    b=bytearray(baseline)
    for _ in range(rng.randrange(1,5)):
        j=rng.randrange(len(b));b[j]=rng.randrange(256)
    fuzz.append(('fuzz'+str(i),bytes(b),{},None))
input_cases=[('matched',input_,1),('short',input_[:259],0),('otherPath',input_.replace(b'CON0',b'CON1'),0),
             ('otherSignature',bytes(4)+input_[4:],0),('suffix',input_.replace(b'_DSD\0',b'_DSM\0'),0)]
for path in (b'\\_SB_.UCP0.CON0._DSD',b'\\_SB.UCP0.CON0._DSD'):
    wire=struct.pack('<I',0x41696541)+(path+b'\0').ljust(256,b'\0')
    input_cases.append(('absolute-'+path.decode(),wire,1))
    for length in range(260):input_cases.append(('absolute-truncated-'+str(length),wire[:length],0))
    for wrong in (path.replace(b'CON0',b'CON1'),path.replace(b'UCP0',b'UCP1'),
                  path.replace(b'_DSD',b'_DSM'),path+b'X',path[1:],path.lower(),b'X'+path):
        input_cases.append(('absolute-other-'+wrong.decode(),struct.pack('<I',0x41696541)+(wrong+b'\0').ljust(256,b'\0'),0))
    for i in range(len(path)+1):
        mutated=bytearray(wire);mutated[4+i]^=0x40
        input_cases.append(('absolute-mutated-'+str(i),bytes(mutated),0))
input_cases.append(('unterminated',struct.pack('<I',0x41696541)+b'\\_SB_.UCP0.CON0._DSD'.ljust(256,b'X'),0))
rows=[];count=0
expected=payload(sink=(0x1912c,0x2d12c,0x3c096))
for image in ('skpdprofile.sys','profile-model.dll'):
    for base in (0x140000000,0x180000000):
        r=Replay(image,base)
        for label,b,params,result in cases+fuzz:
            status,out=r.call('SkPdProfileApply',b,**params)
            assert status in (0,1,2),(label,status)
            if result is not None:assert status==result,(label,status)
            if status==0 or status==2:assert out==b,label
            else:
                diff=[i for i,(x,y) in enumerate(zip(b,out)) if x!=y]
                assert len(diff)==2 and diff[1]==diff[0]+1
                at=diff[0];assert b[at:at+4]==bytes.fromhex('c8d00200')
                assert out[at:at+4]==bytes.fromhex('2cd10200')
                assert out[:at]==b[:at] and out[at+4:]==b[at+4:]
                if label=='baseline':assert out==expected
            count+=1
        for label,b,status in input_cases:
            result,out=r.call('SkPdProfileMatchInput',b)
            assert result==status and out==b
            count+=1
        rows.append(dict(Image=image,Base=hex(base),Cases=len(cases)+len(fuzz)+len(input_cases)))
report=dict(AtUTC=datetime.now(timezone.utc).isoformat(),Passed=True,ARM64Executions=count,
    SYS_SHA256=sha(R/'build/skpdprofile.sys'),Model_SHA256=sha(R/'build/profile-model.dll'),
    SourcePins={p.name:sha(p) for p in (R/'profile.c',R/'profile.h',R/'driver.c',R/'skpdprofile.inf')},
    Cases=rows,ResponseFixtureSHA256=hashlib.sha256(baseline).hexdigest(),
    ExactSysParserExecuted=True,DriverEntryAndWdfFrameworkExecuted=False,
    ACPIResponseSerializationModeled=True,HardwareIO=False,Installed=False,
    HardwareFastChargingFixProven=False,HardwareHubContinuityFixProven=False)
(R/'native-qa.json').write_text(json.dumps(report,indent=2)+'\n')
(R/'fixture-native-dsd.bin').write_bytes(baseline)
(R/'fixture-patched-dsd.bin').write_bytes(expected)
print(json.dumps(report,indent=2))

