# Xiaomi Pad 5 charging — U4 development sources

[Русский](README.ru.md)

This archive provides the available custom implementation and development work for **1871-HQ2-U4**. It contains exact installer/diagnostic/rollback scripts, custom fixed PD filter 0.1.3 source, current binary patch additions and their offline tests, plus the latest offline PD/PPS/LN8000/FRS components. See [the development handoff](docs/CONTINUE-DEVELOPMENT.md) and [charging measurements](docs/FAST-CHARGING.md).

Full Qualcomm source and private signing keys are not available. The vendor drivers cannot all be rebuilt from scratch using this ZIP. Prerequisite binary hashes are recorded, but reference binaries, machine backups, participant logs and dumps are omitted. Offline PPS/FRS work is not installed by U4. Exact source copies and provenance are recorded in SOURCE-PROVENANCE.json; all archive files are indexed by FILES-SHA256.json.

## Build the custom PD filter

Install EWDK/WDK with the ARM64 compiler and KMDF 1.33, and Python with the dependencies in requirements.txt. The tested toolchain is MSVC 14.44.35207 and Windows Kit 10.0.26100.0.

```powershell
python -m pip install -r .\requirements.txt
cd .\fixed-pd-profile-013
.\Build.ps1 -EWDKRoot 'D:\EWDK'
python .\Test.py
python .\TestCallbacks.py
python .\TestLifecycle.py
```

On an x64 build host use `-HostArchitecture x64`. This produces an unsigned SYS and offline model; the tests emulate ARM64 code and do not install it. Signing requires your own development key and certificate. Follow the driver package instructions for actual installation. Historical patch/research build scripts retain workstation paths and need adaptation; see the handoff before executing them.

LICENSE-PD.txt applies to the custom PD filter files named in that notice. Third-party ownership and notices remain unchanged. No blanket license over vendor binaries or copied vendor implementation is granted. This is experimental work supplied as-is; independent from Xiaomi, Qualcomm and Microsoft.
