﻿param()
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Common.ps1')
. (Join-Path $PSScriptRoot 'Completion.ps1')
. (Join-Path $PSScriptRoot 'Peer.ps1')
$folder=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'SK-Charging-Verification'
Assert-SkInternalPath $folder
New-Item -ItemType Directory -Path $folder -Force | Out-Null
$file=Join-Path $folder ((Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N')+'.json')
$r=[ordered]@{Build=$script:SkRelease;At=(Get-Date).ToString('o');InstalledSetVerified=$false;DriverInstalled=$false;RebootIssued=$false;HardwarePowerProven=$false;PPSImplemented=$false;HubContinuityFixed=$false}
try {
 Assert-SkTablet;$m=Assert-SkPackage $PSScriptRoot
 $devices=@(Get-SkDevices);$selected=@(Get-SkBaseline $devices);$pd=Get-SkPdState $devices
 $r.Drivers=$selected;$r.PD=$pd;$r.SelectedSet=Get-SkWholeCompletion $m $selected $pd
 $r.PendingFirstReboot=Get-SkPendingBoot
 $r.InstalledSetVerified=$r.SelectedSet.Complete -and !$r.PendingFirstReboot
 $r | ConvertTo-Json -Depth 16 | Set-Content -LiteralPath $file -Encoding utf8
 Write-Host ('Verification report: '+$file)
 if(!$r.InstalledSetVerified){throw 'Complete driver set not verified. If a reboot is pending, reboot once. Otherwise run Diagnose.cmd and keep its archive.'}
 Write-Host 'PASS: all base INF/SYS identities, Running/Code0, PD0.1.3 image and USB-C attachment match; mode1 is configured.' -ForegroundColor Green
 Write-Host 'This verifies installation, not measured charging speed or hub continuity.'
 [pscustomobject]$r
}catch {
 $r.Error=$_.Exception.Message;$r | ConvertTo-Json -Depth 16 | Set-Content -LiteralPath $file -Encoding utf8
 Write-Host ('Verification report: '+$file);throw
}
