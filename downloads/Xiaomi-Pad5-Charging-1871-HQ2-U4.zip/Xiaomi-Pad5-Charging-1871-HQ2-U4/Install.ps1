﻿param([switch]$CheckOnly,[switch]$Restore,[string]$BackupPath)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Common.ps1')
. (Join-Path $PSScriptRoot 'Completion.ps1')
. (Join-Path $PSScriptRoot 'Peer.ps1')
$r=[ordered]@{Build=$script:SkRelease;Started=(Get-Date).ToString('o');Status='NotStarted';InstalledSetVerified=$false;Success=$false;CheckOnly=[bool]$CheckOnly;Restore=[bool]$Restore;DriverFilesChanged=$false;RebootIssued=$false;LiveDevicesReset=$false;NativeRequestSucceeded=$false;NativeAttempts=@()}
$run=$null;$lock=$null;$modeChanged=$false
function Save-Record {if($run){$r | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath (Join-Path $run 'result.json') -Encoding utf8}}
try {
 if($CheckOnly -and $Restore){throw 'Check and Restore are separate actions'}
 $base=Get-SkPeerBase;Assert-SkInternalPath $base
 $run=Join-Path $base ((Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N'))
 New-Item -ItemType Directory -Path $run -Force | Out-Null
 $r.Status='Preflight';$r.Record=(Join-Path $run 'result.json');Save-Record
 Assert-SkTablet
 $r.OS=Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber,LastBootUpTime
 $r.System=Get-CimInstance Win32_ComputerSystem | Select-Object Manufacturer,Model,SystemType
 $devices=@(Get-SkDevices);$before=@(Get-SkBaseline $devices);$pd=Get-SkPdState $devices
 $r.Before=$before;$r.PreviousPD=$pd
 Initialize-SkNative;$r.ActiveTestSigning=[SkCommunityNative]::TestSigning()
 if($Restore){
  Assert-SkAdmin
  if(Get-SkPendingBoot){throw 'A successful installation is still waiting for its first reboot. Reboot, then use Restore if Verify fails.'}
  if(!$BackupPath){
   if(Test-Path -LiteralPath (Join-Path $PSScriptRoot 'reserve.json')){$BackupPath=$PSScriptRoot}
   else{$BackupPath=(Get-Content -LiteralPath (Join-Path $base 'latest-backup.json') -Raw | ConvertFrom-Json).Path}
  }
  $reserve=Assert-SkCommunityBackup $BackupPath;$m=$reserve.ReleaseIdentity
  Assert-SkPdInventory $m $pd
  if($pd.DeviceId -cne $reserve.PreviousPD.DeviceId){throw 'Backup belongs to a different discovered USB-C instance'}
  foreach($p in $before){
   $allowed=@($reserve.Packages)+@($m.Packages)+@($m.Reference)
   $match=@(foreach($target in $allowed){
    $sys=@($target.Files | Where-Object Name -EQ (Get-SkFileNames $target).Sys)[0]
    $inf=@($target.Files | Where-Object Name -EQ (Get-SkFileNames $target).Inf)[0]
    if($target.Service -eq $p.Service -and [version]$target.Version -eq [version]$p.Version -and $sys.SHA256 -ieq $p.SHA256 -and $inf.SHA256 -ieq $p.InfSHA256){$target}
   })
   if(!$match.Count){throw ('Driver changed outside this trial: '+$p.Service)}
  }
  if((Get-SkRestoreCompletion $reserve $before $pd).Complete){$r.Status='Verified';$r.Success=$true;$r.InstalledSetVerified=$true;Save-Record;[pscustomobject]$r;return}
  if(!$r.ActiveTestSigning){throw 'Active Test Mode is required for these test-signed packages; boot settings were not changed'}
  if(Get-SkUsbStoragePresent){throw 'Safely eject and disconnect all USB storage before Restore; restore can restart the USB stack'}
  $lock=[IO.File]::Open((Join-Path $base 'install.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
  $r.Backup=$BackupPath;$r.RestoreFrom=$BackupPath;Save-Record
  $currentBackup=Join-Path $run 'BeforeRestore';Save-SkCommunityBackup $devices $pd $m $currentBackup
  $r.BeforeRestoreBackup=$currentBackup;Save-Record
  Assert-SkInputsStable $before $pd
  foreach($p in $pd.Inventory){
   $original=@($reserve.PreviousPD.Inventory | Where-Object InfSHA256 -IEQ $p.InfSHA256)
   $candidate=@($m.Extensions[0].Files | Where-Object Name -EQ 'skpdprofile.inf')[0]
   if(!$original.Count -and $p.InfSHA256 -ine $candidate.SHA256){throw 'Unexpected extension appeared after the backup; no package removed'}
  }
  Set-SkMode $pd.DeviceId 0;$r.LiveDevicesReset=$true;$r.Status='Restoring';Save-Record
  foreach($p in $pd.Inventory){
   if(!@($reserve.PreviousPD.Inventory | Where-Object InfSHA256 -IEQ $p.InfSHA256).Count){
    $null=Invoke-SkPeerPnp @('/delete-driver',$p.Name,'/uninstall') (Join-Path $run ('remove-'+$p.Name+'.txt'))
   }
  }
  foreach($p in @($reserve.Packages | Where-Object Service -NE 'qcbattminiclass')){
   $attempt=[SkCommunityNative]::RequestInstall((Join-Path $BackupPath ('packages\'+(Get-SkFileNames $p).Inf)),2)
   $r.NativeAttempts+=@{Service=$p.Service;Flags=2;Succeeded=$attempt.Succeeded;Win32Error=$attempt.Win32Error;Reboot=$attempt.Reboot};Save-Record
   if(!$attempt.Succeeded){throw ('Restore failed: Win32='+$attempt.Win32Error+'; previous mode remains disabled until restore succeeds')}
  }
  foreach($p in $reserve.Extensions){$null=Invoke-SkPeerPnp @('/add-driver',(Join-Path $BackupPath ($p.RelativePath+'\skpdprofile.inf')),'/install') (Join-Path $run ('restore-'+$p.Name+'.txt'))}
  Set-SkMode $pd.DeviceId $reserve.PreviousPD.Mode
  $r.NativeRequestSucceeded=$true;$r.Status='PendingReboot';$r.NeedManualReboot=$true;Save-Record
  Write-Host 'Previous base drivers, PD extension inventory and opt-in restored; reboot manually, then run Diagnose.' -ForegroundColor Yellow
  [pscustomobject]$r;return
 }
 $m=Assert-SkPackage $PSScriptRoot
 $same=Assert-SkCompatibility $m $before;Assert-SkPdInventory $m $pd
 $r.ApprovedMigration=$script:SkApprovedMigrationUsed
 $whole=Get-SkWholeCompletion $m $before $pd;$r.SelectedSet=$whole
 if($CheckOnly){$r.Status='Checked';$r.ReadyForInstallation=$r.ActiveTestSigning;$r.PendingFirstReboot=Get-SkPendingBoot;$r.InstalledSetVerified=$whole.Complete -and !$r.PendingFirstReboot;$r.Success=$true;Save-Record;Write-Host 'Check completed; no driver, certificate or opt-in changed.';[pscustomobject]$r;return}
 if($whole.Complete -and !(Get-SkPendingBoot)){$r.Status='Verified';$r.InstalledSetVerified=$true;$r.Success=$true;Save-Record;Write-Host 'Complete base and attached PD0.1.3 driver set verified.' -ForegroundColor Green;[pscustomobject]$r;return}
 if($r.ApprovedMigration){Write-Host 'Recognized23.5 source set. The installed complete set will be backed up before the dated1871 update.' -ForegroundColor Yellow}
 Assert-SkAdmin
 if(Get-SkPendingBoot){throw 'This package already has a successful pending installation. Reboot once, then run Verify.cmd.'}
 if(!$r.ActiveTestSigning){throw 'Active Test Mode is required. This installer does not change boot/signing policy. See README and Diagnose.'}
 $lock=[IO.File]::Open((Join-Path $base 'install.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
 $backup=Join-Path $run 'Previous';Save-SkCommunityBackup $devices $pd $m $backup
 foreach($name in @('Common.ps1','Migration.ps1','Completion.ps1','Peer.ps1','Backup.ps1','PdMode.cs','Install.ps1','Launch.ps1','Restore.cmd')){Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination $backup}
 $r.Backup=$backup;$r.BackupVerified=$true;Save-Record
 [ordered]@{Path=$backup;At=(Get-Date).ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $base 'latest-backup.json') -Encoding utf8
 $payload=Join-Path $run 'Candidate';New-Item -ItemType Directory -Path $payload -Force | Out-Null
 foreach($name in @('manifest.json','development.cer','packages','reference')){Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination $payload -Recurse}
 $null=Assert-SkPackage $payload
 Trust-SkPublicCertificate (Join-Path $payload 'development.cer') $m.DevelopmentSigner
 $null=Assert-SkPackage $payload -RequireTrusted
 Assert-SkInputsStable $before $pd
 Set-SkMode $pd.DeviceId 1;$modeChanged=$pd.Mode -ne 1;$r.ModeConfigured=1;$r.Status='Staging';Save-Record
 $attempt=[SkCommunityNative]::RequestInstall((Join-Path $payload 'packages'),0x40)
 $r.NativeAttempts+=@{Flags=0x40;Succeeded=$attempt.Succeeded;Win32Error=$attempt.Win32Error;Reboot=$attempt.Reboot};$r.NativeRequestSucceeded=$attempt.Succeeded;Save-Record
 if(!$attempt.Succeeded){throw ('Windows refused the complete driver set: Win32='+$attempt.Win32Error+'; see result.json')}
 [ordered]@{Record=(Join-Path $run 'result.json');At=(Get-Date).ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $base 'latest-install.json') -Encoding utf8
 $after=@(Get-SkBaseline @(Get-SkDevices));$r.After=$after
 if(($after | ConvertTo-Json -Depth 8 -Compress) -cne ($before | ConvertTo-Json -Depth 8 -Compress)){throw 'Selected base driver state changed during deferred staging; preserve the record and backup'}
 $r.Status='PendingReboot';$r.NeedManualReboot=$true;$r.WindowsRequestedReboot=$attempt.Reboot;$r.Success=$false;$r.InstalledSetVerified=$false;Save-Record
 Write-Host ('Previous complete driver set saved: '+$backup) -ForegroundColor Green
 Write-Host 'Save work, safely eject USB storage, unplug USB-C, reboot ONCE. Then run Verify.cmd; do not judge installation from the charging icon.' -ForegroundColor Yellow
 [pscustomobject]$r
}catch {
 $r.Error=$_.Exception.Message;$r.Status='Failed'
 if($modeChanged -and !$r.NativeRequestSucceeded){try{Set-SkMode $pd.DeviceId $pd.Mode;$r.PreviousModeRestored=$true}catch{$r.ModeRestoreError=$_.Exception.Message}}
 if($r.NativeRequestSucceeded){$r.NeedManualReboot=$true}
 Save-Record
 Write-Host $r.Error -ForegroundColor Red
 if($run){Write-Host ('Installation record: '+(Join-Path $run 'result.json'))}
 throw
}finally{if($lock){$lock.Dispose()}}
