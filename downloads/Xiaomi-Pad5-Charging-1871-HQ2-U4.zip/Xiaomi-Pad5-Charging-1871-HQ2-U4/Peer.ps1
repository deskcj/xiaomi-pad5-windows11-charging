﻿# Community discovery and complete-set recovery. All hardware IDs are discovered.
function Initialize-SkPdMode {if(!('SkPeerPdMode' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'PdMode.cs')}}
function Get-SkMode([string]$Id){Initialize-SkPdMode;[SkPeerPdMode]::Read($Id)}
function Set-SkMode([string]$Id,[long]$Value){Initialize-SkPdMode;[SkPeerPdMode]::Set($Id,$Value);if((Get-SkMode $Id) -ne $Value){throw 'PD opt-in write/read verification failed'}}
function Assert-SkAdmin {
 if(!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Run Install.cmd and allow the Administrator prompt.'}
}
function Trust-SkPublicCertificate([string]$Path,[string]$Thumbprint) {
 $cert=New-Object Security.Cryptography.X509Certificates.X509Certificate2 $Path
 if($cert.HasPrivateKey -or $cert.Thumbprint -ine $Thumbprint){throw 'Only the checked public development certificate is allowed'}
 foreach($name in @('Root','TrustedPublisher')){
  $store=New-Object Security.Cryptography.X509Certificates.X509Store $name,'LocalMachine'
  try{
   $store.Open([Security.Cryptography.X509Certificates.OpenFlags]::ReadOnly)
   $found=$store.Certificates.Find([Security.Cryptography.X509Certificates.X509FindType]::FindByThumbprint,$Thumbprint,$false).Count -gt 0
  }finally{$store.Close()}
  if(!$found){try{$store.Open([Security.Cryptography.X509Certificates.OpenFlags]::ReadWrite);$store.Add($cert)}finally{$store.Close()}}
 }
}
function Assert-SkInputsStable($Before,$PD) {
 $devices=@(Get-SkDevices);$current=@(Get-SkBaseline $devices);$currentPD=Get-SkPdState $devices
 if(($current | ConvertTo-Json -Depth 10 -Compress) -cne ($Before | ConvertTo-Json -Depth 10 -Compress) -or ($currentPD | ConvertTo-Json -Depth 10 -Compress) -cne ($PD | ConvertTo-Json -Depth 10 -Compress)){throw 'Driver or PD inventory changed after preflight; retry only after reviewing Diagnose'}
}
function Get-SkPeerBase {Join-Path $env:ProgramData 'SK-Charging-Community'}
function Get-SkDeviceProperties($Device,[string[]]$Keys) {
 $response=Invoke-CimMethod -InputObject $Device -MethodName GetDeviceProperties -Arguments @{devicePropertyKeys=$Keys}
 if($response.ReturnValue -ne 0){throw ('Cannot read device properties: '+$response.ReturnValue)}
 $map=@{};foreach($p in $response.deviceProperties){$map[$p.KeyName]=$p.Data};$map
}
function Get-SkDevices {
 $present=@(Get-CimInstance Win32_PnPEntity -Filter 'Present=True')
 foreach($spec in $script:SkSpecs){
  $matches=@($present | Where-Object {$_.PNPDeviceID.StartsWith($spec.HardwareId+'\',[StringComparison]::OrdinalIgnoreCase) -and @($_.HardwareID) -icontains $spec.HardwareId})
  if($matches.Count -ne 1){throw "Expected one $($spec.HardwareId) device; found $($matches.Count). Compatible base nabu drivers are required."}
  $d=$matches[0];$props=Get-SkDeviceProperties $d @('DEVPKEY_Device_DriverVersion','DEVPKEY_Device_DriverInfPath','DEVPKEY_Device_Service','DEVPKEY_Device_ProblemCode')
  if($props.DEVPKEY_Device_Service -ine $spec.Service){throw ('Unexpected device service: '+$spec.HardwareId)}
  [pscustomobject]@{Service=$spec.Service;Name=$spec.Name;HardwareId=$spec.HardwareId;InstanceId=$d.PNPDeviceID;Version=$props.DEVPKEY_Device_DriverVersion;PublishedInf=$props.DEVPKEY_Device_DriverInfPath;Problem=$props.DEVPKEY_Device_ProblemCode;Image=(Get-SkImage $spec.Service)}
 }
}
function Assert-SkInternalPath([string]$Path) {
 $full=[IO.Path]::GetFullPath($Path);$systemRoot=[IO.Path]::GetPathRoot($env:SystemRoot)
 if([IO.Path]::GetPathRoot($full) -ine $systemRoot){throw 'Save installation and recovery data on the internal Windows drive.'}
 $logical=Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='"+$systemRoot.Substring(0,2)+"'")
 $parts=@(Get-CimAssociatedInstance -InputObject $logical -Association Win32_LogicalDiskToPartition)
 $disks=@($parts | ForEach-Object {Get-CimAssociatedInstance -InputObject $_ -Association Win32_DiskDriveToDiskPartition})
 if($disks.Count -ne 1 -or $disks[0].InterfaceType -eq 'USB' -or $disks[0].PNPDeviceID -match '^USB'){throw 'Cannot confirm the Windows drive is internal.'}
 $parent=$full
 while($parent){
  if(Test-Path -LiteralPath $parent){if((Get-Item -LiteralPath $parent -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Saved data cannot pass through a junction or symbolic link.'}}
  $parent=Split-Path -Parent $parent
 }
}
function Get-SkUsbStoragePresent {@(Get-CimInstance Win32_DiskDrive | Where-Object {$_.InterfaceType -eq 'USB' -or $_.PNPDeviceID -match '^USB'}).Count -gt 0}
function Get-SkPdInventory {
 @(Get-ChildItem -LiteralPath (Join-Path $env:SystemRoot 'INF') -Filter 'oem*.inf' -File | ForEach-Object {
  $text=[IO.File]::ReadAllText($_.FullName)
  if($text -match '(?im)^\s*ExtensionId\s*=\s*\{acecb46e-eb83-443e-9fce-436e4c45db80\}\s*$'){
   if($text -notmatch 'ACPI\\QCOM057D' -or $text -notmatch 'SkNabuPdProfile'){throw 'Unexpected hardware/service in the SK PD extension inventory'}
   $version=[regex]::Match($text,'(?im)^\s*DriverVer\s*=\s*[^,\r\n]+,\s*([^\r\n]+)').Groups[1].Value.Trim()
   [pscustomobject]@{Name=$_.Name;Version=$version;InfSHA256=(Get-SkFileHash -LiteralPath $_.FullName).Hash}
  }
 })
}
function Get-SkPdState($Devices) {
 $usb=@($Devices | Where-Object Service -EQ 'qcusbctcpm')
 if($usb.Count -ne 1){throw 'USB-C device discovery is not unique'}
 $id=$usb[0].InstanceId
 $device=Get-CimInstance Win32_PnPEntity | Where-Object PNPDeviceID -EQ $id
 if(@($device).Count -ne 1){throw 'Cannot read discovered USB-C device'}
 $props=Get-SkDeviceProperties $device @('DEVPKEY_Device_Stack')
 $driver=Get-CimInstance Win32_SystemDriver -Filter "Name='SkNabuPdProfile'"
 $image=$null;$hash=$null
 if($driver){$image=Get-SkImage 'SkNabuPdProfile';if(Test-Path -LiteralPath $image){$hash=(Get-SkFileHash -LiteralPath $image).Hash}}
 [pscustomobject]@{DeviceId=$id;Mode=(Get-SkMode $id);Inventory=@(Get-SkPdInventory);Stack=@($props.DEVPKEY_Device_Stack);Attached=(@($props.DEVPKEY_Device_Stack) -icontains '\Driver\SkNabuPdProfile');State=$driver.State;Image=$image;SHA256=$hash;DeviceProblem=$usb[0].Problem}
}
function Assert-SkPdInventory($Manifest,$State) {
 if($State.Mode -notin @(-1,0,1)){throw 'Unsupported existing SK PD opt-in value; nothing will be changed'}
 $seen=@{}
 foreach($p in $State.Inventory){
  if($p.Name -notmatch '^oem\d+\.inf$'){throw 'Invalid OEM package name'}
  $known=@($Manifest.KnownExtensions | Where-Object {$_.Version -eq $p.Version -and $_.InfSHA256 -ieq $p.InfSHA256})
  if($known.Count -ne 1 -or $seen.ContainsKey($p.Version)){throw 'Unknown, duplicate or newer SK PD extension. Run Diagnose; automatic replacement refused.'}
  $seen[$p.Version]=$true
 }
 if($State.Attached -or $State.State -eq 'Running'){
  if(@($Manifest.KnownExtensions | Where-Object SysSHA256 -IEQ $State.SHA256).Count -ne 1){throw 'Running SK PD image differs from the preserved known versions'}
 }
}
function Get-SkWholeCompletion($Manifest,$Selected,$PD) {
 $base=Get-SkSetCompletion $Manifest $Selected
 $profile=$Manifest.Extensions[0];$expectedInf=@($profile.Files | Where-Object Name -EQ 'skpdprofile.inf')[0]
 $expectedSys=@($profile.Files | Where-Object Name -EQ 'skpdprofile.sys')[0]
 $inf=@($PD.Inventory | Where-Object {$_.InfSHA256 -ieq $expectedInf.SHA256 -and $_.Version -eq $profile.Version}).Count -eq 1
 $pdComplete=$inf -and $PD.Attached -and $PD.State -eq 'Running' -and $PD.SHA256 -ieq $expectedSys.SHA256 -and $PD.Mode -eq 1 -and $null -ne $PD.DeviceProblem -and $PD.DeviceProblem -eq 0
 [pscustomobject]@{Complete=($base.Complete -and $pdComplete);Base=$base;PD=[pscustomobject]@{OEMIdentityPresent=$inf;Attached=$PD.Attached;Running=($PD.State -eq 'Running');SYSIdentityMatches=($PD.SHA256 -ieq $expectedSys.SHA256);ModeConfigured=($PD.Mode -eq 1);Complete=[bool]$pdComplete};HardwarePowerProven=$false;PPSImplemented=$false;HubContinuityFixed=$false}
}
function Find-SkPdFolder([string]$InfHash) {
 $folders=@(Get-ChildItem -LiteralPath (Join-Path $env:SystemRoot 'System32\DriverStore\FileRepository') -Directory -Filter 'skpdprofile.inf_arm64_*' | Where-Object {
  $inf=Join-Path $_.FullName 'skpdprofile.inf';(Test-Path -LiteralPath $inf) -and (Get-SkFileHash -LiteralPath $inf).Hash -ieq $InfHash
 })
 if($folders.Count -ne 1){throw 'Cannot locate a unique complete SK PD DriverStore package for backup'}
 $folders[0].FullName
}
function Save-SkCommunityBackup($Devices,$PD,$Manifest,[string]$Destination) {
 if(Test-Path -LiteralPath (Join-Path $Destination 'reserve.json')){throw 'Use a new backup directory'}
 Save-SkBackup $Devices $Destination
 $reserve=Get-Content -LiteralPath (Join-Path $Destination 'reserve.json') -Raw | ConvertFrom-Json
 $extensions=@()
 foreach($p in $PD.Inventory){
  $folder=Find-SkPdFolder $p.InfSHA256
  $relative='extensions\'+$p.Name
  New-Item -ItemType Directory -Path (Join-Path $Destination $relative) -Force | Out-Null
  $files=@(foreach($ext in @('inf','sys','cat')){
   $name='skpdprofile.'+$ext;$from=Join-Path $folder $name;$to=Join-Path $Destination ($relative+'\'+$name)
   Copy-Item -LiteralPath $from -Destination $to
   [pscustomobject]@{Name=$name;SHA256=(Get-SkFileHash -LiteralPath $to).Hash;Bytes=(Get-Item -LiteralPath $to).Length}
  })
  $extensions+=,[pscustomobject]@{Name=$p.Name;Version=$p.Version;InfSHA256=$p.InfSHA256;RelativePath=$relative;Files=$files}
 }
 $out=[ordered]@{Schema=5;Model='Xiaomi Pad 5';SavedAt=(Get-Date).ToString('o');Packages=@($reserve.Packages);PreviousPD=$PD;Extensions=$extensions;ReleaseIdentity=$Manifest}
 $out | ConvertTo-Json -Depth 18 | Set-Content -LiteralPath (Join-Path $Destination 'reserve.json') -Encoding utf8
 $null=Assert-SkCommunityBackup $Destination
}
function Assert-SkCommunityBackup([string]$Root) {
 Assert-SkInternalPath $Root
 $m=Get-Content -LiteralPath (Join-Path $Root 'reserve.json') -Raw | ConvertFrom-Json
 if($m.Schema -ne 5 -or $m.Model -ne 'Xiaomi Pad 5' -or @($m.Packages).Count -ne 5 -or $m.ReleaseIdentity.Build -ne $script:SkRelease -or $m.PreviousPD.Mode -notin @(-1,0,1)){throw 'Invalid complete-set backup'}
 $seen=@{}
 foreach($p in $m.Packages){
  $spec=@($script:SkSpecs | Where-Object Service -EQ $p.Service)
  if($spec.Count -ne 1 -or $spec[0].Name -cne $p.Name -or $spec[0].HardwareId -cne $p.HardwareId -or $seen.ContainsKey($p.Service)){throw 'Unexpected backup driver specification'}
  $seen[$p.Service]=$true
  Test-SkSavedFiles $Root ('packages') $p.Name $p.Files $p
 }
 $seen=@{}
 if(@($m.Extensions).Count -ne @($m.PreviousPD.Inventory).Count){throw 'Incomplete previous PD inventory backup'}
 foreach($p in $m.Extensions){
  if($p.Name -notmatch '^oem\d+\.inf$' -or $p.RelativePath -cne ('extensions\'+$p.Name) -or $seen.ContainsKey($p.Name)){throw 'Invalid extension backup path'}
  $seen[$p.Name]=$true
  $known=@($m.PreviousPD.Inventory | Where-Object {$_.Name -eq $p.Name -and $_.Version -eq $p.Version -and $_.InfSHA256 -ieq $p.InfSHA256})
  if($known.Count -ne 1){throw 'Extension backup is not in the recorded original inventory'}
  Test-SkSavedFiles $Root $p.RelativePath 'skpdprofile' $p.Files
  if(@($p.Files | Where-Object Name -EQ 'skpdprofile.inf')[0].SHA256 -ine $p.InfSHA256){throw 'Extension backup INF identity mismatch'}
 }
 $m
}
function Invoke-SkPeerPnp([string[]]$Arguments,[string]$Log) {
 $output=& (Join-Path $env:SystemRoot 'System32\pnputil.exe') @Arguments 2>&1
 $code=$LASTEXITCODE;$output | Set-Content -LiteralPath $Log -Encoding utf8
 if($code -notin @(0,3010)){throw ('PnPUtil failed: '+$code+'; see '+$Log)}
 $code
}
function Get-SkPendingBoot {
 $pointer=Join-Path (Get-SkPeerBase) 'latest-install.json'
 if(!(Test-Path -LiteralPath $pointer)){return $false}
 $p=Get-Content -LiteralPath $pointer -Raw | ConvertFrom-Json
 Assert-SkInternalPath $p.Record
 $r=Get-Content -LiteralPath $p.Record -Raw | ConvertFrom-Json
 if(!$r.NativeRequestSucceeded){return $false}
 $boot=(Get-CimInstance Win32_OperatingSystem).LastBootUpTime
 $boot -le [datetime]$r.Started
}
function Get-SkRestoreCompletion($Reserve,$Selected,$PD) {
 $base=Get-SkSetCompletion $Reserve $Selected
 $before=$Reserve.PreviousPD
 $inventoryOk=@($PD.Inventory).Count -eq @($before.Inventory).Count
 foreach($p in $before.Inventory){if(@($PD.Inventory | Where-Object InfSHA256 -IEQ $p.InfSHA256).Count -ne 1){$inventoryOk=$false}}
 $filterOk=if($before.Attached){$PD.Attached -and $PD.State -eq 'Running' -and $PD.SHA256 -ieq $before.SHA256}else{!$PD.Attached}
 [pscustomobject]@{Complete=($base.Complete -and $inventoryOk -and $filterOk -and $PD.Mode -eq $before.Mode);Base=$base;PreviousPDInventoryMatches=$inventoryOk;PreviousFilterMatches=[bool]$filterOk;PreviousModeMatches=($PD.Mode -eq $before.Mode);HardwarePowerProven=$false}
}

. (Join-Path $PSScriptRoot 'Backup.ps1')
