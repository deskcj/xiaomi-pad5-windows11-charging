﻿# Selected package filenames are read from the actual INF, never inferred from the service.
function Get-SkFileNames($Package) {
 $inf=$Package.InfName;$sys=$Package.SysName;$cat=$Package.CatName
 if(!$inf){$inf=$Package.Name+'.inf'};if(!$sys){$sys=$Package.Name+'.sys'};if(!$cat){$cat=$Package.Name+'.cat'}
 foreach($entry in @(@($inf,'inf'),@($sys,'sys'),@($cat,'cat'))){
  if($entry[0] -notmatch '^[a-zA-Z0-9][a-zA-Z0-9_.-]*$' -or [IO.Path]::GetExtension($entry[0]) -ine ('.'+$entry[1])){throw 'Invalid driver file role or filename'}
 }
 if($sys -ine ($Package.Name+'.sys')){throw 'Unexpected kernel driver filename'}
 [pscustomobject]@{Inf=$inf;Sys=$sys;Cat=$cat}
}
function Assert-SkInfIdentity([string]$Path,$Package) {
 $text=[IO.File]::ReadAllText($Path);$names=Get-SkFileNames $Package
 $version=[regex]::Match($text,'(?im)^\s*DriverVer\s*=\s*[^,\r\n]+,\s*([^\r\n;]+)').Groups[1].Value.Trim()
 $services=@([regex]::Matches($text,'(?im)^\s*AddService\s*=\s*([^,\r\n]+),') | ForEach-Object {
  $token=$_.Groups[1].Value.Trim().Trim('"')
  if($token -match '^%([a-zA-Z0-9_.]+)%$'){
   $key=$Matches[1];$value=@([regex]::Matches($text,'(?im)^\s*'+[regex]::Escape($key)+'\s*=\s*"?([^";\r\n]+)"?\s*(?:;[^\r\n]*)?$') | ForEach-Object {$_.Groups[1].Value.Trim()})
   if($value.Count -ne 1){throw 'Cannot resolve INF service string uniquely'};$token=$value[0]
  }
  $token
 })
 if(!$version -or [version]$version -ne [version]$Package.Version -or $text -notmatch '(?i)NTarm64' -or $text -notmatch [regex]::Escape($Package.HardwareId) -or $services.Count -ne 1 -or $services[0] -ine $Package.Service){throw ('Saved INF hardware/service/version mismatch: '+$Package.Service)}
 $binaries=@([regex]::Matches($text,'(?im)^\s*ServiceBinary\s*=\s*%13%\\([^\s;\r\n]+)') | ForEach-Object {$_.Groups[1].Value})
 if($binaries.Count -ne 1 -or $binaries[0] -ine $names.Sys){throw 'Saved INF ServiceBinary mismatch'}
 $catalogs=@([regex]::Matches($text,'(?im)^\s*CatalogFile(?:\.NTarm64)?\s*=\s*([^\s;\r\n]+)') | ForEach-Object {$_.Groups[1].Value} | Select-Object -Unique)
 if($catalogs.Count -ne 1 -or $catalogs[0] -ine $names.Cat){throw 'Saved INF catalog mismatch'}
}
function Find-SkSelectedPackage($Device) {
 if($Device.PublishedInf -notmatch '^oem\d+\.inf$'){throw 'Expected a selected OEM INF for backup'}
 $folder=[IO.Path]::GetFullPath((Split-Path -Parent $Device.Image))
 $store=[IO.Path]::GetFullPath((Join-Path $env:SystemRoot 'System32\DriverStore\FileRepository')).TrimEnd('\')+'\'
 if(!$folder.StartsWith($store,[StringComparison]::OrdinalIgnoreCase)){throw 'Selected image is outside DriverStore'}
 $parent=$folder
 while($parent.Length -ge $store.TrimEnd('\').Length){
  if((Get-Item -LiteralPath $parent -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'DriverStore source cannot pass through a link'}
  $parent=Split-Path -Parent $parent
 }
 $selected=Join-Path $env:SystemRoot ('INF\'+$Device.PublishedInf);$hash=(Get-SkFileHash -LiteralPath $selected).Hash
 $matches=@(Get-ChildItem -LiteralPath $folder -Filter '*.inf' -File | Where-Object {(Get-SkFileHash -LiteralPath $_.FullName).Hash -ieq $hash})
 if($matches.Count -ne 1){throw 'Cannot locate the unique selected INF by its hash in DriverStore'}
 $text=[IO.File]::ReadAllText($matches[0].FullName)
 $catalogs=@([regex]::Matches($text,'(?im)^\s*CatalogFile(?:\.NTarm64)?\s*=\s*([^\s;\r\n]+)') | ForEach-Object {$_.Groups[1].Value} | Select-Object -Unique)
 if($catalogs.Count -ne 1){throw 'Cannot discover a unique ARM64 catalog from selected INF'}
 $row=[pscustomobject]@{Service=$Device.Service;Name=$Device.Name;HardwareId=$Device.HardwareId;Version=$Device.Version;PublishedInf=$Device.PublishedInf;InstanceId=$Device.InstanceId;InfName=$matches[0].Name;SysName=[IO.Path]::GetFileName($Device.Image);CatName=$catalogs[0];Files=@()}
 $names=Get-SkFileNames $row
 Assert-SkInfIdentity $matches[0].FullName $row
 foreach($name in @($names.Inf,$names.Sys,$names.Cat)){
  $path=Join-Path $folder $name;$item=Get-Item -LiteralPath $path -Force
  if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Selected package contains a link'}
 }
 [pscustomobject]@{Folder=$folder;Identity=$row}
}
function Save-SkBackup($Devices,[string]$Destination) {
 Assert-SkInternalPath $Destination
 New-Item -ItemType Directory -Path (Join-Path $Destination 'packages') -Force | Out-Null
 $rows=@();$seen=@{}
 foreach($d in $Devices){
  $selected=Find-SkSelectedPackage $d;$row=$selected.Identity;$names=Get-SkFileNames $row
  foreach($name in @($names.Inf,$names.Sys,$names.Cat)){
   if($seen.ContainsKey($name)){throw 'Duplicate filename in complete backup'};$seen[$name]=$true
   $from=Join-Path $selected.Folder $name;$to=Join-Path $Destination ('packages\'+$name)
   $hash=(Get-SkFileHash -LiteralPath $from).Hash
   Copy-Item -LiteralPath $from -Destination $to
   if((Get-SkFileHash -LiteralPath $to).Hash -ine $hash){throw 'Backup copy hash mismatch'}
   $row.Files+=,[pscustomobject]@{Name=$name;SHA256=$hash;Bytes=(Get-Item -LiteralPath $to).Length}
  }
  $rows+=,$row
 }
 [ordered]@{Schema=5;Model='Xiaomi Pad 5';SavedAt=(Get-Date).ToString('o');Packages=$rows} | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $Destination 'reserve.json') -Encoding UTF8
 foreach($p in $rows){Test-SkSavedFiles $Destination 'packages' $p.Name $p.Files $p}
}
function Test-SkSavedFiles([string]$Root,[string]$Relative,[string]$Name,$Files,$Identity=$null) {
 if(!$Identity){$Identity=[pscustomobject]@{Name=$Name}}
 $roles=Get-SkFileNames $Identity;$expected=@($roles.Inf,$roles.Sys,$roles.Cat)
 if(@($Files).Count -ne 3 -or @(Compare-Object ($expected | Sort-Object) (@($Files.Name) | Sort-Object)).Count){throw 'Incomplete saved driver file roles'}
 foreach($f in $Files){
  if($f.SHA256 -notmatch '^[a-fA-F0-9]{64}$' -or $f.Bytes -le 0){throw 'Invalid saved driver identity'}
  $path=Join-Path $Root ($Relative+'\'+$f.Name);$item=Get-Item -LiteralPath $path -Force
  if($item.Attributes -band [IO.FileAttributes]::ReparsePoint -or $item.Length -ne $f.Bytes -or (Get-SkFileHash -LiteralPath $path).Hash -ine $f.SHA256){throw 'Backup link/hash/size check failed'}
 }
 $cat=Join-Path $Root ($Relative+'\'+$roles.Cat)
 if($Name -ne 'qcbattminiclass8150' -and (Get-AuthenticodeSignature -LiteralPath $cat).Status -ne 'Valid'){throw ('Previous catalog is not trusted for restore: '+$roles.Cat+'. Run Diagnose.cmd; no installation has been requested.')}
 if($Identity.Service){Assert-SkInfIdentity (Join-Path $Root ($Relative+'\'+$roles.Inf)) $Identity}
 foreach($f in $Files){
  if($Name -ne 'qcbattminiclass8150' -and $f.Name -match '\.sys$' -and (Get-AuthenticodeSignature -LiteralPath (Join-Path $Root ($Relative+'\'+$f.Name))).Status -notin @('Valid','NotSigned')){throw ('Previous driver signature cannot be restored: '+$f.Name)}
 }
}

function Get-SkCompatibleReference($Manifest,$Selected) {
 $current=@($Selected | Where-Object Service -EQ 'qcbattminiclass')
 if($current.Count -ne 1){return $null}
 [version]$version=$null
 if(![version]::TryParse([string]$current[0].Version,[ref]$version)){return $null}
 $matches=@(foreach($p in $Manifest.Reference){
  $names=Get-SkFileNames $p
  $sys=@($p.Files | Where-Object Name -EQ $names.Sys);$inf=@($p.Files | Where-Object Name -EQ $names.Inf)
  if($sys.Count -eq 1 -and $inf.Count -eq 1 -and $version -eq [version]$p.Version -and $current[0].SHA256 -ieq $sys[0].SHA256 -and $current[0].InfSHA256 -ieq $inf[0].SHA256){$p}
 })
 if($matches.Count -eq 1){$matches[0]}else{$null}
}
