﻿$ErrorActionPreference='Stop'
$script:SkRelease='1871-HQ2-U4'
$script:SkApprovedMigrationUsed=$null
# SHA256 uses the .NET runtime directly; no PowerShell module autoload is needed.
function Get-SkFileHash {
    param([Parameter(Mandatory=$true)][string]$LiteralPath)
    $full=[IO.Path]::GetFullPath($LiteralPath)
    $sha=[Security.Cryptography.SHA256]::Create()
    $stream=$null
    try {
        $stream=[IO.File]::OpenRead($full)
        $hash=[BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-','')
        [pscustomobject]@{Algorithm='SHA256';Hash=$hash;Path=$full}
    } finally {
        if($stream){$stream.Dispose()}
        $sha.Dispose()
    }
}
. (Join-Path $PSScriptRoot 'Migration.ps1')
. (Join-Path $PSScriptRoot 'Backup.ps1')
$script:SkSpecs=@(
    @{Service='qcpmicext';Name='qcpmicext8150';HardwareId='ACPI\QCOM05E5'},
    @{Service='qcpmictcc';Name='qcpmictcc8150';HardwareId='ACPI\QCOM0582'},
    @{Service='qcusbctcpm';Name='qcusbctcpm8150';HardwareId='ACPI\QCOM057D'},
    @{Service='qcbattmngr';Name='qcbattmngr8150';HardwareId='ACPI\QCOM0531'},
    @{Service='qcbattminiclass';Name='qcbattminiclass8150';HardwareId='ACPI\QCOM052D'})
function Get-SkImage([string]$Service) {
    $p=[Environment]::ExpandEnvironmentVariables((Get-ItemProperty -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\$Service").ImagePath)
    if($p.StartsWith('\SystemRoot\')){$p=$env:SystemRoot+$p.Substring(11)}
    if($p.StartsWith('\??\')){$p=$p.Substring(4)}
    if(![IO.Path]::IsPathRooted($p)){$p=Join-Path $env:SystemRoot $p}
    [IO.Path]::GetFullPath($p)
}
function Assert-SkInternalPath([string]$Path) {
    $full=[IO.Path]::GetFullPath($Path);$systemRoot=[IO.Path]::GetPathRoot($env:SystemRoot)
    if([IO.Path]::GetPathRoot($full) -ine $systemRoot){throw 'Use the internal Windows drive for saved installation/diagnostic data.'}
    $disk=Get-Partition -DriveLetter $systemRoot.Substring(0,1) | Get-Disk
    if(@($disk).Count -ne 1 -or $disk.BusType -in @('USB','iSCSI','File Backed Virtual','Unknown')){throw 'Cannot confirm that the Windows drive is internal.'}
    $parent=$full
    while($parent){
        if(Test-Path -LiteralPath $parent){if((Get-Item -LiteralPath $parent -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Saved data path must not pass through a junction or symbolic link.'}}
        $parent=Split-Path -Parent $parent
    }
}
function Assert-SkTablet {
    if($env:PROCESSOR_ARCHITECTURE -ine 'ARM64'){throw 'Use native ARM64 Windows PowerShell on the tablet.'}
    $c=Get-CimInstance Win32_ComputerSystem;$os=Get-CimInstance Win32_OperatingSystem
    if($c.Manufacturer -ine 'Xiaomi' -or $c.Model -ine 'Pad 5'){throw 'This package supports Xiaomi Pad 5 (nabu) only.'}
    if([int]$os.BuildNumber -lt 22000 -or $os.ProductType -ne 1){throw 'Windows 11 ARM64 is required.'}
}
function Get-SkDevices {
    $present=@(Get-PnpDevice -PresentOnly)
    foreach($spec in $script:SkSpecs){
        $found=@($present|Where-Object {$_.InstanceId.StartsWith($spec.HardwareId+'\',[StringComparison]::OrdinalIgnoreCase)})
        $matches=@($found|Where-Object {@(Get-PnpDeviceProperty -InstanceId $_.InstanceId -KeyName DEVPKEY_Device_HardwareIds).Data -icontains $spec.HardwareId})
        if($matches.Count -ne 1){throw "Expected one $($spec.HardwareId) device; found $($matches.Count). Install the base nabu Windows drivers first."}
        $props=@{}
        Get-PnpDeviceProperty -InstanceId $matches[0].InstanceId -KeyName DEVPKEY_Device_DriverVersion,DEVPKEY_Device_DriverInfPath,DEVPKEY_Device_Service,DEVPKEY_Device_ProblemCode|ForEach-Object {$props[$_.KeyName]=$_.Data}
        if($props.DEVPKEY_Device_Service -ine $spec.Service){throw "Unexpected service for $($spec.HardwareId)"}
        [pscustomobject]@{Service=$spec.Service;Name=$spec.Name;HardwareId=$spec.HardwareId;InstanceId=$matches[0].InstanceId;Version=$props.DEVPKEY_Device_DriverVersion;PublishedInf=$props.DEVPKEY_Device_DriverInfPath;Problem=$props.DEVPKEY_Device_ProblemCode;Image=(Get-SkImage $spec.Service)}
    }
}
function Get-SkBaseline($Devices) {
    @($Devices|ForEach-Object {
        $s=Get-CimInstance Win32_SystemDriver -Filter "Name='$($_.Service)'"
        $inf=Join-Path $env:SystemRoot ('INF\'+$_.PublishedInf)
        [pscustomobject]@{Service=$_.Service;Version=$_.Version;Problem=$_.Problem;Image=$_.Image;SHA256=(Get-SkFileHash -LiteralPath $_.Image).Hash;State=$s.State;HardwareId=$_.HardwareId;InstanceId=$_.InstanceId;PublishedInf=$_.PublishedInf;InfSHA256=(Get-SkFileHash -LiteralPath $inf).Hash}
    })
}
function Get-SkSupportingHashes {
    foreach($service in @('qcpep','qcspmi','UrsSynopsys','USBXHCI')){
        try{$image=Get-SkImage $service;[pscustomobject]@{Service=$service;SHA256=(Get-SkFileHash -LiteralPath $image).Hash}}
        catch{[pscustomobject]@{Service=$service;Error=$_.Exception.Message}}
    }
}
function Initialize-SkNative {
    if('SkCommunityNative' -as [type]){return}
    Add-Type -TypeDefinition @'
using System; using System.Runtime.InteropServices;
public static class SkCommunityNative {
 public sealed class InstallResult { public bool Succeeded; public bool Reboot; public int Win32Error; }
 [StructLayout(LayoutKind.Sequential)] private struct CI {public uint Length; public uint Options;}
 [DllImport("ntdll.dll")] private static extern int NtQuerySystemInformation(int cls,ref CI info,uint length,out uint returned);
 public static bool TestSigning() {CI info=new CI(); info.Length=8;uint returned;
  int status=NtQuerySystemInformation(103,ref info,8,out returned);
  if(status<0 || returned<8) throw new InvalidOperationException("Cannot read active Code Integrity policy");
  return (info.Options & 2)!=0;
 }
 [DllImport("newdev.dll",EntryPoint="DiInstallDriverW",ExactSpelling=true,CharSet=CharSet.Unicode,SetLastError=true)]
 [return:MarshalAs(UnmanagedType.Bool)]
 public static extern bool Install(IntPtr window,string path,uint flags,[MarshalAs(UnmanagedType.Bool)]out bool reboot);
 public static InstallResult RequestInstall(string path,uint flags) {
  bool reboot;bool success=Install(IntPtr.Zero,path,flags,out reboot);
  int error=success?0:Marshal.GetLastWin32Error();
  return new InstallResult {Succeeded=success,Reboot=reboot,Win32Error=error};
 }
}
'@
}
function Assert-SkPackage([string]$Root,[switch]$RequireTrusted) {
    $m=Get-Content -LiteralPath (Join-Path $Root 'manifest.json') -Raw|ConvertFrom-Json
    if($m.Schema -ne 5 -or $m.Build -ne $script:SkRelease -or $m.Model -ne 'Xiaomi Pad 5' -or @($m.Packages).Count -ne 4 -or @($m.Reference).Count -ne 2 -or @($m.Extensions).Count -ne 1){throw 'Invalid release manifest'}
    if(@($m.Packages|Where-Object Service -eq 'qcbattminiclass').Count -or $m.Reference[0].Service -cne 'qcbattminiclass'){throw 'Miniclass must be reference only'}
    $signer='F38EDD5C105095C8342556158CE66253F045965D';$certHash='1C655BB59BEF778420AB5E47BAE06A6FB8FF9178AA5881D99FCFC32904642D3B'
    if($m.DevelopmentSigner -ine $signer -or $m.CertificateSHA256 -ine $certHash){throw 'Unexpected development certificate'}
    $certPath=Join-Path $Root 'development.cer';$cert=New-Object Security.Cryptography.X509Certificates.X509Certificate2 $certPath
    if($cert.HasPrivateKey -or $cert.Thumbprint -ine $signer -or (Get-SkFileHash -LiteralPath $certPath).Hash -ine $certHash){throw 'Invalid public certificate'}
    $seen=@{};$paths=@()
    foreach($p in (@($m.Packages)+@($m.Reference)+@($m.Extensions))){
        $spec=@(($script:SkSpecs+@{Service='SkNabuPdProfile';Name='skpdprofile';HardwareId='ACPI\QCOM057D'})|Where-Object Service -eq $p.Service)
        if($spec.Count -ne 1 -or $seen.ContainsKey($(if($p.Service -eq 'qcbattminiclass'){$p.ProfileId}else{$p.Service})) -or $p.Name -cne $spec[0].Name -or $p.HardwareId -cne $spec[0].HardwareId){throw 'Unexpected/duplicate driver specification'}
        $key=if($p.Service -eq 'qcbattminiclass'){$p.ProfileId}else{$p.Service}
        $seen[$key]=$true;$kind=if($p.Service -eq 'qcbattminiclass'){$p.RelativePath}else{'packages'}
        if($p.Service -eq 'qcbattminiclass' -and ($p.ProfileId -notin @('nabu1680','nabu10730') -or $p.RelativePath -cne ('reference\'+$p.ProfileId))){throw 'Unexpected reference profile/path'}
        if($kind -eq 'packages' -and $p.Signer -ine $signer){throw 'Unexpected package signer'}
        if(@($p.Files).Count -ne 3){throw 'Incomplete driver package'}
        $names=@($p.Files|ForEach-Object {$_.Name})
        $roles=Get-SkFileNames $p
        if(@(Compare-Object ($names|Sort-Object) (@($roles.Sys,$roles.Inf,$roles.Cat)|Sort-Object)).Count){throw 'Unexpected driver filenames'}
        foreach($f in $p.Files){
            $relative=$kind+'\'+$f.Name;$path=Join-Path $Root $relative;$paths+=$relative;$item=Get-Item -LiteralPath $path -Force
            if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Payload cannot contain symbolic links'}
            if((Get-SkFileHash -LiteralPath $path).Hash -ine $f.SHA256 -or $item.Length -ne $f.Bytes){throw "SHA256/size mismatch: $($f.Name)"}
            if($kind -eq 'packages' -and $f.Name -match '\.(sys|cat)$'){
                $s=Get-AuthenticodeSignature -LiteralPath $path
                # Missing trust is allowed before importing the public certificate.
                # Afterwards Windows must report Valid; broken/missing signatures fail.
                if(!$s.SignerCertificate -or $s.SignerCertificate.Thumbprint -ine $signer -or $s.Status -notin @('Valid','NotTrusted','UnknownError') -or ($RequireTrusted -and $s.Status -ne 'Valid')){throw "Invalid/untrusted signature: $($f.Name), $($s.Status)"}
            }
        }
        $inf=[IO.File]::ReadAllText((Join-Path $Root ($kind+'\'+$roles.Inf)))
        $infVersion=[regex]::Match($inf,'(?im)^\s*DriverVer\s*=\s*[^,\r\n]+,\s*([^\r\n;]+)').Groups[1].Value.Trim()
        if(!$infVersion -or [version]$infVersion -ne [version]$p.Version -or $inf -notmatch 'NTarm64' -or $inf -notmatch [regex]::Escape($p.HardwareId)){throw 'INF version/hardware mismatch'}
        if($p.DriverDate){
            $date=[regex]::Match($inf,'(?im)^\s*DriverVer\s*=\s*([^,\r\n]+),').Groups[1].Value.Trim()
            if($date -ne $p.DriverDate){throw 'INF date does not match the migration manifest'}
        }
    }
    $actual=@(foreach($kind in @('packages','reference')){Get-ChildItem -LiteralPath (Join-Path $Root $kind) -Recurse -File|ForEach-Object {$_.FullName.Substring([IO.Path]::GetFullPath($Root).TrimEnd('\').Length+1)}})
    if($actual.Count -ne 21 -or @(Compare-Object ($actual|Sort-Object) ($paths|Sort-Object)).Count){throw 'Unexpected payload file'}
    $pd=$m.Extensions[0]
    if($pd.Service -cne 'SkNabuPdProfile' -or $pd.Version -ne '0.1.3.0' -or $pd.RequiredMode -ne 1 -or $pd.ExtensionId -ine '{acecb46e-eb83-443e-9fce-436e4c45db80}'){throw 'Invalid required PD profile'}
    $pdInf=[IO.File]::ReadAllText((Join-Path $Root 'packages\skpdprofile.inf'))
    if($pdInf -notmatch '(?im)^ExtensionId\s*=\s*\{acecb46e-eb83-443e-9fce-436e4c45db80\}\s*$'){throw 'PD extension identity mismatch'}
    foreach($ref in $m.Reference){
        $names=Get-SkFileNames $ref
        $pin=if($ref.ProfileId -eq 'nabu1680'){@{Version='1.0.1680.0';InfName='qcbattminiclass8150.inf';Cat='qcbattminiclass8150.cat';SysSHA='7F7ECE18BF7ED43827E9E331274C4DA15A765B615B886DB8BE3209B9144FF4C4';InfSHA='F56E2A728B175A1A6BDD85378218156832A64A8D6A91BA7C2A3FAEAF1E3D6DFF'}}else{@{Version='1.0.10730.0';InfName='MiPad5_battminiclass.inf';Cat='MiPad5_battminiclass.cat';SysSHA='B78FBE26F1521B56F850876030A433883A99383ECD3A65D556CBC0BD120E9C4C';InfSHA='355F15B86EBF2B3B715A99A4784809547125DCF540B8ED7860FDD6F4C329F6F5'}}
        if([version]$ref.Version -ne [version]$pin.Version -or $names.Inf -cne $pin.InfName -or $names.Cat -cne $pin.Cat -or @($ref.Files | Where-Object Name -EQ $names.Sys)[0].SHA256 -ine $pin.SysSHA -or @($ref.Files | Where-Object Name -EQ $names.Inf)[0].SHA256 -ine $pin.InfSHA){throw 'Unsupported reference identity'}
        Assert-SkInfIdentity (Join-Path $Root ($ref.RelativePath+'\'+$names.Inf)) $ref
    }
    $m
}
function Assert-SkCompatibility($Manifest,$Before) {
    $script:SkApprovedMigrationUsed=$null
    $ref=Get-SkCompatibleReference $Manifest $Before
    if(!$ref){throw 'Unknown battery miniclass SYS/INF profile. Run Diagnose.cmd; the installed miniclass is preserved and no replacement is requested.'}
    $same=$true
    foreach($p in $Manifest.Packages){
        $current=@($Before|Where-Object Service -eq $p.Service)[0]
        if(!$current){throw 'Required base driver is missing'}
        if([version]$current.Version -gt [version]$p.Version){
            if(!$script:SkApprovedMigrationUsed){$script:SkApprovedMigrationUsed=Get-SkApprovedMigration $Manifest $Before @(Get-SkSupportingHashes)}
            if(!$script:SkApprovedMigrationUsed){throw "Newer $($p.Service) is installed. Automatic downgrade refused. Run Diagnose.cmd; this source set is not an approved migration."}
        }
        $desired=@($p.Files|Where-Object Name -eq ($p.Name+'.sys'))[0]
        if([version]$current.Version -ne [version]$p.Version -or $current.SHA256 -ine $desired.SHA256 -or $current.InfSHA256 -ine @($p.Files|Where-Object Name -eq (Get-SkFileNames $p).Inf)[0].SHA256){$same=$false}
    }
    $same
}
