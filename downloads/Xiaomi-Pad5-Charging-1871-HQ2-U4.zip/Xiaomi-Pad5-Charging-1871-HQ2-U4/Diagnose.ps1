﻿param([ValidateRange(0,600)][int]$Seconds=0)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Common.ps1')
. (Join-Path $PSScriptRoot 'Completion.ps1')
. (Join-Path $PSScriptRoot 'Peer.ps1')
$base=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'SK-Charging-Diagnostics'
Assert-SkInternalPath $base
$root=Join-Path $base ((Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $root -Force | Out-Null
$r=[ordered]@{Build=$script:SkRelease;At=(Get-Date).ToString('o');InstalledSetVerified=$false;ReadOnlyHardware=$true;DriverInstalled=$false;DeviceReset=$false;PrivatePMICIOCTLUsed=$false;RebootIssued=$false;Errors=@()}
try{$r.Computer=Get-CimInstance Win32_ComputerSystem | Select-Object Manufacturer,Model,SystemType;$r.OS=Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber,LastBootUpTime;$r.Windows=Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' | Select-Object DisplayVersion,EditionID,UBR,BuildLabEx}catch{$r.Errors+=$_.Exception.Message}
try{$m=Assert-SkPackage $PSScriptRoot;$r.PackageVerified=$true}catch{$r.PackageVerified=$false;$r.Errors+=$_.Exception.Message}
try{
 $devices=@(Get-SkDevices);$selected=@(Get-SkBaseline $devices);$pd=Get-SkPdState $devices
 $r.Drivers=$selected;$r.PD=$pd
 if($m){$r.SelectedSet=Get-SkWholeCompletion $m $selected $pd;$r.PendingFirstReboot=Get-SkPendingBoot;$r.InstalledSetVerified=$r.SelectedSet.Complete -and !$r.PendingFirstReboot}
 $pointer=Join-Path (Get-SkPeerBase) 'latest-backup.json'
 if(Test-Path -LiteralPath $pointer){$previous=Assert-SkCommunityBackup ((Get-Content -LiteralPath $pointer -Raw | ConvertFrom-Json).Path);$r.PreviousSet=Get-SkRestoreCompletion $previous $selected $pd}
}catch{$r.Errors+=$_.Exception.Message}
try{
 $r.SelectedPackageFiles=@(foreach($d in $devices){
  try{
   $found=Find-SkSelectedPackage $d;$names=Get-SkFileNames $found.Identity
   $relative='selected-packages\'+$d.Service
   New-Item -ItemType Directory -Path (Join-Path $root $relative) -Force | Out-Null
   $files=@(foreach($name in @($names.Inf,$names.Sys,$names.Cat)){
    $from=Join-Path $found.Folder $name;$to=Join-Path $root ($relative+'\'+$name)
    $hash=(Get-SkFileHash -LiteralPath $from).Hash;Copy-Item -LiteralPath $from -Destination $to
    if((Get-SkFileHash -LiteralPath $to).Hash -ine $hash){throw 'Diagnostic copy hash mismatch'}
    $sig=if($name -match '\.(sys|cat)$'){Get-AuthenticodeSignature -LiteralPath $from}else{$null}
    [pscustomobject]@{Name=$name;Bytes=(Get-Item -LiteralPath $to).Length;SHA256=$hash;SignatureStatus=[string]$sig.Status;Signer=$sig.SignerCertificate.Thumbprint}
   })
   [pscustomobject]@{Service=$d.Service;RelativePath=$relative;InfName=$names.Inf;SysName=$names.Sys;CatName=$names.Cat;Files=$files;ExportOnly=$true}
  }catch{[pscustomobject]@{Service=$d.Service;Error=$_.Exception.Message;ExportOnly=$true}}
 })
}catch{$r.Errors+=$_.Exception.Message}
try{Initialize-SkNative;$r.ActiveTestSigning=[SkCommunityNative]::TestSigning()}catch{$r.Errors+=$_.Exception.Message}
try{$r.Support=@(Get-SkSupportingHashes);$r.ClassExtensions=@(foreach($name in @('UcmCx.sys','UcmTcpciCx.sys','Wdf01000.sys')){$path=Join-Path $env:SystemRoot ('System32\drivers\'+$name);[pscustomobject]@{Name=$name;SHA256=(Get-SkFileHash -LiteralPath $path).Hash;Version=(Get-Item -LiteralPath $path).VersionInfo.FileVersion}})}catch{$r.Errors+=$_.Exception.Message}
try{
 if(!('SkCommunityBattery' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'BatteryTelemetry.cs')}
 $r.Battery=@([SkCommunityBattery]::Read())
 if($Seconds){$clock=[Diagnostics.Stopwatch]::StartNew();while($clock.Elapsed.TotalSeconds -lt $Seconds){[pscustomobject]@{At=(Get-Date).ToString('o');Battery=@([SkCommunityBattery]::Read())} | ConvertTo-Json -Depth 6 -Compress | Add-Content -LiteralPath (Join-Path $root 'battery-samples.jsonl') -Encoding utf8;Start-Sleep -Seconds 5}}
}catch{$r.Errors+=$_.Exception.Message}
try{$r.USB=@(Get-CimInstance Win32_PnPEntity -Filter 'Present=True' | Where-Object {$_.PNPDeviceID -like 'USB*'} | Select-Object Name,Service,PNPDeviceID,ConfigManagerErrorCode);$r.Disks=@(Get-CimInstance Win32_DiskDrive | Select-Object Model,InterfaceType,Status)}catch{$r.Errors+=$_.Exception.Message}
try{
 $installed=Get-SkPeerBase
 if(Test-Path -LiteralPath $installed){
  $records=@(Get-ChildItem -LiteralPath $installed -Filter result.json -Recurse -File | Sort-Object LastWriteTime -Descending | Select-Object -First 4)
  $r.InstallationRecords=@(foreach($file in $records){Get-Content -LiteralPath $file.FullName -Raw | ConvertFrom-Json})
 }
 $setup=Join-Path $env:SystemRoot 'INF\setupapi.dev.log'
 if(Test-Path -LiteralPath $setup){Select-String -LiteralPath $setup -Pattern 'qcpmicext8150|qcpmictcc8150|qcusbctcpm8150|qcbattmngr8150|battminiclass|skpdprofile' -Context 5,10 | Select-Object -Last 30 | Out-String -Width 240 | Set-Content -LiteralPath (Join-Path $root 'charging-setupapi.txt') -Encoding utf8}
}catch{$r.Errors+=$_.Exception.Message}
try {
 $events=@(Get-WinEvent -FilterHashtable @{LogName='System';StartTime=(Get-Date).AddMinutes(-30)} -MaxEvents 1000 -ErrorAction Stop | Where-Object ProviderName -Match 'PnP|USB|Kernel-Power|Disk|WHEA|BugCheck' | Select-Object TimeCreated,Id,LevelDisplayName,ProviderName,Message)
 ConvertTo-Json -InputObject $events -Depth 6 | Set-Content -LiteralPath (Join-Path $root 'events.json') -Encoding utf8
 $r.EventLogStatus='Collected'
}catch {
 if($_.FullyQualifiedErrorId -like 'NoMatchingEventsFound*'){
  '[]' | Set-Content -LiteralPath (Join-Path $root 'events.json') -Encoding utf8
  $r.EventLogStatus='NoRecentEvents'
 }else{$r.EventLogStatus='CollectionFailed';$r.Errors+=$_.Exception.Message}
}
foreach($failed in @($r.SelectedPackageFiles | Where-Object Error)){$r.Errors+=($failed.Service+': '+$failed.Error)}
$r | ConvertTo-Json -Depth 22 | Set-Content -LiteralPath (Join-Path $root 'diagnostic.json') -Encoding utf8
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=$root+'.zip';[IO.Compression.ZipFile]::CreateFromDirectory($root,$zip)
Write-Host ('Diagnostic archive: '+$zip)
if($r.InstalledSetVerified){Write-Host 'Installed complete charging driver set: VERIFIED.' -ForegroundColor Green}else{Write-Warning 'Installed complete charging driver set: NOT VERIFIED. Read diagnostic.json and installation records.'}
Write-Host 'No report is uploaded. Review device identifiers and paths before sharing.'
[pscustomobject]@{DiagnosticArchive=$zip;Report=(Join-Path $root 'diagnostic.json');InstalledSetVerified=$r.InstalledSetVerified;Errors=$r.Errors;HardwareChanged=$false}
