# Xiaomi Pad 5 charging drivers — 1871-HQ2-U4

[Русский](README.ru.md) · [Project](https://github.com/deskcj/xiaomi-pad5-windows11-charging)


U4 also fixes the actual CMD diagnostic launch: file hashes use .NET SHA256 without relying on PowerShell module autoload. An empty recent event log is handled normally, and failed selected-package exports are listed in the diagnostic summary. Driver binaries are unchanged from U3/U2.

This package contains the **1871-HQ2 drivers currently working on the project tablet**, with a complete-set installer, verification, backup and diagnostics. It is for **Xiaomi Pad 5 / nabu, Windows 11 ARM64**, with existing compatible nabu base drivers and active Test Mode.

Compared with the public 1869-PD013-U1 package, the PMIC extension is updated to **1.0.1871.0**. **U3 contains exactly the same SYS files as U2.** It updates the installer to recognize one audited source set with qcpmicext **23.5.57.553**, and updates the PMIC INF date and signed catalog. Unknown higher-version sets still stop installation. An already installed, fully verified U3 set needs no Administrator prompt or repeat installation.

The PMIC INF date is **11/04/2026**, one day newer than the recognized source INF. Windows uses date and version to choose between equally ranked packages; merely removing the numeric version check would not ensure that the intended package is selected. U3 keeps deferred installation of the complete set and does not request a forced live upgrade. **The transition from the recognized 23.5 set still needs verification on hardware.**

## Install

1. Extract the **entire archive to the internal Windows drive**, for example `C:\Xiaomi-Pad5-Charging`. Do not run inside the ZIP or from the USB drive being tested.
2. Double-click **Install.cmd**. Allow the Administrator prompt if an update is needed. **Active Test Mode is required**; this installer does not enable it or change Secure Boot/BCD.
3. If the result is **PendingReboot**, save work, safely eject USB storage, unplug USB-C devices and reboot **once**. The installer never reboots automatically. PendingReboot means Windows accepted deferred installation; it does not mean the new drivers are active.
4. Run **Verify.cmd** after Windows loads and wait for **PASS**. If Install reports **Verified** because the exact set was already active, no additional reboot is needed.
5. Test a directly connected SSD or OTG device, safely eject and disconnect it, then connect a charger directly. Repeat charger → OTG → charger. If a connection fails, run **Diagnose.cmd** and share its ZIP after reviewing the contents.

No Python, SDK, EWDK or manual Device Manager installation is needed. `cmd.bat` also opens Install. **Check.cmd** checks compatibility and package integrity without installing drivers.

## Included drivers

| Component | Version | Installation |
|---|---|---|
| PMIC extension | 1.0.1871.0 | Install |
| Type-C backend | 1.0.1867.0 | Install |
| USB-C client | 1.0.1853.0 | Install |
| Battery manager | 1.0.10732.0 | Install |
| Fixed PD filter | 0.1.3.0 | Install and configure mode 1 |
| Battery miniclass | Qualcomm 1680 or Xiaomi 10730 | Detect and preserve |

The installer discovers the actual hardware instances and selected INF/SYS/CAT filenames. Both audited battery-miniclass profiles are supported. The 23.5.57.553 migration requires exact identities for all five selected base INF/SYS pairs, their device bindings and three supporting transport drivers; matching the version number alone is insufficient. An unknown miniclass profile, unrecognized higher-version base set or unknown PD extension stops installation and can be investigated using Diagnose. This is a package for supported **nabu** configurations; compatibility with every modified Windows image is not established.

## Results and remaining work

- ✅ Direct charging and SSD/OTG switching have worked in recorded tests.
- ✅ Hub, SSD and charging work together; returning the PD charger resumes charging.
- ✅ The tested power bank, iPhone charger and Samsung charger deliver real battery charge.
- ✅ Samsung fixed USB-PD **9 V / 3 A** is confirmed. A sustained 1871 test measured about **13.8 W average net battery power**, reaching about **14.6 W**. The **27 W contract ceiling is not measured input or battery power**.
- ✅ A Xiaomi MDY-11-EZ charger test measured about **8.6 V at the USB input** and **16 W average net battery power**. Elevated input voltage and accelerated charging are supported by telemetry; this does not establish input current, protocol or full 33 W.
- ⚠️ Removing PD power from **Acer HY41-T9** still briefly disconnects and reconnects the SSD. This can interrupt disk access; avoid this transition during writes.
- ⏳ PPS and full **33 W** charging remain unconfirmed.
- ⏳ A speed or hub-continuity improvement over public 1869 has not been demonstrated. The newer PMIC handling does not resolve the remaining hub interruption.

To compare chargers, connect directly without a hub, use a battery level around 30–70%, similar temperature and load, and record at least five minutes. A charger label or Windows icon does not establish charging power. A suitable USB power meter can independently measure actual input voltage, current and power.

## Backup and diagnostics

Before an update, Install saves the exact selected charging/battery packages, recognized PD extensions and the previous USB-C opt-in under `%ProgramData%\SK-Charging-Community\...\Previous`. The unchanged miniclass is backed up for reference and is never installed or restored by this package. Copy hashes and INF bindings are checked before requesting installation.

**Restore.cmd** uses the latest backup. Run it only if a return to the previous set is needed after the installation reboot: safely eject and disconnect USB storage, run Restore and reboot manually. Restore can restart the USB stack. Unknown intervening driver changes and incomplete backups are refused.

**Diagnose.cmd** creates a ZIP under `%LOCALAPPDATA%\SK-Charging-Diagnostics`, containing OS/build, selected driver versions/hashes, installation records, USB/battery state and copies of the selected charging/battery INF/SYS/CAT files. It does not install or reset devices or upload the report. Review local paths and device identifiers before sharing.

The included certificate is a **public development certificate**; the installer adds it to LocalMachine Root and TrustedPublisher if needed. No private signing key is included.

## Validation and limitations

The project tablet completed its first manual reboot and **Verify.cmd passed** with all selected INF/SYS identities, Running/Code0 and the PD filter matching. Actual Install.cmd then verified the current set without requesting another installation; Diagnose.cmd also passed. The launcher explicitly loads the native Windows Security/Utility modules at global scope to avoid a first-launch module-autoload failure. Driver binaries and driver INF/CAT files are unchanged. This is installation verification on the project tablet; full33W/PPS, hub continuity, and compatibility with every community setup are not established. A separately installed NabuTypeC package can outrank the requested Type-C backend; do not treat a partial selected set as a successful upgrade.

See **VALIDATION.json**: 47 workflow scenarios, 44 migration checks, 12 launcher cases, 6 CMD bridge cases, 6 selected-backup cases, SHA256 regression with module autoload disabled, and 10 INF/SYS catalog membership checks passed. Upgrade and recovery scenarios use mocked Windows mutations. Actual **Check.cmd** and **Diagnose.cmd** passed on the project tablet; diagnostics exported all five selected INF/SYS/CAT packages without collection errors. The actual Install.cmd was accepted by Windows as a deferred complete-set installation. The previous complete set was backed up and the selected running drivers stayed unchanged. No new kernel driver was built. The recognized 23.5 migration has not been installed on hardware. **PASS verifies the selected installation, not charging speed or uninterrupted hub power.**

`manifest.json` pins the driver payload. `FILES-SHA256.json` lists the archive contents. These are experimental, test-signed drivers, supplied **as-is without warranty**. Keep backups and a recovery method. The project is independent of Xiaomi, Qualcomm and Microsoft. Third-party notices are preserved in [THIRD-PARTY-NOTICE.md](THIRD-PARTY-NOTICE.md).

## Support development

[DonationAlerts](https://www.donationalerts.com/r/deskcj) · [PayPal](https://paypal.me/vladcj)

You can also help by sharing reproducible results, charger models and Windows versions. Donations support research, not a guaranteed fix or delivery date.
