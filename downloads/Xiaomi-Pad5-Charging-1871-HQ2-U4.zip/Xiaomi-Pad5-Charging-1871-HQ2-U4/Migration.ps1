﻿# A known source set, not a general permission to replace newer drivers.
# All five selected INF/SYS identities must match, on the already discovered
# nabu hardware IDs. Underlying Qualcomm transport identities are checked too.
function Get-SkMigrationSourceIdentity {
    @(
        @{Service='qcpmicext';HardwareId='ACPI\QCOM05E5';Version='23.5.57.553';
          SHA256='E17D4C1B24D4331D5BD575CA9EA47FE598264B34246073D05536D29FC19060C4';
          InfSHA256='7CE5D55C73D49AC74E3D6AC8703B4DCF6B42061D8DCA5031171D7615A21FB8C0'},
        @{Service='qcpmictcc';HardwareId='ACPI\QCOM0582';Version='1.0.1680.0';
          SHA256='BE9850CE5AB8A9E5EAD615DE592FF8177154BDE9496320910210DC503B2B46E9';
          InfSHA256='A2186743C1D2385FAEAC584AD66E85FEBDE5685ABD2FA531598FA20FC4EF0E28'},
        @{Service='qcusbctcpm';HardwareId='ACPI\QCOM057D';Version='1.0.1680.0';
          SHA256='7C63F4A4B8A9EE0F49B427B6AC94867D2475E02F85D92D5FBCFE4A8AA1804067';
          InfSHA256='611A25FCFFFECDE9FD414F8FF5E8FABAF26B1C07DB7B8C40D0E7EA4AD6EBFC4C'},
        @{Service='qcbattmngr';HardwareId='ACPI\QCOM0531';Version='1.0.10730.0';
          SHA256='3659A20DE0606AA7283EA3197A1C212E28BFEC212C838914F19D74BE629453A3';
          InfSHA256='6D6CAB6DDC82D0CF02AB1F8930423F67C0F6BF786940D323995D131459943004'},
        @{Service='qcbattminiclass';HardwareId='ACPI\QCOM052D';Version='1.0.10730.0';
          SHA256='B78FBE26F1521B56F850876030A433883A99383ECD3A65D556CBC0BD120E9C4C';
          InfSHA256='355F15B86EBF2B3B715A99A4784809547125DCF540B8ED7860FDD6F4C329F6F5'}
    )
}

function Test-SkMigrationSource($Selected) {
    $expected=@(Get-SkMigrationSourceIdentity)
    if (@($Selected).Count -ne $expected.Count) { return $false }
    foreach ($source in $expected) {
        $found=@($Selected | Where-Object Service -eq $source.Service)
        if ($found.Count -ne 1) { return $false }
        $driver=$found[0]
        if ($driver.Version -ne $source.Version -or $driver.SHA256 -ine $source.SHA256 -or
            $driver.InfSHA256 -ine $source.InfSHA256 -or $driver.HardwareId -ine $source.HardwareId -or
            !$driver.InstanceId -or !$driver.InstanceId.StartsWith($source.HardwareId+'\',[StringComparison]::OrdinalIgnoreCase) -or
            $driver.PublishedInf -notmatch '^oem\d+\.inf$' -or $driver.State -ne 'Running' -or
            $null -eq $driver.Problem -or $driver.Problem -ne 0) { return $false }
    }
    return $true
}

function Test-SkMigrationSupport($Support) {
    $required=@{
        qcpep='39FAFCD60536C7D36DD95187DC9F51BFC4AF661B614BCE4A5E9EC0729FE24E01'
        qcspmi='203ED9CA47359E66B2F421739DBD9EC679D2C24B17EF4B5ECF176A96847D1B15'
        UrsSynopsys='F0F0E0BA825128402913276C897D33D7AA589B4F0923B63935D8C00EB92738C0'
    }
    foreach ($name in $required.Keys) {
        $found=@($Support | Where-Object Service -eq $name)
        if ($found.Count -ne 1 -or $found[0].SHA256 -ine $required[$name]) { return $false }
    }
    return $true
}

function Get-SkApprovedMigration($Manifest,$Selected,$Support) {
    if (!(Test-SkMigrationSource $Selected) -or !(Test-SkMigrationSupport $Support)) { return $null }
    $target=@($Manifest.Packages | Where-Object Service -eq 'qcpmicext')
    if ($target.Count -ne 1 -or $target[0].Version -ne '1.0.1871.0' -or $target[0].DriverDate -ne '11/04/2026') {
        throw 'Recognized source requires the dated1871 migration package; no driver installation was requested.'
    }
    [pscustomobject]@{Name='nabu-qcpmicext23557553-known-set';SourceVersion='23.5.57.553';TargetVersion='1.0.1871.0';
        SourceDriverDate='11/03/2026';TargetDriverDate='11/04/2026';
        ExactSourceINFAndSYSChecked=$true;RequiredTransportHashesChecked=$true;
        ForceInstallRequested=$false;InstallationMethod='Deferred complete set, flags0x40'}
}
