﻿# Read-only completion check. A successful staging call is not this result.
function Get-SkSetCompletion($Manifest,$Selected) {
 $references=@($Manifest.Reference | Where-Object {$null -ne $_})
 if($references.Count -gt 1){
  $profile=Get-SkCompatibleReference $Manifest $Selected
  $references=if($profile){@($profile)}else{@($references[0])}
 }
 $targets=@($Manifest.Packages)+$references
 if(!$targets.Count){throw 'No required driver set in manifest'}
 $seen=@{};$rows=@()
 foreach($p in $targets){
  if(!$p.Service -or $seen.ContainsKey($p.Service)){throw 'Duplicate or unnamed required service'}
  $seen[$p.Service]=$true
  $roles=Get-SkFileNames $p
  $sys=@($p.Files | Where-Object Name -EQ $roles.Sys)
  $inf=@($p.Files | Where-Object Name -EQ $roles.Inf)
  if($sys.Count -ne 1 -or $sys[0].SHA256 -notmatch '^[0-9a-fA-F]{64}$'){throw 'Required SYS identity is missing'}
  if($inf.Count -ne 1 -or $inf[0].SHA256 -notmatch '^[0-9a-fA-F]{64}$'){throw 'Required INF identity is missing'}
  $matches=@($Selected | Where-Object Service -EQ $p.Service)
  $unique=$matches.Count -eq 1
  $version=$false;$hash=$false;$running=$false;$healthy=$false;$infHash=$false;$binding=$false
  if($unique){
   $current=$matches[0]
   [version]$selectedVersion=$null
   $version=([version]::TryParse([string]$current.Version,[ref]$selectedVersion) -and $selectedVersion -eq [version]$p.Version)
   $hash=$current.SHA256 -ieq $sys[0].SHA256
   $infHash=$current.InfSHA256 -ieq $inf[0].SHA256
   $binding=$current.HardwareId -ieq $p.HardwareId -and $current.InstanceId -and $current.PublishedInf
   $running=$current.State -eq 'Running'
   # Missing Code is unknown, not Code0.
   $healthy=$null -ne $current.Problem -and $current.Problem -eq 0
  }
  $rows+=[pscustomobject]@{Service=$p.Service;UniqueSelectedDevice=$unique;HardwareBindingMatches=[bool]$binding;VersionMatches=$version;SHA256Matches=$hash;InfSHA256Matches=$infHash;Running=$running;ProblemCodeZero=$healthy;Complete=($unique -and $binding -and $version -and $hash -and $infHash -and $running -and $healthy)}
 }
 $complete=@($rows | Where-Object Complete -NE $true).Count -eq 0
 [pscustomobject]@{Complete=$complete;Status=$(if($complete){'Verified'}else{'NotVerified'});Rows=$rows;DriverInstallCalled=$false;HardwarePowerProven=$false}
}
