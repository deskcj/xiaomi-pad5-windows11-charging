using System;
using System.Runtime.InteropServices;
using System.ComponentModel;
public static class SkPeerPdMode {
 [StructLayout(LayoutKind.Sequential)] struct Info { public uint cb;public Guid cls;public uint inst;public UIntPtr reserved; }
 [DllImport("setupapi.dll",SetLastError=true)] static extern IntPtr SetupDiCreateDeviceInfoList(IntPtr cls,IntPtr wnd);
 [DllImport("setupapi.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool SetupDiOpenDeviceInfoW(IntPtr set,string id,IntPtr wnd,uint flags,ref Info info);
 [DllImport("setupapi.dll",SetLastError=true)] static extern IntPtr SetupDiOpenDevRegKey(IntPtr set,ref Info info,uint scope,uint profile,uint type,uint access);
 [DllImport("setupapi.dll")] static extern bool SetupDiDestroyDeviceInfoList(IntPtr set);
 [DllImport("advapi32.dll",CharSet=CharSet.Unicode)] static extern int RegQueryValueExW(IntPtr key,string name,IntPtr reserved,out uint type,byte[] data,ref uint n);
 [DllImport("advapi32.dll",CharSet=CharSet.Unicode)] static extern int RegSetValueExW(IntPtr key,string name,uint reserved,uint type,byte[] data,uint n);
 [DllImport("advapi32.dll",CharSet=CharSet.Unicode)] static extern int RegDeleteValueW(IntPtr key,string name);
 [DllImport("advapi32.dll")] static extern int RegCloseKey(IntPtr key);
 const string Name="SkExperimentalFixed9V3A";
 static IntPtr Open(string id,out IntPtr set,bool write) {
  if(id==null || !id.StartsWith(@"ACPI\QCOM057D\",StringComparison.OrdinalIgnoreCase)) throw new ArgumentException("Only the discovered QCOM057D instance is allowed");
  set=SetupDiCreateDeviceInfoList(IntPtr.Zero,IntPtr.Zero);
  if(set==new IntPtr(-1)) throw new Win32Exception(Marshal.GetLastWin32Error());
  try {
   Info info=new Info();info.cb=(uint)Marshal.SizeOf(typeof(Info));
   if(!SetupDiOpenDeviceInfoW(set,id,IntPtr.Zero,0,ref info)) throw new Win32Exception(Marshal.GetLastWin32Error());
   IntPtr key=SetupDiOpenDevRegKey(set,ref info,1,0,1,write?3u:1u);
   if(key==new IntPtr(-1)) throw new Win32Exception(Marshal.GetLastWin32Error());return key;
  }catch{SetupDiDestroyDeviceInfoList(set);throw;}
 }
 public static long Read(string id) {
  IntPtr set;IntPtr key=Open(id,out set,false);
  try {uint type,n=4;byte[] data=new byte[4];int s=RegQueryValueExW(key,Name,IntPtr.Zero,out type,data,ref n);
   if(s==2)return -1;if(s!=0)throw new Win32Exception(s);
   if(type!=4||n!=4)throw new InvalidOperationException("Unexpected opt-in registry type");
   return BitConverter.ToUInt32(data,0);
  }finally{RegCloseKey(key);SetupDiDestroyDeviceInfoList(set);}
 }
 public static void Set(string id,long value) {
  if(value!=-1&&value!=0&&value!=1)throw new ArgumentOutOfRangeException("value");
  IntPtr set;IntPtr key=Open(id,out set,true);
  try {int s=value==-1?RegDeleteValueW(key,Name):RegSetValueExW(key,Name,0,4,BitConverter.GetBytes((uint)value),4);
   if(s!=0&&!(value==-1&&s==2))throw new Win32Exception(s);
  }finally{RegCloseKey(key);SetupDiDestroyDeviceInfoList(set);}
 }
}
