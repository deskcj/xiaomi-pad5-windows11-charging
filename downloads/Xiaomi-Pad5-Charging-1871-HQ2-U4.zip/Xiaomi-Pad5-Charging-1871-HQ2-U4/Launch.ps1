﻿param([ValidateSet('Install','Diagnose','Restore','Verify','Check')][string]$Action='Install',
      [switch]$NonInteractive)
$ErrorActionPreference='Stop'
$transcript=$null
try {
    $logRoot=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'SK-Charging-Launcher'
    New-Item -ItemType Directory -Path $logRoot -Force | Out-Null
    $transcript=Join-Path $logRoot ($Action+'-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N')+'.txt')
    Start-Transcript -LiteralPath $transcript | Out-Null
}catch {Write-Warning ('Cannot save launcher log: '+$_.Exception.Message)}
$code=1
try {
    # Import the inbox modules at global scope before calling child scripts.
    # First-launch command autoload can otherwise lose Security cmdlets in scope.
    foreach($moduleName in @('Microsoft.PowerShell.Utility','Microsoft.PowerShell.Security')){
        $modulePath=Join-Path $env:SystemRoot ('System32\WindowsPowerShell\v1.0\Modules\'+$moduleName+'\'+$moduleName+'.psd1')
        Import-Module -Name $modulePath -Global -ErrorAction Stop
    }
    $admin=([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    $needsAdmin=$Action -in @('Install','Restore')
    if($Action -eq 'Install' -and !$admin){
        # A fully matching, active set can be verified without requesting elevation.
        # Preflight failure stops here; it must never be treated as a valid no-op.
        $probe=& (Join-Path $PSScriptRoot 'Install.ps1') -CheckOnly
        $needsAdmin=!$probe.InstalledSetVerified
    }
    if($needsAdmin -and !$admin){
        if($NonInteractive){throw 'Driver changes require Administrator rights. Run Install.cmd interactively and allow its Administrator prompt.'}
        $shell=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
        # This is the user's interactive installer console, not a background helper.
        $process=Start-Process -FilePath $shell -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$PSCommandPath+'"'),'-Action',$Action) -Verb RunAs -WindowStyle Normal -Wait -PassThru
        $code=$process.ExitCode
    }else {
        if($Action -eq 'Diagnose'){& (Join-Path $PSScriptRoot 'Diagnose.ps1') | Format-List}
        elseif($Action -eq 'Verify'){& (Join-Path $PSScriptRoot 'Verify.ps1') | Format-List}
        elseif($Action -eq 'Check'){& (Join-Path $PSScriptRoot 'Install.ps1') -CheckOnly | Format-List}
        elseif($Action -eq 'Restore'){& (Join-Path $PSScriptRoot 'Install.ps1') -Restore | Format-List}
        else {& (Join-Path $PSScriptRoot 'Install.ps1') | Format-List}
        $code=0
    }
}catch {
    Write-Host ('Action failed or Administrator launch was cancelled: '+$_.Exception.Message) -ForegroundColor Red
    $code=1
}finally {
    if($transcript){Write-Host ('Launcher log: '+$transcript);Stop-Transcript | Out-Null}
}
if(!$NonInteractive){$null=Read-Host 'Press Enter to close'}
exit $code
